"""Isolated image-map checks; never generates or approves production artwork."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from PIL import Image
import embroidery_region_map as mapping
import embroidery_layout as layout
import production_profiles as profiles


class RegionMapTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = Path(self.temp.name)
        self.e = {'ROOT': Path(__file__).resolve().parents[1], 'STORE': self.store,
                  'read': lambda p: json.loads(Path(p).read_text(encoding='utf8')),
                  'scoped': Path, 'sha': lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()}
        self.profile = layout.load(self.e)

    def asset(self, name, color, size=(100,100)):
        file = self.store / (name + '.png')
        Image.new('RGB',size,color).save(file)
        return {'path': str(file), 'sha256': self.e['sha'](file)}

    def test_exact_motifs_map_to_wearer_sides_and_same_unmirrored_sleeves(self):
        regions = {'left_chest': self.asset('chest','red'), 'left_sleeve': self.asset('sleeve','blue',(40,160))}
        regions['right_sleeve'] = regions['left_sleeve']
        for style in ('crewneck sweatshirt','hoodie','quarter-zip pullover'):
            ref = mapping.reference(self.profile,style,regions,False,self.e)
            self.assertEqual(ref['mapped_regions'],sorted(regions))
            with Image.open(ref['path']) as im:
                cy = 380 if style=='crewneck sweatshirt' else 465
                self.assertEqual(im.getpixel((730,cy)),(255,0,0))
                self.assertEqual(im.getpixel((240,800)),(0,0,255))
                self.assertEqual(im.getpixel((960,800)),(0,0,255))
            self.assertEqual(mapping.reference(self.profile,style,regions,False,self.e),ref)

    def test_front_back_filtering_blank_sleeves_and_source_hash_guards(self):
        regions = {'left_chest': self.asset('chest','red'), 'back': self.asset('back','green')}
        front = mapping.reference(self.profile,'crewneck sweatshirt',regions,False,self.e)
        rear = mapping.reference(self.profile,'crewneck sweatshirt',regions,True,self.e)
        self.assertEqual(front['mapped_regions'],['left_chest'])
        self.assertEqual(rear['mapped_regions'],['back'])
        self.assertNotEqual(front['sha256'],rear['sha256'])
        with Image.open(rear['path']) as im:
            self.assertEqual(im.getpixel((600,450)),(0,128,0))
            self.assertEqual(im.getpixel((240,800)),(237,237,237))
        regions['left_chest']['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'hash changed'):
            mapping.reference(self.profile,'crewneck sweatshirt',regions,False,self.e)

    def test_mockup_manifest_uses_original_sources_and_sample_placement(self):
        refs=[{'sha256':'a'*64,'regions':['left_chest']},
              {'sha256':'b'*64,'regions':['left_sleeve','right_sleeve']},
              {'role':'same_listing_layout_anchor'}]
        prompt=profiles.reference_manifest(refs)
        self.assertIn('Image 1: COMPLETE approved embroidery for left_chest ONLY',prompt)
        self.assertIn('Image 2: COMPLETE approved embroidery for left_sleeve, right_sleeve ONLY',prompt)
        self.assertIn('same-listing product photo for artwork placement, relative scale and continuity ONLY',prompt)
        self.assertNotIn('HIGHEST PRIORITY POSITION AUTHORITY',prompt)
        self.assertNotIn('SAME-LISTING VISUAL REGION MAP',prompt)


if __name__=='__main__':
    unittest.main(verbosity=2)
