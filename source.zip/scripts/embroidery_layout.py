"""Versioned design-free guides and lossless portrait normalization inside n8n."""
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw

VERSION = 'shared-guides-v1'
REGIONS = ('center_chest', 'left_chest', 'right_chest', 'left_sleeve', 'back')


class SleeveCanvasRejected(ValueError):
    """The acquired image needs recomposition, never repeated attachment or clipping."""

GUIDANCE = ('This reference is a DESIGN-FREE LAYOUT GUIDE, not artwork. Use its orientation and safe area only. '
            'Never reproduce its guide lines, colored rectangle, silhouette, labels or background panel. '
            'Create this brief\'s own scene; do not add a patch backing, enclosing border or extra copy.')
SLEEVE = ('WORKING ARTBOARD: HEIGHT:WIDTH 26:7, equivalently WIDTH:HEIGHT 7:26. '
          'One complete connected vertical scene, one shared sleeve artwork only, never a pair or mirror. '
          'Compose natively for the narrow upright artboard; preserve natural character proportions. '
          'The generator transport canvas is 9:16: leave ONLY clean white side margins outside the centered 7:26 artboard. '
          'The complete scene must occupy ONLY the central 44 percent of the transport image width; leave at least 28 percent pure white on EACH side. '
          'The workflow removes those empty margins before review; do not put any artwork, labels or guides there. '
          'Keep all content and a clear safety margin inside the artboard. No square/horizontal scene, stretching or cropped details. '
          'Construct every object from flat solid-color filled shapes, as in cut-paper illustration, never a stroked line drawing. '
          'Object silhouettes must meet the white background directly with their fill color; do not trace their edges in black or another color. '
          'Short essential details may be drawn strictly inside a filled object, never along its outside edge. '
          'Do not draw the guide rectangle, any vertical side rails, panels or framing lines. ')


def digest(data):
    return hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def validate(profile, e):
    if profile.get('version') != VERSION or profile.get('fingerprint') != digest({k: v for k, v in profile.items() if k != 'fingerprint'}):
        raise ValueError('Embroidery guide profile changed')
    base = (e['ROOT'] / 'config/embroidery-guides' / VERSION).resolve()
    for ref in list(profile['design'].values()) + list(profile['placement'].values()):
        file = e['scoped'](ref['path'])
        if not file.resolve().is_relative_to(base) or e['sha'](file) != ref['sha256']:
            raise ValueError('Embroidery guide file or hash changed')
    return profile


def load(e):
    return validate(e['read'](e['ROOT'] / 'config/embroidery-layout-standard.json'), e)


def design(profile, region):
    return profile['design']['left_sleeve' if region == 'right_sleeve' else region]


def canvas_policy(e):
    policy = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json').get('sleeve_canvas_policy')
    if policy and (policy.get('mode') != 'keep_native_canvas' or policy.get('flow_aspect_ratio') not in ('9:16', '16:9')
                   or policy.get('authority') != 'direct_user' or not policy.get('reference')):
        raise ValueError('Unknown sleeve canvas policy')
    return policy


def output_ratio_ok(width, height, ratio, e):
    if ratio == '7:26' and canvas_policy(e):
        return any(ratio_ok(width, height, value) for value in ('7:26', '9:16', '16:9'))
    return ratio_ok(width, height, ratio)


def sleeve_transport(e):
    """Show the narrow working zone in the actual generator canvas, avoiding fit-to-width."""
    policy = canvas_policy(e)
    landscape = policy and policy['flow_aspect_ratio'] == '16:9'
    image = Image.new('RGB', (1600, 900) if landscape else (900, 1600), 'white')
    # Visible guide strokes were copied into generated sleeves; retain only the pale safe-area fill.
    ImageDraw.Draw(image).rectangle((697, 70, 902, 830) if landscape else (265, 114, 635, 1486), fill='#f2f5f7')
    file = e['ROOT'] / 'config/embroidery-guides' / VERSION / ('left-sleeve-transport-16x9-v1.png' if landscape else 'left-sleeve-transport-9x16-v2.png')
    if file.exists():
        with Image.open(file) as old:
            if old.size != image.size or old.convert('RGB').tobytes() != image.tobytes():
                raise ValueError('Versioned sleeve transport guide changed')
    else:
        file.parent.mkdir(parents=True, exist_ok=True)
        image.save(file, format='PNG')
    return {'path': str(file), 'sha256': e['sha'](file), 'role': 'design_free_composition_guide'}


def placement(profile, style, regions, back=False):
    chest = 'back' if back else 'left_right' if 'right_chest' in regions else 'left' if 'left_chest' in regions else 'center' if 'center_chest' in regions else 'none'
    return profile['placement'][style + '|' + chest + '|' + str(int('left_sleeve' in regions))]


def folded_guide(style, e):
    """Clean geometric fold reference; no product design, lettering or personalization."""
    if style not in ('crewneck sweatshirt', 'hoodie', 'quarter-zip pullover'):
        raise ValueError('Unknown folded garment style')
    image = Image.new('RGB', (1200, 1200), 'white')
    draw = ImageDraw.Draw(image)
    fill, line = '#e7e7e7', '#9a9a9a'
    draw.rounded_rectangle((290, 175, 910, 1035), 65, fill=fill, outline=line, width=5)
    if style == 'hoodie':
        draw.ellipse((380, 60, 820, 365), fill=fill, outline=line, width=5)
        draw.ellipse((455, 115, 745, 285), fill='white', outline=line, width=4)
    else:
        draw.arc((450, 80, 750, 305), 0, 180, fill=line, width=12)
    if style == 'quarter-zip pullover':
        draw.line((600, 210, 600, 470), fill=line, width=8)
    for points, cuff in (
        ([(265, 280), (115, 505), (210, 980), (390, 940), (300, 520), (345, 365)], (210, 920, 395, 1000)),
        ([(935, 280), (1085, 505), (990, 980), (810, 940), (900, 520), (855, 365)], (805, 920, 990, 1000)),
    ):
        draw.polygon(points, fill=fill, outline=line, width=5)
        draw.rounded_rectangle(cuff, 12, fill='#d7d7d7', outline=line, width=4)
    file = e['ROOT'] / 'config/embroidery-guides' / VERSION / (style.replace(' ', '-') + '-folded-blank-v1.png')
    if not file.exists():
        file.parent.mkdir(parents=True, exist_ok=True)
        image.save(file, format='PNG')
    else:
        with Image.open(file) as old:
            if old.size != image.size or old.convert('RGB').tobytes() != image.tobytes():
                raise ValueError('Versioned blank fold guide changed')
    return {'path': str(file), 'sha256': e['sha'](file), 'role': 'design_free_fold_guide'}


def ratio_ok(width, height, ratio):
    w, h = map(int, ratio.split(':'))
    return width * h == height * w if ratio in ('7:26', '1:1') else abs((width / height) / (w / h) - 1) <= .02


def normalize(asset, e):
    """Keep the downloaded original. Crop only verified empty white margins; never resize."""
    raw = e['scoped'](asset['path'])
    if e['sha'](raw) != asset['sha256']:
        raise ValueError('Sleeve source hash changed')
    with Image.open(raw) as source:
        rgb = source.convert('RGB')
    policy = canvas_policy(e)
    if policy:
        if not output_ratio_ok(rgb.width, rgb.height, '7:26', e):
            raise ValueError('Sleeve native canvas must be 16:9, 9:16 or an existing 7:26 source')
        diff = ImageChops.difference(rgb, Image.new('RGB', rgb.size, 'white'))
        if not ImageChops.lighter(ImageChops.lighter(*diff.split()[:2]), diff.split()[2]).point(lambda x: 255 if x > 7 else 0).getbbox():
            raise SleeveCanvasRejected('Sleeve design is blank')
        return dict(asset), {'operation': 'preserve_native_canvas', 'policy': policy, 'original': dict(asset),
                             'normalized': dict(asset), 'raw_size': list(rgb.size), 'output_size': list(rgb.size),
                             'cropped': False, 'resized': False}
    if ratio_ok(rgb.width, rgb.height, '7:26'):
        return dict(asset), None
    if not ratio_ok(rgb.width, rgb.height, '9:16'):
        raise ValueError('Sleeve generator canvas must be portrait 9:16 before normalization')
    diff = ImageChops.difference(rgb, Image.new('RGB', rgb.size, 'white'))
    mask = ImageChops.lighter(ImageChops.lighter(*diff.split()[:2]), diff.split()[2]).point(lambda x: 255 if x > 7 else 0)
    bounds = mask.getbbox()
    if not bounds:
        raise SleeveCanvasRejected('Sleeve design is blank')
    multiple = rgb.height // 26
    if not multiple:
        raise ValueError('Sleeve source is too small')
    width, height = 7 * multiple, 26 * multiple
    if bounds[2] - bounds[0] > width or bounds[3] - bounds[1] > height:
        raise SleeveCanvasRejected('Sleeve scene exceeds the 7:26 artboard; revise composition, never stretch or clip it')
    left = max(0, min(rgb.width - width, (bounds[0] + bounds[2] - width) // 2))
    top = max(0, min(rgb.height - height, (bounds[1] + bounds[3] - height) // 2))
    box = (left, top, left + width, top + height)
    if not (box[0] <= bounds[0] and box[1] <= bounds[1] and box[2] >= bounds[2] and box[3] >= bounds[3]):
        raise SleeveCanvasRejected('Sleeve normalization would cut artwork')
    cropped = rgb.crop(box)
    target = raw.with_name(raw.stem + '-7x26.png')
    if target.exists():
        with Image.open(target) as existing:
            if existing.size != cropped.size or existing.convert('RGB').tobytes() != cropped.tobytes():
                raise ValueError('Sleeve normalized file changed; preserve both versions')
    else:
        cropped.save(target, format='PNG')
    result = {'path': str(target), 'sha256': e['sha'](target)}
    return result, {'operation': 'white_margin_crop_only', 'original': dict(asset), 'normalized': result, 'crop_box': list(box),
                    'raw_size': list(rgb.size), 'output_size': list(cropped.size), 'output_aspect_ratio': '7:26', 'resized': False}


def build(root):
    """Geometric engineering references, containing no generated product artwork."""
    directory = root / 'config/embroidery-guides' / VERSION
    directory.mkdir(parents=True, exist_ok=True)
    profile = {'version': VERSION, 'design': {}, 'placement': {},
               'sleeve_output_aspect_ratio': '7:26', 'sleeve_generation_aspect_ratio': '9:16',
               'placement_rule': 'Both outer sleeves use the identical unmirrored artwork, upright along the sleeve axis, at the same garment-relative height. Bottom remains above the ribbed cuff. Never move the design into an upper-arm badge. Other regions follow the visible selected zones; unselected zones stay blank.'}
    def save(name, image, role):
        file = directory / name
        if file.exists():
            with Image.open(file) as old:
                if old.size != image.size or old.convert('RGB').tobytes() != image.convert('RGB').tobytes():
                    raise ValueError('Versioned guide already exists with different pixels')
        else:
            image.save(file, format='PNG')
        return {'path': str(file), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'role': role}
    for region in REGIONS:
        size = (700, 2600) if region == 'left_sleeve' else (700, 700)
        image = Image.new('RGB', size, 'white'); draw = ImageDraw.Draw(image)
        pad = tuple(round(n * .06) for n in size)
        draw.rectangle((pad[0], pad[1], size[0] - pad[0] - 1, size[1] - pad[1] - 1), fill='#f2f5f7', outline='#8c9fae', width=3)
        profile['design'][region] = save(region + '.png', image, 'design_free_composition_guide')
    silhouette = [(152,33),(174,49),(200,54),(226,49),(248,33),(302,64),(350,100),(350,320),(300,320),(288,145),(285,350),(115,350),(112,145),(100,320),(50,320),(50,100),(98,64)]
    for style in ('crewneck sweatshirt', 'hoodie', 'quarter-zip pullover'):
        for chest, sleeves in ((chest, sleeves) for chest in ('none', 'center', 'left', 'left_right', 'back') for sleeves in (False, True)):
            face = 'back' if chest == 'back' else 'front'
            image = Image.new('RGB', (1200, 1200), 'white'); draw = ImageDraw.Draw(image)
            scale = lambda points: [(round(x * 3), round(y * 3 + 20)) for x, y in points]
            draw.polygon(scale(silhouette), fill='#ededed', outline='#8b8b8b', width=3)
            for line in [[(50,305),(101,305)],[(299,305),(350,305)],[(115,336),(285,336)]]:
                draw.line(scale(line), fill='#999999', width=3)
            center_y = 110 if style == 'crewneck sweatshirt' else 144
            zones = [(62,166,97,296),(303,166,338,296)] if sleeves else []
            if face == 'back':
                y = 99 if style == 'crewneck sweatshirt' else 145; zones += [(150,y,250,y+100)]
            else:
                if chest == 'center': zones += [(153,center_y,247,center_y+94)]
                if chest in ('left', 'left_right'): zones += [(227,104 if style=='crewneck sweatshirt' else 132,259,136 if style=='crewneck sweatshirt' else 164)]
                if chest == 'left_right': zones += [(125,104 if style=='crewneck sweatshirt' else 144,207,186 if style=='crewneck sweatshirt' else 226)]
                if style == 'quarter-zip pullover': draw.line(scale([(200,46),(200,120)]), fill='#777777', width=6)
                if style == 'hoodie': draw.rectangle((420,800,780,965), outline='#aaaaaa', width=3)
            for x1,y1,x2,y2 in zones:
                box=scale([(x1,y1),(x2,y2)]); draw.rectangle((box[0][0],box[0][1],box[1][0],box[1][1]),outline='#718da0',width=4)
            name=style.replace(' ','-')+'-'+chest+'-'+str(int(sleeves))+'.png'
            profile['placement'][style+'|'+chest+'|'+str(int(sleeves))] = save(name,image,'design_free_placement_guide')
    profile['fingerprint'] = digest(profile)
    file = root / 'config/embroidery-layout-standard.json'
    file.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding='utf-8')
    return profile


if __name__ == '__main__':
    result=build(Path(__file__).resolve().parents[1])
    print(json.dumps({'version': result['version'], 'design_guides': len(result['design']), 'placement_guides': len(result['placement'])}))
