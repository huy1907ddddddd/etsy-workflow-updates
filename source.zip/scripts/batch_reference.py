"""A single immutable batch reference; approved artwork always takes precedence."""
from pathlib import Path
from PIL import Image

GUIDANCE = ('The batch reference is visual guidance for style, finish and presentation only. '
            'Follow this item\'s own brief, text, motif counts and selected positions. '
            'Do not copy unrelated motifs, models, names, logos, backgrounds or exterior outlines. '
            'Exact human-approved artwork and sample references take precedence over this supporting image.')


def validate(asset, e):
    if not isinstance(asset, dict) or set(asset) != {'path', 'sha256', 'role'} or asset['role'] != 'batch_style_reference':
        raise ValueError('Invalid batch reference descriptor')
    file = e['scoped'](asset['path'])
    root = (e['STORE'] / 'batch-references').resolve()
    if not file.resolve().is_relative_to(root) or not file.is_file() or e['sha'](file) != asset['sha256']:
        raise ValueError('Batch reference file or hash changed')
    if file.stat().st_size > 10 * 1024 * 1024:
        raise ValueError('Batch reference exceeds 10 MB')
    with Image.open(file) as im:
        if im.format not in ('JPEG', 'PNG', 'WEBP') or im.width * im.height > 40000000:
            raise ValueError('Unsupported batch reference image')
        im.verify()
    return dict(asset)
