"""Isolated native batch fixtures; no real Flow, Lark, SKU files or KPI mutations."""
import copy
import hashlib
import importlib.util
import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image, ImageDraw

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('production-engine.py'))
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
import production_batch as batch
import flow_lark_orchestration as flow


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.original=(engine.STORE,engine.JOBS)
        self.tmp=tempfile.TemporaryDirectory(prefix='batch-fixture-',dir=engine.STORE)
        engine.STORE=Path(self.tmp.name);engine.JOBS=engine.STORE/'jobs';engine.JOBS.mkdir()
        self.c=engine.connect(engine.STORE/'fixture.sqlite');self.env=vars(engine)
        self.auth={'authority':'direct_user','reference':'Isolated fixture user command only'}
        self.submit={'action':'batch_submit','batch_id':'fixture-batch','kind':'apparel_2d','name':'Fixture',
                     'items':[{'title':'Otter bakery','idea_prompt':'An otter bakery corner.'},
                              {'title':'Otter gardener','idea_prompt':'An otter garden.'}],**self.auth}
        self.n=0
        self.selection_patch=patch('chatgpt_image_orchestration.selection',return_value={'provider':'chatgpt'})
        self.selection_patch.start()
        self.google_patch=patch('google_delivery.sync',return_value={'status':'fixture_disabled'})
        self.google_patch.start()
        self.runtime_file=engine.ROOT/'workspace/flow-worker/runtime/image-provider.json'
        self.runtime_before=self.runtime_file.read_bytes() if self.runtime_file.exists() else None
        original_write=engine.write
        def isolated_write(file,value):
            if Path(file).resolve()==self.runtime_file.resolve():raise AssertionError('Fixture attempted to write the live image-provider file')
            return original_write(file,value)
        self.write_patch=patch.object(engine,'write',side_effect=isolated_write);self.write_patch.start()

    def tearDown(self):
        self.selection_patch.stop()
        self.google_patch.stop()
        self.write_patch.stop()
        self.assertEqual(self.runtime_file.read_bytes() if self.runtime_file.exists() else None,self.runtime_before)
        self.c.close();engine.STORE,engine.JOBS=self.original;self.tmp.cleanup()

    def execute(self,cmd):return engine.execute(self.c,cmd)

    def test_explicit_native_start_releases_only_its_own_worker_error_holds(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for worker,bid in [('flow-worker','A'),('batch-worker','B')]:
                file=root/'workspace'/worker/'runtime/workflow-error-hold.json'
                file.parent.mkdir(parents=True);file.write_text(json.dumps({'batch_id':bid,'code':'fixture_error'}),encoding='utf-8')
            batch.controls.release_error_holds(root,'A')
            self.assertFalse((root/'workspace/flow-worker/runtime/workflow-error-hold.json').exists())
            self.assertEqual(len(list((root/'workspace/flow-worker/runtime').glob('workflow-error-released-*.json'))),1)
            self.assertTrue((root/'workspace/batch-worker/runtime/workflow-error-hold.json').exists())

    def test_completed_resume_releases_exact_poll_hold_without_reopening_work(self):
        self.start()
        b=batch.batch(self.c,'fixture-batch')
        self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id=?",(b['batch_id'],))
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(b['batch_id'],))
        command={'action':'batch_start','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth}
        hold={'batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],'code':'n8n_native_failed_check_private_log','task_id':None,'stop_pending':False}
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);file=root/'workspace/flow-worker/runtime/workflow-error-hold.json';file.parent.mkdir(parents=True)
            other=root/'workspace/batch-worker/runtime/workflow-error-hold.json';other.parent.mkdir(parents=True)
            other.write_text(json.dumps({**hold,'code':'codex_usage_limit_exceeded'}),encoding='utf-8')
            with patch.object(engine,'ROOT',root):
                for change in ({'batch_id':'other'}, {'batch_fingerprint':'f'*64}, {'stop_pending':True}, {'task_id':'image-task'}, {'code':'flow_quota_required'}, {'code':'flow_unusual_activity_required'}, {'code':'flow_login_required'}, {'code':'flow_ui_changed'}):
                    file.write_text(json.dumps({**hold,**change}),encoding='utf-8')
                    self.execute(command);self.assertTrue(file.exists());self.assertTrue(other.exists())
                self.c.execute("UPDATE production_batch_items SET state='queued' WHERE batch_id=?",(b['batch_id'],))
                file.write_text(json.dumps(hold),encoding='utf-8');self.execute(command);self.assertTrue(file.exists())
                self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(b['batch_id'],))
                before={t:[tuple(r) for r in self.c.execute('SELECT * FROM '+t)] for t in ('production_batches','production_batch_items','production_batch_tasks','design_assets','design_approvals','jobs','tasks','artifacts','kpi','config')}
                original=json.dumps(hold).encode();file.write_bytes(original)
                result=self.execute(command)
                self.assertFalse(file.exists());self.assertTrue(other.exists())
                archived=list(file.parent.glob('workflow-error-released-*.json'))
                self.assertEqual(len(archived),1);self.assertEqual(archived[0].read_bytes(),original)
                self.assertEqual(result['status'],'batch_completed');self.assertFalse(result['generation_called'])
                for t,rows in before.items():self.assertEqual([tuple(r) for r in self.c.execute('SELECT * FROM '+t)],rows)
                self.execute(command);self.assertEqual(len(list(file.parent.glob('workflow-error-released-*.json'))),1)
                with self.assertRaisesRegex(ValueError,'fingerprint'):
                    self.execute({**command,'batch_fingerprint':'f'*64})

    def test_new_start_releases_only_verified_cancelled_batch_task_hold(self):
        self.start();self.cycle()
        old=batch.batch(self.c,'fixture-batch')
        task=self.c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=? LIMIT 1',(old['batch_id'],)).fetchone()
        self.assertIsNotNone(task)
        self.c.execute("UPDATE production_batch_tasks SET status='superseded' WHERE id=?",(task['id'],))
        self.c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=?",(old['batch_id'],))
        self.c.execute("UPDATE production_batches SET status='closed_partial' WHERE batch_id=?",(old['batch_id'],))
        hold={'batch_id':old['batch_id'],'batch_fingerprint':old['fingerprint'],'task_id':task['id'],'code':'task_no_longer_pending','stop_pending':False}
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);file=root/'workspace/flow-worker/runtime/workflow-error-hold.json';file.parent.mkdir(parents=True)
            def check(value,released=False):
                file.write_text(json.dumps(value),encoding='utf-8');batch.controls.release_error_holds(root,'new-batch',self.c)
                self.assertEqual(file.exists(),not released)
            for change in ({'code':'flow_quota_required'},{'code':'flow_unusual_activity_required'},{'stop_pending':True},{'batch_fingerprint':'f'*64},{'task_id':'missing'}):check({**hold,**change})
            self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?",(old['batch_id'],));check(hold)
            self.c.execute("UPDATE production_batches SET status='closed_partial' WHERE batch_id=?",(old['batch_id'],))
            self.c.execute("UPDATE production_batch_tasks SET status='pending' WHERE id=?",(task['id'],));check(hold)
            self.c.execute("UPDATE production_batch_tasks SET status='superseded' WHERE id=?",(task['id'],))
            self.c.execute("UPDATE production_batch_items SET state='queued' WHERE batch_id=?",(old['batch_id'],));check(hold)
            self.c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=?",(old['batch_id'],));check(hold,True)
            archived=list(file.parent.glob('workflow-error-released-*.json'));self.assertEqual(len(archived),1)
            self.assertEqual(json.loads(archived[0].read_text()),hold)
            self.c.execute("INSERT INTO design_tasks VALUES(?,?,?,?,?,?,?,?)",('retired-design','retired-brief',1,'2d','d'*64,'superseded','{}',engine.now()))
            design_hold={**hold,'task_id':'retired-design'}
            check(design_hold)
            self.c.execute("UPDATE production_batch_items SET brief_id='retired-brief' WHERE batch_id=? AND position=0",(old['batch_id'],))
            check(design_hold,True)
            self.assertEqual(len(list(file.parent.glob('workflow-error-released-*.json'))),2)

    def test_new_start_retires_only_upload_hold_of_fully_cancelled_batch(self):
        self.start();self.cycle()
        old=batch.batch(self.c,'fixture-batch')
        task=self.c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=? LIMIT 1',(old['batch_id'],)).fetchone()
        self.c.execute("UPDATE production_batch_tasks SET status='cancelled' WHERE id=?",(task['id'],))
        self.c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=?",(old['batch_id'],))
        self.c.execute("UPDATE production_batches SET status='closed_partial' WHERE batch_id=?",(old['batch_id'],))
        hold={'batch_id':old['batch_id'],'batch_fingerprint':old['fingerprint'],'task_id':task['id'],'code':'flow_upload_ui_failed','stop_pending':False}
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);file=root/'workspace/flow-worker/runtime/workflow-error-hold.json';file.parent.mkdir(parents=True)
            def check(value,released=False):
                original=json.dumps(value,indent=2).encode();file.write_bytes(original)
                batch.controls.release_error_holds(root,'new-batch',self.c)
                self.assertEqual(file.exists(),not released)
                if released:self.assertEqual(next(file.parent.glob('workflow-error-released-*.json')).read_bytes(),original)
            for change in ({'code':'flow_quota_required'},{'code':'flow_unusual_activity_required'},{'code':'flow_login_required'},
                           {'code':'flow_captcha_required'},{'code':'flow_configuration_ui_failed'},
                           {'stop_pending':True},{'stop_pending':None},{'batch_fingerprint':'f'*64},{'task_id':'missing'}):
                check({**hold,**change})
            for status in ['pending','superseded']:
                self.c.execute('UPDATE production_batch_tasks SET status=? WHERE id=?',(status,task['id']));check(hold)
            self.c.execute("UPDATE production_batch_tasks SET status='cancelled' WHERE id=?",(task['id'],))
            self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?",(old['batch_id'],));check(hold)
            self.c.execute("UPDATE production_batches SET status='closed_partial' WHERE batch_id=?",(old['batch_id'],))
            self.c.execute("UPDATE production_batch_items SET state='queued' WHERE batch_id=?",(old['batch_id'],));check(hold)
            self.c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=?",(old['batch_id'],))
            self.c.execute("UPDATE production_batch_tasks SET batch_id='other-batch' WHERE id=?",(task['id'],));check(hold)
            self.c.execute('UPDATE production_batch_tasks SET batch_id=? WHERE id=?',(old['batch_id'],task['id']))
            check(hold,True)

    def test_explicit_code_is_immutable_and_its_topic_is_inferred_before_generation(self):
        self.submit['items'][0]['listing_code']='UST_261015_01_TQH'
        result=self.execute(self.submit)
        first=result['items'][0]
        self.assertEqual(first['listing_code'],'UST_261015_01_TQH')
        self.assertEqual(first['item_id'],first['listing_code'])
        record=batch.manifest(batch.batch(self.c,result['batch_id']))['items'][0]
        self.assertEqual(record['brief']['topic_code'],'UST')
        self.assertEqual(record['brief']['idea_prompt'],self.submit['items'][0]['idea_prompt'])
        self.assertEqual(self.execute(self.submit)['batch_fingerprint'],result['batch_fingerprint'])
        altered=copy.deepcopy(self.submit);altered['items'][0]['listing_code']='UST_261015_02_TQH'
        with self.assertRaisesRegex(ValueError,'immutable'):self.execute(altered)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],0)

    def test_supplied_codes_cannot_conflict_or_be_reused_by_another_batch(self):
        first=copy.deepcopy(self.submit);first['items'][0]['listing_code']='UST_261015_01_TQH'
        self.execute(first)
        second=copy.deepcopy(first);second['batch_id']='other-batch'
        with self.assertRaisesRegex(ValueError,'already used'):self.execute(second)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM production_batches WHERE batch_id='other-batch'").fetchone()[0],0)
        for invalid in [{'listing_code':'UST_261015_01'}, {'listing_code':'UST_261332_01_TQH'},
                        {'listing_code':'UST_261015_01_TQH','item_id':'0001'},
                        {'listing_code':'UST_261015_01_TQH','topic_code':'GEN'}]:
            trial=copy.deepcopy(second);trial['items'][0].update(invalid)
            with self.subTest(invalid=invalid),self.assertRaises(ValueError):self.execute(trial)
        duplicate=copy.deepcopy(second)
        for entry in duplicate['items']:entry['listing_code']='UST_261015_03_TQH'
        with self.assertRaisesRegex(ValueError,'Duplicate item IDs'):self.execute(duplicate)

    def test_cancelled_unallocated_work_releases_the_exact_supplied_code(self):
        first=copy.deepcopy(self.submit);first['items'][0]['listing_code']='UST_261017_11_TQH'
        preview=self.execute(first)
        self.execute({'action':'batch_stop','batch_id':first['batch_id'],**self.auth})
        self.execute({'action':'batch_discard_remaining','batch_id':first['batch_id'],'batch_fingerprint':preview['batch_fingerprint'],**self.auth})
        second=copy.deepcopy(first);second['batch_id']='new-intake';second['items'][0]['idea_prompt']='Corrected artwork with the same user code.'
        result=self.execute(second)
        self.assertEqual(result['items'][0]['listing_code'],'UST_261017_11_TQH')
        self.assertEqual(result['items'][0]['item_id'],'UST_261017_11_TQH')
        old=self.c.execute('SELECT state,listing_code FROM production_batch_items WHERE batch_id=? AND item_id=?',(first['batch_id'],'UST_261017_11_TQH')).fetchone()
        self.assertEqual(tuple(old),('cancelled',None))
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM jobs').fetchone()[0],0)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)

    def test_cancelled_allocated_work_still_protects_its_code(self):
        first=copy.deepcopy(self.submit);first['items'][0]['listing_code']='UST_261017_11_TQH'
        preview=self.execute(first)
        self.execute({'action':'batch_stop','batch_id':first['batch_id'],**self.auth})
        self.execute({'action':'batch_discard_remaining','batch_id':first['batch_id'],'batch_fingerprint':preview['batch_fingerprint'],**self.auth})
        self.c.execute('UPDATE production_batch_items SET listing_code=? WHERE batch_id=? AND item_id=?',('UST_261017_11_TQH',first['batch_id'],'UST_261017_11_TQH'))
        second=copy.deepcopy(first);second['batch_id']='unsafe-reuse'
        with self.assertRaisesRegex(ValueError,'already used'):self.execute(second)

    def test_explicit_code_already_reserved_is_rejected_before_asking_for_images(self):
        self.submit['items'][0]['listing_code']='UST_261015_01_TQH'
        self.c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',('another-brief','UST_261015_01_TQH','UST','2026-10-18','reserved','Fixture',engine.now()))
        with self.assertRaisesRegex(ValueError,'already used'):self.execute(self.submit)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],0)

    def test_locked_size_accepts_one_float_step_without_changing_plan_or_accepting_oversize(self):
        path=engine.STORE/'locked-size.png';Image.new('RGB',(32,32),'white').save(path)
        art={'path':str(path),'sha256':engine.sha(path),'width_cm':math.nextafter(7,math.inf),'height_cm':8.351895734597157,
             'artwork_approval_reference':'fixture artwork approval','size_approval_reference':'fixture size approval'}
        plan={'garment':'crewneck','color':'sand','back_artwork':False,'regions':{
            'center_chest':dict(art,width_cm=26),'left_sleeve':dict(art),'right_sleeve':dict(art)}}
        before=copy.deepcopy(plan);self.assertEqual(engine.validate_plan(plan),before);self.assertEqual(plan,before)
        for region,axis,value in [('left_sleeve','width_cm',math.nextafter(art['width_cm'],math.inf)),
                                  ('left_sleeve','width_cm',7.01),('center_chest','height_cm',26.01),
                                  ('right_sleeve','width_cm',float('nan')),('right_sleeve','height_cm',float('inf')),
                                  ('left_sleeve','height_cm',0)]:
            with self.subTest(region=region,axis=axis,value=value):
                invalid=copy.deepcopy(plan);invalid['regions'][region][axis]=value
                with self.assertRaisesRegex(ValueError,'Dimensions outside shared maximum'):engine.validate_plan(invalid)

    def test_new_size_resolution_caps_float_roundoff_at_the_exact_maximum(self):
        path=engine.STORE/'roundoff-bounds.png';Image.new('RGB',(1024,1024),'white').save(path)
        regions=['center_chest','left_sleeve','right_sleeve']
        brief={'brief_id':'fixture-roundoff','topic_code':'GEN','product_type':'physical_apparel','product_id':'fixture-roundoff',
               'garment':'crewneck','color':'sand','available_styles':['crewneck sweatshirt'],'back_artwork':False,
               'personalization':{'enabled':False},'sources':[],'motifs':{r:'Fixture artwork' for r in regions}}
        self.execute({'action':'receive_brief','brief':brief})
        art={'path':str(path),'sha256':engine.sha(path),'bounds_px':[90,17,934,1024]}
        self.assertGreater(844*(7/844),7)
        resolved=engine.resolve_plan(self.c,{'brief_id':brief['brief_id'],'artwork':{r:dict(art) for r in regions}})
        self.assertEqual(resolved['plan']['regions']['left_sleeve']['width_cm'],7)
        self.assertEqual(resolved['plan']['regions']['left_sleeve']['height_cm'],1007*(7/844))

    def start(self,submit=None):
        r=self.execute(submit or self.submit)
        control={'batch_id':r['batch_id'],'batch_fingerprint':r['batch_fingerprint'],**self.auth}
        self.execute(dict(control,action='batch_confirm'));self.execute(dict(control,action='batch_start'))
        return r

    def cycle(self):return self.execute({'action':'batch_cycle'})

    def test_completed_flow_scope_advances_to_authorized_next_batch_once(self):
        old=self.start();self.cycle()
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(old['batch_id'],))
        self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(old['batch_id'],))
        self.assertEqual(self.cycle()['status'],'batch_completed')
        previous_tasks=[dict(r) for r in self.c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=?',(old['batch_id'],))]
        new=self.start({**self.submit,'batch_id':'fixture-next'})
        choice={'provider':'flow','mode':'flow','batch_id':old['batch_id'],
                'unusual_activity_policy':{'enabled':True,'cooldown_ms':600000,'reference':'Fixture ten-minute policy'},
                'generation_failure_policy':{'enabled':True,'cooldown_ms':60000,'reference':'Fixture one-minute policy'}}
        writes=[];original_write=self.env['write']
        def write(file,value):
            if str(file).replace('\\','/').endswith('/runtime/image-provider.json'):writes.append(value)
            else:original_write(file,value)
        with patch('chatgpt_image_orchestration.selection',side_effect=lambda e:writes[-1] if writes else choice),patch.dict(self.env,{'write':write}):
            result=self.cycle();self.cycle()
            snapshot=flow.execute(self.c,{'action':'flow_cycle'},self.env)
            self.assertTrue(snapshot['tasks'])
            self.assertTrue(all(t['flow_project_key']==new['batch_id'] for t in snapshot['tasks']))
        self.assertEqual(result['batch_id'],new['batch_id']);self.assertEqual(len(writes),1)
        self.assertEqual(writes[0]['batch_id'],new['batch_id'])
        self.assertEqual(writes[0]['unusual_activity_policy'],choice['unusual_activity_policy'])
        self.assertEqual(writes[0]['generation_failure_policy'],choice['generation_failure_policy'])
        self.assertEqual([dict(r) for r in self.c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=?',(old['batch_id'],))],previous_tasks)

    def test_scope_handoff_does_not_replace_paused_unknown_or_other_provider_scope(self):
        old=self.start();self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?",(old['batch_id'],))
        self.start({**self.submit,'batch_id':'fixture-next'})
        for choice in ({'provider':'flow','batch_id':old['batch_id']},{'provider':'flow','batch_id':'missing-batch'},
                       {'provider':'chatgpt','batch_id':old['batch_id']},{'provider':'flow'}):
            writes=[];original_write=self.env['write']
            def write(file,value):
                if str(file).replace('\\','/').endswith('/runtime/image-provider.json'):writes.append(value)
                else:original_write(file,value)
            with patch('chatgpt_image_orchestration.selection',return_value=choice),patch.dict(self.env,{'write':write}):self.cycle()
            self.assertEqual(writes,[])

    def candidate(self,t):
        p=t['payload'];output=Path(p['output_directory']);output.mkdir(parents=True,exist_ok=True)
        screenshot=engine.STORE/'fixture-ui.png';Image.new('RGB',(32,32),'white').save(screenshot)
        proof={'url':'https://flow.google.com/project/fixture-only','model':'Nano Banana Pro','executor':'independent_flow_worker',
               'acquisition':'flow_download','screenshot_path':str(screenshot),'screenshot_sha256':engine.sha(screenshot)}
        assets=[];records=[];provenance=[]
        for image in p['images']:
            self.n+=1;key=image.get('region',image.get('name'));path=output/(key+'.png')
            portrait=image.get('aspect_ratio')=='9:16'
            im=Image.new('RGB',(180,320) if portrait else (320,180) if image.get('aspect_ratio')=='16:9' else (100,100),'white');ImageDraw.Draw(im).rectangle((70,30,110,290) if portrait else (40,20,60,80),fill=(self.n*17%250,self.n*23%250,self.n*31%250));im.save(path)
            assets.append({'image_key':key,'path':str(path),'sha256':engine.sha(path)})
            records.append(dict(proof,image_key=key))
            refs=image.get('references',list(p.get('references',{}).values()))
            provenance.append({'image_key':key,'prompt_sha256':hashlib.sha256(image['prompt'].encode()).hexdigest(),
                               'reference_sha256':sorted(r['sha256'] for r in refs)})
        proof.update(images=records,prompt_provenance=provenance)
        return {'action':'flow_auto_submit','task_id':t['id'],'task_fingerprint':t['fingerprint'],'revision':t['revision'],
                'assets':assets,'proof':proof}

    def decision(self,review,choice='approve',reason=''):
        return {**{k:review[k] for k in ('review_id','entity','revision','stage','fingerprint')},
                'event_id':'fixture-event-'+uuidhex(review['review_id']+choice),'message_id':'fixture-message',
                'authority':'direct_user','reference':'Isolated fixture human '+choice,'decision':choice,'reason':reason}

    def first_sample(self):
        self.start();s=self.cycle();t=s['tasks'][0];cmd=self.candidate(t);self.execute(cmd)
        review=self.cycle()['reviews'][0]
        return t,cmd,review

    def test_submit_is_immutable_inert_and_duplicate_idempotent(self):
        r=self.execute(self.submit);self.assertEqual(r,self.execute(self.submit))
        for table in ('design_jobs','jobs','design_approvals','approvals','tasks','kpi','reservations'):
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0)
        altered=copy.deepcopy(self.submit);altered['items'][0]['idea_prompt']='changed'
        with self.assertRaises(ValueError):self.execute(altered)
        self.assertFalse(r['generation_started'])

    def test_start_requires_current_confirmed_manifest(self):
        r=self.execute(self.submit)
        for cmd in [{'action':'batch_start','batch_fingerprint':r['batch_fingerprint']},
                    {'action':'batch_confirm','batch_fingerprint':'wrong'}]:
            with self.assertRaises(ValueError):self.execute({**cmd,'batch_id':r['batch_id'],**self.auth})
        self.assertEqual(self.cycle()['status'],'batch_idle')

    def test_one_active_batch_and_waiting_reorder(self):
        self.start()
        for bid in ['fixture-batch-two','fixture-batch-three']:
            r=self.execute({**self.submit,'batch_id':bid})
            self.execute({'action':'batch_confirm','batch_id':bid,'batch_fingerprint':r['batch_fingerprint'],**self.auth})
            with self.assertRaisesRegex(ValueError,'Stop the active batch'):
                self.execute({'action':'batch_start','batch_id':bid,'batch_fingerprint':r['batch_fingerprint'],**self.auth})
        self.execute({'action':'batch_reorder','batch_ids':['fixture-batch-three','fixture-batch-two'],**self.auth})
        self.assertEqual(self.cycle()['batch_id'],'fixture-batch')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM production_batches WHERE status='active'").fetchone()[0],1)
        with self.assertRaises(ValueError):self.execute({'action':'batch_reorder','batch_ids':['fixture-batch-three'],**self.auth})

    def test_sample_pending_quality_and_human_policy_binding(self):
        _,_,review=self.first_sample()
        self.assertFalse(review['visual_qa']['passed']);self.assertIn('toàn bộ batch',review['summary'])
        wrong=self.decision(review);wrong['fingerprint']='wrong'
        self.assertFalse(flow.apply_decision(self.c,wrong,self.env)['accepted'])
        approved=flow.apply_decision(self.c,self.decision(review),self.env)
        self.assertTrue(approved['policy_granted'])
        for table in ('approvals','design_approvals'):
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0)

    def test_delegated_review_requires_real_grant_exact_revision_and_hashed_visual_findings(self):
        _,_,review=self.first_sample();b=batch.batch(self.c,'fixture-batch')
        file=engine.STORE/'delegated-reviews/fixture.json'
        evidence={'reviewer':'Codex','review_id':review['review_id'],'image_sha256':review['images'][0]['sha256'],'visual_findings':'Fixture only: checked subject and lettering against its exact source prompt.','decision':'approve'}
        engine.write(file,evidence)
        command={'action':'batch_operator_review','batch_id':b['batch_id'],'item_id':review['entity']['item_id'],'revision':review['revision'],'fingerprint':review['fingerprint'],'evidence_path':str(file),'evidence_sha256':engine.sha(file),**self.auth}
        with self.assertRaisesRegex(ValueError,'delegated review'):self.execute(command)
        self.execute({'action':'batch_delegate_reviews','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth})
        with self.assertRaises(ValueError):self.execute({**command,'evidence_sha256':'0'*64})
        with self.assertRaises(ValueError):self.execute({**command,'revision':review['revision']+1})
        result=self.execute(command);self.assertTrue(result['policy_granted'])
        self.assertTrue(batch.policy(self.c,b)['message_id'].startswith('codex-visual-review:'))

    def test_sample_amendment_preserves_original_and_stale_review_rejected(self):
        t,cmd,review=self.first_sample()
        flow.apply_decision(self.c,self.decision(review,'revise','Move bakery toward center.'),self.env)
        new=self.cycle()['tasks'][0]
        self.assertEqual(new['revision'],2);self.assertIn('Move bakery toward center.',new['payload']['images'][0]['prompt'])
        self.assertTrue(Path(cmd['assets'][0]['path']).is_file())
        self.assertFalse(flow.apply_decision(self.c,self.decision(review),self.env)['accepted'])
        with self.assertRaises(ValueError):self.execute(cmd)

    def test_mockup_revision_retains_viewed_originals_and_sample_without_regenerating_them(self):
        _, sample, review = self.first_sample(); b = batch.batch(self.c, 'fixture-batch')
        self.execute({'action':'batch_delegate_reviews','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth})
        flow.apply_decision(self.c, self.decision(review), self.env)
        before_policy = batch.policy(self.c, b)
        t = self.cycle()['tasks'][0]; candidate = self.candidate(t)
        journal = {'task_id':t['id'],'revision':t['revision'],'fingerprint':t['fingerprint'],'images':{}}
        observations = {}; corrections = {}
        for image, asset, proof in zip(t['payload']['images'], candidate['assets'], candidate['proof']['images']):
            name = image['name']; retain = name in ('02_model_front.jpg','05_embroidery_dimensions.jpg')
            journal['images'][name] = {'status':'acquired','asset':asset,'proof':dict(proof,prompt_sha256=hashlib.sha256(image['prompt'].encode()).hexdigest())}
            observations[name] = {'image_sha256':asset['sha256'],'visual_findings':'Fixture observation only','decision':'retain' if retain else 'revise'}
            if not retain:corrections[name] = 'Fixture: use the assigned camera, not the source front hero.'
        journal_file = engine.STORE/'worker-journal.json'; engine.write(journal_file,journal)
        evidence_file = engine.STORE/'delegated-reviews/mockups.json'
        engine.write(evidence_file,{'reviewer':'Codex','task_id':t['id'],'revision':t['revision'],'fingerprint':t['fingerprint'],'images':observations,'corrections':corrections,'human_viewing_claimed':False})
        command = {'action':'batch_revise_mockups','batch_id':b['batch_id'],'item_id':t['item_id'],'task_id':t['id'],'revision':t['revision'],'fingerprint':t['fingerprint'],'evidence_path':str(evidence_file),'evidence_sha256':engine.sha(evidence_file),'journal_path':str(journal_file),'journal_sha256':engine.sha(journal_file),**self.auth}
        with self.assertRaisesRegex(ValueError,'Stop the exact'):self.execute(command)
        self.execute({'action':'batch_stop','batch_id':b['batch_id'],**self.auth})
        with self.assertRaisesRegex(ValueError,'evidence'):self.execute({**command,'evidence_sha256':'0'*64})
        unknown = copy.deepcopy(journal); unknown['images']['06_flatlay.jpg']={'status':'generation_started','generation_id':'unknown'}
        engine.write(journal_file,unknown)
        with self.assertRaisesRegex(ValueError,'Reconcile unknown'):self.execute({**command,'journal_sha256':engine.sha(journal_file)})
        unknown['events']=[{'event':'unusual_activity_cooldown_started','image_key':'06_flatlay.jpg','generation_id':'unknown','not_before':'2099-01-01T00:00:00Z'}]
        engine.write(journal_file,unknown)
        with self.assertRaisesRegex(ValueError,'cooldown'):self.execute({**command,'journal_sha256':engine.sha(journal_file)})
        engine.write(journal_file,journal)
        result = self.execute(command); self.assertEqual(result,self.execute(command))
        self.assertEqual(batch.policy(self.c,b),before_policy)
        self.execute({'action':'batch_start','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth})
        replacement = self.cycle()['tasks'][0]
        self.assertEqual(replacement['revision'],t['revision']+1)
        self.assertEqual([x['name'] for x in replacement['payload']['images']],list(corrections))
        self.assertEqual(replacement['payload']['references']['approved_sample']['sha256'],sample['assets'][0]['sha256'])
        rule = engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for image in replacement['payload']['images']:
            self.assertIn('REQUIRED CAMERA FOR THIS OUTPUT:',image['prompt'])
            self.assertIn(corrections[image['name']],image['prompt']);self.assertTrue(image['prompt'].endswith(rule))
        with self.assertRaises(ValueError):self.execute(candidate)
        self.execute(self.candidate(replacement))
        self.assertEqual(len(json.loads(batch.item(self.c,b['batch_id'],t['item_id'])['images'])),6)

    def test_policy_runs_rest_five_then_next_item_sample_without_human_repeat(self):
        _,cmd,review=self.first_sample();flow.apply_decision(self.c,self.decision(review),self.env)
        self.execute(cmd) # Old retry must not revoke policy or reopen sample approval.
        rest=self.cycle()['tasks'][0];self.assertEqual(len(rest['payload']['images']),5)
        self.assertEqual(rest['payload']['references']['approved_sample']['sha256'],cmd['assets'][0]['sha256'])
        self.execute(self.candidate(rest));self.cycle()
        next_sample=self.cycle()['tasks'][0];self.assertEqual(next_sample['item_id'],'0002');self.assertEqual(len(next_sample['payload']['images']),1)
        self.execute(self.candidate(next_sample));next_rest=self.cycle()['tasks'][0]
        self.assertEqual(len(next_rest['payload']['images']),5);self.assertFalse(self.cycle()['reviews'])
        self.execute(self.candidate(next_rest));self.cycle()
        self.assertEqual(self.cycle()['status'],'awaiting_kpi_activation')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM jobs').fetchone()[0],0)

    def test_delegation_keeps_next_item_sample_waiting_for_actual_operator_review(self):
        _,_,review=self.first_sample();b=batch.batch(self.c,'fixture-batch')
        self.execute({'action':'batch_delegate_reviews','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth})
        flow.apply_decision(self.c,self.decision(review),self.env)
        rest=self.cycle()['tasks'][0];self.execute(self.candidate(rest));self.cycle()
        gated=self.cycle();self.assertFalse(gated['reviews'])
        full_review=gated['operator_reviews'][0];self.assertEqual(full_review['stage'],'mockups')
        self.assertEqual(len(full_review['images']),6)
        self.assertIsNone(batch.item(self.c,b['batch_id'],'0001')['listing_code'])
        file=engine.STORE/'delegated-reviews/full-set.json'
        evidence={'reviewer':'Codex','review_id':full_review['review_id'],'images':[{'name':image['name'],'sha256':image['sha256']} for image in full_review['images']],'visual_findings':'Fixture only: full set inspected.','decision':'approve'}
        engine.write(file,evidence)
        command={'action':'batch_operator_review','batch_id':b['batch_id'],'item_id':'0001','revision':full_review['revision'],'fingerprint':full_review['fingerprint'],'evidence_path':str(file),'evidence_sha256':engine.sha(file),**self.auth}
        with self.assertRaises(ValueError):self.execute({**command,'fingerprint':'0'*64})
        self.assertEqual(self.execute(command)['status'],'batch_mockups_approve')
        self.cycle();next_sample=self.cycle()['tasks'][0];self.execute(self.candidate(next_sample))
        waiting=self.cycle();self.assertEqual(waiting['tasks'],[]);self.assertEqual(waiting['reviews'][0]['entity']['item_id'],'0002')
        self.assertIsNone(batch.item(self.c,'fixture-batch','0002')['listing_code'])

    def test_profile_uses_sweater_only_no_art_sizes_or_thread_claims(self):
        self.start();p=self.cycle()['tasks'][0]['payload']
        self.assertEqual(p['aspect_ratio'],'1:1')
        self.assertEqual(p['sizes_in'],{});self.assertEqual(p['images'][0]['wardrobe']['garment'],'crewneck sweatshirt')
        self.assertNotIn('PHYSICAL DIMENSIONS',p['images'][0]['prompt']);self.assertNotIn('Tatami',p['images'][0]['prompt'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_jobs').fetchone()[0],0)

    def test_locked_mockup_views_do_not_repeat_source_hero_framing_or_recolor_the_aop(self):
        _,_,review=self.first_sample();flow.apply_decision(self.c,self.decision(review),self.env)
        p=self.cycle()['tasks'][0]['payload']
        self.assertEqual(p['source_idea_prompt'],self.submit['items'][0]['idea_prompt'])
        for image in p['images']:
            self.assertTrue(image['prompt'].startswith('Rephotograph the exact uploaded approved AOP crewneck.'))
            self.assertNotIn(self.submit['items'][0]['idea_prompt'],image['prompt'])
            self.assertNotIn('Garment: navy',image['prompt'])
            self.assertNotIn('embroidery dimensions',image['prompt'])
            self.assertEqual(image['wardrobe']['color_source'],'locked_approved_sample')

    def test_workflow_acceptance_requires_explicit_human_and_finished_reviewed_sample(self):
        command={'action':'batch_accept_workflow','workflow_accepted_by_user':True,**self.auth}
        with self.assertRaises(ValueError):self.execute(command)
        _,_,review=self.first_sample();flow.apply_decision(self.c,self.decision(review),self.env)
        with self.assertRaises(ValueError):self.execute(command)
        self.execute(self.candidate(self.cycle()['tasks'][0]));self.cycle()
        with self.assertRaises(ValueError):self.execute({**command,'workflow_accepted_by_user':False})
        result={'ok':True,'status':'fixture_activation'}
        with patch.dict(self.env,{'execute':lambda c,cmd: result if cmd['action']=='activate_kpi' and cmd['authority']=='direct_user' and cmd['workflow_accepted_by_user'] else None}):
            self.assertEqual(batch.execute(self.c,command,self.env),result)

    def test_stop_hides_tasks_without_deleting_history(self):
        self.start();t=self.cycle()['tasks'][0]
        self.execute({'action':'batch_stop','batch_id':'fixture-batch',**self.auth})
        self.assertEqual(batch.queue(self.c),[])
        self.assertEqual(self.execute({'action':'browser_queue'})['tasks'],[])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],1)
        self.execute(self.candidate(t))
        self.assertEqual(batch.batch(self.c,'fixture-batch')['status'],'stopped')

    def test_restart_retains_identical_pending_task(self):
        self.start();t=self.cycle()['tasks'][0];self.c.commit();self.c.close();self.c=engine.connect(engine.STORE/'fixture.sqlite')
        self.assertEqual(self.cycle()['tasks'][0]['id'],t['id'])
        self.assertEqual(self.cycle()['tasks'][0]['fingerprint'],t['fingerprint'])

    def test_candidate_wrong_provenance_or_false_visual_qa_rejected(self):
        self.start();t=self.cycle()['tasks'][0];cmd=self.candidate(t)
        for patcher in (lambda x:x['proof'].update(visually_verified=True),
                        lambda x:x['proof']['prompt_provenance'][0].update(prompt_sha256='wrong'),
                        lambda x:x.update(task_fingerprint='wrong')):
            changed=copy.deepcopy(cmd);patcher(changed)
            with self.assertRaises(ValueError):self.execute(changed)

    def test_failed_item_retries_same_task_and_order(self):
        self.start();t=self.cycle()['tasks'][0]
        i=batch.item(self.c,'fixture-batch','0001');batch.set_item(self.c,i,'failed',error='fixture interruption')
        self.assertEqual(self.cycle()['status'],'batch_item_failed')
        self.execute({'action':'batch_retry','batch_id':'fixture-batch','item_id':'0001',**self.auth})
        self.assertEqual(self.cycle()['tasks'][0]['id'],t['id'])

    def test_transport_limits_and_no_document_authority(self):
        for changed in ({'items':[]},{'items':[self.submit['items'][0]]*501},{'authority':'attached_document'},
                        {'kind':'other'},{'items':[dict(self.submit['items'][0],item_id='same'),dict(self.submit['items'][1],item_id='same')]}):
            with self.assertRaises(ValueError):self.execute({**self.submit,**changed})

    def test_card_confirm_and_start_is_atomic_bound_and_replay_safe(self):
        submitted=self.execute(self.submit)
        command={'action':'batch_confirm_start','batch_id':submitted['batch_id'],'batch_fingerprint':submitted['batch_fingerprint'],'card_expected_status':['submitted']}
        body={'event_id':'fixture-real-card-event','message_id':'om_fixture_card','authority':'direct_user','reference':'Fixture human card click','interaction_type':'card_action','command':command}
        with patch.object(batch,'canonical_command',return_value=body),patch('chatgpt_image_orchestration.selection',return_value={'provider':'chatgpt'}):
            first=self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            self.assertEqual(first['status'],'batch_queued')
            self.assertEqual(batch.batch(self.c,submitted['batch_id'])['status'],'active')
            self.assertEqual(self.execute({'action':'batch_lark_command','event_id':body['event_id']}),first)
            stale=self.execute({'action':'batch_lark_command','event_id':'fixture-other-click'})
            self.assertEqual(stale,first)
        body['event_id']='fixture-stale-card-event'
        with patch.object(batch,'canonical_command',return_value=body):
            stale=self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            self.assertFalse(stale['accepted']);self.assertIn('Card expired',stale['error'])

    def test_web_stop_preserves_bindings_rejects_other_transports_and_replays_safely(self):
        self.start()
        b=batch.batch(self.c,'fixture-batch')
        command={'action':'batch_stop','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],'card_expected_status':['active']}
        body={'event_id':'fixture-web-stop','reference':'Fixture authenticated web control','transport':'web','interaction_type':'web_control','command':command}
        invalid=[dict(body,transport='lark'),dict(body,interaction_type='message'),
                 dict(body,command=dict(command,batch_fingerprint='0'*64)),
                 dict(body,command=dict(command,card_expected_status=['submitted']))]
        for n,bad in enumerate(invalid):
            bad['event_id']='fixture-web-stop-invalid-'+str(n)
            with patch.object(batch,'canonical_command',return_value=bad):
                result=self.execute({'action':'batch_lark_command','event_id':bad['event_id']})
            self.assertFalse(result['accepted'])
            self.assertEqual(batch.batch(self.c,b['batch_id'])['status'],'active')
        with patch.object(batch,'canonical_command',return_value=body):
            first=self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            self.assertEqual(first['status'],'batch_stopped')
            self.assertEqual(self.execute({'action':'batch_lark_command','event_id':body['event_id']}),first)
        self.assertEqual(batch.batch(self.c,b['batch_id'])['status'],'stopped')

    def test_card_start_resumes_only_its_exact_flow_scope(self):
        submitted=self.execute(self.submit)
        command={'action':'batch_confirm_start','batch_id':submitted['batch_id'],'batch_fingerprint':submitted['batch_fingerprint'],'card_expected_status':['submitted']}
        body={'event_id':'fixture-resume-card','reference':'Fixture explicit card start','interaction_type':'card_action','command':command}
        calls=[];scope_writes=[];env=dict(self.env,execute=lambda c,cmd:calls.append(cmd),write=lambda p,v:scope_writes.append(v))
        with patch.object(batch,'canonical_command',return_value=body),patch('chatgpt_image_orchestration.selection',return_value={'provider':'flow'}):
            batch.execute(self.c,{'action':'batch_lark_command','event_id':body['event_id']},env)
        self.assertEqual(len(calls),1);self.assertEqual(calls[0]['action'],'chatgpt_worker_select')
        self.assertEqual(calls[0]['batch_id'],submitted['batch_id']);self.assertTrue(calls[0]['resume_image_worker'])

    def test_card_state_binding_does_not_partly_confirm_on_failed_start(self):
        submitted=self.execute(self.submit)
        with self.assertRaisesRegex(ValueError,'exact current submitted'):
            self.execute({'action':'batch_confirm_start','batch_id':submitted['batch_id'],'batch_fingerprint':'0'*64,**self.auth})
        self.assertEqual(batch.batch(self.c,submitted['batch_id'])['status'],'submitted')

    def test_canonical_event_replay_preserves_result(self):
        body={'event_id':'fixture-event','command':self.submit,'reference':'fixture signed command'}
        with patch.object(batch,'canonical_command',return_value=body):
            a=self.execute({'action':'batch_lark_command','event_id':'fixture-event'})
            b=self.execute({'action':'batch_lark_command','event_id':'fixture-event'})
        self.assertEqual(a,b);self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batches').fetchone()[0],1)

    def test_invalid_human_command_is_durable_rejection_without_partial_batch(self):
        bad=copy.deepcopy(self.submit);bad['items'][1]['idea_prompt']=''
        body={'event_id':'fixture-invalid-event','command':bad,'reference':'fixture signed invalid command'}
        with patch.object(batch,'canonical_command',return_value=body):
            a=self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            b=self.execute({'action':'batch_lark_command','event_id':body['event_id']})
        self.assertEqual(a,b);self.assertFalse(a['accepted']);self.assertFalse(a['retryable'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batches').fetchone()[0],0)

    def test_chosen_batch_temporarily_excludes_unrelated_legacy_task(self):
        self.assertTrue(batch.runnable(self.c,brief_id='legacy-unknown'))
        self.start();self.cycle()
        self.assertFalse(batch.runnable(self.c,brief_id='legacy-unknown'))
        self.execute({'action':'batch_stop','batch_id':'fixture-batch',**self.auth})
        self.assertTrue(batch.runnable(self.c,brief_id='legacy-unknown'))

    def test_embroidery_sample_requires_real_first_two_stage_approvals(self):
        submit={**self.submit,'kind':'embroidery_brief','items':[{'title':'Otter bakery','brief':'NGỰC: four otters\nTAY: a bakery corner.'},
                                                              {'title':'Otter garden','brief':'CHEST: flowers\nSLEEVE: gardening.'}]}
        self.start(submit);self.cycle()
        first=self.execute({'action':'browser_queue'})['tasks'][0]
        self.assertEqual(first['kind'],'flow_design_2d')
        self.execute(self.candidate(first));self.cycle()
        i=batch.item(self.c,'fixture-batch','0001');review=flow.review_packet(self.c,{'brief_id':i['brief_id']},self.env)
        self.assertEqual(review['stage'],'2d');self.assertFalse(batch.queue(self.c))
        flow.apply_decision(self.c,self.decision(review),self.env)
        preview=self.execute({'action':'browser_queue'})['tasks'][0];self.assertEqual(preview['kind'],'flow_design_embroidery')
        self.execute(self.candidate(preview));review=flow.review_packet(self.c,{'brief_id':i['brief_id']},self.env)
        flow.apply_decision(self.c,self.decision(review),self.env)
        sample=self.cycle()['tasks'][0];self.assertEqual(sample['stage'],'sample_mockup')
        self.assertEqual(sample['payload']['aspect_ratio'],'1:1')
        self.execute(self.candidate(sample));review=self.cycle()['reviews'][0];flow.apply_decision(self.c,self.decision(review),self.env)
        rest=self.cycle()['tasks'][0];self.execute(self.candidate(rest));self.cycle();self.cycle()
        next_design=self.execute({'action':'browser_queue'})['tasks'][0]
        self.execute(self.candidate(next_design));self.cycle()
        next_preview=self.execute({'action':'browser_queue'})['tasks'][0]
        self.assertEqual(next_preview['kind'],'flow_design_embroidery')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE brief_id=? AND stage='2d'",(next_design['brief_id'],)).fetchone()[0],0)

    def finish_images(self):
        _,_,review=self.first_sample();flow.apply_decision(self.c,self.decision(review),self.env)
        self.execute(self.candidate(self.cycle()['tasks'][0]));self.cycle()
        self.execute(self.candidate(self.cycle()['tasks'][0]));self.execute(self.candidate(self.cycle()['tasks'][0]));self.cycle()

    def test_kpi_enabled_handoff_preserves_locked_images_and_neutral_source(self):
        self.finish_images();self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        r=self.cycle();self.assertEqual(len(r['production_jobs']),1,r)
        code=r['production_jobs'][0]['listing_code'];j=engine.job(self.c,code)
        self.assertTrue(engine.approved(self.c,j,'brief',engine.digest(json.loads(j['plan']))))
        source=engine.read(engine.JOBS/(code+'.json'))
        self.assertEqual(source['packet']['confirmed_product_brief']['rendering_mode'],'apparel_2d')
        self.assertEqual(source['packet']['confirmed_product_brief']['approved_resolved_dimensions_in'],{})
        self.assertEqual(source['packet']['confirmed_product_brief']['available_styles'],['crewneck sweatshirt'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0],0)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)
        self.assertIsNone(flow.review_packet(self.c,{'listing_code':code},self.env))
        changed=dict(j,plan=json.dumps({**json.loads(j['plan']),'color':'black'}))
        self.assertFalse(engine.approved(self.c,changed,'brief',engine.digest(json.loads(changed['plan']))))

    def test_export_fresh_api_readback_checks_actual_content(self):
        self.finish_images();self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        code=self.cycle()['production_jobs'][0]['listing_code'];j=engine.job(self.c,code)
        originals=engine.artifact(self.c,j,'images')['payload'];processed=[]
        for a in originals:
            path=engine.STORE/(a['name']+'.processed.jpg');Image.open(a['path']).resize((3000,3000)).save(path)
            processed.append({'name':a['name'],'path':str(path),'sha256':engine.sha(path),'source_sha256':a['sha256']})
        engine.put(self.c,j,'processed',{'images':processed})
        packet={'listing_code':code,'revision':1,'review_fingerprint':'fixture-content-fp','title':'Fixture title',
                'description':'Fixture description','tags':['fixture tag'],'thumbnail':processed[0],'images':processed}
        t=engine.task(self.c,j,'lark_review',{'url':engine.REVIEW_URL,'packet':packet})
        report=engine.STORE/'lark-listing-readbacks'/'receipt.json'
        content={'listing_code':code,'title':packet['title'],'description':packet['description'],'tags':packet['tags'],'thumbnail_sha256':processed[0]['sha256']}
        observed={'ok':True,'task_id':t['id'],'task_fingerprint':t['fingerprint'],'document_url':engine.REVIEW_URL,
                  'observed_listing_code_count':1,'verified_after_readback':True,'official_api_origin':'https://open.larksuite.com','content':content}
        engine.write(report,observed);observed.update(readback_path=str(report),readback_sha256=engine.sha(report))
        proof={'executor':'lark_docs_api','verified_after_readback':True,'url':engine.REVIEW_URL,'content_fingerprint':packet['review_fingerprint'],
               'readback_path':str(report),'readback_sha256':observed['readback_sha256']}
        cmd={'action':'lark_listing_verified','task_id':t['id'],'proof':proof}
        class Response:
            def __init__(self,data):self.data=data
            def __enter__(self):
                import io
                return io.BytesIO(json.dumps(self.data).encode())
            def __exit__(self,*args):return False
        with patch.object(engine,'read',side_effect=lambda p: {'localToken':'fixture'} if str(p).endswith('lark-review.private.json') else json.loads(Path(p).read_text(encoding='utf-8-sig'))):
            with patch('urllib.request.urlopen',return_value=Response({**observed,'content':{**content,'title':'wrong'}})):
                with self.assertRaises(ValueError):self.execute(cmd)
            with patch('urllib.request.urlopen',return_value=Response(observed)):
                self.assertEqual(self.execute(cmd)['status'],'verified')

    def test_delegated_processed_images_require_explicit_current_visual_approval(self):
        self.finish_images();b=batch.batch(self.c,'fixture-batch')
        self.execute({'action':'batch_delegate_reviews','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],**self.auth})
        self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        review=self.cycle()['operator_reviews'][0]
        batch.sample_decision(self.c,self.decision(review),self.env)
        code=self.cycle()['production_jobs'][0]['listing_code'];j=engine.job(self.c,code)
        originals=engine.artifact(self.c,j,'images')['payload'];processed=[]
        for a in originals:
            path=engine.STORE/(a['name']+'.final.jpg');Image.open(a['path']).resize((3000,3000)).save(path)
            processed.append({'name':a['name'],'path':str(path),'sha256':engine.sha(path),'source_sha256':a['sha256']})
        fp=engine.put(self.c,j,'processed',{'images':processed})
        self.assertFalse(engine.approved(self.c,j,'processed',fp))
        self.assertEqual(engine.advance(self.c,j)['status'],'awaiting_processed_approval')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)
        corrected={'images':[{**image,'logo':{'status':'removed'}} for image in processed],
                   'source_directory':str(engine.STORE/'sources'),'destination_directory':str(engine.STORE/'corrected')}
        def processor(c,current,source,kind,regions):
            self.assertEqual(source['payload'],originals)
            return engine.put(c,current,kind,corrected)
        with patch.object(engine,'process',side_effect=processor):
            repair=self.execute({'action':'batch_correct_logos','batch_id':b['batch_id'],'listing_code':code,'logo_regions':{},**self.auth})
        self.assertEqual(repair['status'],'processed_logos_corrected_awaiting_visual_review')
        self.assertEqual(engine.artifact(self.c,j,'processed_before_logo_correction')['fingerprint'],fp)
        with self.assertRaises(ValueError):self.execute({'action':'approve','listing_code':code,'revision':j['revision'],'stage':'processed','fingerprint':fp,**self.auth})
        fp=engine.artifact(self.c,j,'processed')['fingerprint']
        self.assertFalse(engine.approved(self.c,j,'processed',fp))
        self.execute({'action':'approve','listing_code':code,'revision':j['revision'],'stage':'processed','fingerprint':fp,**self.auth})
        self.assertTrue(engine.approved(self.c,j,'processed',fp))

    def test_table_initialization_does_not_commit_native_transaction(self):
        batch.tables(self.c);self.c.commit();self.c.execute('BEGIN IMMEDIATE');self.execute(self.submit);self.c.rollback()
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batches').fetchone()[0],0)

    def test_tqh_package_keeps_exactly_six_mockups_and_two_locked_embroidery_originals(self):
        import delivery_layout
        self.execute({'action':'batch_enable_tqh',**self.auth})
        code='GEN_261017_01';public=engine.public_code(self.c,code)
        self.assertEqual(public,code+'_TQH');self.assertEqual(engine.public_code(self.c,public),public)
        images=[]
        for index,name in enumerate(engine.IMAGES):
            file=engine.STORE/name;Image.new('RGB',(3000,3000),(index*25,80,90)).save(file)
            images.append({'name':name,'path':str(file),'sha256':engine.sha(file)})
        sources=[]
        for name in ['chest','sleeve']:
            file=engine.STORE/(name+'.png');Image.new('RGB',(80,80),'white').save(file);sources.append({'path':str(file),'sha256':engine.sha(file)})
        plan={'regions':{'center_chest':sources[0],'left_sleeve':sources[1],'right_sleeve':sources[1]}}
        j={'code':code,'revision':1,'plan':json.dumps(plan)}
        p={'payload':{'images':images},'fingerprint':'a'*64};text={'payload':{'title':'Fixture','description':'Fixture description','tags':['tag']}}
        original=engine.scoped
        def scope(value,*args):
            value=str(value).replace('\\','/')
            for base in ['C:/Huy/Đã xử lý/','C:/Huy/Chưa xử lý/']:
                if value.startswith(base):value=engine.STORE/'public'/value[len('C:/Huy/'):];break
            return original(value,*args)
        with patch.object(engine,'scoped',side_effect=scope):
            for _ in range(2):
                result=delivery_layout.package(self.c,j,p,text,'b'*64,'package','',vars(engine))
                folder=Path(result['destination']);self.assertEqual(folder.name,public);self.assertEqual(len(list(folder.iterdir())),8)
                self.assertTrue(all(x.name.startswith(public+'_') for x in folder.iterdir()))
                self.assertEqual({x['sha256'] for x in result['files'] if x['role'].startswith(('07_','08_'))},{x['sha256'] for x in sources})
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)

    @patch('review_transport.local_delivery', return_value=False)
    def test_entire_two_item_batch_process_export_and_kpi_with_fixture_providers(self, _legacy_delivery):
        import kpi_sync_orchestration as kpi
        self.execute({'action':'batch_enable_tqh',**self.auth})
        for n,entry in enumerate(self.submit['items'],1):entry.update(listing_code='UST_261015_%02d_TQH'%n)
        self.finish_images()
        self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        sheet='https://local-workspace.invalid/wiki/LOCAL_DESTINATION_REQUIRED'
        self.execute({'action':'set_kpi_sheet','url':sheet,**self.auth})
        original_scoped=engine.scoped
        def isolated_scope(p,*roots):
            normalized=str(p).replace('\\','/')
            for label,folder in [('raw','Chưa xử lý'),('processed','Đã xử lý')]:
                prefix='C:/Huy/'+folder+'/'
                if normalized.startswith(prefix):p=engine.STORE/'fixture-deliveries'/label/normalized[len(prefix):];break
            return original_scoped(p,*roots)
        completed=[]
        with patch.object(engine,'scoped',side_effect=isolated_scope):
            for unused in range(2):
                code=self.cycle()['production_jobs'][0]['listing_code']
                self.assertTrue(code.endswith('_TQH'))
                self.assertIn(code,[entry['listing_code'] for entry in self.submit['items']])
                reservation=self.c.execute('SELECT * FROM reservations WHERE code=?',(code,)).fetchone()
                self.assertEqual(reservation['topic'],'UST')
                self.assertEqual(reservation['target_date'],(engine.datetime.fromisoformat(engine.now()).astimezone(engine.TZ).date()+engine.timedelta(days=2)).isoformat())
                self.assertNotEqual(reservation['target_date'],'2026-10-15')
                registry_path=engine.JOBS/'registry.json'
                registry=engine.read(registry_path) if registry_path.exists() else {'jobs':{}}
                self.assertNotIn(code,registry['jobs'])
                state=self.execute({'action':'advance','listing_code':code})
                self.assertEqual(state['status'],'needs_text',state)
                j=engine.job(self.c,code)
                ready=engine.read(registry_path)['jobs'][code]
                self.assertEqual(ready['status'],'ready_for_title_description')
                self.assertEqual(ready['input_sha256'],j['source_hash'])
                self.assertTrue(ready['approval']['ai_text_generation_authorized'])
                self.assertIn('batch policy, no individual visual QA claimed',ready['approval']['reference'])
                self.assertEqual(self.c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0],0)
                processed=engine.artifact(self.c,j,'processed')['payload']['images']
                self.assertEqual(len(processed),6)
                route=engine.artifact(self.c,j,'processed')['payload']
                self.assertIn('fixture-deliveries',route['source_directory']);self.assertIn('raw',route['source_directory'])
                self.assertIn('processed',route['destination_directory'])
                for image in processed:
                    with Image.open(image['path']) as actual:self.assertEqual(actual.size,(3000,3000))
                keywords=[{'keyword':'fixture term '+str(n),'requested_filter':'physical','checked_at_utc':engine.now(),'evidence_status':'indexed_record','competition_level':'low','listing_count':80,'indexed_avg_listing_views':600,'indexed_avg_listing_views_24h':2,'provider_says_insufficient_data':False} for n in range(20)]
                title=('Fixture otter bakery sweater animal lover gift with cozy woodland characters for bakers and friends in casual everyday outfits' if unused==0 else
                       'Fixture otter garden sweater animal lover gift with cozy woodland characters for gardeners and friends in casual everyday outfits')
                text={'listing_code':code,'title':title.ljust(137,'!'),
                    'description':'Fixture neutral crewneck sweater copy.', 'tags':[x['keyword'] for x in keywords[:13]],
                    'keyword_evidence':keywords,'provenance':{'input_sha256':j['source_hash']},'keyword_provenance':{'keyword_policy':'ai_first_20_to_13_v1','source_hash':j['source_hash']}}
                self.execute({'action':'attach_text','listing_code':code,'text':text})
                state=self.execute({'action':'advance','listing_code':code});self.assertEqual(state['status'],'awaiting_lark_verification',state)
                task=state['browser_task'];packet=task['payload']['packet']
                report=engine.STORE/'lark-listing-readbacks'/(task['id']+'.json')
                actual={'ok':True,'task_id':task['id'],'task_fingerprint':task['fingerprint'],'document_url':engine.REVIEW_URL,
                    'observed_listing_code_count':1,'verified_after_readback':True,'official_api_origin':'https://open.larksuite.com',
                    'content':{'listing_code':code,'title':packet['title'],'description':packet['description'],'tags':packet['tags'],'thumbnail_sha256':packet['thumbnail']['sha256']}}
                engine.write(report,actual);actual.update(readback_path=str(report),readback_sha256=engine.sha(report))
                proof={'executor':'lark_docs_api','url':engine.REVIEW_URL,'content_fingerprint':packet['review_fingerprint'],
                    'verified_after_readback':True,'readback_path':str(report),'readback_sha256':engine.sha(report)}
                class Response:
                    def __enter__(self):
                        import io
                        return io.BytesIO(json.dumps(actual).encode())
                    def __exit__(self,*args):pass
                with patch('urllib.request.urlopen',return_value=Response()):self.execute({'action':'lark_listing_verified','task_id':task['id'],'proof':proof})
                state=self.execute({'action':'advance','listing_code':code});self.assertEqual(state['status'],'awaiting_kpi_sync',state)
                self.assertEqual(len(engine.artifact(self.c,j,'package')['payload']['files']),6)
                cycle=self.execute({'action':'kpi_sync_cycle'});task=cycle['tasks'][0]
                provider={'official_api_origin':'https://open.larksuite.com','read_response':{'code':0},'write_response':{'code':0},
                    'target_url':sheet,'spreadsheet_token':'fixture-sheet','sheet_id':'fixture-tab','range':'fixture-tab!A1:C3',
                    'readback_at':engine.now(),'rows':cycle['rows']}
                evidence={**provider,'executor':kpi.EXECUTOR,'verified_after_readback':True,'task_id':task['id'],'revision':task['revision'],
                    'task_fingerprint':task['fingerprint'],'rows_fingerprint':cycle['rows_fingerprint']}
                with tempfile.TemporaryDirectory(prefix='batch-kpi-fixture-',dir=engine.ROOT/'workspace/kpi-worker') as tmp:
                    file=Path(tmp)/'proof.json';engine.write(file,evidence)
                    command={'action':'kpi_sync_verified','task_id':task['id'],'revision':task['revision'],'task_fingerprint':task['fingerprint'],
                        'rows_fingerprint':cycle['rows_fingerprint'],'target_url':sheet,
                        'proof':{'executor':kpi.EXECUTOR,'verified_after_readback':True,'path':str(file),'sha256':engine.sha(file)}}
                    with patch.object(kpi,'canonical_readback',return_value=provider):self.execute(command)
                self.assertEqual(engine.job(self.c,code)['state'],'completed');completed.append(code)
                self.cycle()
                repaired=self.execute({'action':'batch_repair_outputs','batch_id':'fixture-batch','listing_code':code,**self.auth})
                self.assertTrue(repaired['image_bytes_unchanged']);self.assertTrue(repaired['kpi_unchanged'])
                raw=engine.artifact(self.c,engine.job(self.c,code),'images')['payload']
                regions={x['name']:{'source_sha256':x['sha256'],'box':[1,1,3,3]} for x in raw}
                wrong=copy.deepcopy(regions);wrong[raw[0]['name']]['source_sha256']='0'*64
                with self.assertRaisesRegex(ValueError,'source binding'):
                    self.execute({'action':'batch_correct_logos','batch_id':'fixture-batch','listing_code':code,'logo_regions':wrong,**self.auth})
                fixed=self.execute({'action':'batch_correct_logos','batch_id':'fixture-batch','listing_code':code,'logo_regions':regions,**self.auth})
                self.assertEqual(fixed['destination'],repaired['destination']);self.assertTrue(fixed['kpi_unchanged'])
                self.assertEqual(len(list(Path(fixed['destination']).iterdir())),6)
                self.assertTrue(all(x.name.startswith(code+'_') and x.suffix=='.jpg' for x in Path(fixed['destination']).iterdir()))
                self.assertEqual(fixed['visual_qa'],'pending_user_review')
                self.assertEqual(self.execute({'action':'batch_correct_logos','batch_id':'fixture-batch','listing_code':code,'logo_regions':regions,**self.auth})['destination'],fixed['destination'])
                legacy=Path(fixed['destination'])/'processed-v001-legacy';legacy.mkdir();legacy_image=legacy/'old.jpg'
                legacy_image.write_bytes(raw[0] and Path(raw[0]['path']).read_bytes());old_hash=engine.sha(legacy_image)
                cleaned=self.execute({'action':'batch_compact_outputs','batch_id':'fixture-batch','listing_code':code,**self.auth})
                self.assertEqual(cleaned['image_count'],6);self.assertFalse(cleaned['generation_called'])
                self.assertEqual(len(list(Path(cleaned['destination']).iterdir())),6)
                self.assertEqual(engine.sha(engine.scoped(legacy_image)),old_hash)
                task_count=self.c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]
                terminal=self.execute({'action':'advance','listing_code':code})
                self.assertEqual(terminal['status'],'completed');self.assertFalse(terminal['generation_called'])
                self.c.execute("DELETE FROM artifacts WHERE code=? AND kind='package'",(code,))
                with self.assertRaisesRegex(ValueError,'reconcile without generating'):
                    engine.advance(self.c,engine.job(self.c,code))
                engine.put(self.c,engine.job(self.c,code),'package',terminal['package'])
                self.assertEqual(self.c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0],task_count)
                self.cycle()
            self.assertEqual(batch.batch(self.c,'fixture-batch')['status'],'completed')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],2)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0],0)
        self.assertEqual(len(set(completed)),2)


    def skip_fixture(self,profile3=False):
        if profile3:self.submit['profile_version']=3
        t,cmd,review=self.first_sample();batch.sample_decision(self.c,self.decision(review),self.env)
        t=self.cycle()['tasks'][0];candidate=self.candidate(t);key=t['payload']['images'][1]['name']
        env={**self.env,'ROOT':engine.STORE}
        journal=env['ROOT']/'workspace/flow-worker/runtime'/('task-'+hashlib.sha256(t['id'].encode()).hexdigest()+'.json')
        engine.write(journal,{'task_id':t['id'],'fingerprint':t['fingerprint'],'revision':t['revision'],'images':{key:{'status':'generation_started','generation_id':'failed-fixture'}}})
        command={'action':'flow_cycle',**self.auth,'mockup_skip':{'task_id':t['id'],'task_fingerprint':t['fingerprint'],'revision':t['revision'],'image_key':key,'generation_id':'failed-fixture',
                 'evidence':{'screenshot_path':candidate['proof']['screenshot_path'],'screenshot_sha256':candidate['proof']['screenshot_sha256'],'failed_tiles':['Failed This generation might violate our policies.']}}}
        return t,candidate,key,command,env,journal

    def test_native_skip_requires_exact_failed_mockup_preserves_payload_and_submits_only_remaining_views(self):
        t,candidate,key,command,env,journal=self.skip_fixture();before=dict(self.c.execute('SELECT * FROM production_batch_tasks WHERE id=?',(t['id'],)).fetchone())
        for change in ['revision','task_fingerprint','generation_id','evidence']:
            bad=copy.deepcopy(command);bad['mockup_skip'][change]=({**bad['mockup_skip']['evidence'],'failed_tiles':['Failed Usage limit']} if change=='evidence' else 'wrong')
            with self.subTest(change=change),self.assertRaises(ValueError):batch.skip_mockup(self.c,bad,env)
        self.assertEqual(batch.skipped_task(self.c,t['id']),[])
        receipt=batch.skip_mockup(self.c,command,env);self.assertEqual(batch.skip_mockup(self.c,command,env),receipt)
        self.assertEqual(dict(self.c.execute('SELECT * FROM production_batch_tasks WHERE id=?',(t['id'],)).fetchone()),before)
        self.assertEqual(batch.queue(self.c)[0]['skipped_images'],[receipt])
        with self.assertRaisesRegex(ValueError,'exact requested'):self.execute(candidate)
        filtered=copy.deepcopy(candidate)
        filtered['assets']=[a for a in filtered['assets'] if a['image_key']!=key]
        for group in ['images','prompt_provenance']:filtered['proof'][group]=[x for x in filtered['proof'][group] if x['image_key']!=key]
        self.execute(filtered)
        images=json.loads(batch.item(self.c,t['batch_id'],t['item_id'])['images']);self.assertNotIn(key,images);self.assertEqual(len(images),5)
        self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        with patch('review_transport.local_delivery',return_value=False):code=self.cycle()['production_jobs'][0]['listing_code']
        j=engine.job(self.c,code);self.assertEqual(json.loads(j['plan'])['skipped_mockups'],[key])
        original=engine.scoped
        def scope(p,*roots):
            s=str(p).replace('\\','/')
            if s.startswith('C:/Huy/Chưa xử lý/') or s.startswith('C:/Huy/Đã xử lý/'):p=engine.STORE/'skip-delivery'/s.removeprefix('C:/Huy/')
            return original(p,*roots)
        with patch.object(engine,'scoped',side_effect=scope):
            state=self.execute({'action':'advance','listing_code':code});self.assertEqual(state['status'],'needs_text')
            processed=engine.artifact(self.c,j,'processed');self.assertEqual(len(processed['payload']['images']),5)
            import delivery_layout,google_delivery,zipfile
            text={'payload':{'title':'Fixture title','description':'Fixture description','tags':['fixture']}}
            package=delivery_layout.package(self.c,j,processed,text,'b'*64,'package','',vars(engine));self.assertEqual(package['skipped_mockups'],[key]);self.assertEqual(len(package['files']),5)
            archive=google_delivery.zip_package(j,package,vars(engine))
            with zipfile.ZipFile(archive) as z:self.assertEqual(len(z.namelist()),5);self.assertFalse(any(key in n for n in z.namelist()))
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)

    def test_skip_rejects_representative_design_acquired_image_and_bad_evidence(self):
        t,candidate,key,command,env,journal=self.skip_fixture()
        for texts in [[],['Failed Image could not be generated.'],['Failed This generation might violate our policies. Unusual activity'],['Failed This generation might violate our policies. Content was blocked.']]:
            bad=copy.deepcopy(command);bad['mockup_skip']['evidence']['failed_tiles']=texts
            with self.subTest(texts=texts),self.assertRaises(ValueError):batch.skip_mockup(self.c,bad,env)
        bad=copy.deepcopy(command);bad['mockup_skip']['evidence']['screenshot_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'evidence changed'):batch.skip_mockup(self.c,bad,env)
        saved=engine.read(journal);saved['images'][key]['status']='acquired';engine.write(journal,saved)
        with self.assertRaisesRegex(ValueError,'acquired assets'):batch.skip_mockup(self.c,command,env)
        bad=copy.deepcopy(command);bad['mockup_skip']['task_id']='design-task'
        with self.assertRaisesRegex(ValueError,'never a design'):batch.skip_mockup(self.c,bad,env)
        self.c.execute("UPDATE production_batch_tasks SET stage='sample_mockup' WHERE id=?",(t['id'],))
        with self.assertRaisesRegex(ValueError,'representative review'):batch.skip_mockup(self.c,command,env)

    def test_profile3_skip_keeps_the_versioned_names_and_cannot_remove_every_requested_view(self):
        import production_profiles
        t,candidate,key,command,env,journal=self.skip_fixture(True)
        payload=t['payload'];self.assertEqual(payload['profile_version'],3)
        saved=engine.read(journal)
        for image in payload['images']:saved['images'][image['name']]={'status':'generation_started','generation_id':'failed-fixture'}
        engine.write(journal,saved)
        for image in payload['images'][:-1]:
            command['mockup_skip']['image_key']=image['name'];batch.skip_mockup(self.c,command,env)
        command['mockup_skip']['image_key']=payload['images'][-1]['name']
        with self.assertRaisesRegex(ValueError,'acquired view required'):batch.skip_mockup(self.c,command,env)
        b=batch.batch(self.c,t['batch_id']);i=batch.item(self.c,t['batch_id'],t['item_id'])
        self.assertEqual(batch.item_names(self.c,b,i),[production_profiles.PRINT[0],production_profiles.PRINT[-1]])
        with self.assertRaises(ValueError):engine.verify_assets([])
        with self.assertRaises(ValueError):production_profiles.names({'profile_version':3,'product_kind':'apparel_2d','skipped_mockups':production_profiles.PRINT})

def uuidhex(s):return hashlib.sha256(s.encode()).hexdigest()[:20]

if __name__=='__main__':unittest.main(verbosity=2)
