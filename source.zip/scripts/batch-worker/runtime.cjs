'use strict';
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { timingSafeEqual, createHash } = require('node:crypto');
const { NativeN8n, atomic, claimProcessLock } = require('../flow-worker/native-n8n.cjs');
const { LarkListing } = require('./lark-listing.cjs');
const read = f => JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, ''));
class BatchRuntime {
  poolMode(){const file=path.join(this.config.workflowRoot,'config/flow-worker-pool.private.json');return fs.existsSync(file)&&read(file).enabled===true;}
  errorHoldFile(){
    const base=path.join(this.config.stateDir,'workflow-error-hold.json');
    if(!this.poolMode())return base;
    const file=path.join(this.config.workflowRoot,'workspace/flow-worker/runtime/pool-state.private.json');
    const lane=fs.existsSync(file)?read(file).lanes.find(x=>x.batch_id===this.currentBatch):null;
    return lane?path.join(this.config.workflowRoot,'workspace/flow-worker',lane.id===1?'runtime':`lanes/chrome-${lane.id}/runtime`,'workflow-error-hold.json'):base;
  }
  constructor(config, deps = {}) { this.config = config; this.native = deps.native || new NativeN8n(config); this.publisher = deps.publisher || new LarkListing(config); this.fetch = deps.fetch || fetch; this.stopping = false; fs.mkdirSync(config.stateDir, { recursive: true }); this.notices = fs.existsSync(path.join(config.stateDir, 'notices.json')) ? read(path.join(config.stateDir, 'notices.json')) : {}; }
  status(value) { atomic(path.join(this.config.stateDir, 'status.json'), { ...value, build: '20261024-codex-quota1', pid: process.pid, updated_at: new Date().toISOString() }); return value; }
  async block(error) {
    if(this.stopping)return this.status({status:'stopped'});
    const code = /^[a-z0-9_]{1,100}$/.test(error.code || error.message) ? error.code || error.message : 'batch_runtime_failed';
    if(code!=='native_execution_busy'&&this.currentBatch){
      let stop_pending=false;
      try{await require('../workflow-error-stop.cjs').stopOnError(this.native,this.errorHoldFile(),{batch_id:this.currentBatch,batch_fingerprint:this.productionScope?.batch_fingerprint,code,listing_code:this.productionScope?.listing_code});}
      catch{stop_pending=true;}
      const value=this.status({status:'awaiting_repair',code,batch_id:this.currentBatch,automatic_retry:false,stop_pending,requires_user_resume:true});
      try{await this.notify({status:'batch_worker_blocked',batch_id:this.currentBatch,error:code});}catch{/* Durable notice is retried without advancing production. */}
      return value;
    }
    const value = this.status({ status: code === 'native_execution_busy' ? 'waiting_native_execution' : 'blocked', code, batch_id: this.currentBatch });
    if (code !== 'native_execution_busy') {
      try { await this.notify({ status: 'batch_worker_blocked', batch_id: this.currentBatch, error: code }); } catch { /* Retry after the next native cycle. */ }
    }
    return value;
  }
  async pauseRepeatedFailure(failure){
    const snapshot=await this.native.execute({action:'batch_status',batch_id:failure.batch_id});
    const batch=snapshot.ok===true?snapshot.batches?.find(b=>b.batch_id===failure.batch_id):null;
    if(!batch||batch.fingerprint!==failure.batch_fingerprint)throw Error('failure_pause_binding_changed');
    if(batch.status==='active'){
      const stopped=await this.native.execute({action:'batch_stop',batch_id:batch.batch_id,batch_fingerprint:batch.fingerprint,authority:'direct_user',reference:'Workflow3 user 21/10/2026 authorized automatic failure recovery; pause after three repeated production errors; preserve checkpoints and completed work'});
      if(stopped.status!=='batch_stopped')throw Error('repeated_failure_pause_failed');
    }
    if(['active','stopped'].includes(batch.status)){
      atomic(path.join(this.config.stateDir,'production-failure.json'),{...failure,attempts:0,halted_after:failure.attempts,paused_at:new Date().toISOString()});
      await this.notify({status:'batch_repeated_failure_paused',batch_id:batch.batch_id,error:failure.code,listing_code:failure.listing_code});
      return this.status({status:'awaiting_repair',code:failure.code,batch_id:batch.batch_id,listing_code:failure.listing_code,attempts:failure.attempts,automatic_retry:false});
    }
    return this.status({status:'failure_scope_changed',batch_id:batch.batch_id,automatic_retry:false});
  }
  keywordLimit(job) {
    if (!this.config.commandFile || !/^[A-Z]{2,5}_\d{6}_\d{2}(?:_[A-Z0-9]+)?$/.test(job.listing_code || '')) return null;
    const base = path.dirname(this.config.commandFile), source = path.join(base, 'jobs', job.listing_code + '.json');
    const directory = path.resolve(base, '../etsy-keywords/checkpoints', job.listing_code);
    if (!fs.existsSync(source) || !fs.existsSync(directory)) return null;
    const sourceHash = createHash('sha256').update(fs.readFileSync(source)).digest('hex');
    const failures = [];
    for (const set of fs.readdirSync(directory).filter(name => /^[a-f0-9]{64}$/.test(name))) {
      for (const name of fs.readdirSync(path.join(directory, set)).filter(name => /^\d{2}\.json$/.test(name))) {
        const file = path.join(directory, set, name), record = read(file);
        if (record.status !== 'failed' || record.listing_code !== job.listing_code || record.input_sha256 !== sourceHash || record.candidate_set_hash !== set) continue;
        const age = Date.now() - Date.parse(record.checked_at_utc);
        if (!Number.isFinite(age) || age < 0 || age >= 86400000) continue;
        let error = record.raw_mcp_result?.error;
        if (typeof error?.message === 'string') { try { error = JSON.parse(error.message); } catch { continue; } }
        if (error?.error_kind === 'fair_use_limited' && error.retryable === false) failures.push({ path: file, checked_at_utc: record.checked_at_utc, sha256: createHash('sha256').update(fs.readFileSync(file)).digest('hex') });
      }
    }
    failures.sort((a, b) => Date.parse(b.checked_at_utc) - Date.parse(a.checked_at_utc));
    const limit = failures[0], marker = path.join(this.config.stateDir, 'keyword-limit-' + job.listing_code + '.json');
    // An explicit later resume may try again; the same recorded limit must not immediately stop it twice.
    if (!limit || (fs.existsSync(marker) && read(marker).sha256 === limit.sha256)) return null;
    return { ...limit, marker };
  }
  async notify(result) {
    if (result.status === 'batch_completed' && Array.isArray(result.completion_reports)) return;
    if (!result.batch_id) return;
    const key = JSON.stringify([result.status, result.active_item?.item_id, result.active_item?.state, result.error]);
    if (this.notices[result.batch_id] === key) return;
    const c = read(this.config.larkConfigFile);
    const text = result.status === 'batch_completed' ? `Đã hoàn tất mẻ ${result.batch_id}. File đầu ra và KPI đã được xác nhận.` :
      result.status === 'awaiting_kpi_activation' ? `Mẻ ${result.batch_id} đã có ảnh, đang chờ nghiệm thu lần đầu để cấp mã và xuất listing. Khi bạn đã kiểm tra và chấp nhận hệ thống, gửi NGHIỆM THU WORKFLOW để bật KPI một lần; các mẻ sau không cần bật lại.` :
      result.status === 'batch_item_failed' ? `Mẻ ${result.batch_id} dừng ở mẫu ${result.active_item?.item_id || ''}: ${result.error}. Gửi THỬ LẠI ${result.batch_id} ${result.active_item?.item_id || ''} sau khi xử lý lỗi.` :
      result.status === 'batch_worker_blocked' && result.error === 'ytrends_fair_use_limited' ? `Mẻ ${result.batch_id} đang chờ vì YTrends báo hết ngân sách nghiên cứu của phiên (fair_use_limited, retryable=false). Kết quả hợp lệ và ảnh được giữ nguyên. Không tự thử lại hoặc đổi phiên; chỉ tiếp tục sau khi giới hạn được gỡ và bạn cho chạy lại.` :
      result.status === 'batch_worker_blocked' && result.error === 'codex_usage_limit_exceeded' ? `Mẻ ${result.batch_id} đã dừng vì Codex báo hết hạn mức sử dụng. Ảnh, Title, keyword và các lượt duyệt đã có được giữ nguyên. Kiểm tra hạn mức trong Codex; khi dùng được trở lại, bấm Tiếp tục mẻ. Không tự thử lại hoặc đổi tài khoản.` :
      result.status === 'keyword_signal_shortfall' ? `Mẫu ${result.listing_code}: đã kiểm tra 20 tags, có ${result.eligible_count}/13 tags đạt điều kiện view và cạnh tranh thấp/trung bình. Giữ kết quả, không tìm bổ sung và chưa xuất nội dung/KPI cho mẫu này.` :
      result.status === 'keyword_candidate_shortfall' ? `Mẫu ${result.listing_code}: lượt tìm Ytrend có ${result.discovered_count} cụm trong dữ liệu${Number.isInteger(result.relevant_candidate_count)?`, ${result.relevant_candidate_count}/20 ứng viên phù hợp`:''}. Mẻ đã tạm dừng, giữ ảnh và nội dung đã làm; không tìm bổ sung hoặc gọi AI lặp lại để ép đủ số.` :
      result.status === 'batch_repeated_failure_paused' ? `Mẻ ${result.batch_id} đã tạm dừng sau 3 lần lỗi ở mẫu ${result.listing_code}: ${result.error}. Đã giữ checkpoint, ngừng thử lặp; Codex sẽ kiểm tra theo lịch theo dõi lỗi.` :
      result.status === 'batch_worker_blocked' ? `Mẻ ${result.batch_id} đã dừng vì lỗi: ${result.error}. Giữ checkpoint; không tự chạy lại. Sửa lỗi rồi bấm Tiếp tục mẻ.` :
      result.status === 'batch_run_plan_blocked' ? `Danh sách chạy đêm đã dừng ở mẻ ${result.batch_id}: nguồn hoặc nhận xét đã đổi sau khi duyệt. Mở menu, kiểm tra và giao lại đúng phiên bản; các mẻ khác chưa tự chạy.` :
      `Mẻ ${result.batch_id} · ${result.status} · mẫu ${result.active_item?.item_id || ''}: ${result.active_item?.state || ''}`;
    const stopped=['batch_worker_blocked','batch_repeated_failure_paused','batch_item_failed','batch_run_plan_blocked','keyword_candidate_shortfall','keyword_signal_shortfall'].includes(result.status);
    const response = await this.fetch('http://127.0.0.1:8790/batch-result', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': c.localToken }, body: JSON.stringify({ batch_id: result.batch_id, event_id: 'progress-' + result.batch_id + '-' + createHash('sha256').update(key).digest('hex').slice(0, 32), message: text, ...(stopped?{notification_kind:'workflow_stopped'}:{}) }), signal: AbortSignal.timeout(5000), redirect: 'error' });
    if (!response.ok) throw Error('batch_progress_notification_pending');
    this.notices[result.batch_id] = key; atomic(path.join(this.config.stateDir, 'notices.json'), this.notices);
  }
  async notifyCompletions(reports) {
    if (!reports?.length) return;
    const file = path.join(this.config.stateDir, 'completion-notices.json');
    if (!this.completions) {
      this.completions = fs.existsSync(file) ? read(file) : {};
      if (!fs.existsSync(file)) {
        const batches = reports.filter(r => r.kind === 'batch_completed');
        const current = new Set([batches.at(-1)?.batch_id, ...reports.filter(r => r.kind === 'group_completed').flatMap(r => r.batch_ids)]);
        for (const report of batches) {
          const alreadySent = this.notices[report.batch_id]?.startsWith('["batch_completed",');
          if (alreadySent || !current.has(report.batch_id)) this.completions[report.report_id] = { status: alreadySent ? 'previously_reported' : 'before_upgrade' };
        }
        atomic(file, this.completions);
      }
    }
    for (const report of reports) {
      let notice = this.completions[report.report_id];
      if (notice && notice.status !== 'pending') continue;
      if (!notice) {
        const lines = report.kind === 'google_completed'
          ? ['✅ ĐÃ ĐỒNG BỘ GOOGLE', report.listing_codes.join(', '), ...report.google_files.map(f => f.path.join('/') + '\n' + f.url)]
          : report.kind === 'group_completed'
          ? [`✅ ĐÃ XONG CẢ NHÓM ${report.batches.length} MẺ`, `${report.completed_count}/${report.item_count} mẫu hoàn tất.`,
            ...report.batches.map(b => `• ${b.listing_codes[0]}${b.listing_codes.length > 1 ? ' → ' + b.listing_codes.at(-1) : ''}: ${b.completed_count}/${b.item_count} mẫu`)]
          : ['✅ ĐÃ XONG MẺ', `${report.completed_count}/${report.item_count} mẫu hoàn tất · ${report.file_count} ảnh.`,
            report.listing_codes.join(', '), ...(report.cancelled_count ? [`Đã hủy: ${report.cancelled_count} mẫu.`] : []),
            ...report.output_directories.map(p => 'Ảnh: ' + p)];
        lines.push(`KPI đã xác nhận: ${report.kpi_count} listing.`);
        if (report.google_pending > 0) lines.push(report.google_enabled ? `Google đang chờ đồng bộ: ${report.google_pending} mẫu. Sẽ báo riêng khi xong.` : 'File đã xong trên máy. Google đang chờ kết nối tài khoản.');
        if (report.docs_url) lines.push('Nội dung Docs: ' + report.docs_url);
        if (report.kpi_url) lines.push('Bảng KPI: ' + report.kpi_url);
        notice = this.completions[report.report_id] = { status: 'pending', batch_id: report.batch_id, event_id: report.report_id, message: lines.join('\n'), ...(report.documents?.length?{documents:report.documents}:{}) };
        atomic(file, this.completions);
      }
      const c = read(this.config.larkConfigFile);
      const response = await this.fetch('http://127.0.0.1:8790/batch-result', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': c.localToken },
        body: JSON.stringify({ batch_id: notice.batch_id, event_id: notice.event_id, message: notice.message, ...(notice.documents?{documents:notice.documents}:{}) }), signal: AbortSignal.timeout(5000), redirect: 'error' });
      if (!response.ok) throw Error('batch_completion_notification_pending');
      notice.status = 'queued'; notice.queued_at = new Date().toISOString(); atomic(file, this.completions);
    }
  }
  async tick() {
    const errorHold=path.join(this.config.stateDir,'workflow-error-hold.json');
    if(fs.existsSync(errorHold)&&!this.poolMode()){const hold=read(errorHold);this.currentBatch=hold.batch_id;return this.block(Error(hold.code));}
    this.productionScope=null;
    const result = await this.native.execute({ action: 'batch_cycle' });
    this.currentBatch = result.batch_id || null;
    if (!result.ok || !Array.isArray(result.production_jobs || [])) throw Error('batch_cycle_invalid');
    await this.notifyCompletions(result.completion_reports);
    for (const job of result.production_jobs || []) {
      if (this.stopping) break;
      const limit = this.keywordLimit(job);
      if (limit) {
        const policy = this.config.researchLimitPause;
        if (policy?.batch_id === result.batch_id && typeof policy.reference === 'string' && policy.reference.trim()) {
          const stopped = await this.native.execute({ action: 'batch_stop', batch_id: result.batch_id, batch_fingerprint: result.batch_fingerprint, authority: 'direct_user', reference: policy.reference });
          if (stopped.ok !== true || stopped.status !== 'batch_stopped') throw Error('keyword_limit_pause_failed');
          atomic(limit.marker, { ...limit, batch_id: result.batch_id, listing_code: job.listing_code, paused_at: new Date().toISOString() });
        }
        return this.block(Error('ytrends_fair_use_limited'));
      }
      // Title, candidates and tag selection each allow 330s; the whole pipeline needs a longer budget.
      this.productionScope={batch_id:result.batch_id,batch_fingerprint:result.batch_fingerprint,listing_code:job.listing_code,revision:job.revision??result.active_item?.revision??null};
      const failureFile=path.join(this.config.stateDir,'production-failure.json'),previous=fs.existsSync(failureFile)?read(failureFile):null;
      if(previous?.attempts>=3&&['batch_id','batch_fingerprint','listing_code','revision'].every(k=>previous[k]===this.productionScope[k]))return this.pauseRepeatedFailure(previous);
      this.status({status:'production_running',...this.productionScope});
      const state = await this.native.execute({ action: 'advance', listing_code: job.listing_code }, { timeoutMs: 1800000 });
      this.productionScope=null;
      if(previous)atomic(failureFile,{...previous,attempts:0,resolved_at:new Date().toISOString()});
      if(['keyword_candidate_shortfall','keyword_signal_shortfall'].includes(state.status)){
        const stopped=await this.native.execute({action:'batch_stop',batch_id:result.batch_id,batch_fingerprint:result.batch_fingerprint,authority:'direct_user',reference:'Workflow3 user 21/10/2026: no keyword expansion on shortfall; protective pause of this exact batch to preserve work and prevent repeat AI calls'});
        if(stopped.status!=='batch_stopped')throw Error('keyword_shortfall_pause_failed');
        await this.notify({...state,batch_id:result.batch_id});
        return this.status({status:'awaiting_keyword_review',code:state.status,batch_id:result.batch_id,listing_code:job.listing_code,eligible_count:state.eligible_count,discovered_count:state.discovered_count,additional_search_on_shortfall:false});
      }
      if (state.status === 'awaiting_lark_verification' && state.browser_task?.kind === 'lark_review') {
        const task = state.browser_task;
        if (typeof task.payload === 'string') task.payload = JSON.parse(task.payload);
        const file = path.join(this.config.stateDir, 'pending-' + task.id + '.json');
        let pending = fs.existsSync(file) ? read(file) : null;
        if (!pending) {
          const proof = await this.publisher.deliver(task, { beforeWrite: async () => {
            const live = await this.native.execute({ action: 'status', listing_code: job.listing_code });
            if (live.revision !== task.revision || live.state !== 'awaiting_lark_verification') throw Error('listing_task_superseded');
          } });
          pending = { action: 'lark_listing_verified', task_id: task.id, proof }; atomic(file, pending);
        }
        await this.native.execute(pending);
        await this.native.execute({ action: 'advance', listing_code: job.listing_code });
      }
    }
    await this.notify(result);
    if(require('../review-transport.cjs').choice(this.config.workflowRoot).delivery_backend!=='local_v1'&&['batch_idle','batch_completed'].includes(result.status)&&fs.existsSync(path.join(this.config.workflowRoot,'config/thumbnail-copy.json'))){
      const scan=await this.native.execute({action:'thumbnail_scan'});
      if(scan.next_item){
        this.status({status:'thumbnail_copy_running',copy_id:scan.next_item.id});
        this.copyNative||=new NativeN8n({...this.config,mainWorkflowId:'EtsyThumbnailCopyV1',nativeTimeoutMs:1800000});
        let copy;
        try{copy=await this.copyNative.execute({copy_id:scan.next_item.id});}
        catch(error){
          const deferred=await this.native.execute({action:'thumbnail_defer',copy_id:scan.next_item.id});
          return this.status({status:deferred.status,copy_id:scan.next_item.id,code:'thumbnail_copy_check_report',reasons:deferred.reasons});
        }
        return this.status({status:copy.status,copy_id:copy.copy_id,listing_code:copy.listing_code,url:copy.url});
      }
    }
    return this.status({ status: result.status || 'idle', batch_id: result.batch_id || null, active_item: result.active_item || null });
  }
  stop() { this.stopping = true; this.native.stop();this.copyNative?.stop(); }
}
function makeReadbackServer(config, publisher) {
  return http.createServer(async (req, res) => {
    const answer = (status, body) => { res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(body)); };
    if (req.method === 'GET' && req.url === '/health') return answer(200, { ok: true, service: 'lark-listing-readback' });
    const token = read(config.larkConfigFile).localToken, got = Buffer.from(String(req.headers['x-review-token'] || '')), expected = Buffer.from(token);
    if (got.length !== expected.length || !timingSafeEqual(got, expected)) return answer(401, { ok: false, code: 'unauthorized' });
    if(req.method==='POST'&&['/listing-hub/prepare','/listing-hub/deliver','/listing-hub/relabel'].includes(req.url)){
      try{
        if(req.url.endsWith('/prepare'))return answer(200,await publisher.prepareHub());
        let body='';for await(const b of req){body+=b;if(body.length>4096)throw Error('listing_hub_request_too_large');}
        const input=JSON.parse(body);if(!/^(?:hub2|tqh)-[A-Za-z0-9_-]{1,90}$/.test(input.task_id||''))throw Error('listing_hub_task_invalid');
        const task=read(path.join(config.workflowRoot,'workspace/production/layout-migration/tasks',input.task_id+'.json'));
        if(task.fingerprint!==input.task_fingerprint)throw Error('listing_hub_fingerprint_changed');
        if(req.url.endsWith('/relabel')){
          if(!/^hub2-[A-Za-z0-9_-]{1,90}$/.test(input.source_task_id||''))throw Error('listing_hub_source_invalid');
          return answer(200,await publisher.relabel(input.source_task_id,task));
        }
        await publisher.deliver(task);return answer(200,await publisher.inspect(task.id));
      }catch(e){return answer(409,{ok:false,code:e.code||e.message||'listing_hub_failed'});}
    }
    if(req.url.startsWith('/thumbnail-')||req.url.startsWith('/copy-')){
      try{if(await require('./thumbnail-server.cjs').handle(req,res,config,publisher,answer))return;}
      catch(e){return answer(409,{ok:false,code:e.code||e.message||'thumbnail_copy_failed'});}
    }
    const match = /^\/lark-listing\/([A-Za-z0-9_-]{1,100})$/.exec(req.url);
    const layout=/^\/lark-layout\/([A-Za-z0-9_-]{1,100})$/.exec(req.url);
    if(req.method==='POST'&&layout){
      try{let body='';for await(const bytes of req){body+=bytes;if(body.length>2048)throw Error('layout_request_too_large');}
        const input=JSON.parse(body);if(!/^[a-f0-9]{64}$/.test(input.expected_fingerprint||''))throw Error('layout_fingerprint_required');
        return answer(200,await publisher.repairLayout(layout[1],input.expected_fingerprint));
      }catch(e){return answer(409,{ok:false,code:e.code||'listing_layout_repair_failed'});}
    }
    if (req.method !== 'GET' || !match) return answer(404, { ok: false, code: 'route_not_found' });
    try { return answer(200, await publisher.inspect(match[1])); } catch (e) { return answer(409, { ok: false, code: e.code || 'listing_readback_unavailable' }); }
  });
}
async function main() {
  const base = read(process.env.FLOW_WORKER_CONFIG || 'C:/Huy/etsy-workflow/config/flow-worker.private.json');
  const config = { ...base, stateDir: path.join(base.workflowRoot, 'workspace/batch-worker/runtime'), logDir: path.join(base.workflowRoot, 'logs/batch-worker'), brokerPort: 5691 };
  fs.mkdirSync(config.stateDir, { recursive: true });
  const publisher = new LarkListing(config);
  if (process.argv.includes('--check')) { console.log(JSON.stringify({ ok: true, docs: await publisher.readiness(), generation_called: false })); return; }
  const release = claimProcessLock(path.join(config.stateDir, 'worker.lock'), 'batch-worker'), runtime = new BatchRuntime(config, { publisher });
  const stopFile = path.join(config.stateDir, 'stop.request'); if (fs.existsSync(stopFile)) fs.unlinkSync(stopFile);
  const server = makeReadbackServer(config, publisher); server.on('error', () => runtime.stop()); server.listen(8792, '127.0.0.1');
  const stopWatch = fs.watch(config.stateDir, () => { if (fs.existsSync(stopFile)) runtime.stop(); });
  process.once('SIGINT', () => runtime.stop()); process.once('SIGTERM', () => runtime.stop());
  try { while (!runtime.stopping) { try { await runtime.tick(); } catch (e) { await runtime.block(e); }
    if (process.argv.includes('--once')) break;
    await new Promise(resolve => { const timer = setTimeout(done, 30000), watcher = fs.watch(config.stateDir, (_e, name) => { if (String(name) === 'stop.request') done(); }); function done() { clearTimeout(timer); watcher.close(); resolve(); } });
  } } finally { runtime.stop(); stopWatch.close(); server.close(); release(); }
}
if (require.main === module) main().catch(() => { console.error('batch_worker_start_failed'); process.exitCode = 1; });
module.exports = { BatchRuntime, makeReadbackServer };
