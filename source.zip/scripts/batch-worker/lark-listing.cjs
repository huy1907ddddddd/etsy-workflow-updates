'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { atomic } = require('../flow-worker/native-n8n.cjs');
const TARGET = 'LOCAL_BINDING_URL';
const ORIGIN = 'https://open.larksuite.com';
const hash = b => createHash('sha256').update(b).digest('hex');
const fail = code => { throw Object.assign(new Error(code), { code }); };
const textOf = block => Object.values(block).find(v => v && Array.isArray(v.elements))?.elements.map(x => x.text_run?.content || '').join('') || '';
const paragraph = text => ({ block_type: 2, text: { elements: [{ text_run: { content: text } }] } });
const heading = text => ({block_type:3,heading1:{elements:[{text_run:{content:text}}]}});
const subheading=text=>({block_type:4,heading2:{elements:[{text_run:{content:text}}]}});
const fieldHeading=text=>({block_type:5,heading3:{elements:[{text_run:{content:text}}]}});
const fieldText=(value,label)=>value.startsWith(label+':\n')?value.slice(label.length+2):value;
function desired(task,target=TARGET) {
  const p = task.payload?.packet;
  if (task.kind !== 'lark_review' || task.status !== 'pending' || !p || p.listing_code !== task.code || p.revision !== task.revision || !/^[a-f0-9]{64}$/.test(p.review_fingerprint || '') || ![TARGET,target].includes(task.payload.url)) fail('listing_task_invalid');
  if (!p.title || !p.description || !Array.isArray(p.tags) || p.tags.length !== 13 || !/^[a-f0-9]{64}$/.test(p.thumbnail?.sha256 || '')) fail('listing_packet_invalid');
  return p;
}
class LarkListing {
  constructor(config, deps = {}) { this.config = config; this.client = deps.client; this.now = deps.now || Date.now; fs.mkdirSync(config.stateDir, { recursive: true }); }
  layout(){const f=path.join(this.config.workflowRoot,'config/listing-layout.json');return fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')):{};}
  target(){return this.layout().url||TARGET;}
  connect() {
    if (this.client) return;
    const c = JSON.parse(fs.readFileSync(this.config.larkConfigFile, 'utf8').replace(/^\uFEFF/, ''));
    const lark = require('../lark-review/node_modules/@larksuiteoapi/node-sdk');
    const logger = Object.fromEntries(['trace', 'debug', 'info', 'warn', 'error', 'fatal'].map(k => [k, () => {}]));
    this.client = new lark.Client({ appId: c.appId, appSecret: c.appSecret, domain: lark.Domain.Lark, logger });
  }
  async request(method, url, extras = {}) {
    this.connect(); let r;
    try { r = await this.client.request({ method, url: ORIGIN + url, timeout: 20000, maxRedirects: 0, ...extras }); }
    catch (e) { fail(e.response?.data?.code === 99991672 ? 'listing_docs_scope_required' : [403, 400].includes(e.response?.status) ? 'listing_doc_access_required' : 'listing_docs_api_unavailable'); }
    if (r?.code !== 0) fail(r?.code === 99991672 ? 'listing_docs_scope_required' : 'listing_docs_api_rejected');
    return r.data;
  }
  async identify(target=TARGET) {
    if(![TARGET,this.target()].includes(target))fail('listing_destination_identity_changed');
    const token=target.split('/wiki/')[1];if(!/^[A-Za-z0-9]+$/.test(token||''))fail('listing_destination_identity_changed');
    const data = await this.request('GET', '/open-apis/wiki/v2/spaces/get_node', { params: { token } });
    if (data.node?.obj_type !== 'docx' || !/^[A-Za-z0-9]+$/.test(data.node.obj_token || '')) fail('listing_destination_identity_changed');
    if(target!==TARGET&&data.node.obj_token!==this.layout().document_id)fail('listing_destination_identity_changed');
    return data.node.obj_token;
  }
  async blocks(doc) {
    let all = [], token;
    do { const r = await this.request('GET', '/open-apis/docx/v1/documents/' + doc + '/blocks', { params: { page_size: 500, ...(token ? { page_token: token } : {}) } });
      if (!Array.isArray(r.items) || all.length + r.items.length > 100000) fail('listing_doc_blocks_invalid');
      all.push(...r.items); token = r.has_more ? r.page_token : null; if (r.has_more && !token) fail('listing_doc_pagination_invalid');
    } while (token);
    return all;
  }
  file(taskId) { if (!/^[A-Za-z0-9_-]{1,100}$/.test(taskId || '')) fail('listing_task_id_invalid'); return path.join(this.config.stateDir, 'delivery-' + taskId + '.json'); }
  async readiness() { try { await this.blocks(await this.identify(this.target())); return { ready: true, read_access: true, write_access_verified: false }; } catch (e) { return { ready: false, code: e.code || 'listing_docs_not_ready' }; } }
  async download(token) {
    this.connect(); let resource;
    try { resource = await this.client.drive.media.download({ path: { file_token: token } }); } catch { fail('listing_thumbnail_readback_failed'); }
    if (typeof resource?.getReadableStream !== 'function') fail('listing_thumbnail_readback_failed');
    const stream = resource.getReadableStream(), chunks = []; let size = 0;
    try { for await (const chunk of stream) { size += chunk.length; if (size > 15 * 1024 * 1024) fail('listing_thumbnail_too_large'); chunks.push(Buffer.from(chunk)); } } finally { stream.destroy(); }
    return Buffer.concat(chunks);
  }
  async inspect(taskId) {
    const record = JSON.parse(fs.readFileSync(this.file(taskId), 'utf8')); const p = desired(record.task,this.target()),target=record.task.payload.url;
    const doc = await this.identify(target); if (doc !== record.document_id) fail('listing_document_changed');
    const prefix=record.layout==='sections_v2'?'ID ':'SKU ';
    const blocks = await this.blocks(doc), marker = prefix + p.listing_code;
    const matches = blocks.filter(b => textOf(b) === marker);
    if (matches.length !== 1 || matches[0].block_id !== record.block_ids[0]) fail('listing_sku_duplicate_or_changed');
    const root = blocks.find(b => b.block_id === doc), childIds = root?.children || [];
    const start = childIds.indexOf(record.block_ids[0]);
    if (start < 0 || JSON.stringify(childIds.slice(start, start + record.block_ids.length)) !== JSON.stringify(record.block_ids)) fail('listing_block_order_changed');
    const own = record.block_ids.map(id => blocks.find(b => b.block_id === id)); if (own.some(b => !b)) fail('listing_block_missing');
    if (own[1].block_type !== 27 || !own[1].image?.token) fail('listing_thumbnail_missing');
    const v2=record.layout==='sections_v2';
    if(v2&&(textOf(own[2])!=='Title'||textOf(own[4])!=='Mô tả'||textOf(own.at(-2))!=='Tags'))fail('listing_section_headers_changed');
    const title = v2?textOf(own[3]):fieldText(textOf(own[2]),'Title'), tags = v2?textOf(own.at(-1)):fieldText(textOf(own.at(-1)),'Tags');
    const description = v2?own.slice(5,-2).map(textOf).join('\n\n'):own.slice(3, -1).map((b,i)=>i===0?fieldText(textOf(b),'Mô tả'):textOf(b)).join('\n\n');
    const thumbHash = hash(await this.download(own[1].image.token));
    const content = { listing_code: textOf(own[0]).slice(prefix.length), title, description, tags: tags.split(', '), thumbnail_sha256: thumbHash };
    if (content.title !== p.title || content.description !== p.description || JSON.stringify(content.tags) !== JSON.stringify(p.tags) || thumbHash !== p.thumbnail.sha256) fail('listing_readback_content_mismatch');
    const report = { ok: true, task_id: taskId, task_fingerprint: record.task.fingerprint, document_url: target, official_api_origin: ORIGIN,
      observed_listing_code_count: matches.length, content, verified_after_readback: true, document_id: doc, block_ids: record.block_ids };
    const reportFile = path.join(this.config.workflowRoot, 'workspace/production/lark-listing-readbacks', 'readback-' + taskId + '.json'); atomic(reportFile, report);
    return { ...report, observed_at: new Date(this.now()).toISOString(), readback_path: reportFile, readback_sha256: hash(fs.readFileSync(reportFile)) };
  }
  async deliver(task, hooks = {}) {
    const p = desired(task,this.target()), file = this.file(task.id),target=task.payload.url; let saved;
    if (fs.existsSync(file)) { saved = JSON.parse(fs.readFileSync(file, 'utf8')); if (saved.task.fingerprint !== task.fingerprint) fail('listing_task_binding_changed'); }
    const v2=task.payload.layout==='sections_v2'||target!==TARGET;
    const doc = await this.identify(target), existing = await this.blocks(doc), marker = (v2?'ID ':'SKU ') + p.listing_code;
    if (!saved) {
      if (existing.some(b => textOf(b) === marker || textOf(b) === p.listing_code)) fail('listing_existing_sku_needs_reconciliation');
      saved = { task, document_id: doc, status: 'prepared', client_token: hash(Buffer.from(task.id + ':' + task.fingerprint)).slice(0, 32), block_ids: [],...(v2?{layout:'sections_v2'}:{}) }; atomic(file, saved);
    }
    if (saved.document_id !== doc) fail('listing_document_changed');
    if (hooks.beforeWrite) await hooks.beforeWrite();
    if (!saved.block_ids.length) {
      // Stable official client_token reconciles an unknown create result without appending twice.
      const children = saved.layout==='sections_v2'?[subheading(marker),{block_type:27,image:{}},fieldHeading('Title'),paragraph(p.title),fieldHeading('Mô tả'),...p.description.split('\n\n').map(paragraph),fieldHeading('Tags'),paragraph(p.tags.join(', '))]:[heading(marker), { block_type: 27, image: {} }, paragraph('Title:\n'+p.title), ...p.description.split('\n\n').map((s,i)=>paragraph((i===0?'Mô tả:\n':'')+s)), paragraph('Tags:\n'+p.tags.join(', '))];
      if (children.length > 50 || children.some(b => (textOf(b).length > 10000))) fail('listing_doc_block_limit');
      saved.status = 'creating'; atomic(file, saved);
      const boundary=v2?this.layout().section_end_id:null,root=existing.find(b=>b.block_id===doc),index=boundary?root?.children?.indexOf(boundary):-1;
      if(boundary&&(!Number.isInteger(index)||index<0))fail('listing_hub_boundary_changed');
      const r = await this.request('POST', '/open-apis/docx/v1/documents/' + doc + '/blocks/' + doc + '/children', { params: { document_revision_id: -1, client_token: saved.client_token }, data: { children, index } });
      if (r.children?.length !== children.length || r.children.some(b => !b.block_id)) fail('listing_created_blocks_invalid');
      saved.block_ids = r.children.map(b => b.block_id); saved.status = 'blocks_created'; atomic(file, saved);
    }
    const current = await this.blocks(doc), image = current.find(b => b.block_id === saved.block_ids[1]);
    if (!saved.image_token) {
      if (image?.image?.token) saved.image_token = image.image.token;
      else {
        const real = fs.realpathSync(p.thumbnail.path);
        const roots=[this.config.workflowRoot,'C:/Huy/Đã xử lý/Áo thêu','C:/Huy/Đã xử lý/Áo 2D'].filter(r=>fs.existsSync(r));
        if (!roots.some(root=>{const relative=path.relative(fs.realpathSync(root),real);return relative&&!relative.startsWith('..')&&!path.isAbsolute(relative);}) || hash(fs.readFileSync(real)) !== p.thumbnail.sha256) fail('listing_thumbnail_source_changed');
        this.connect(); let uploaded;
        try { uploaded = await this.client.drive.media.uploadAll({ data: { file_name: path.basename(real), parent_type: 'docx_image', parent_node: saved.block_ids[1], size: fs.statSync(real).size, file: fs.createReadStream(real) } }); } catch { fail('listing_media_upload_required'); }
        if (!uploaded?.file_token) fail('listing_media_upload_required'); saved.image_token = uploaded.file_token;
      }
      atomic(file, saved);
    }
    if (image?.image?.token !== saved.image_token) await this.request('PATCH', '/open-apis/docx/v1/documents/' + doc + '/blocks/' + saved.block_ids[1], { params: { document_revision_id: -1 }, data: { replace_image: { token: saved.image_token } } });
    saved.status = 'readback_pending'; atomic(file, saved);
    const actual = await this.inspect(task.id); saved.status = 'verified'; atomic(file, saved);
    return { executor: 'lark_docs_api', url: target, content_fingerprint: p.review_fingerprint, verified_after_readback: true, readback_path: actual.readback_path, readback_sha256: actual.readback_sha256 };
  }
  async repairLayout(taskId,expectedFingerprint) {
    const record=JSON.parse(fs.readFileSync(this.file(taskId),'utf8')),p=desired(record.task,this.target());
    if(record.task.fingerprint!==expectedFingerprint)fail('listing_task_binding_changed');
    if(record.layout==='sections_v2')return this.inspect(taskId);
    await this.inspect(taskId);
    const doc=await this.identify(),blocks=await this.blocks(doc);
    const fields=[[record.block_ids[2],'Title',p.title],[record.block_ids[3],'Mô tả',p.description.split('\n\n')[0]],[record.block_ids.at(-1),'Tags',p.tags.join(', ')]];
    for(const [id,label,original] of fields){
      const actual=textOf(blocks.find(b=>b.block_id===id)),target=label+':\n'+original;
      if(actual===target)continue;
      if(actual!==original)fail('listing_manual_edit_preserved');
      await this.request('PATCH','/open-apis/docx/v1/documents/'+doc+'/blocks/'+id,{params:{document_revision_id:-1},data:{update_text_elements:{elements:[{text_run:{content:label+':\n',text_element_style:{bold:true}}},{text_run:{content:original}}]}}});
    }
    // Legacy entries were plain paragraphs, so Lark's outline could not expose them.
    const navigation=p.listing_code+' · Title, Mô tả, Tags';
    const matches=blocks.filter(b=>textOf(b)===navigation);
    if(matches.length>1)fail('listing_navigation_duplicate');
    if(!matches.length){
      const elements=fields.flatMap(([id,label],i)=>[...(i?[{text_run:{content:'  ·  '}}]:[]),{text_run:{content:label,text_element_style:{link:{url:TARGET+'#'+id}}}}]);
      await this.request('POST','/open-apis/docx/v1/documents/'+doc+'/blocks/'+doc+'/children',{params:{document_revision_id:-1,client_token:hash(Buffer.from('navigation-v1:'+taskId+':'+expectedFingerprint)).slice(0,32)},data:{children:[heading(navigation),{block_type:2,text:{elements}}],index:0}});
      if((await this.blocks(doc)).filter(b=>textOf(b)===navigation&&b.block_type===3).length!==1)fail('listing_navigation_not_visible');
    }
    return this.inspect(taskId);
  }
  async relabel(sourceId,task){
    const prior=JSON.parse(fs.readFileSync(this.file(sourceId),'utf8')),p=desired(task,this.target());
    const old=desired(prior.task,this.target());
    if(prior.layout!=='sections_v2'||p.listing_code!==old.listing_code+'_TQH'||p.title!==old.title||p.description!==old.description||JSON.stringify(p.tags)!==JSON.stringify(old.tags)||p.thumbnail.sha256!==old.thumbnail.sha256)fail('listing_relabel_binding_changed');
    const doc=await this.identify(task.payload.url),blocks=await this.blocks(doc),marker=blocks.find(b=>b.block_id===prior.block_ids[0]);
    if(!marker||![old.listing_code,p.listing_code].map(x=>'ID '+x).includes(textOf(marker)))fail('listing_relabel_manual_edit');
    if(blocks.some(b=>b.block_id!==marker.block_id&&textOf(b)==='ID '+p.listing_code))fail('listing_relabel_duplicate');
    if(textOf(marker)!=='ID '+p.listing_code)await this.request('PATCH','/open-apis/docx/v1/documents/'+doc+'/blocks/'+marker.block_id,{params:{document_revision_id:-1},data:{update_text_elements:{elements:[{text_run:{content:'ID '+p.listing_code}}]}}});
    const file=this.file(task.id);
    if(fs.existsSync(file)&&JSON.parse(fs.readFileSync(file,'utf8')).task.fingerprint!==task.fingerprint)fail('listing_task_binding_changed');
    atomic(file,{...prior,task,status:'verified',relabelled_from:sourceId});
    return this.inspect(task.id);
  }
  async prepareHub(){
    if(this.layout().url){await this.identify(this.target());return {ok:true,...this.layout()};}
    const doc=await this.identify(),title='NỘI DUNG LISTING TỰ ĐỘNG — BẢN MỚI',end='KHO NỘI DUNG TRƯỚC ĐÂY';
    let blocks=await this.blocks(doc),starts=blocks.filter(b=>textOf(b)===title),ends=blocks.filter(b=>textOf(b)===end);
    if(starts.length>1||ends.length>1)fail('listing_hub_duplicate');
    if(!starts.length&&!ends.length){
      const old=heading(end);old.heading1.style={folded:true};
      await this.request('POST','/open-apis/docx/v1/documents/'+doc+'/blocks/'+doc+'/children',{params:{document_revision_id:-1,client_token:hash(Buffer.from('separate-listing-sections-v2:'+doc)).slice(0,32)},data:{children:[heading(title),paragraph('Mỗi ID có thumbnail, Title, Mô tả và 13 Tags riêng. Dùng mục lục bên trái để chuyển ID. Nội dung cũ được giữ ở khu lưu trữ bên dưới.'),old],index:0}});
      blocks=await this.blocks(doc);starts=blocks.filter(b=>textOf(b)===title);ends=blocks.filter(b=>textOf(b)===end);
    }
    if(starts.length!==1||ends.length!==1)fail('listing_hub_creation_unconfirmed');
    const layout={layout:'sections_v2',url:TARGET,document_id:doc,section_start_id:starts[0].block_id,section_end_id:ends[0].block_id,title};
    atomic(path.join(this.config.workflowRoot,'config/listing-layout.json'),layout);
    await this.identify(layout.url);
    return {ok:true,...layout};
  }
}
module.exports = { LarkListing, TARGET, ORIGIN, desired, textOf, paragraph, fieldText };
