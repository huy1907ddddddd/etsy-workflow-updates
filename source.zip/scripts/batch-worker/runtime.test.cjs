'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { Readable } = require('node:stream');
const { LarkListing, TARGET, paragraph } = require('./lark-listing.cjs');
const { BatchRuntime } = require('./runtime.cjs');
const hash = b => createHash('sha256').update(b).digest('hex');
function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'batch-publisher-test-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const stateDir = path.join(root, 'workspace/batch-worker/runtime'); fs.mkdirSync(stateDir, { recursive: true });
  const imageFile = path.join(root, 'thumbnail.jpg'), bytes = Buffer.from('fixture image original bytes'); fs.writeFileSync(imageFile, bytes);
  const config = { workflowRoot: root, stateDir, larkConfigFile: path.join(root, 'lark.private.json') }; fs.writeFileSync(config.larkConfigFile, JSON.stringify({ localToken: 'x'.repeat(40) }));
  const packet = { listing_code: 'ANM_261017_01', revision: 1, review_fingerprint: 'a'.repeat(64), title: 'Fixture title', description: 'Line one\n\nLine two\n', tags: Array.from({ length: 13 }, (_, i) => 'tag ' + i), thumbnail: { path: imageFile, sha256: hash(bytes) } };
  const task = { id: 'task-1', code: packet.listing_code, revision: 1, status: 'pending', kind: 'lark_review', fingerprint: 'b'.repeat(64), payload: { url: TARGET, packet } };
  const blocks = [{ block_id: 'doc1', children: [] }], calls = [],createdByToken=new Map(); let created, unknown = false;
  const client = { request: async req => {
    calls.push(req);
    if (req.url.includes('get_node')) return { code: 0, data: { node: { obj_type: 'docx', obj_token: 'doc1' } } };
    if (req.method === 'GET' && req.url.endsWith('/blocks')) return { code: 0, data: { items: structuredClone(blocks), has_more: false } };
    if (req.method === 'POST') { created=createdByToken.get(req.params.client_token);if (!created) { const offset=blocks.length-1;created = req.data.children.map((b, i) => ({ ...structuredClone(b), block_id: 'b' + (offset+i) }));createdByToken.set(req.params.client_token,created); blocks.push(...created); blocks[0].children.splice(req.data.index===-1?blocks[0].children.length:req.data.index,0,...created.map(b=>b.block_id)); }
      if (unknown) { unknown = false; throw Error('unknown result'); } return { code: 0, data: { children: created } }; }
    if (req.method === 'PATCH') {
      if(req.data.replace_image)blocks[2].image = { token: req.data.replace_image.token };
      else {const block=blocks.find(b=>req.url.endsWith('/'+b.block_id));(block.text||block.heading2||block.heading3||block.heading1).elements=structuredClone(req.data.update_text_elements.elements);}
      return { code: 0, data: {} };
    }
    throw Error('unexpected request');
  }, drive: { media: { uploadAll: async () => ({ file_token: 'media1' }), download: async () => ({ getReadableStream: () => Readable.from([bytes]) }) } } };
  return { root, config, packet, task, blocks, calls, publisher: new LarkListing(config, { client }), unknown: () => unknown = true };
}

test('batch production gets a longer execution budget and lock waiting sends no error notification', async t => {
  const f = fixture(t), commands = [], notices = [];
  const runtime = new BatchRuntime(f.config, { publisher: {}, native: { execute: async (command, options) => {
    commands.push({ command, options });
    if(command.action==='advance')assert.equal(JSON.parse(fs.readFileSync(path.join(f.config.stateDir,'status.json'))).status,'production_running');
    return command.action === 'batch_cycle' ? { ok: true, status: 'batch_active', batch_id: 'batch-test', production_jobs: [{ listing_code: 'UST_261016_05_TQH' }] } : { ok: true, status: 'needs_text' };
  } }, fetch: async (_url, request) => { notices.push(JSON.parse(request.body)); return { ok: true }; } });
  await runtime.tick();
  assert.deepEqual(commands[1], { command: { action: 'advance', listing_code: 'UST_261016_05_TQH' }, options: { timeoutMs: 1800000 } });
  const sent = notices.length;
  assert.equal((await runtime.block(Error('native_execution_busy'))).status, 'waiting_native_execution');
  assert.equal(notices.length, sent);
  assert.equal((await runtime.block(Error('native_execution_timeout'))).status, 'awaiting_repair');
  assert.equal(notices.length, sent + 1);
});

test('intentional batch worker shutdown does not create a false error hold or stop notification',async t=>{
 const f=fixture(t);let commands=0,notices=0;
 const runtime=new BatchRuntime(f.config,{publisher:{},native:{execute:async()=>{commands++;},stop:()=>{}},fetch:async()=>{notices++;return {ok:true};}});
 runtime.currentBatch='batch-paused';runtime.stop();
 assert.equal((await runtime.block(Error('n8n_native_failed_check_private_log'))).status,'stopped');
 assert.equal(commands,0);assert.equal(notices,0);assert.equal(fs.existsSync(path.join(f.config.stateDir,'workflow-error-hold.json')),false);
});

test('Codex usage limit stops the exact batch once, names the provider and waits across restart', async t => {
  const f=fixture(t),commands=[],notices=[];let active=true;
  const deps={publisher:{},native:{execute:async cmd=>{
    commands.push(cmd);
    if(cmd.action==='batch_status')return {ok:true,batches:[{batch_id:'batch-quota',fingerprint:'a'.repeat(64),status:active?'active':'stopped'}]};
    if(cmd.action==='batch_stop'){active=false;return {ok:true,status:'batch_stopped'};}
    assert.fail('Unexpected retry after quota');
  }},fetch:async(_url,req)=>{notices.push(JSON.parse(req.body));return {ok:true};}};
  let runtime=new BatchRuntime(f.config,deps);runtime.currentBatch='batch-quota';
  runtime.productionScope={batch_fingerprint:'a'.repeat(64),listing_code:'CRM_261026_05_TQH'};
  await runtime.block(Error('codex_usage_limit_exceeded'));
  runtime=new BatchRuntime(f.config,deps);await runtime.tick();await runtime.tick();
  assert.equal(commands.filter(c=>c.action==='batch_stop').length,1);assert.equal(notices.length,1);
  assert.match(notices[0].message,/Codex báo hết hạn mức/);assert.match(notices[0].message,/Tiếp tục mẻ/);
  const hold=JSON.parse(fs.readFileSync(path.join(f.config.stateDir,'workflow-error-hold.json')));
  assert.equal(hold.code,'codex_usage_limit_exceeded');assert.equal(hold.stop_pending,false);assert.equal(hold.listing_code,'CRM_261026_05_TQH');
});

test('non-retryable YTrends limit pauses the exact batch through n8n and preserves valid checkpoints', async t => {
  const f = fixture(t), code = 'UST_261016_05_TQH', set = 'd'.repeat(64);
  f.config.researchLimitPause = { batch_id: 'batch-test', reference: 'Fixture user requested repair; protective pause of this batch only.' };
  f.config.commandFile = path.join(f.root, 'etsy-codex/production-command.json');
  const source = path.join(f.root, 'etsy-codex/jobs', code + '.json'), checkpoints = path.join(f.root, 'etsy-keywords/checkpoints', code, set);
  fs.mkdirSync(path.dirname(source), { recursive: true }); fs.writeFileSync(source, '{"fixture":true}'); fs.mkdirSync(checkpoints, { recursive: true });
  const sourceHash = hash(fs.readFileSync(source)), valid = path.join(checkpoints, '01.json'), limited = path.join(checkpoints, '02.json');
  fs.writeFileSync(valid, JSON.stringify({ status: 'checked', listing_code: code, input_sha256: sourceHash, candidate_set_hash: set }));
  const failure = { status: 'failed', listing_code: code, input_sha256: sourceHash, candidate_set_hash: set, checked_at_utc: new Date().toISOString(), raw_mcp_result: { error: { message: JSON.stringify({ error_kind: 'fair_use_limited', retryable: false }) } } };
  fs.writeFileSync(limited, JSON.stringify(failure)); const before = fs.readFileSync(valid, 'utf8'), commands = [], notices = [];
  const runtime = new BatchRuntime(f.config, { publisher: {}, native: { execute: async command => {
    commands.push(command);
    if (command.action === 'batch_cycle') return { ok: true, status: 'batch_active', batch_id: 'batch-test', batch_fingerprint: 'a'.repeat(64), production_jobs: [{ listing_code: code }] };
    if (command.action === 'batch_stop') return { ok: true, status: 'batch_stopped' };
    if (command.action === 'batch_status') return {ok:true,batches:[{batch_id:'batch-test',fingerprint:'a'.repeat(64),status:'stopped'}]};
    return { ok: true, status: 'needs_text' };
  } }, fetch: async (_url, request) => { notices.push(JSON.parse(request.body)); return { ok: true }; } });
  assert.equal((await runtime.tick()).code, 'ytrends_fair_use_limited');
  assert.deepEqual(commands.map(c => c.action), ['batch_cycle', 'batch_stop', 'batch_status']);
  assert.equal(commands[1].batch_fingerprint, 'a'.repeat(64));
  assert.equal(commands[1].authority, 'direct_user'); assert.equal(commands[1].reference, f.config.researchLimitPause.reference);
  assert.equal(fs.readFileSync(valid, 'utf8'), before); assert.equal(notices.length, 1);
  assert.equal(runtime.keywordLimit({ listing_code: code }), null);
  fs.unlinkSync(path.join(f.config.stateDir, 'keyword-limit-' + code + '.json')); delete f.config.researchLimitPause; commands.length = 0;
  assert.equal((await runtime.tick()).code, 'ytrends_fair_use_limited');
  assert.deepEqual(commands.map(c => c.action), []); // The durable gate prevents even a new production cycle.
  failure.checked_at_utc = new Date(Date.now() - 2000).toISOString(); fs.writeFileSync(limited, JSON.stringify(failure));
  assert.ok(runtime.keywordLimit({ listing_code: code }));
  failure.input_sha256 = 'e'.repeat(64); fs.writeFileSync(limited, JSON.stringify(failure));
  assert.equal(runtime.keywordLimit({ listing_code: code }), null);
  failure.input_sha256 = sourceHash; failure.raw_mcp_result.error.message = JSON.stringify({ error_kind: 'connection_error', retryable: true }); fs.writeFileSync(limited, JSON.stringify(failure));
  assert.equal(runtime.keywordLimit({ listing_code: code }), null);
});
test('first production error stops the batch and persisted gate waits for an explicit native start',async t=>{
  const f=fixture(t),commands=[],notices=[];let active=true,failing=true;
  const deps={publisher:{},native:{execute:async cmd=>{
    commands.push(cmd);
    if(cmd.action==='batch_cycle')return {ok:true,status:active?'batch_active':'batch_idle',batch_id:active?'batch-A':null,batch_fingerprint:'a'.repeat(64),active_item:{revision:1},production_jobs:active?[{listing_code:'CRM_261023_02_TQH'}]:[]};
    if(cmd.action==='advance'){if(failing)throw Error('n8n_native_failed_check_private_log');return {ok:true,status:'needs_text'};}
    if(cmd.action==='batch_status')return {ok:true,batches:[{batch_id:'batch-A',fingerprint:'a'.repeat(64),status:active?'active':'stopped'}]};
    if(cmd.action==='batch_stop'){active=false;return {ok:true,status:'batch_stopped'};}
    assert.fail('Unexpected command');
  }},fetch:async(_url,req)=>{notices.push(JSON.parse(req.body));return{ok:true};}};
  let runtime=new BatchRuntime(f.config,deps);
  try{await runtime.tick();assert.fail('Expected failure');}catch(e){await runtime.block(e);}
  assert.equal(active,false);assert.equal(commands.filter(x=>x.action==='advance').length,1);
  runtime=new BatchRuntime(f.config,deps);await runtime.tick();await runtime.tick();
  assert.equal(commands.filter(x=>x.action==='advance').length,1);assert.equal(notices.length,1);
  assert.equal(notices[0].notification_kind,'workflow_stopped');assert.match(notices[0].message,/không tự chạy lại/);
  // Simulate the canonical batch_start release, not a worker clearing its own gate.
  fs.renameSync(path.join(f.config.stateDir,'workflow-error-hold.json'),path.join(f.config.stateDir,'released.json'));
  active=true;failing=false;await runtime.tick();assert.equal(commands.filter(x=>x.action==='advance').length,2);
});

test('failed protective pause blocks more production calls until n8n can stop; changed fingerprints are never stopped',async t=>{
  const f=fixture(t),commands=[];let canPause=false;
  const scope={batch_id:'batch-A',batch_fingerprint:'a'.repeat(64),listing_code:'CRM_261023_02_TQH',revision:1};
  fs.writeFileSync(path.join(f.config.stateDir,'production-failure.json'),JSON.stringify({...scope,attempts:3,code:'n8n_native_failed_check_private_log'}));
  const runtime=new BatchRuntime(f.config,{publisher:{},fetch:async()=>({ok:true}),native:{execute:async cmd=>{
    commands.push(cmd);
    if(cmd.action==='batch_cycle')return{ok:true,status:'batch_active',batch_id:scope.batch_id,batch_fingerprint:scope.batch_fingerprint,active_item:{revision:1},production_jobs:[{listing_code:scope.listing_code}]};
    if(cmd.action==='batch_status')return{ok:true,batches:[{batch_id:scope.batch_id,fingerprint:canPause?scope.batch_fingerprint:'b'.repeat(64),status:'active'}]};
    if(cmd.action==='batch_stop')return{ok:true,status:'batch_stopped'};
    assert.fail('Must pause before another advance');
  }}});
  await assert.rejects(runtime.tick(),/binding_changed/);assert.equal(commands.some(x=>x.action==='batch_stop'),false);
  canPause=true;assert.equal((await runtime.tick()).status,'awaiting_repair');assert.equal(commands.some(x=>x.action==='advance'),false);
});
test('native lock contention does not consume the production failure limit',async t=>{
  const f=fixture(t),runtime=new BatchRuntime(f.config,{publisher:{},native:{},fetch:()=>assert.fail('No busy notification')});
  runtime.productionScope={batch_id:'batch-A',batch_fingerprint:'a'.repeat(64),listing_code:'CRM_261023_02_TQH'};
  for(let i=0;i<4;i++)assert.equal((await runtime.block(Error('native_execution_busy'))).status,'waiting_native_execution');
  assert.equal(fs.existsSync(path.join(f.config.stateDir,'production-failure.json')),false);
});
test('keyword signal shortfall reports the exact count without publishing or advancing another job',async t=>{
  const f=fixture(t),commands=[],notices=[];
  const runtime=new BatchRuntime(f.config,{publisher:{deliver:()=>assert.fail('No incomplete listing delivery')},native:{execute:async command=>{
    commands.push(command);
    if(command.action==='batch_cycle')return {ok:true,status:'batch_active',batch_id:'batch-test',batch_fingerprint:'f'.repeat(64),production_jobs:[{listing_code:'CRM_261023_02_TQH'},{listing_code:'CRM_261023_03_TQH'}]};
    return command.action==='batch_stop'?{ok:true,status:'batch_stopped'}:{ok:true,status:'keyword_signal_shortfall',listing_code:'CRM_261023_02_TQH',eligible_count:8};
  }},fetch:async(_url,request)=>{notices.push(JSON.parse(request.body));return{ok:true};}});
  const state=await runtime.tick();assert.equal(state.status,'awaiting_keyword_review');assert.equal(state.eligible_count,8);assert.equal(state.additional_search_on_shortfall,false);
  assert.deepEqual(commands.map(x=>x.action),['batch_cycle','advance','batch_stop']);assert.equal(commands[2].batch_fingerprint,'f'.repeat(64));assert.equal(notices.length,1);assert.match(notices[0].message,/8\/13/);
});
test('empty discovery pauses the exact batch once, so the next cycle cannot call candidate AI again',async t=>{
  const f=fixture(t),commands=[],notices=[];let stopped=false;
  const runtime=new BatchRuntime(f.config,{publisher:{},native:{execute:async command=>{
    commands.push(command.action);
    if(command.action==='batch_cycle')return {ok:true,status:stopped?'batch_idle':'batch_active',batch_id:stopped?null:'batch-test',batch_fingerprint:'e'.repeat(64),production_jobs:stopped?[]:[{listing_code:'CRM_261023_02_TQH'}]};
    if(command.action==='batch_stop'){assert.equal(command.batch_id,'batch-test');assert.equal(command.batch_fingerprint,'e'.repeat(64));stopped=true;return{ok:true,status:'batch_stopped'};}
    return {ok:true,status:'keyword_candidate_shortfall',listing_code:'CRM_261023_02_TQH',discovered_count:0,relevant_candidate_count:null};
  }},fetch:async(_url,request)=>{notices.push(JSON.parse(request.body));return{ok:true};}});
  assert.equal((await runtime.tick()).code,'keyword_candidate_shortfall');await runtime.tick();
  assert.deepEqual(commands,['batch_cycle','advance','batch_stop','batch_cycle']);assert.equal(notices.length,1);assert.match(notices[0].message,/0 cụm/);
});
test('official publish ordered content+thumbnail, fresh readback proof, retry does not append twice', async t => {
  const f = fixture(t); const proof = await f.publisher.deliver(f.task); assert.equal(proof.executor, 'lark_docs_api');
  const a = await f.publisher.inspect(f.task.id), b = await f.publisher.inspect(f.task.id); assert.equal(a.readback_sha256, b.readback_sha256);
  assert.deepEqual(a.content, { listing_code: f.packet.listing_code, title: f.packet.title, description: f.packet.description, tags: f.packet.tags, thumbnail_sha256: f.packet.thumbnail.sha256 });
  await f.publisher.deliver(f.task); assert.equal(f.calls.filter(x => x.method === 'POST').length, 1); assert.equal(f.calls.filter(x => x.method === 'PATCH').length, 1);
  assert.ok(a.readback_path.startsWith(path.join(f.root, 'workspace/production/lark-listing-readbacks')));
  f.blocks[3].text.elements[0].text_run.content = 'someone changed title'; await assert.rejects(f.publisher.inspect(f.task.id), /content_mismatch/);
});
test('legacy Docs get visible field labels once, with content and thumbnail unchanged',async t=>{
  const f=fixture(t);await f.publisher.deliver(f.task);
  f.blocks[3].text.elements[0].text_run.content=f.packet.title;
  f.blocks[4].text.elements[0].text_run.content=f.packet.description.split('\n\n')[0];
  f.blocks.at(-1).text.elements[0].text_run.content=f.packet.tags.join(', ');
  const count=f.calls.filter(c=>c.method==='PATCH').length;
  const a=await f.publisher.repairLayout(f.task.id,f.task.fingerprint);
  assert.equal(a.content.title,f.packet.title);assert.equal(a.content.description,f.packet.description);
  assert.match(f.blocks[3].text.elements[0].text_run.content,/^Title:\n/);
  assert.equal(f.blocks.filter(b=>b.heading1?.elements[0]?.text_run?.content===f.packet.listing_code+' · Title, Mô tả, Tags').length,1);
  await f.publisher.repairLayout(f.task.id,f.task.fingerprint);
  assert.equal(f.calls.filter(c=>c.method==='PATCH').length,count+3);
  await assert.rejects(f.publisher.repairLayout(f.task.id,'wrong'),/binding_changed/);
});

test('separate listing hub has real section headings and verifies exact text without touching old destination',async t=>{
 const f=fixture(t),url='https://csg2m8jcr9dn.sg.larksuite.com/wiki/TestHub';
 fs.mkdirSync(path.join(f.root,'config'),{recursive:true});fs.writeFileSync(path.join(f.root,'config/listing-layout.json'),JSON.stringify({layout:'sections_v2',url,document_id:'doc1'}));
 f.task.payload.url=url;const proof=await f.publisher.deliver(f.task);assert.equal(proof.url,url);
 const actual=await f.publisher.inspect(f.task.id);assert.equal(actual.content.title,f.packet.title);assert.equal(actual.content.description,f.packet.description);
 assert.deepEqual(f.blocks.filter(b=>b.block_type===5).map(b=>b.heading3.elements[0].text_run.content),['Title','Mô tả','Tags']);
 assert.equal(f.blocks[1].heading2.elements[0].text_run.content,'ID '+f.packet.listing_code);
 await f.publisher.deliver(f.task);assert.equal(f.calls.filter(r=>r.method==='POST').length,1);
});

test('TQH relabel edits only existing marker, preserves content and retries without appending',async t=>{
 const f=fixture(t);f.task.payload.layout='sections_v2';await f.publisher.deliver(f.task);
 const task=structuredClone(f.task);task.id='tqh-1';task.code+='_TQH';task.payload.packet.listing_code=task.code;task.fingerprint='c'.repeat(64);
 const count=f.blocks.length,old=await f.publisher.inspect(f.task.id);
 const proof=await f.publisher.relabel(f.task.id,task);assert.equal(proof.content.listing_code,task.code);assert.equal(proof.content.description,old.content.description);
 await f.publisher.relabel(f.task.id,task);assert.equal(f.blocks.length,count);assert.equal(f.calls.filter(r=>r.method==='POST').length,1);
 task.payload.packet.title='unexpected rewrite';await assert.rejects(f.publisher.relabel(f.task.id,task),/binding_changed/);
});

test('unknown create result reuses stable official client_token and source hash checks prevent modified upload', async t => {
  const f = fixture(t); f.unknown(); await assert.rejects(f.publisher.deliver(f.task), /api_unavailable/); await f.publisher.deliver(f.task);
  const writes = f.calls.filter(x => x.method === 'POST'); assert.equal(writes.length, 2); assert.equal(writes[0].params.client_token, writes[1].params.client_token); assert.equal(f.blocks.filter(b => b.block_id === 'b0').length, 1);
});
test('preexisting conflicting SKU and duplicate block order refuse writes rather than replace other data', async t => {
  const f = fixture(t); f.blocks.push({ ...paragraph('SKU ' + f.packet.listing_code), block_id: 'someone_else' });
  await assert.rejects(f.publisher.deliver(f.task), /existing_sku/); assert.equal(f.calls.filter(x => x.method !== 'GET').length, 0);
});
test('batch coordinator uses n8n for progress/advance/verified; native commit replay does not publish twice', async t => {
  const f = fixture(t); let deliveries = 0, commitFail = true; const commands = [];
  const native = { execute: async c => { commands.push(c); if (c.action === 'batch_cycle') return { ok: true, status: 'active', production_jobs: [{ listing_code: f.task.code }] };
    if (c.action === 'advance') return { status: 'awaiting_lark_verification', browser_task: f.task };
    if (c.action === 'status') return { revision: 1, state: 'awaiting_lark_verification' };
    if (c.action === 'lark_listing_verified' && commitFail) { commitFail = false; throw Error('unknown_native_commit'); }
    return { ok: true }; }, stop() {} };
  const publisher = { deliver: async (_t, hooks) => { await hooks.beforeWrite(); deliveries++; return { receipt: 'real-fixture' }; } };
  const runtime = new BatchRuntime(f.config, { native, publisher }); await assert.rejects(runtime.tick(), /unknown_native_commit/); await runtime.tick(); assert.equal(deliveries, 1);
  const commits = commands.filter(c => c.action === 'lark_listing_verified'); assert.equal(commits.length, 2); assert.deepEqual(commits[0], commits[1]);
});
test('blocked progress sends the actual error once and preserves the batch identity', async t => {
  const f = fixture(t), messages = [];
  const runtime = new BatchRuntime(f.config, { native: {}, publisher: {}, fetch: async (_url, options) => { messages.push(JSON.parse(options.body)); return { ok: true }; } });
  const result = { batch_id: 'fixture-batch', status: 'batch_worker_blocked', error: 'listing_readback_unavailable' };
  await runtime.notify(result); await runtime.notify(result);
  assert.equal(messages.length, 1); assert.match(messages[0].message, /listing_readback_unavailable/);
  assert.equal(messages[0].batch_id, 'fixture-batch');
});

function completedReport(batch_id, queue_order = 1) {
  return { report_id: 'batch-done-' + batch_id, kind: 'batch_completed', batch_id, queue_order, completed_count: 3, item_count: 3,
    cancelled_count: 0, file_count: 15, kpi_count: 3, listing_codes: ['UST_261018_31_TQH', 'UST_261018_32_TQH', 'UST_261018_33_TQH'],
    output_directories: ['C:/fixture/processed/UST'], docs_url: 'https://example.test/docs', kpi_url: 'https://example.test/kpi' };
}

test('idle snapshots report each finished batch and the whole group once, including after restart', async t => {
  const f = fixture(t), messages = [], old = completedReport('old', 1), members = ['a', 'b', 'c'].map((id, i) => completedReport(id, i + 2));
  const group = { ...members[2], report_id: 'group-done-abc', kind: 'group_completed', batch_ids: ['a', 'b', 'c'], batches: members, completed_count: 9, item_count: 9, kpi_count: 9 };
  const reports = [old, ...members, group], native = { execute: async command => {
    assert.equal(command.action, 'batch_cycle'); return { ok: true, status: 'batch_idle', production_jobs: [], completion_reports: reports };
  } }, fetch = async (_url, req) => { messages.push(JSON.parse(req.body)); return { ok: true }; };
  const runtime = new BatchRuntime(f.config, { native, publisher: {}, fetch });
  runtime.notices.b = '["batch_completed",null,null,null]';
  await runtime.tick(); await runtime.tick();
  const restarted = new BatchRuntime(f.config, { native, publisher: {}, fetch }); await restarted.tick();
  assert.deepEqual(messages.map(m => m.event_id), ['batch-done-a', 'batch-done-c', 'group-done-abc']);
  assert.match(messages[0].message, /3\/3 mẫu hoàn tất · 15 ảnh/);
  assert.match(messages[0].message, /UST_261018_31_TQH/);
  assert.match(messages[2].message, /ĐÃ XONG CẢ NHÓM 3 MẺ/);
  assert.match(messages[2].message, /9\/9 mẫu hoàn tất/);
  assert.match(messages[2].message, /https:\/\/example.test\/docs/);
  assert.match(messages[2].message, /KPI đã xác nhận: 9 listing/);
});

test('completion delivery retries the exact durable message after connection loss or unknown acceptance', async t => {
  const f = fixture(t), report = completedReport('last'), messages = [];
  const deps = { native: {}, publisher: {}, fetch: async (_url, req) => { messages.push(JSON.parse(req.body)); throw Error('unknown_acceptance'); } };
  const runtime = new BatchRuntime(f.config, deps);
  await assert.rejects(runtime.notifyCompletions([report]), /unknown_acceptance/);
  const pending = JSON.parse(fs.readFileSync(path.join(f.config.stateDir, 'completion-notices.json'), 'utf8'));
  assert.equal(pending[report.report_id].status, 'pending');
  deps.fetch = async (_url, req) => { messages.push(JSON.parse(req.body)); return { ok: true }; };
  const restarted = new BatchRuntime(f.config, deps);
  await restarted.notifyCompletions([{ ...report, listing_codes: ['changed-snapshot'] }]);
  await restarted.notifyCompletions([report]);
  assert.equal(messages.length, 2); assert.deepEqual(messages[0], messages[1]);
});

test('new completion facts prevent the older transition notice from sending a second message', async t => {
  const f = fixture(t), messages = [];
  const runtime = new BatchRuntime(f.config, { native: {}, publisher: {}, fetch: async (_url, req) => { messages.push(req); return { ok: true }; } });
  await runtime.notify({ status: 'batch_completed', batch_id: 'fixture', completion_reports: [] });
  assert.equal(messages.length, 0);
  await runtime.notifyCompletions([]); assert.equal(messages.length, 0);
});

test('local completion states cloud pending, and verified cloud completion deduplicates after restart',async t=>{
 const f=fixture(t),messages=[],deps={native:{},publisher:{},fetch:async(_url,req)=>{messages.push(JSON.parse(req.body));return {ok:true};}};
 const report={...completedReport('new'),google_pending:2,google_enabled:true};
 await new BatchRuntime(f.config,deps).notifyCompletions([report]);assert.match(messages[0].message,/Google đang chờ đồng bộ: 2 mẫu/);
 const cloud={...report,report_id:'google-batch-done-new',kind:'google_completed',google_pending:0,google_files:[{path:['Áo 2D','UST','UST_261020_01_TQH.zip'],url:'https://drive.google.com/file/d/fixture/view'}]};
 await new BatchRuntime(f.config,deps).notifyCompletions([report,cloud]);await new BatchRuntime(f.config,deps).notifyCompletions([report,cloud]);
 assert.equal(messages.length,2);assert.match(messages[1].message,/ĐÃ ĐỒNG BỘ GOOGLE/);assert.match(messages[1].message,/Áo 2D\/UST\//);
});
