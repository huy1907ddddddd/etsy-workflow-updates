"""Test stage gates with synthetic fixtures only; no Flow calls or live approvals."""
import copy
import importlib.util
import json
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('production-engine.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]


def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'passed':True})


def fails(fn):
    try:fn()
    except (ValueError,KeyError):return True
    return False


original_store=m.STORE;original_jobs=m.JOBS
with tempfile.TemporaryDirectory(prefix='design-test-',dir=m.STORE) as tmp:
    m.STORE=Path(tmp)
    m.JOBS=m.STORE/'jobs';m.JOBS.mkdir()
    c=m.connect(m.STORE/'isolated.sqlite')
    b={'brief_id':'isolated-design','topic_code':'HLW','product_type':'physical_apparel','product_id':'test',
       'garment':'crewneck','color':'cream','available_styles':['crewneck sweatshirt'],
       'motifs':{'center_chest':'test flower','left_sleeve':'test leaf','right_sleeve':'test leaf'},
       'back_artwork':False,'personalization':{'enabled':False},'sources':[]}
    received=m.execute(c,{'action':'receive_brief','brief':b})
    start={'action':'design_start','brief_id':b['brief_id'],'brief_fingerprint':received['brief_fingerprint'],
           'authority':'direct_user','reference':'isolated test brief authorization only'}
    check('Attached document cannot authorize design generation',fails(lambda:m.execute(c,{**start,'authority':'attached_document'})))
    check('Brief approval must match exact fingerprint',fails(lambda:m.execute(c,{**start,'brief_fingerprint':'wrong'})))
    result=m.execute(c,start)
    outline_rule=m.read(m.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    check('2D prompts end with mandatory outer-outline rule after motif instructions',all(i['prompt'].endswith(outline_rule) for i in result['browser_task']['payload']['images']))
    old_settings=json.loads(c.execute('SELECT settings FROM design_jobs WHERE brief_id=?',(b['brief_id'],)).fetchone()[0])
    old_settings.pop('mandatory_outline_rule',None)
    c.execute('UPDATE design_jobs SET settings=? WHERE brief_id=?',(json.dumps(old_settings),b['brief_id']))
    check('Existing jobs with old prompt snapshots receive the current outline rule',all(i['prompt'].endswith(outline_rule) for i in m.execute(c,{'action':'design_advance','brief_id':b['brief_id']})['browser_task']['payload']['images']))
    check('Design starts before KPI activation without dated code or KPI',result['status']=='awaiting_design_2d' and result['listing_code'] is None and c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0]==0 and c.execute('SELECT COUNT(*) FROM reservations').fetchone()[0]==0)
    check('Both sleeves present and back absent unless confirmed',set(i['region'] for i in result['browser_task']['payload']['images'])==set(b['motifs']))
    check('Repeated start reuses exactly one task',m.execute(c,start)['browser_task']['id']==result['browser_task']['id'] and c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0]==1)
    check('Existing browser queue exposes the new 2D task',m.execute(c,{'action':'browser_queue'})['tasks'][0]['kind']=='flow_design_2d')
    check('Preview cannot advance before all 2D assets and approval',m.execute(c,{'action':'design_advance','brief_id':b['brief_id']})['status']=='awaiting_design_2d')
    screenshot=m.STORE/'synthetic-ui-fixture.png';Image.new('RGB',(10,10),'white').save(screenshot)
    proof={'url':'https://flow.google.com/project/isolated-test-only','model':'Nano Banana Pro',
           'visually_verified':True,'screenshot_path':str(screenshot)}

    def files(task, stage):
        root=Path(task['payload']['output_directory']);root.mkdir(parents=True,exist_ok=True)
        out={}
        for region in [i['region'] for i in task['payload']['images']]:
            path=root/(region+'.png')
            im=Image.new('RGB',(100,100),'white');ImageDraw.Draw(im).rectangle((40,20,59,79),fill='blue');im.save(path)
            out[region]={'path':str(path),'sha256':m.sha(path)}
        return out

    first_task=result['browser_task'];two_d=files(first_task,'2d')
    attach={'action':'design_attach','brief_id':b['brief_id'],'revision':1,'stage':'2d',
            'task_id':first_task['id'],'assets':two_d,'proof':proof}
    check('Assets require actual evidence fields and Pro model',fails(lambda:m.execute(c,{**attach,'proof':{**proof,'model':'Flash'}})))
    partial=m.execute(c,{**attach,'assets':{'center_chest':two_d['center_chest']}})
    check('Partial download keeps missing regional tasks pending',partial['missing_regions']==['left_sleeve','right_sleeve'] and m.execute(c,{'action':'browser_queue'})['tasks'][0]['missing_regions']==['left_sleeve','right_sleeve'])
    result=m.execute(c,attach)
    check('All 2D files stop for user approval; no preview task yet',result['status']=='awaiting_design_2d_approval' and c.execute("SELECT COUNT(*) FROM design_tasks WHERE stage='embroidery'").fetchone()[0]==0)
    check('Retrying a completed attachment does not create extra assets or approvals',m.execute(c,attach)['fingerprint']==result['fingerprint'] and c.execute('SELECT COUNT(*) FROM design_assets').fetchone()[0]==3)
    approve={'action':'design_approve','brief_id':b['brief_id'],'revision':1,'stage':'2d','fingerprint':result['fingerprint'],
             'authority':'direct_user','reference':'isolated fixture 2D approval only'}
    check('Wrong design hash is rejected',fails(lambda:m.execute(c,{**approve,'fingerprint':'wrong'})))
    result=m.execute(c,approve);preview_task=result['browser_task']
    check('Retrying 2D approval reuses the same preview task',m.execute(c,approve)['browser_task']['id']==preview_task['id'])
    check('Preview uses each exact approved 2D reference',all(i['references']==[{**two_d[i['region']],'role':'exact_locked_2d'}] for i in preview_task['payload']['images']))
    check('Preview retains the supplied embroidery prompt and adds the permanent outline rule',all(i['prompt']==m.read(m.ROOT/'config/artwork-flow-prompts.json')['embroidery_preview']+'\n'+outline_rule for i in preview_task['payload']['images']))
    altered=Path(two_d['center_chest']['path']);backup=altered.read_bytes();altered.write_bytes(b'changed')
    check('Changing approved 2D invalidates preview advancement',fails(lambda:m.execute(c,{'action':'design_advance','brief_id':b['brief_id']})))
    altered.write_bytes(backup)
    preview=files(preview_task,'embroidery')
    result=m.execute(c,{'action':'design_attach','brief_id':b['brief_id'],'revision':1,'stage':'embroidery','task_id':preview_task['id'],'assets':preview,'proof':proof})
    check('Preview completion waits for its own approval',result['status']=='awaiting_design_embroidery_approval')
    check('Cannot resolve unapproved preview into production plan',fails(lambda:m.execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':1})))
    result=m.execute(c,{**approve,'stage':'embroidery','fingerprint':result['fingerprint'],'reference':'isolated fixture preview approval only'})
    check('Approved design reaches size stage without granting size approval',result['status']=='approved_artwork_ready_for_sizes')
    plan=m.execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':1})['plan']
    check('All six mockup prompts carry the permanent outline rule',all(i['prompt'].endswith(outline_rule) for i in m.image_plan({'plan':json.dumps(plan),'code':'TEST_ONLY','revision':1})['images']))
    wardrobe=m.read(m.ROOT/'config/mockup-wardrobe-standard.json')
    check('User palettes contain 17 sweatshirt and 9 hoodie/quarterzip colors',len(wardrobe['palettes']['crewneck sweatshirt'])==17 and len(wardrobe['palettes']['hoodie'])==9 and wardrobe['palettes']['hoodie']==wardrobe['palettes']['quarter-zip pullover'] and 'beige' not in wardrobe['palettes']['hoodie'])
    sets=[m.image_plan({'plan':json.dumps(plan),'code':'ANM_261015_%02d'%n,'revision':1}) for n in range(1,28)]
    check('Successive thumbnails rotate through all three styles', [x['images'][0]['wardrobe']['garment'] for x in sets[:3]]==wardrobe['style_rotation'])
    check('Every mockup uses an allowed style/color in every rotation',all(i['wardrobe']['color'] in wardrobe['palettes'][i['wardrobe']['garment']] for x in sets for i in x['images']))
    check('Thumbnails stay sand/beige and each set contains three styles',all(x['images'][0]['wardrobe']['color'] in ('sand','beige') and len(set(i['wardrobe']['garment'] for i in x['images']))==3 for x in sets))
    check('Wardrobe rotation preserves references and physical dimensions on all images',all(x['references']==plan['regions'] and x['sizes_in']==sets[0]['sizes_in'] and all('PHYSICAL DIMENSIONS IN INCHES:' in i['prompt'] for i in x['images']) for x in sets))
    check('Mockup rotation retries are deterministic',sets[0]==m.image_plan({'plan':json.dumps(plan),'code':'ANM_261015_01','revision':1}))
    check('Largest size calculated from white background once with correct aspect',abs(plan['regions']['center_chest']['width_cm']-26/3)<1e-10 and plan['regions']['center_chest']['height_cm']==26 and plan['regions']['left_sleeve']['height_cm']==21)
    check('Plan retains actual artwork approval and asks for size review',all(a['artwork_approval_reference']=='isolated fixture preview approval only' and a['size_approval_reference'] is None and a['design_revision']==1 for a in plan['regions'].values()))
    proposal=m.execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':1})
    check('Size proposal reuses the saved calculation',c.execute("SELECT COUNT(*) FROM design_events WHERE kind='sizes_resolved_once'").fetchone()[0]==1)
    size_cmd={'action':'design_approve_sizes','brief_id':b['brief_id'],'revision':1,'fingerprint':proposal['size_fingerprint'],
              'authority':'direct_user','reference':'isolated size approval only'}
    check('Size approval requires exact saved proposal and direct authority',fails(lambda:m.execute(c,{**size_cmd,'fingerprint':'wrong'})) and fails(lambda:m.execute(c,{**size_cmd,'authority':'attached_document'})))
    sized=m.execute(c,size_cmd)
    check('Approved sizes are stored and reused without recalculation',sized['status']=='approved_artwork_and_sizes' and all(a['size_approval_reference']=='isolated size approval only' for a in sized['plan']['regions'].values()) and c.execute("SELECT COUNT(*) FROM design_events WHERE kind='sizes_resolved_once'").fetchone()[0]==1)
    test_cmd={'action':'prepare_test_listing','brief_id':b['brief_id'],'listing_code':'HLW_261015_01_PILOT','authority':'direct_user','reference':'isolated native test only'}
    check('Native test rejects document authority and ordinary production codes',fails(lambda:m.execute(c,{**test_cmd,'authority':'attached_document'})) and fails(lambda:m.execute(c,{**test_cmd,'listing_code':'HLW_261015_01'})))
    pilot=m.execute(c,test_cmd)
    check('Native pilot can reuse approved artwork before KPI acceptance without reserving capacity',pilot['status']=='queued' and pilot['kpi_counted'] is False and c.execute('SELECT COUNT(*) FROM reservations').fetchone()[0]==0)
    check('Native pilot is idempotent and excluded from the hourly production queue',m.execute(c,test_cmd)['status']=='already_queued' and not any(x['code'].endswith('_PILOT') for x in m.execute(c,{'action':'queue'})['jobs']))
    check('Pilot never counts toward KPI even after later activation',m.allocate_kpi(c,m.job(c,test_cmd['listing_code']),'test',m.now())['status']=='explicit_test_listing_not_counted')
    changed={'action':'design_plan','brief_id':b['brief_id'],'revision':1,'bounds_px':{'center_chest':[40,20,60,60]}}
    check('Changing saved bounds requires user instruction',fails(lambda:m.execute(c,changed)))
    fresh=m.execute(c,{**changed,'authority':'direct_user','reference':'isolated corrected bounds approval request'})
    check('Explicit bounds correction invalidates old size approval',fresh['status']=='resolved_sizes_awaiting_review' and all(a['size_approval_reference'] is None for a in fresh['plan']['regions'].values()))
    revised=m.execute(c,{'action':'design_revise','brief_id':b['brief_id'],'revision':1,'stage':'embroidery',
       'authority':'direct_user','reference':'isolated correction request','reason':'Use denser neat threads, preserve the approved 2D.'})
    check('Preview-only revision preserves exact approved 2D and drops preview approval',revised['revision']==2 and revised['status']=='awaiting_design_embroidery' and c.execute("SELECT COUNT(*) FROM design_approvals WHERE revision=2 AND stage='embroidery'").fetchone()[0]==0)
    check('Old revision cannot attach or approve',fails(lambda:m.execute(c,attach)) and fails(lambda:m.execute(c,approve)))
    revised=m.execute(c,{'action':'design_revise','brief_id':b['brief_id'],'revision':2,'stage':'2d',
       'authority':'direct_user','reference':'isolated redraw request','reason':'Simplify the internal lines.'})
    check('2D revision invalidates both downstream stages and old pending tasks',revised['revision']==3 and revised['status']=='awaiting_design_2d' and c.execute("SELECT COUNT(*) FROM design_approvals WHERE revision=3 AND stage IN ('2d','embroidery')").fetchone()[0]==0 and c.execute("SELECT COUNT(*) FROM design_tasks WHERE revision=2 AND status='superseded'").fetchone()[0]==1)
    c.commit();c.close();c=m.connect(m.STORE/'isolated.sqlite')
    check('Stages survive database reopen and retain original history',m.execute(c,{'action':'design_status','brief_id':b['brief_id']})['revision']==3 and c.execute('SELECT COUNT(*) FROM design_assets WHERE revision=1').fetchone()[0]==6)
    back=copy.deepcopy(b);back['brief_id']='isolated-back';back['back_artwork']=True;back['motifs']['back']='test large flower'
    r=m.execute(c,{'action':'receive_brief','brief':back});r=m.execute(c,{**start,'brief_id':back['brief_id'],'brief_fingerprint':r['brief_fingerprint']})
    check('Confirmed back artwork adds a fourth region',len(r['browser_task']['payload']['images'])==4)
    c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':m.now()})))
    reserve={**start,'action':'reserve_listing','brief_id':back['brief_id'],'brief_fingerprint':r['browser_task']['payload']['brief_fingerprint']}
    check('New dated code waits for approved artwork and sizes',fails(lambda:m.execute(c,reserve)))
    for stage in ('2d','embroidery'):
        t=r['browser_task'];a=files(t,stage)
        r=m.execute(c,{'action':'design_attach','brief_id':back['brief_id'],'revision':1,'stage':stage,'task_id':t['id'],'assets':a,'proof':proof})
        r=m.execute(c,{**approve,'brief_id':back['brief_id'],'stage':stage,'fingerprint':r['fingerprint']})
    r=m.execute(c,{'action':'design_plan','brief_id':back['brief_id'],'revision':1})
    r=m.execute(c,{**size_cmd,'brief_id':back['brief_id'],'fingerprint':r['size_fingerprint']})
    allocation=m.execute(c,reserve)
    queued=m.execute(c,{'action':'prepare_listing','brief_id':back['brief_id'],'plan':r['plan']})
    check('Approved design connects to a new source and production job',queued['status']=='queued' and queued['listing_code']==allocation['listing_code'])
    wrong=copy.deepcopy(r['plan']);wrong['regions']['back']['width_cm']=1
    check('Source handoff rejects altered approved dimensions',fails(lambda:m.execute(c,{'action':'prepare_listing','brief_id':back['brief_id'],'plan':wrong})))
    approved_plan=m.execute(c,{'action':'approve','listing_code':queued['listing_code'],'revision':1,'stage':'brief',
                              'fingerprint':queued['brief_fingerprint'],'authority':'direct_user','reference':'isolated production plan approval'})
    output=m.execute(c,{'action':'advance','listing_code':queued['listing_code']})
    check('Artwork handoff reaches the existing six-image mockup stage',output['status']=='awaiting_browser_images' and len(output['browser_task']['payload']['images'])==6)
    check('A dated listing prevents upstream art revision in place',fails(lambda:m.execute(c,{'action':'design_revise','brief_id':back['brief_id'],'revision':1,'stage':'2d','authority':'direct_user','reference':'isolated test','reason':'change'})))
    check('Stage tests never count unfinished listing KPI',c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0]==0)
    cancel={**start,'action':'design_cancel','revision':3}
    check('Design cancellation rejects stale revision, fingerprint and nonhuman authority',all(fails(lambda change=change:m.execute(c,{**cancel,**change})) for change in ({'revision':2},{'brief_fingerprint':'wrong'},{'authority':'document'})))
    history={table:c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ('design_assets','design_approvals','kpi','jobs')}
    cancelled=m.execute(c,cancel)
    check('Cancellation removes pending design work and preserves assets and approvals',cancelled['status']=='cancelled' and cancelled['cancelled_tasks']==1 and not c.execute("SELECT 1 FROM design_tasks WHERE brief_id=? AND status='pending'",(b['brief_id'],)).fetchone() and all(c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]==count for table,count in history.items()))
    check('Cancelled design cannot recreate tasks on advance or repeated start',m.execute(c,{'action':'design_advance','brief_id':b['brief_id']})['status']=='cancelled' and m.execute(c,start)['status']=='cancelled' and not any(t.get('brief_id')==b['brief_id'] for t in m.execute(c,{'action':'browser_queue'})['tasks']))
    check('Cancellation rejects artwork allocated to a listing',fails(lambda:m.execute(c,{**cancel,'brief_id':back['brief_id'],'revision':1,'brief_fingerprint':reserve['brief_fingerprint']})))
    c.close()
m.STORE=original_store;m.JOBS=original_jobs
report={'ok':True,'checks':checks,'check_count':len(checks),'isolated_database':True,
        'synthetic_asset_and_ui_fixtures':True,'flow_generation_tested':False,'real_kpi_written':False,'live_brief_approved':False}
m.write(m.STORE/'design-stage-test-report.json',report)
print(json.dumps({'ok':True,'checks':len(checks),'flow_called':False,'live_kpi_written':False}))
