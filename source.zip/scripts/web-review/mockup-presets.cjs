'use strict';
const {hash,fail}=require('../lark-review/review.cjs');
const printed=['01_thumbnail.jpg','02_female_angle.jpg','03_female_seated.jpg','04_flatlay.jpg','05_print_closeup.jpg'];
const embroidery=['01_thumbnail.jpg','02_hoodie_folded.jpg','04_sweatshirt_flatlay.jpg','05_hoodie_flatlay.jpg','07_embroidery_closeup.jpg','10_flatlay.jpg'];
function names(kind){if(kind==='embroidery_prompts')return embroidery;if(['apparel_2d','pajama_top','pajama_set','sleep_pants'].includes(kind))return printed;fail('mockup_preset_invalid');}
function validate(body){
 const expected=names(body.kind);
 if(typeof body.name!=='string'||!body.name.trim()||body.name.trim().length>100||typeof body.source!=='string'||Buffer.byteLength(body.source)>1000000)fail('mockup_preset_invalid');
 const parts=(body.source.trim()+'\n').split(/^===== ([0-9]{2}_[a-z_]+\.jpg) =====[ \t]*\r?\n/m);
 if(parts[0].trim()||parts.length!==expected.length*2+1||expected.some((n,i)=>parts[i*2+1]!==n||!parts[i*2+2].trim()))fail('mockup_preset_incomplete');
 const value={schema_version:1,name:body.name.trim(),kind:body.kind,source:body.source,clean_flatlay:expected.includes('04_flatlay.jpg')?'04_flatlay.jpg':'10_flatlay.jpg'};
 return {...value,id:hash(JSON.stringify(value))};
}
module.exports={names,validate};
