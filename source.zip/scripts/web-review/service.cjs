'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),os=require('node:os');
const {randomBytes,randomUUID}=require('node:crypto');
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const {ReviewStore,hash,fail}=require('../lark-review/review.cjs');
const {BatchStore,MAX_BYTES}=require('../lark-review/batch.cjs');
const {makeServer}=require('../lark-review/service.cjs');
const {atomic,claimProcessLock}=require('../flow-worker/native-n8n.cjs');
const {menuActions,batchCard}=require('../lark-review/cards.cjs');
const mockupPresets=require('./mockup-presets.cjs');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const kinds=['apparel_2d','embroidery_prompts','pajama_top','pajama_set','sleep_pants'];
const loopback=ip=>['127.0.0.1','::1','::ffff:127.0.0.1'].includes(ip);
const token=()=>randomBytes(24).toString('base64url');
const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/manifest.webmanifest':'manifest.webmanifest','/sw.js':'sw.js','/icon.svg':'icon.svg'};
const mimes={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.zip':'application/zip','.json':'application/json','.csv':'text/csv; charset=utf-8'};
class WebTransport{
  constructor(service){this.service=service;this.state=service.web;this.store=service.store;this.directory=path.join(path.dirname(service.config.stateFile),'uploads');}
  async upload(bytes){const id='img_web_'+hash(bytes),file=path.join(this.directory,id);fs.mkdirSync(this.directory,{recursive:true});if(!fs.existsSync(file))fs.writeFileSync(file,bytes);this.state.images[id]={path:file,sha256:hash(bytes)};this.store.save();return id;}
  async send(_chat,type,content,uuid){
    const id='web_'+hash(uuid).slice(0,40);
    if(!this.state.messages[id]){
      this.state.messages[id]={id,type,content,at:Date.now()};
      const review=type==='interactive'&&content.header?.title?.content==='Đủ ảnh để duyệt';
      const done=type==='text'&&/ĐÃ XONG/.test(content.text||'');
      const stopped=content.notification_kind==='workflow_stopped';
      if(review||done||stopped){
        const body=content.text||content.elements?.map(x=>x.text?.content||'').filter(Boolean).join('\n')||'Workflow đã dừng. Mở Workflow3 để xem lỗi; sửa lỗi rồi bấm Tiếp tục mẻ.';
        this.state.pushJobs||={};this.state.pushJobs[id]={title:stopped?'Workflow đã dừng':review?'Có ảnh cần bạn duyệt':'Mẻ đã hoàn thành',body:review?'Mở Workflow3 để xem ảnh và duyệt đúng mẻ.':body.slice(0,180),status:'pending',tag:id};
      }
      this.store.save();this.service.changed();
    }
    return id;
  }
  async update(id,card){if(!this.state.messages[id])fail('web_message_not_found');this.state.messages[id].content=card;this.store.save();this.service.changed();}
  async document(chat,asset,uuid){const id='doc_'+hash(asset.bytes);this.state.documents[id]={bytes_path:path.join(this.directory,id),sha256:hash(asset.bytes),name:asset.name};fs.mkdirSync(this.directory,{recursive:true});fs.writeFileSync(this.state.documents[id].bytes_path,asset.bytes);this.store.save();return this.send(chat,'document',{asset:id,name:asset.name},uuid);}
}
class WebService{
  constructor(config,deps={}){
    config.batchWebhookUrl||='http://127.0.0.1:5678/webhook/etsy-batch-command';
    this.config=config;this.store=deps.store||new ReviewStore(config);this.batch=new BatchStore(this.store);
    this.web=this.store.state.web||={messages:{},images:{},documents:{},sessions:{},requests:{},push:[]};
    this.transport=new WebTransport(this);this.forward=deps.forward||this.native.bind(this);this.snapshot=deps.snapshot||this.readSnapshot.bind(this);this.failures=new Map();this.assets=new Map();this.updated=Date.now();this.snapshotAt=0;
    this.batch.notify('web-welcome','Chọn loại sản phẩm để tạo mẻ. Mẻ mới được lưu vào hàng chờ sau khi bạn xác nhận.',menuActions());this.store.save();
  }
  changed(){this.updated=Date.now();}
  async native(body){let response;try{response=await fetch(body.event_type==='batch_command'?this.config.batchWebhookUrl:this.config.n8nWebhookUrl,{method:'POST',headers:{'content-type':'application/json',[this.config.n8nTokenHeader||'x-review-token']:this.config.n8nToken},body:JSON.stringify(body),signal:AbortSignal.timeout(20000),redirect:'error'});}catch{fail('n8n_unavailable',503);}if(!response.ok)fail(response.status===409?'stale_review':'n8n_unavailable',503);return response.json();}
  async flush(){if(this.flushing)return;this.flushing=true;try{await this.store.flush(this.forward);await this.batch.flush(this.forward);for(const r of Object.values(this.store.state.reviews))if(r.status==='sending')await this.store.deliver(r.review_id,this.transport);await this.store.deliverWorkerStatus(this.transport);await this.store.deliverCardUpdates(this.transport);await this.batch.deliver(this.transport);await this.push();}finally{this.flushing=false;}}
  // Safari rejects placeholder VAPID subjects; use this workflow's configured HTTPS identity.
  async push(){const host=this.config.httpsHosts?.[0];if(!this.config.vapid||!host)return;this.web.push=this.web.push.filter(p=>Object.values(this.web.sessions).some(s=>s.expires>Date.now()&&s.pushEndpoint===p.endpoint));for(const job of Object.values(this.web.pushJobs||{})){if(job.status!=='pending'||(job.next||0)>Date.now())continue;job.sent||=[];let failed=false;for(const subscription of this.web.push){const id=hash(subscription.endpoint);if(job.sent.includes(id))continue;try{await require('web-push').sendNotification(subscription,JSON.stringify({title:job.title,body:job.body,tag:job.tag}),{vapidDetails:{...this.config.vapid,subject:'https://'+host},TTL:86400,timeout:8000,topic:hash(job.tag).slice(0,32)});job.sent.push(id);}catch(e){if([404,410].includes(e.statusCode)){this.web.push=this.web.push.filter(s=>s.endpoint!==subscription.endpoint);}else failed=true;}this.store.save();}job.status=failed?'pending':'sent';job.next=Date.now()+60000;this.store.save();}}
  async readSnapshot(){
    if(Date.now()-this.snapshotAt<4000&&this.cachedSnapshot)return this.cachedSnapshot;
    const {stdout}=await promisify(execFile)(this.config.python||'python',[path.join(__dirname,'snapshot.py')],{cwd:this.config.workflowRoot,windowsHide:true,encoding:'utf8',maxBuffer:8*1024*1024,timeout:15000});
    this.cachedSnapshot=JSON.parse(stdout.replace(/^\uFEFF/,''));this.snapshotAt=Date.now();return this.cachedSnapshot;
  }
  asset(a){const id=hash(JSON.stringify([a.path,a.sha256]));this.assets.set(id,{...a});return '/api/files/'+id;}
  cardView(card,mid){
    const walk=elements=>(elements||[]).flatMap(e=>{
      if(e.tag==='div')return [{type:'text',text:e.text?.content||''}];
      if(e.tag==='img')return [{type:'image',url:'/api/images/'+e.img_key,label:e.alt?.content||'Ảnh cần duyệt'}];
      if(e.tag==='input')return [{type:'input',name:e.name,label:e.label?.content||'Yêu cầu sửa',max:6000}];
      if(e.tag==='form')return [{type:'form',elements:walk(e.elements)}];
      if(e.tag==='button'){const v=e.behaviors?.find(b=>b.type==='callback')?.value;if(!v||(v.scope==='batch'&&['apparel','embroidery','pajama','pants','queue','cancel'].includes(v.action)))return [];return [{type:'button',label:e.text.content,token:hash(JSON.stringify(v)),style:e.type||'default',confirm:e.confirm?.text?.content||'',submit:v.action==='submit_revision'}];}return [];
    });
    return {title:card.header?.title?.content||'Điều khiển mẻ',elements:walk(card.body?.elements),message_id:mid};
  }
  actionValue(mid,digest){const card=this.web.messages[mid]?.content;if(!card)fail('web_card_not_found',404);let found;const walk=els=>{for(const e of els||[]){if(e.elements)walk(e.elements);for(const b of e.behaviors||[])if(b.type==='callback'&&hash(JSON.stringify(b.value))===digest)found={value:b.value,confirm:e.confirm?.text?.content};}};walk(card.body?.elements);if(!found)fail('web_action_not_found',409);return found;}
  session(req){const value=/(?:^|;\s*)workflow_session=([A-Za-z0-9_-]+)/.exec(req.headers.cookie||'')?.[1],session=value&&this.web.sessions[hash(value)];if(!session||session.expires<Date.now())fail('login_required',401);return session;}
  origin(req){const host=req.headers.host||'';if(!this.hosts().has(host))fail('host_not_allowed',403);if(req.headers.origin&&req.headers.origin!==this.originFor(host))fail('origin_not_allowed',403);if(req.headers['sec-fetch-site']==='cross-site')fail('cross_site_denied',403);return host;}
  originFor(host){return (this.config.httpsHosts?.includes(host)?'https://':'http://')+host;}
  hosts(){if(this.config.configFile&&fs.existsSync(this.config.configFile))this.config.httpsHosts=read(this.config.configFile).httpsHosts||[];return new Set([`localhost:${this.config.webPort}`,`127.0.0.1:${this.config.webPort}`,...Object.values(os.networkInterfaces()).flat().filter(n=>n.family==='IPv4').map(n=>`${n.address}:${this.config.webPort}`),...(this.config.httpsHosts||[])]);}
  createSession(req,res){const raw=token(),csrf=token();this.web.sessions[hash(raw)]={csrf,expires:Date.now()+30*86400000,created_at:Date.now()};for(const [k,v]of Object.entries(this.web.sessions))if(v.expires<Date.now())delete this.web.sessions[k];this.store.save();res.setHeader('set-cookie',`workflow_session=${raw}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${this.config.httpsHosts?.includes(req.headers.host)?'; Secure':''}`);return {ok:true,csrf};}
  event(id){return {event_id:'web_event_'+id,message_id:'web_message_'+id};}
  async request(body){
    if(!/^[a-f0-9-]{36}$/.test(body.event_id||''))fail('event_id_required');
    const old=this.web.requests[body.event_id],digest=hash(JSON.stringify(body));if(old){if(old.digest!==digest)fail('event_conflict',409);return {...old.result,duplicate:true};}
    const event=this.event(body.event_id);let result;
    if(body.type==='intake'){
      if(!kinds.includes(body.kind)||typeof body.name!=='string'||!body.name.trim()||body.name.length>300||typeof body.source!=='string'||Buffer.byteLength(body.source)>MAX_BYTES)fail('intake_invalid');
      if(body.embroidery_mode!==undefined&&(body.kind!=='embroidery_prompts'||!['artwork_stages','prompt_to_mockup'].includes(body.embroidery_mode)))fail('embroidery_mode_invalid');
      let reference;if(body.reference_id){reference=this.web.references?.[body.reference_id];if(!reference||hash(fs.readFileSync(reference.path))!==reference.sha256)fail('batch_reference_invalid');}
      let preset;if(body.mockup_preset_id&&body.mockup_preset_id!=='none'){preset=this.web.mockupPresets?.[body.mockup_preset_id];if(!preset||preset.kind!==body.kind)fail('mockup_preset_invalid');preset=mockupPresets.validate(preset);}
      const session={kind:body.kind,name:body.name.trim(),profile_version:3,expires_at:Date.now()+86400000,...(reference?{reference_image:{...reference}}:{}),...(preset?{mockup_prompt_set:preset}:{}),...(body.kind==='embroidery_prompts'?{positions:body.positions}:{})};
      if(body.embroidery_mode==='prompt_to_mockup')session.embroidery_mode='prompt_to_mockup';
      result=this.batch.stage({...event,session},body.source);
    }else if(body.type==='action'){
      const a=this.actionValue(body.message_id,body.token);if(a.confirm&&body.confirmed!==true)fail('confirmation_required',409);
      const data={header:{event_id:event.event_id},event:{operator:{open_id:this.config.humanOpenId},context:{open_chat_id:this.config.chatId,open_message_id:body.message_id},action:{tag:'button',value:a.value,form_value:body.form||{}}}};
      result=a.value.scope==='review'?this.store.receiveCard(data):this.batch.receiveCard(data);
      if(result.card?.data)await this.transport.update(body.message_id,result.card.data);
      if(result.toast?.type==='error')fail('action_rejected',409);
    }else if(body.type==='command'){
      const snapshot=await this.snapshot(),list=snapshot.batches||[];let command;
      if(body.action==='batch_status')command={action:'batch_status'};
      else if(body.action==='batch_run_selected'){
        if(!Array.isArray(body.batch_ids)||body.batch_ids.length<1||new Set(body.batch_ids).size!==body.batch_ids.length||body.batch_ids.some(id=>!list.some(b=>b.batch_id===id&&['submitted','confirmed','stopped','prepared','preparing'].includes(b.status))))fail('batch_selection_invalid');
        command={action:body.action,batch_ids:body.batch_ids};
      }else{
        const b=list.find(b=>b.batch_id===body.batch_id);if(!b)fail('batch_not_found',404);
        const allowed={batch_confirm:['submitted'],batch_start:['confirmed','ready','stopped','prepared'],batch_stop:['active','ready','preparing','prepared'],batch_discard_remaining:['stopped'],batch_retry:['stopped','active','ready']}[body.action];
        if(!allowed?.includes(b.status))fail('batch_state_changed',409);
        if(body.action==='batch_discard_remaining'&&body.confirmed!==true)fail('confirmation_required',409);
        this.batch.state.manifests[b.batch_id]={...this.batch.state.manifests[b.batch_id],batch_fingerprint:b.fingerprint,status:b.status};
        command={action:body.action,batch_id:b.batch_id,batch_fingerprint:b.fingerprint,card_expected_status:[b.status]};
        if(body.action==='batch_retry'){const i=b.items.find(i=>i.item_id===body.item_id&&i.state==='failed');if(!i)fail('failed_item_not_found');command.item_id=i.item_id;command.card_item_revision=i.revision;}
      }
      result=this.batch.queue({...event,interaction_type:'web_control',label:body.action},command);
    }else fail('request_type_invalid');
    this.web.requests[body.event_id]={digest,result};this.store.save();this.snapshotAt=0;this.changed();this.flush().catch(()=>{});return {ok:true,...result};
  }
  async state(){
    let snapshot;try{snapshot=structuredClone(await this.snapshot());}catch{snapshot={batches:[],reports:[],kpi:[],error:'Không đọc được trạng thái sản xuất. Các thao tác đang được giữ an toàn.'};}
    for(const report of snapshot.reports||[])for(const a of report.files||[]){a.url=this.asset(a);delete a.path;delete a.sha256;}
    for(const batch of snapshot.batches||[])if(batch.reference_image){batch.reference_image={url:this.asset(batch.reference_image)};}
    const kpi=path.join(this.config.workflowRoot,'workspace/production/local-reports/KPI.csv');
    if(fs.existsSync(kpi))snapshot.kpi_url=this.asset({path:kpi,sha256:hash(fs.readFileSync(kpi)),name:'KPI.csv'});
    const obsolete=new Set(Object.entries(this.batch.state.notifications).filter(([key])=>Object.values(this.batch.state.outbox).some(o=>o.status!=='pending'&&key.startsWith(o.body.message_id+':error:'))).map(([,n])=>n.message_id));
    const messages=Object.values(this.web.messages).filter(m=>!obsolete.has(m.id)).sort((a,b)=>b.at-a.at).slice(0,100).map(m=>({id:m.id,at:m.at,type:m.type,...(m.type==='interactive'?{card:this.cardView(m.content,m.id)}:m.type==='text'?{text:m.content.text}:m.type==='document'?{document:{url:'/api/documents/'+m.content.asset,name:m.content.name}}:{})}));
    const reviews=Object.values(this.store.state.reviews).filter(r=>['pending','sending','decision_pending'].includes(r.status)).map(r=>({id:r.review_id,status:r.status,stage:r.stage,revision:r.revision,summary:r.summary,entity:r.entity,batch_policy:r.batch_policy,expires_at:r.expires_at,images:r.images.map(a=>({label:a.label||'Ảnh cần duyệt',url:this.asset(a)})),card:messages.find(m=>m.id===r.messages.find(x=>x.slot==='final')?.message_id)?.card}));
    const workerFile=path.join(this.config.workflowRoot,'workspace/batch-worker/runtime/status.json');let worker={status:'unknown'};try{const s=read(workerFile);worker={status:s.status,batch_id:s.batch_id,active_item:s.active_item,updated_at:s.updated_at};}catch{}
    if(snapshot.flow_pool?.enabled){
      const poolFile=path.join(this.config.workflowRoot,'workspace/flow-worker/runtime/pool-status.json');
      try{snapshot.flow_pool.workers=read(poolFile).workers.map(w=>({worker_lane:w.worker_lane,email:w.email,status:w.status,code:w.code,task_id:w.task_id,image_key:w.image_key,updated_at:w.updated_at}));}catch{snapshot.flow_pool.workers=[];}
    }
    return {ok:true,...snapshot,messages,reviews,worker,worker_notice:this.store.state.worker_status?{status:this.store.state.worker_status.status,message:this.store.state.worker_status.message}:null,pending:Object.values(this.batch.state.outbox).filter(o=>o.status==='pending').length+Object.values(this.store.state.outbox).filter(o=>o.status==='pending').length,updated:this.updated};
  }
  server(){
    return http.createServer(async(req,res)=>{
      const json=(status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
      res.setHeader('cache-control','no-store');res.setHeader('x-content-type-options','nosniff');res.setHeader('referrer-policy','no-referrer');res.setHeader('x-frame-options','DENY');res.setHeader('content-security-policy',"default-src 'self'; img-src 'self' blob:; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
      try{
        this.origin(req);const url=new URL(req.url,'http://localhost');
        if(req.method==='GET'&&files[url.pathname]){const file=path.join(__dirname,'public',files[url.pathname]);res.setHeader('content-type',mimes[path.extname(file)]||'text/plain');return res.end(fs.readFileSync(file));}
        if(req.method==='GET'&&url.pathname==='/api/session'){const s=this.session(req);return json(200,{ok:true,csrf:s.csrf});}
        let body;
        if(req.method==='POST'){
          if(req.headers.origin!==this.originFor(req.headers.host))fail('origin_required',403);
          if(req.headers['content-type']?.split(';')[0]!=='application/json')fail('json_required',415);
          const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>(url.pathname==='/api/reference'?14*1024*1024:MAX_BYTES+15000))fail('request_too_large',413);chunks.push(chunk);}try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{fail('json_invalid');}
          if(url.pathname==='/api/local-session'){if(!loopback(req.socket.remoteAddress)||!/^((localhost)|(127\.0\.0\.1)):\d+$/.test(req.headers.host))fail('local_computer_only',403);return json(200,this.createSession(req,res));}
          if(url.pathname==='/api/login'){
            const ip=req.socket.remoteAddress,attempt=this.failures.get(ip)||{n:0,at:Date.now()};if(Date.now()-attempt.at>600000){attempt.n=0;attempt.at=Date.now();}if(attempt.n>=8)fail('login_try_later',429);attempt.n++;this.failures.set(ip,attempt);
            if(!this.web.pairing||this.web.pairing.expires<Date.now()||hash(String(body.code||'').replace(/\s|-/g,'').toUpperCase())!==this.web.pairing.hash)fail('pairing_code_invalid',401);
            delete this.web.pairing;this.failures.delete(ip);return json(200,this.createSession(req,res));
          }
        }
        const session=this.session(req);
        if(req.method==='POST'&&req.headers['x-workflow-csrf']!==session.csrf)fail('csrf_invalid',403);
        if(req.method==='GET'&&url.pathname==='/api/mockup-presets')return json(200,{ok:true,presets:Object.values(this.web.mockupPresets||{})});
        if(req.method==='POST'&&url.pathname==='/api/mockup-presets'){
          const preset=mockupPresets.validate(body);this.web.mockupPresets||={};
          if(Object.values(this.web.mockupPresets).some(p=>p.kind===preset.kind&&p.name.toLocaleLowerCase()===preset.name.toLocaleLowerCase()&&p.id!==preset.id))fail('mockup_preset_name_exists');
          if(!this.web.mockupPresets[preset.id]&&Object.keys(this.web.mockupPresets).length>=100)fail('mockup_preset_limit');
          this.web.mockupPresets[preset.id]=preset;this.store.save();return json(200,{ok:true,preset});
        }
        if(req.method==='POST'&&url.pathname==='/api/reference'){
          if(typeof body.data!=='string'||! /^[A-Za-z0-9+/]+={0,2}$/.test(body.data))fail('batch_reference_invalid');
          const bytes=Buffer.from(body.data,'base64');if(bytes.length>10*1024*1024)fail('reference_too_large',413);
          const ext=bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'))?'png':bytes[0]===255&&bytes[1]===216?'jpg':bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP'?'webp':null;if(!ext)fail('batch_reference_invalid');
          const id=hash(bytes),directory=path.join(this.config.workflowRoot,'workspace/production/batch-references'),file=path.join(directory,id+'.'+ext);fs.mkdirSync(directory,{recursive:true});if(!fs.existsSync(file))fs.writeFileSync(file,bytes,{flag:'wx',mode:0o600});
          try{await promisify(execFile)(this.config.python||'python',['-c','from PIL import Image; import sys; im=Image.open(sys.argv[1]); assert im.format in ("PNG","JPEG","WEBP") and im.width*im.height<=40000000; im.verify()',file],{windowsHide:true,timeout:15000});}catch{fail('batch_reference_invalid');}
          this.web.references||={};this.web.references[id]={path:file,sha256:id,role:'batch_style_reference'};this.store.save();return json(200,{ok:true,reference_id:id,url:this.asset(this.web.references[id])});
        }
        if(req.method==='GET'&&url.pathname==='/api/push-key')return json(200,{ok:true,publicKey:this.config.vapid?.publicKey});
        if(req.method==='POST'&&url.pathname==='/api/push-subscription'){
          const s=body.subscription;let u;try{u=new URL(s?.endpoint);}catch{fail('push_subscription_invalid');}
          if(u.protocol!=='https:'||u.username||u.password||u.port||!(/(^|\.)push\.apple\.com$/.test(u.hostname)||['fcm.googleapis.com','updates.push.services.mozilla.com'].includes(u.hostname))||! /^[A-Za-z0-9_-]{80,100}$/.test(s.keys?.p256dh||'')||! /^[A-Za-z0-9_-]{20,30}$/.test(s.keys?.auth||''))fail('push_subscription_invalid');
          this.web.push=this.web.push.filter(p=>p.endpoint!==s.endpoint);if(this.web.push.length>=10)fail('push_device_limit');this.web.push.push({endpoint:s.endpoint,keys:{p256dh:s.keys.p256dh,auth:s.keys.auth}});session.pushEndpoint=s.endpoint;this.store.save();return json(200,{ok:true});
        }
        if(req.method==='POST'&&url.pathname==='/api/pairing'){
          if(!loopback(req.socket.remoteAddress))fail('local_computer_only',403);const code=randomBytes(9).toString('hex').toUpperCase();this.web.pairing={hash:hash(code),expires:Date.now()+600000};this.store.save();return json(200,{ok:true,code:code.match(/.{1,6}/g).join('-'),expires:this.web.pairing.expires,urls:[...this.hosts()].filter(h=>!h.startsWith('127.')&&!h.startsWith('localhost')).map(h=>this.originFor(h))});
        }
        if(req.method==='POST'&&url.pathname==='/api/logout'){const raw=/(?:^|;\s*)workflow_session=([A-Za-z0-9_-]+)/.exec(req.headers.cookie||'')?.[1];this.web.push=this.web.push.filter(p=>p.endpoint!==session.pushEndpoint);delete this.web.sessions[hash(raw)];this.store.save();res.setHeader('set-cookie','workflow_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return json(200,{ok:true});}
        if(req.method==='POST'&&url.pathname==='/api/request')return json(202,await this.request(body));
        if(req.method==='GET'&&url.pathname==='/api/state')return json(200,await this.state());
        if(req.method==='GET'&&url.pathname.startsWith('/api/')){
          const [, ,kind,id]=url.pathname.split('/');let a,bytes;
          if(kind==='files'){a=this.assets.get(id);if(!a)fail('file_not_found',404);bytes=/\.(png|jpg|jpeg|webp)$/i.test(a.path)?this.store.validateImage(a):this.store.validateDocument(a).bytes;}
          else if(kind==='images'){a=this.web.images[id];if(a){bytes=fs.readFileSync(a.path);if(hash(bytes)!==a.sha256)fail('image_hash_changed',409);}}
          else if(kind==='documents'){const d=this.web.documents[id];if(d){a={name:d.name};bytes=fs.readFileSync(d.bytes_path);if(hash(bytes)!==d.sha256)fail('document_hash_changed',409);}}
          if(!a||!bytes)fail('file_not_found',404);
          const mime=kind==='images'?(bytes[0]===137?'image/png':bytes[0]===255?'image/jpeg':'image/webp'):mimes[path.extname(a.name||a.path).toLowerCase()]||'application/octet-stream';res.setHeader('content-type',mime);
          if(!mime.startsWith('image/'))res.setHeader('content-disposition',"attachment; filename*=UTF-8''"+encodeURIComponent(a.name||path.basename(a.path)));return res.end(bytes);
        }
        fail('route_not_found',404);
      }catch(e){json(e.status||500,{ok:false,code:e.code||'web_request_failed'});}
    });
  }
  async run(){
    const internal=makeServer(this.config,this.store,()=>this.flush().catch(()=>{}),()=> 'connected',()=>this.flush().catch(()=>{}),this.batch),web=this.server();
    await new Promise((resolve,reject)=>{internal.once('error',reject);internal.listen(this.config.port||8790,'127.0.0.1',resolve);});
    try{await new Promise((resolve,reject)=>{web.once('error',reject);web.listen(this.config.webPort,this.config.webBind||'0.0.0.0',resolve);});}catch(e){internal.close();throw e;}
    const stopFile=this.config.stateFile+'.stop.request';if(fs.existsSync(stopFile))fs.unlinkSync(stopFile);
    const stop=()=>{clearInterval(tick);watch.close();internal.close();web.close();};
    const watch=fs.watch(path.dirname(stopFile),()=>{if(fs.existsSync(stopFile))stop();});
    const tick=setInterval(()=>this.flush().catch(()=>{}),1500);process.once('SIGINT',stop);process.once('SIGTERM',stop);await this.flush();
    atomic(path.join(path.dirname(this.config.stateFile),'status.json'),{status:'running',transport:'private_web',pid:process.pid,webPort:this.config.webPort,updated_at:new Date().toISOString()});
    console.log('Workflow web ready on port '+this.config.webPort);
  }
}
async function main(){const file=process.env.WEB_REVIEW_CONFIG||path.resolve(__dirname,'../../config/web-review.private.json'),config={...read(file),configFile:file};if(config.transport!=='web'||!config.humanOpenId||!config.chatId||!Number.isInteger(config.webPort))fail('web_config_invalid');fs.mkdirSync(path.dirname(config.stateFile),{recursive:true});const release=claimProcessLock(config.stateFile+'.lock','web-review');process.once('exit',release);await new WebService(config).run();}
module.exports={WebService,WebTransport};
if(require.main===module)main().catch(e=>{console.error(e.code||'web_service_start_failed');process.exitCode=1;});
