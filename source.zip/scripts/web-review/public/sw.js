'use strict';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
// Keep reviews and decisions on the network; never replay an approval offline.
self.addEventListener('push',event=>{const data=event.data?.json()||{};event.waitUntil(self.registration.showNotification(data.title||'Workflow3',{body:data.body||'Có cập nhật trong xưởng.',icon:'/icon.svg',tag:data.tag||'workflow3',data:{url:'/#reviews'}}));});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.openWindow(event.notification.data?.url||'/'));});
