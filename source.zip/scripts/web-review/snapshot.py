"""Read-only dashboard projection; all production mutations remain in native n8n."""
import json
import sqlite3
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
c = sqlite3.connect((root / 'workspace/production/production.sqlite').as_uri() + '?mode=ro', uri=True)
c.row_factory = sqlite3.Row
c.execute('PRAGMA query_only=ON')
batches = []
for row in c.execute('SELECT * FROM production_batches ORDER BY queue_order,created_at'):
    b = {k: row[k] for k in ('batch_id', 'fingerprint', 'status', 'queue_order')}
    p = json.loads(row['payload'])
    b.update(name=p.get('name', row['batch_id']), kind=p.get('kind'))
    if p.get('embroidery_mode'):
        b['embroidery_mode'] = p['embroidery_mode']
    b['mockup_preset_name']=p.get('mockup_prompt_set',{}).get('name','Không trang trí')
    if p.get('reference_image'):
        b['reference_image'] = p['reference_image']
    b['items'] = [dict(i) for i in c.execute('SELECT item_id,state,revision,listing_code,error FROM production_batch_items WHERE batch_id=? ORDER BY position', (row['batch_id'],))]
    batches.append(b)
run = c.execute("SELECT value FROM config WHERE key='batch_run_plan'").fetchone()
reports = []
for row in c.execute("SELECT a.code,a.revision,a.payload FROM artifacts a JOIN jobs j ON a.code=j.code AND a.revision=j.revision WHERE a.kind='package' AND j.state='completed' ORDER BY j.created_at DESC"):
    p = json.loads(row['payload'])
    r = {'code': p.get('public_listing_code', row['code']), 'revision': row['revision'], 'completed_at': p.get('completed_at'), 'files': p.get('files', [])}
    for f in r['files']:
        f['name'] = Path(f['path']).name
    content = c.execute("SELECT payload FROM artifacts WHERE code=? AND revision=? AND kind='text'", (row['code'], row['revision'])).fetchone()
    if content:
        text = json.loads(content['payload'])
        r.update({k: text.get(k) for k in ('title', 'description', 'tags')})
    local = c.execute("SELECT payload FROM artifacts WHERE code=? AND revision=? AND kind='local_delivery'", (row['code'], row['revision'])).fetchone()
    if local:
        proof = json.loads(local['payload'])
        r['files'] += [dict(proof[k], name=Path(proof[k]['path']).name) for k in ('report', 'content')]
    reports.append(r)
    cloud = c.execute("SELECT payload FROM artifacts WHERE code=? AND revision=? AND kind='google_delivery'", (row['code'], row['revision'])).fetchone()
    if cloud:
        receipt = json.loads(cloud['payload'])
        r['google'] = {key: receipt[key]['url'] for key in ('docs', 'sheets', 'drive')}
kpi = [dict(r) for r in c.execute("SELECT code,target_date,completed_at FROM kpi WHERE code NOT LIKE '%_PILOT' ORDER BY target_date,completed_at")]
result = {'batches': batches, 'run_plan': json.loads(run['value']) if run else None, 'reports': reports, 'kpi': kpi}
pool=c.execute("SELECT value FROM config WHERE key='flow_worker_pool'").fetchone()
if pool:
    value=json.loads(pool[0])
    result['flow_pool']={k:value[k] for k in ('enabled','lanes','queue')}
google_config = root / 'config/google-delivery.json'
if google_config.is_file():
    g = json.loads(google_config.read_text(encoding='utf-8-sig'))
    status_file = root / 'workspace/production/google-sync/status.json'
    result['google_sync'] = json.loads(status_file.read_text(encoding='utf-8-sig')) if status_file.is_file() else {}
    result['google_sync']['enabled'] = g.get('enabled', False)
    result['google_sync']['urls'] = {'docs': 'https://docs.google.com/document/d/' + g['document_id'] + '/edit', 'sheets': 'https://docs.google.com/spreadsheets/d/' + g['spreadsheet_id'] + '/edit', 'drive': 'https://drive.google.com/drive/folders/' + g['folder_id']}
sys.stdout.reconfigure(encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
