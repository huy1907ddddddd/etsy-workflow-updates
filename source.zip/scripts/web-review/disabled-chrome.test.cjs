'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {chromium}=require('C:/Users/ADMIN/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {WebService}=require('./service.cjs');

test('dashboard hides a disabled Chrome and derives counts from enabled lanes without removing its batch history',async t=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'two-chrome-ui-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const lanes=[1,2,3].map(id=>({id,email:id===3?'shaun@example.com':`account${id}@example.com`,batch_id:'batch'+id,disabled:id===3}));
 const workers=lanes.map(l=>({worker_lane:l.id,status:l.disabled?'disabled':'idle'}));
 const poolFile=path.join(root,'workspace/flow-worker/runtime/pool-status.json');fs.mkdirSync(path.dirname(poolFile),{recursive:true});
 const save=()=>fs.writeFileSync(poolFile,JSON.stringify({workers}));save();
 const data={flow_pool:{enabled:true,lanes},batches:lanes.map(l=>({batch_id:l.batch_id,name:'Saved batch '+l.id,kind:'embroidery_prompts',status:'stopped',items:[{item_id:'item',state:'queued'}]})),reports:[],kpi:[]};
 const config={transport:'web',workflowRoot:root,stateFile:path.join(root,'state.json'),humanOpenId:'fixture_owner',chatId:'fixture_chat',localToken:'x'.repeat(40),webPort:0,allowedImageRoots:[root]};
 const service=new WebService(config,{snapshot:async()=>structuredClone(data)});service.flush=async()=>{};
 const server=service.server();await new Promise(r=>server.listen(0,'127.0.0.1',r));config.webPort=server.address().port;t.after(()=>new Promise(r=>server.close(r)));
 const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});t.after(()=>browser.close());
 const page=await browser.newPage();await page.goto('http://127.0.0.1:'+config.webPort+'/');await page.getByRole('button',{name:'Mở trên máy tính này'}).click();
 await page.getByRole('heading',{name:'2/2 Chrome đã nhận mẻ',exact:true}).waitFor();
 await page.locator('a[data-tab="queue"]').click();
 await page.getByRole('heading',{name:'2 Chrome · mỗi Chrome một mẻ',exact:true}).waitFor();
 assert.equal(await page.locator('#group-progress h4').count(),2);assert.equal(await page.locator('#group-progress').getByText(/shaun|Chrome 3/).count(),0);
 assert.equal(await page.locator('#batch-list > article').count(),3);
 assert.equal(data.batches.length,3);
 lanes[2].disabled=false;await page.reload();await page.getByRole('heading',{name:'2 Chrome · mỗi Chrome một mẻ',exact:true}).waitFor();
 workers[2].status='idle';lanes[2].disabled=true;save();await page.reload();await page.getByRole('heading',{name:'2 Chrome · mỗi Chrome một mẻ',exact:true}).waitFor();assert.equal(await page.locator('#group-progress h4').count(),2);
 lanes[2].disabled=false;save();await page.reload();await page.getByRole('heading',{name:'3 Chrome · mỗi Chrome một mẻ',exact:true}).waitFor();assert.equal(await page.locator('#group-progress h4').count(),3);
});
