'use strict';
const fs=require('node:fs'),path=require('node:path');
const {atomic}=require('../flow-worker/native-n8n.cjs');
const root=path.resolve(__dirname,'../..'),file=path.join(root,'config/web-review.private.json');
if(fs.existsSync(file)){console.log('Existing web configuration preserved.');process.exit(0);}
const old=JSON.parse(fs.readFileSync(path.join(root,'config/lark-review.private.json'),'utf8').replace(/^\uFEFF/,'')),keys=require('web-push').generateVAPIDKeys();
const config={transport:'web',workflowRoot:root,stateFile:path.join(root,'workspace/web-review/state.json'),humanOpenId:'web_owner',chatId:'web_private_workspace',port:8790,webPort:8796,webBind:'0.0.0.0',cardDestinations:[],vapid:keys};
for(const k of ['localToken','n8nToken','n8nTokenHeader','n8nWebhookUrl','batchWebhookUrl','allowedImageRoots'])if(old[k]!==undefined)config[k]=old[k];
config.allowedImageRoots=[...new Set([...config.allowedImageRoots,...['C:/Huy/Đã xử lý','C:/Huy/Chưa xử lý'].filter(p=>fs.existsSync(p))])];
config.batchWebhookUrl||='http://127.0.0.1:5678/webhook/etsy-batch-command';
atomic(file,config);console.log('Private web configuration saved. No bot token required.');
