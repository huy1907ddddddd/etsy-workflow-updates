const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {runJob,TEXT_WORKER_BUILD} = require('./codex-title-description-worker.cjs');
const {runListing} = require('./codex-listing-worker.cjs');
const keywordWorker = require('./codex-keyword-worker.cjs');
const {runProduction} = require('./production-worker.cjs');
const root = path.resolve(__dirname, '..');
const cli = process.env.ETSY_CODEX_CLI;
if (!cli || !fs.existsSync(cli)) throw Error('Codex CLI missing');
const token = fs.readFileSync(path.join(root, 'bridge-token.txt'), 'utf8').trim();
let busy = false;
function reply(res, code, body) {
  if (!res.destroyed) {res.writeHead(code, {'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(body));}
}
const server = http.createServer(async (req, res) => {
  if (req.headers.origin) return reply(res,403,{error:'Browser requests are not allowed'});
  if (req.method === 'GET' && req.url === '/health') return reply(res,200,{ok:true,busy,service:'etsy-production',version:7,build:'20261026-pajama-set1',text_worker_build:TEXT_WORKER_BUILD,product_profiles:3,capabilities:['pilot','registered_listing','keyword_discovery','keyword_candidates','keyword_checkpoint','tag_selection','durable_production','versioned_approval','image_processor','kpi_allocation','browser_outbox','typed_codex_usage_limits']});
  const keywordRoutes=['/keywords/preflight','/keywords/seeds','/keywords/discovery-plan','/keywords/discovery-checkpoint','/keywords/candidates','/keywords/plan','/keywords/checkpoint','/keywords/selection'];
  if (req.method !== 'POST' || (req.url !== '/title-description' && req.url !== '/production' && !keywordRoutes.includes(req.url))) return reply(res,404,{error:'Not found'});
  if (req.headers['x-bridge-token'] !== token) return reply(res,401,{error:'Invalid bridge token'});
  if (busy && req.url !== '/production') return reply(res,409,{error:'Codex is busy; retry later'});
  try {
    let size=0;
    const chunks=[];
    for await (const chunk of req) {
      size+=chunk.length;
      if (size>(['/keywords/checkpoint','/keywords/discovery-checkpoint','/production'].includes(req.url)?2000000:4096)) return reply(res,413,{error:'Request too large'});
      chunks.push(chunk);
    }
    const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if(req.url==='/production')return runProduction({res,input,reply,release:()=>{}});
    if (busy) return reply(res,409,{error:'Codex is busy; retry later'});
    if(req.url==='/keywords/preflight')return reply(res,200,keywordWorker.preflight(input));
    if(req.url==='/keywords/discovery-plan')return reply(res,200,keywordWorker.discoveryPlan(input));
    if(req.url==='/keywords/discovery-checkpoint')return reply(res,200,keywordWorker.saveDiscovery(input));
    if(req.url==='/keywords/plan')return reply(res,200,keywordWorker.plan(input));
    if(req.url==='/keywords/checkpoint')return reply(res,200,keywordWorker.saveCheckpoint(input));
    busy=true;
    if(req.url==='/keywords/seeds')return keywordWorker.runSeeds({res,input,cli,reply,release:()=>{busy=false;}});
    if(req.url==='/keywords/candidates')return keywordWorker.runCandidates({res,input,cli,reply,release:()=>{busy=false;}});
    if(req.url==='/keywords/selection')return keywordWorker.runSelection({res,input,cli,reply,release:()=>{busy=false;}});
    const worker = input && Object.hasOwn(input,'listing_code') ? runListing : runJob;
    worker({res,input,cli,reply,release:()=>{busy=false;}});
  } catch(error) {busy=false;return reply(res,400,{error:'Keyword or job request failed validation',detail:error.message});}
});
server.requestTimeout=360000;
server.listen(8788,'127.0.0.1',()=>console.log('CODEX_PILOT_READY http://127.0.0.1:8788'));
server.on('error',error=>{console.error('Pilot bridge failed:',error.code);process.exit(1);});
