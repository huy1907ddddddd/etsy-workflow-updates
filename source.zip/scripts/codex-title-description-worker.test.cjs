'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');
const { PassThrough } = require('node:stream');

async function runFixture(t, webSearch, toolTypes, failure = null) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'codex-web-probe-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  let args, released = 0;
  const fixture = { exports: {} };
  const spawn = (_exe, command) => {
    args = command;
    const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.stdin = new PassThrough(); child.kill = () => child.emit('close', null);
    setImmediate(() => {
      if (failure) { child.stdout.write(JSON.stringify(failure) + '\n'); child.emit('close', 1); return; }
      fs.writeFileSync(command[command.indexOf('-o') + 1], JSON.stringify({ fixture: true }));
      for (const type of toolTypes) child.stdout.write(JSON.stringify({ type: 'item.completed', item: { type, id: type } }) + '\n');
      child.stdout.write(JSON.stringify({ type: 'turn.completed', usage: {} }) + '\n'); child.emit('close', 0);
    });
    return child;
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'codex-title-description-worker.cjs'), 'utf8'), {
    require: name => name === 'node:child_process' ? { spawn } : require(name), module: fixture, __dirname, process, Buffer, setTimeout, clearTimeout,
  });
  const response = await new Promise(resolve => fixture.exports.runJob({ res: {}, input: {}, cli: 'fixture-cli', outputRoot: directory,
    outputSchemaPath: path.join(directory, 'schema.json'), webSearch, load: () => ({ hash: 'a'.repeat(64), prompt: 'fixture', instructions: 'fixture' }),
    release: () => released++, reply: (_res, status, body) => resolve({ status, body }) }));
  assert.equal(released, 1);
  const reports = fs.readdirSync(directory).filter(name => name.startsWith('worker-failure-')).map(name => JSON.parse(fs.readFileSync(path.join(directory, name), 'utf8')));
  return { ...response, args, reports };
}

test('Title worker remains text-only and rejects a web-search result', async t => {
  const normal = await runFixture(t, false, []); assert.equal(normal.status, 200); assert.equal(normal.body.external_tools_used, false);
  assert.equal(normal.args.includes('web_search="live"'), false);
  assert.ok(normal.args.includes('web_search="disabled"'));
  assert.ok(normal.args.includes('features.shell_tool=false'));
  assert.ok(normal.args.includes('mcp_servers.node_repl.enabled=false'));
  const rejected=await runFixture(t, false, ['web_search']);
  assert.equal(rejected.status, 502);
  assert.equal(rejected.reports[0].error_code,'codex_text_turn_invalid');
  assert.ok(rejected.reports[0].event_types.some(e=>e.item_type==='web_search'));
});

test('research requires actual search events, enables live search and keeps evidence', async t => {
  const result = await runFixture(t, true, ['web_search']);
  assert.equal(result.status, 200); assert.equal(result.body.external_tools_used, true); assert.equal(result.body.research_events.length, 1);
  assert.ok(result.args.includes('web_search="live"')); assert.ok(result.args.includes('features.shell_tool=false'));
  assert.equal((await runFixture(t, true, [])).status, 502);
});

test('research rejects MCP, commands and file changes even alongside web search', async t => {
  for (const type of ['mcp_tool_call', 'command_execution', 'file_change']) assert.equal((await runFixture(t, true, ['web_search', type])).status, 502);
});

test('CLI quota on stdout with empty stderr is preserved and returned as a non-retryable usage limit', async t => {
  const failure = { type: 'turn.failed', error: { message: 'You’ve hit your usage limit. Try again later.', codex_error_info: 'usage_limit_exceeded' } };
  const result = await runFixture(t, false, [], failure);
  assert.equal(result.status, 502); assert.equal(result.body.error, 'codex_usage_limit_exceeded');
  assert.equal(result.body.retryable, false); assert.equal(result.reports.length, 1);
  assert.equal(result.reports[0].stderr, ''); assert.deepEqual(result.reports[0].failure_events, [failure]);
  assert.equal(result.reports[0].error_code, result.body.error);
});

test('an unrelated CLI failure is retained without being mislabeled as a usage limit', async t => {
  const failure = { type: 'error', message: 'Connection closed unexpectedly' };
  const result = await runFixture(t, false, [], failure);
  assert.equal(result.body.error, 'codex_generation_failed');
  assert.deepEqual(result.reports[0].failure_events, [failure]);
});
