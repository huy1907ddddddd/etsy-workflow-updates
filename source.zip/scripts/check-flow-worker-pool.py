"""Three-lane isolation/queue tests in a temporary SQLite DB and filesystem."""
import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import flow_worker_pool as pool
import production_batch as batch


class PoolTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row;self.addCleanup(self.c.close)
        self.c.execute('CREATE TABLE config(key TEXT PRIMARY KEY,value TEXT)');batch.tables(self.c)
        self.accounts=['one@example.com','two@example.com','three@example.com']
        def write(file,value):
            file=Path(file);file.parent.mkdir(parents=True,exist_ok=True);file.write_text(json.dumps(value),encoding='utf8')
        self.e={'ROOT':self.root,'read':lambda p:json.loads(Path(p).read_text()),'write':write,'scoped':lambda p:Path(p).resolve(),
                'sha':lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(),
                'now':lambda:'2026-11-05T02:00:00+00:00','design_module':lambda:SimpleNamespace(authority=self.authority)}
        write(pool.selection_file(self.e),{'provider':'flow','account_policy':{'enabled':True,'reference':'saved policy','accounts':[{'email':x}for x in self.accounts]}})
        for n in range(5):
            bid='b'+str(n);self.c.execute('INSERT INTO production_batches VALUES(?,?,?,?,?,?,?)',(bid,str(n)*64,'{}','confirmed',n,'fixture','2026-11-05'))
            self.c.execute('INSERT INTO production_batch_items VALUES(?,?,?,?,?,?,?,?,?,?)',(bid,'item',0,'queued',1,'brief'+str(n),None,'{}',None,None))

    def authority(self,cmd):
        if cmd.get('authority')!='direct_user' or not cmd.get('reference'):
            raise ValueError('Human authority required')

    def configure(self,**extra):
        return pool.execute(self.c,{'action':'batch_pool_configure','accounts':self.accounts,'batch_ids':['b0','b1','b2','b3','b4'],'authority':'direct_user','reference':'Fixture human requests3Chrome',**extra},self.e)

    def ready(self):
        p=pool.get(self.c)
        for lane in p['lanes']:lane['ready']=True
        pool.save(self.c,p)

    def test_three_unique_leases_fifo_and_fourth_waits_until_completion(self):
        self.configure();self.ready();p=pool.schedule(self.c,self.e)
        self.assertEqual([x['batch_id']for x in p['lanes']],['b0','b1','b2'])
        self.assertEqual(self.c.execute("SELECT count(*) FROM production_batches WHERE status='active'").fetchone()[0],3)
        self.assertEqual(pool.schedule(self.c,self.e)['lanes'],p['lanes'])
        self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id='b1'")
        p=pool.schedule(self.c,self.e)
        self.assertEqual([x['batch_id']for x in p['lanes']],['b0','b3','b2'])
        self.assertIsNone(next(x for x in p['queue']if x['batch_id']=='b4')['assigned'])

    def test_disabled_shaun_keeps_checkpoint_and_only_other_two_lanes_receive_work(self):
        self.configure();self.ready()
        lane=pool.get(self.c)['lanes'][2]
        marker=pool.runtime(self.e,lane)/'worker.disabled.json'
        self.e['write'](marker,{'reference':'Fixture user uses only Chrome1 and2'})
        p=pool.schedule(self.c,self.e)
        self.assertEqual([x['batch_id'] for x in p['lanes']],['b0','b1',None])
        self.assertFalse(p['lanes'][2]['ready']);self.assertTrue(p['lanes'][2]['disabled'])
        with pool.command_scope(self.c,{'worker_lane':3},self.e):
            self.assertIsNone(pool.choose(self.c,self.e))
            with self.assertRaisesRegex(ValueError,'disabled'):
                pool.execute(self.c,{'action':'batch_pool_ready','authority':'direct_user','reference':'Fixture readiness must not reactivate removed Chrome'},self.e)
        marker.unlink();self.ready();p=pool.schedule(self.c,self.e)
        self.assertEqual(p['lanes'][2]['batch_id'],'b2')
        self.e['write'](marker,{'reference':'Disable again after lease was acquired'})
        p=pool.schedule(self.c,self.e)
        self.assertEqual(p['lanes'][2]['batch_id'],'b2')
        self.assertEqual(next(x for x in p['queue'] if x['batch_id']=='b2')['assigned'],3)
        self.assertEqual(self.c.execute("SELECT status FROM production_batches WHERE batch_id='b2'").fetchone()[0],'active')
        for _ in range(4):
            with pool.command_scope(self.c,{},self.e):
                self.assertIn(pool.choose(self.c,self.e)['batch_id'],('b0','b1'))

    def test_error_stops_only_its_batch_and_does_not_auto_resume(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id='b1'")
        batch.controls.stop_plan(self.c,'b1');p=pool.schedule(self.c,self.e)
        self.assertEqual(p['lanes'][1]['blocked'],'batch_stopped')
        self.assertEqual([x['batch_id']for x in p['lanes']],['b0','b1','b2'])
        self.assertEqual(self.c.execute("SELECT count(*) FROM production_batches WHERE status='active'").fetchone()[0],2)
        pool.resume(self.c,batch.batch(self.c,'b1'),self.e,'Fixture human repaired/resumes exactbatch')
        self.assertIsNone(pool.get(self.c)['lanes'][1]['blocked'])

    def test_lane_scope_provider_and_journals_never_cross(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        import chatgpt_image_orchestration as images
        for number in (1,2,3):
            with pool.command_scope(self.c,{'action':'flow_cycle','worker_lane':number},self.e):
                chosen=pool.choose(self.c,self.e);self.assertEqual(chosen['batch_id'],'b'+str(number-1))
                choice=images.selection(self.e);self.assertEqual(choice['batch_id'],chosen['batch_id'])
                self.assertEqual(choice['account_policy']['preferred_email'],self.accounts[number-1])
                self.assertTrue(choice['account_policy']['pool_fixed_account'])
                self.assertTrue(pool.in_scope(chosen['batch_id']));self.assertFalse(pool.in_scope('unrelated'))
        self.assertTrue(pool.in_scope('unrelated'))
        with self.assertRaisesRegex(ValueError,'lease changed'):
            with pool.command_scope(self.c,{'worker_lane':2,'worker_lane_batch_id':'b0'},self.e):pass
        with self.assertRaisesRegex(ValueError,'another Flow lane'):
            with pool.command_scope(self.c,{'worker_lane':2,'batch_id':'b0'},self.e):pass

    def test_login_readiness_is_required_and_proof_is_bound_to_account(self):
        self.configure();p=pool.schedule(self.c,self.e);self.assertTrue(all(x['batch_id']is None for x in p['lanes']))
        with pool.command_scope(self.c,{'worker_lane':2},self.e):
            file=pool.runtime(self.e)/'ready.json';self.e['write'](file,{'worker_lane':2,'verified_email':self.accounts[1],'checked_at':self.e['now']()})
            cmd={'action':'batch_pool_ready','authority':'direct_user','reference':'Fixture signed-in account observed','evidence_path':str(file),'evidence_sha256':self.e['sha'](file)}
            pool.execute(self.c,cmd,self.e)
            self.e['write'](file,{'worker_lane':2,'verified_email':self.accounts[0],'checked_at':self.e['now']()});cmd['evidence_sha256']=self.e['sha'](file)
            with self.assertRaisesRegex(ValueError,'matching Flow account'):pool.execute(self.c,cmd,self.e)
        p=pool.schedule(self.c,self.e);self.assertEqual(p['lanes'][1]['batch_id'],'b0');self.assertIsNone(p['lanes'][0]['batch_id'])

    def test_changed_fingerprint_blocks_and_stopped_checkpoint_is_adopted_without_resume(self):
        self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id='b0'")
        self.configure(checkpoint_batch_id='b0');self.ready();p=pool.schedule(self.c,self.e)
        self.assertEqual(p['lanes'][0]['batch_id'],'b0');self.assertEqual(p['lanes'][0]['blocked'],'batch_stopped')
        self.c.execute("UPDATE production_batches SET fingerprint='changed' WHERE batch_id='b1'")
        p=pool.schedule(self.c,self.e);self.assertEqual(p['lanes'][1]['blocked'],'batch_binding_changed')

    def test_disabled_pool_preserves_legacy_selector_and_duplicate_accounts_rejected(self):
        self.assertFalse(pool.enabled(self.c))
        original=batch.controls.choose(self.c,self.e);self.assertIsNone(original)
        with self.assertRaisesRegex(ValueError,'three distinct'):
            self.configure(accounts=[self.accounts[0]]*3)

    def test_finished_last_lease_clears_provider_and_legacy_jobs_stay_parked(self):
        self.configure(batch_ids=['b0']);self.ready();pool.schedule(self.c,self.e)
        self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id='b0'")
        p=pool.schedule(self.c,self.e)
        self.assertTrue(all(x['batch_id'] is None for x in p['lanes']))
        self.assertIsNone(self.e['read'](pool.selection_file(self.e))['batch_id'])
        self.assertFalse(batch.runnable(self.c,brief_id='unrelated'))

    def test_native_job_commands_follow_owner_and_wrong_lane_is_rejected(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        with pool.command_scope(self.c,{'brief_id':'brief1'},self.e):
            self.assertEqual(self.e['read'](pool.selection_file(self.e))['worker_lane'],2)
        with self.assertRaisesRegex(ValueError,'Job belongs'):
            with pool.command_scope(self.c,{'worker_lane':1,'brief_id':'brief1'},self.e):pass

    def test_pending_tasks_filtered_before_shared_queue_limit(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        for n in range(3):
            self.c.execute("UPDATE production_batch_items SET state='generating_sample' WHERE batch_id=?",('b'+str(n),))
            for k in range(12):
                self.c.execute('INSERT INTO production_batch_tasks VALUES(?,?,?,?,?,?,?,?,?,?)',(f't{n}-{k}','b'+str(n),'item',1,'sample_mockup',str(k),'pending','{}',None,'2026-11-05'))
        with pool.command_scope(self.c,{'worker_lane':3},self.e):
            self.assertEqual(len(batch.queue(self.c)),12)
            self.assertTrue(all(x['batch_id']=='b2' for x in batch.queue(self.c)))

    def test_signed_web_queue_does_not_apply_legacy_global_worker_binding(self):
        self.configure()
        body={'event_id':'fixture-pool-web','message_id':'fixture-web-button','reference':'Fixture human selects queued batches','command':{'action':'batch_run_selected','batch_ids':['b1','b2']}}
        with patch('production_batch.canonical_command',return_value=body):
            result=batch.execute(self.c,{'action':'batch_lark_command','event_id':body['event_id']},self.e)
        self.assertEqual(result['group_status'],'parallel')
        self.assertFalse(any(x.get('ready') for x in pool.get(self.c)['lanes']))
        self.assertIsNone(self.e['read'](pool.selection_file(self.e))['batch_id'])
        with patch('production_batch.canonical_command',return_value=body):
            self.assertEqual(batch.execute(self.c,{'action':'batch_lark_command','event_id':body['event_id']},self.e),result)

    def test_real_design_schema_without_kind_column_can_submit_only_in_own_lane(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        self.c.execute('CREATE TABLE design_tasks(id TEXT PRIMARY KEY,brief_id TEXT,revision INTEGER,stage TEXT,fingerprint TEXT,status TEXT,payload TEXT,created_at TEXT)')
        import chatgpt_image_orchestration as images
        for n,stage in enumerate(['2d','embroidery','sizes']):
            self.c.execute('INSERT INTO design_tasks VALUES(?,?,?,?,?,?,?,?)',('design'+str(n),'brief1',1,stage,'f'*64,'pending','{}','2026-11-05'))
        for n,stage in enumerate(['2d','embroidery']):
            self.assertEqual(images.source_task(self.c,'design'+str(n))['kind'],'flow_design_'+stage)
            with pool.command_scope(self.c,{'worker_lane':2,'task_id':'design'+str(n)},self.e):
                self.assertTrue(pool.in_scope('b1'))
            with self.assertRaisesRegex(ValueError,'another Flow lane'):
                with pool.command_scope(self.c,{'worker_lane':1,'task_id':'design'+str(n)},self.e):pass
        with self.assertRaisesRegex(ValueError,'Source must be an image task'):images.source_task(self.c,'design2')

    def test_old_batch_unlimited_retry_grant_never_transfers_into_pool_choices(self):
        template=self.e['read'](pool.selection_file(self.e))
        grant={'enabled':True,'cooldown_ms':600000,'retry_after_cooldown':True,'retry_unlimited':True,'reference':'Fixture old human grant ONLY batch-old'}
        template['unusual_activity_policy']=grant;self.e['write'](pool.selection_file(self.e),template)
        self.configure();self.ready();p=pool.schedule(self.c,self.e)
        for lane in p['lanes']:
            self.assertNotIn('unusual_activity_policy',self.e['read'](pool.runtime(self.e,lane)/'image-provider.json'))
        self.assertEqual(p['provider_template']['unusual_activity_policy'],grant)
        self.e['write'](pool.runtime(self.e,p['lanes'][2])/'image-provider.json',template)
        pool.execute(self.c,{'action':'batch_pool_poll','refresh_choices':True,'authority':'direct_user','reference':'Fixture human repairs inherited retry scope'},self.e)
        self.assertNotIn('unusual_activity_policy',self.e['read'](pool.runtime(self.e,p['lanes'][2])/'image-provider.json'))

    def test_explicit_pool_retry_grant_reaches_all_current_and_future_leases(self):
        self.configure();self.ready();pool.schedule(self.c,self.e)
        policy={'enabled':True,'cooldown_ms':600000,'retry_after_cooldown':True,'retry_unlimited':True}
        cmd={'action':'batch_pool_poll','refresh_choices':True,'unusual_activity_policy':policy,
             'authority':'direct_user','reference':'Fixture user authorizes all current and future batches every full ten minutes'}
        result=pool.execute(self.c,cmd,self.e)
        expected=dict(policy,reference=cmd['reference'])
        self.assertEqual(result['pool']['unusual_activity_policy'],expected)
        for lane in result['pool']['lanes']:
            choice=self.e['read'](pool.runtime(self.e,lane)/'image-provider.json')
            self.assertEqual(choice['unusual_activity_policy'],expected)
            self.assertEqual(choice['account_policy']['preferred_email'],lane['email'])
            self.assertTrue(choice['account_policy']['pool_fixed_account'])
            self.assertNotIn('on_unusual_activity',choice['account_policy'])
        self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id='b0'")
        refreshed=pool.schedule(self.c,self.e)
        self.assertEqual(refreshed['lanes'][0]['batch_id'],'b3')
        self.assertEqual(self.e['read'](pool.selection_file(self.e))['unusual_activity_policy'],expected)
        self.assertNotIn('unusual_activity_policy',refreshed['provider_template'])

    def handover_fixture(self):
        self.configure();self.ready();p=pool.schedule(self.c,self.e)
        self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id='b0'")
        for lane in (p['lanes'][0],p['lanes'][2]):
            self.e['write'](pool.runtime(self.e,lane)/'worker.disabled.json',{'reason':'batch1_handover_maintenance' if lane['id']==1 else 'user_disabled_shaun'})
        self.e['write'](pool.runtime(self.e,{'id':1})/'pool-status.json',{'updated_at':self.e['now'](),'workers':[{'worker_lane':i,'pid':None,'process_status':'disabled'} for i in (1,3)]})
        evidence=self.root/'inspection.json';self.e['write'](evidence,{'checked':True})
        self.c.execute("INSERT INTO production_batch_tasks VALUES(?,?,?,?,?,?,?,?,?,?)",('task','b2','i',1,'sample_mockup','fp','pending','{}',None,'now'))
        file=pool.runtime(self.e,p['lanes'][2])/'task-fixture.json'
        self.e['write'](file,{'task_id':'task','fingerprint':'fp','revision':1,'images':{},'events':[]})
        request={'batch_id':'b2','batch_fingerprint':p['lanes'][2]['batch_fingerprint'],'source_lane':3,'target_lane':1,
                 'previous_batch_id':'b0','previous_batch_fingerprint':p['lanes'][0]['batch_fingerprint'],
                 'journals':[{'name':file.name,'sha256':self.e['sha'](file)}],'evidence_path':str(evidence),'evidence_sha256':self.e['sha'](evidence)}
        return {'action':'batch_pool_poll','authority':'direct_user','reference':'Fixture user explicitly moves inspected batch','handover':request},file

    def test_explicit_handover_preserves_source_and_parks_previous_batch(self):
        cmd,file=self.handover_fixture()
        asset=self.root/'original.png';asset.write_bytes(b'fixture original bytes')
        journal=self.e['read'](file);journal['images']={'left_chest':{'status':'acquired','asset':{'path':str(asset),'sha256':self.e['sha'](asset)}}}
        self.e['write'](file,journal);cmd['handover']['journals'][0]['sha256']=self.e['sha'](file);original=file.read_bytes()
        result=pool.execute(self.c,cmd,self.e);self.assertEqual(result['status'],'flow_batch_handed_over')
        p=pool.get(self.c);self.assertEqual(p['lanes'][0]['batch_id'],'b2');self.assertIsNone(p['lanes'][2]['batch_id'])
        self.assertEqual(file.read_bytes(),original);self.assertEqual((pool.runtime(self.e,{'id':1})/file.name).read_bytes(),original)
        self.assertEqual(next(x for x in p['queue'] if x['batch_id']=='b0')['assigned'],None)
        self.assertEqual(self.c.execute("SELECT status FROM production_batches WHERE batch_id='b0'").fetchone()[0],'stopped')
        self.assertTrue((pool.runtime(self.e,{'id':3})/'worker.disabled.json').exists())
        self.assertEqual(asset.read_bytes(),b'fixture original bytes')

    def test_handover_rejects_unknown_outcome_until_exact_native_retry_permit(self):
        cmd,file=self.handover_fixture();j=self.e['read'](file);j['images']={'thumbnail':{'status':'generation_started','generation_id':'old'}};self.e['write'](file,j)
        cmd['handover']['journals'][0]['sha256']=self.e['sha'](file)
        with self.assertRaisesRegex(ValueError,'Reconcile every'):
            pool.execute(self.c,cmd,self.e)
        permit={'task_id':'task','task_fingerprint':'fp','revision':1,'image_key':'thumbnail','generation_id':'old'}
        self.c.execute('INSERT INTO config VALUES(?,?)',('flow_generation_retry:fixture',json.dumps(permit)))
        self.assertTrue(pool.execute(self.c,cmd,self.e)['ok'])

    def test_handover_rejects_changed_manifest_running_target_and_nonhuman(self):
        cmd,file=self.handover_fixture()
        with self.assertRaisesRegex(ValueError,'Human authority'):
            pool.execute(self.c,dict(cmd,authority='worker'),self.e)
        cmd['handover']['journals']=[]
        with self.assertRaisesRegex(ValueError,'manifest'):
            pool.execute(self.c,cmd,self.e)
        self.e['write'](pool.runtime(self.e,{'id':1})/'pool-status.json',{'updated_at':self.e['now'](),'workers':[{'worker_lane':1,'pid':123,'process_status':'running'}]})
        with self.assertRaisesRegex(ValueError,'quiescent'):
            pool.execute(self.c,cmd,self.e)

    def test_pool_retry_grant_rejects_short_wait_missing_authority_or_refresh(self):
        self.configure()
        policy={'enabled':True,'cooldown_ms':600000,'retry_after_cooldown':True,'retry_unlimited':True}
        cmd={'action':'batch_pool_poll','refresh_choices':True,'unusual_activity_policy':policy,
             'authority':'direct_user','reference':'Fixture human'}
        for change in ({'cooldown_ms':60000},{'enabled':False},{'retry_after_cooldown':False},{'retry_unlimited':False}):
            with self.assertRaisesRegex(ValueError,'full ten-minute'):
                pool.execute(self.c,dict(cmd,unusual_activity_policy=dict(policy,**change)),self.e)
        with self.assertRaisesRegex(ValueError,'full ten-minute'):
            pool.execute(self.c,dict(cmd,refresh_choices=False),self.e)
        with self.assertRaisesRegex(ValueError,'Human authority'):
            pool.execute(self.c,dict(cmd,authority='worker'),self.e)
        self.assertNotIn('unusual_activity_policy',pool.get(self.c))


if __name__=='__main__':unittest.main(verbosity=2)
