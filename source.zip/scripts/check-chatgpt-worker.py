"""Native ChatGPT browser worker fixtures; no live image/chat or production mutation."""
import copy
import importlib.util
import json
import hashlib
import unittest
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('batch_fixture', Path(__file__).with_name('check-production-batch.py'))
fixture = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture)
import chatgpt_image_orchestration as chat


class ChatGPTTests(unittest.TestCase):
    def setUp(self):
        self.f = fixture.BatchTests(); self.f.setUp()
        self.selection_patch = patch.object(chat, 'selection', return_value={})
        self.selection_patch.start()
        self.f.start(); self.task = self.f.cycle()['tasks'][0]

    def tearDown(self):
        self.selection_patch.stop()
        self.f.tearDown()

    def queue(self):
        return self.f.execute({'action': 'chatgpt_image_enqueue', 'source_task_id': self.task['id'],
            'source_fingerprint': self.task['fingerprint'], 'test_only': True, **self.f.auth})

    def command(self, job_id):
        payload = json.loads(self.f.c.execute('SELECT payload FROM chatgpt_image_jobs WHERE id=?', (job_id,)).fetchone()[0])
        task = copy.deepcopy(self.task); task['payload']['output_directory'] = payload['output_directory']
        command = self.f.candidate(task)
        proof = command['proof']; proof.update(executor='independent_chatgpt_worker', acquisition='chatgpt_download', model='ChatGPT observed fixture model', url='https://chatgpt.com/c/fixture-conversation')
        records = []
        for asset, provenance in zip(command['assets'], proof['prompt_provenance']):
            receipt = Path(payload['output_directory']) / (asset['image_key'] + '.receipt.json')
            data = {'url': proof['url'], 'model': proof['model'], 'prompt_sha256': provenance['prompt_sha256'],
                    'reference_sha256': provenance['reference_sha256'], 'asset': {'path':asset['path'], 'sha256':asset['sha256']},
                    'acquisition': 'chatgpt_download', 'user_prompt_visible': True, 'download_button_label': 'Download'}
            receipt.write_text(json.dumps(data), encoding='utf-8')
            record = {**proof, **provenance, 'receipt_path':str(receipt), 'receipt_sha256':self.f.env['sha'](receipt)}
            record.pop('images',None); record.pop('prompt_provenance',None); records.append(record)
        proof.update(records[0], images=records)
        return {'action':'chatgpt_image_attach', 'job_id':job_id, 'source_fingerprint':self.task['fingerprint'], 'assets':command['assets'], 'proof':proof}

    def test_test_job_is_idempotent_and_source_unchanged(self):
        first = self.queue(); self.assertEqual(first, self.queue())
        self.assertEqual(self.f.cycle()['tasks'][0], self.task)
        self.assertEqual(self.f.c.execute('SELECT COUNT(*) FROM chatgpt_image_jobs').fetchone()[0],1)

    def test_stale_source_and_document_authority_rejected(self):
        for extra in ({'source_fingerprint':'wrong'}, {'authority':'document'}):
            with self.assertRaises(ValueError):
                self.f.execute({'action':'chatgpt_image_enqueue','source_task_id':self.task['id'], 'source_fingerprint':self.task['fingerprint'], 'test_only':True, **self.f.auth, **extra})

    def test_test_result_does_not_attach_or_approve_production(self):
        job = self.queue()['job_id']; command = self.command(job)
        result = self.f.execute(command); self.assertEqual(result['status'],'chatgpt_test_completed')
        self.assertEqual(result,self.f.execute(command)); self.assertFalse(result['quality_verified'])
        self.assertEqual(self.f.cycle()['tasks'][0]['id'],self.task['id'])
        self.assertFalse(self.f.cycle()['reviews'])
        self.assertEqual(self.f.c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0],0)

    def test_extension_candidate_explicitly_requires_active_codex_and_no_automatic_qa(self):
        job=self.queue()['job_id'];command=self.command(job)
        command['proof']['executor']='codex_chatgpt_browser'
        with self.assertRaises(ValueError):self.f.execute(command)
        for record in [command['proof']]+command['proof']['images']:
            record.update(executor='codex_chatgpt_browser',browser_transport='official_extension',requires_active_codex_session=True)
        result=self.f.execute(command)
        self.assertFalse(result['quality_verified']);self.assertFalse(self.f.cycle()['reviews'])

    def test_windows_computer_use_proof_names_transport_and_keeps_human_qa(self):
        job=self.queue()['job_id'];command=self.command(job)
        for record in [command['proof']]+command['proof']['images']:
            record.update(executor='codex_chatgpt_browser',browser_transport='windows_computer_use',requires_active_codex_session=True)
        result=self.f.execute(command)
        self.assertEqual(result['status'],'chatgpt_test_completed');self.assertFalse(result['quality_verified'])

    def test_changed_receipt_screenshot_prompt_and_false_approval_fail(self):
        job = self.queue()['job_id']; original = self.command(job)
        for mutation in (lambda x:x['proof'].update(visually_verified=True), lambda x:x['proof'].update(screenshot_sha256='wrong'),
                         lambda x:x['proof'].update(receipt_sha256='wrong'), lambda x:x['proof']['images'][0].update(prompt_sha256='wrong')):
            command=copy.deepcopy(original);mutation(command)
            with self.assertRaises(ValueError):self.f.execute(command)

    def test_real_batch_route_uses_chatgpt_proof_and_still_requires_review(self):
        live = self.f.execute({'action':'chatgpt_image_enqueue','source_task_id':self.task['id'],
            'source_fingerprint':self.task['fingerprint'],'test_only':False,**self.f.auth})
        command=self.command(live['job_id']);result=self.f.execute(command)
        self.assertFalse(result['quality_verified'])
        self.assertEqual(self.f.cycle()['reviews'][0]['stage'],'sample_mockup')
        self.assertEqual(self.f.c.execute('SELECT COUNT(*) FROM production_batch_policies').fetchone()[0],0)

    def production_cycle(self, tasks=None):
        import flow_lark_orchestration as flow
        with patch.object(chat, 'selection', return_value={'provider':'chatgpt','mode':'extension_production'}), \
             patch.object(flow, 'execute', return_value={'reviews':[]}), \
             patch.dict(self.f.env, {'execute':lambda c,cmd: {'tasks':tasks if tasks is not None else [self.task]}}):
            return chat.execute(self.f.c, {'action':'chatgpt_cycle'}, self.f.env)

    def test_production_extension_auto_enqueues_once_and_excludes_test_jobs(self):
        test_id=self.queue()['job_id']
        first=self.production_cycle();second=self.production_cycle()
        self.assertEqual(first['tasks'],second['tasks']);self.assertEqual(len(first['tasks']),1)
        self.assertFalse(first['tasks'][0]['test_only']);self.assertNotEqual(first['tasks'][0]['id'],test_id)
        self.assertEqual(first['executor_required'],'active_codex_session_with_official_browser_extension')
        self.assertEqual(self.f.c.execute('SELECT COUNT(*) FROM chatgpt_image_jobs').fetchone()[0],2)
        self.assertEqual(self.production_cycle([])['tasks'],[])
        self.assertEqual(self.f.c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0],0)

    def test_unresolved_flow_checkpoint_is_reported_without_stopping_other_jobs(self):
        other=copy.deepcopy(self.task);other['id']='other-pending-task'
        original=chat.enqueue
        def guarded(c,task,*args,**kwargs):
            if task['id']==self.task['id']:
                raise ValueError('Flow checkpoint contains generated or unresolved images; reconcile before provider transfer')
            return original(c,task,*args,**kwargs)
        with patch.object(chat,'enqueue',side_effect=guarded):
            result=self.production_cycle([self.task,other])
        self.assertEqual([t['source_task']['id'] for t in result['tasks']],['other-pending-task'])
        self.assertEqual(result['queue_issues'][0]['task_id'],self.task['id'])

    def test_highest_chat_reasoning_is_frozen_in_new_job_and_requires_observed_proof(self):
        with patch.object(chat,'selection',return_value={'chat_reasoning':'highest_available'}):
            job=self.queue()['job_id']
        command=self.command(job)
        with self.assertRaisesRegex(ValueError,'reasoning evidence'):
            self.f.execute(command)
        for record in command['proof']['images']:
            fields={'reasoning_policy':'highest_available','reasoning_label':'Observed fixture highest level','reasoning_menu_verified':True}
            record.update(fields)
            receipt=Path(record['receipt_path']);data=json.loads(receipt.read_text());data.update(fields)
            receipt.write_text(json.dumps(data));record['receipt_sha256']=self.f.env['sha'](receipt)
        command['proof'].update(command['proof']['images'][0])
        result=self.f.execute(command);self.assertEqual(result['status'],'chatgpt_test_completed')

    def test_flow_cooldown_policy_is_explicit_native_configuration(self):
        written=[]
        command={'action':'chatgpt_worker_select','mode':'flow','unusual_activity_policy':{'enabled':True,'cooldown_ms':600000},**self.f.auth}
        with patch.dict(self.f.env,{'write':lambda p,value:written.append(value)}):
            chat.execute(self.f.c,command,self.f.env)
            with self.assertRaises(ValueError):
                chat.execute(self.f.c,{**command,'unusual_activity_policy':{'enabled':True,'cooldown_ms':599999}},self.f.env)
        self.assertEqual(written[0]['provider'],'flow')
        self.assertEqual(written[0]['unusual_activity_policy']['cooldown_ms'],600000)
        self.assertEqual(written[0]['unusual_activity_policy']['reference'],self.f.auth['reference'])
        with patch.dict(self.f.env,{'write':lambda p,value:written.append(value)}):
            chat.execute(self.f.c,{**command,'unusual_activity_policy':{'enabled':True,'cooldown_ms':600000,'retry_after_cooldown':True}},self.f.env)
            with self.assertRaises(ValueError):
                chat.execute(self.f.c,{**command,'unusual_activity_policy':{'enabled':True,'cooldown_ms':600000,'retry_after_cooldown':False}},self.f.env)
        self.assertTrue(written[-1]['unusual_activity_policy']['retry_after_cooldown'])

    def test_selecting_next_flow_batch_retains_one_minute_failed_policy(self):
        policy={'enabled':True,'cooldown_ms':60000,'reference':'Earlier fixture user'}
        written=[]
        with patch.object(chat,'selection',return_value={'generation_failure_policy':policy}), patch.dict(self.f.env,{'write':lambda p,value:written.append(value)}):
            chat.execute(self.f.c,{'action':'chatgpt_worker_select','mode':'flow',**self.f.auth},self.f.env)
        self.assertEqual(written[0]['generation_failure_policy'],policy)


if __name__ == '__main__':unittest.main(verbosity=2)
