"""Isolated deletion scope checks; no real output, service, or database writes."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('production-engine.py'))
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
import production_batch as batch
import production_batch_delete as deletion


class DeleteTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='isolated-batch-delete-')
        root=Path(self.tmp.name)/'workflow';store=root/'workspace/production';jobs=root/'n8n/jobs'
        self.e=dict(vars(engine),ROOT=root,STORE=store,JOBS=jobs)
        self.c=engine.connect(store/'fixture.sqlite');batch.tables(self.c)
        self.cmd=dict(action='batch_delete',batch_id='fixture-target',batch_fingerprint='target-fp',
                      authority='direct_user',reference='Fixture explicit scoped deletion')
        self.review=root/'n8n/private-review.json'
        engine.write(root/'config/lark-review.private.json',{'stateFile':str(self.review)})
        engine.write(root/'workspace/flow-worker/runtime/supervisor-status.json',{'status':'stopped'})
        engine.write(self.review,{'reviews':{'r-target':{'entity':{'batch_id':'fixture-target'}},
                                            'r-keep':{'entity':{'batch_id':'fixture-keep'}}},
                                 'seen':{},'outbox':{'target':{'review_id':'r-target'},'keep':{'review_id':'r-keep'}},
                                 'batch':{'events':{'target':{'batch_id':'fixture-target'},'keep':{'batch_id':'fixture-keep'}}}})
        engine.write(jobs/'registry.json',{'jobs':{'TST_261016_01':{'status':'ready'},'GEN_261016_01':{'status':'completed'}}})
        for bid,brief,code in [('fixture-target','B-target','TST_261016_01'),('fixture-keep','B-keep','GEN_261016_01')]:
            self.c.execute('INSERT INTO production_batches VALUES(?,?,?,?,?,?,?)',(bid,'target-fp' if bid==self.cmd['batch_id'] else 'keep-fp','{}','stopped',1,'fixture','now'))
            self.c.execute('INSERT INTO production_batch_items VALUES(?,?,?,?,?,?,?,?,?,?)',(bid,code,1,'production',1,brief,None,'{}',code,None))
            self.c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)',(code,1,'production','hash','{}','now'))
            self.c.execute('INSERT INTO config VALUES(?,?)',('review_delegation:'+bid,json.dumps({'batch_id':bid})))
            self.c.execute('INSERT INTO config VALUES(?,?)',('flow_generation_retry:'+bid,json.dumps({'batch_id':bid})))
            engine.write(store/'batches'/bid/'manifest.json',{'batch_id':bid})
            engine.write(root/'workspace/flow-worker/browser-profile/flow-worker-projects.json',{'projects':{'fixture-target':{},'fixture-keep':{}}})
            engine.write(jobs.parent/'current-state'/('batch-'+bid+'.json'),{'state':'before'})
        self.kept=engine.sha(store/'batches/fixture-keep/manifest.json')

    def tearDown(self):self.c.close();self.tmp.cleanup()

    def test_preview_and_exact_deletion_preserve_other_batch(self):
        preview=deletion.execute(self.c,self.cmd,self.e)
        self.assertEqual(self.c.execute('SELECT count(*) FROM jobs').fetchone()[0],2)
        self.assertTrue((self.e['STORE']/'batches/fixture-target/manifest.json').exists())
        engine.write(self.e['JOBS'].parent/'current-state/batch-fixture-target.json',{'preview':'new receipt bytes'})
        result=deletion.execute(self.c,dict(self.cmd,dry_run=False,delete_fingerprint=preview['delete_fingerprint']),self.e)
        self.assertEqual(result['status'],'batch_deleted')
        self.assertEqual([r[0] for r in self.c.execute('SELECT batch_id FROM production_batches')],['fixture-keep'])
        self.assertEqual([r[0] for r in self.c.execute('SELECT code FROM jobs')],['GEN_261016_01'])
        self.assertEqual(len(list(self.c.execute('SELECT * FROM config'))),2)
        self.assertEqual(engine.sha(self.e['STORE']/'batches/fixture-keep/manifest.json'),self.kept)
        self.assertFalse((self.e['STORE']/'batches/fixture-target').exists())
        self.assertEqual(list(engine.read(self.review)['reviews']),['r-keep'])
        self.assertEqual(list(engine.read(self.e['JOBS']/'registry.json')['jobs']),['GEN_261016_01'])

    def test_changed_inventory_or_active_batch_cannot_delete(self):
        p=deletion.execute(self.c,self.cmd,self.e)
        engine.write(self.e['STORE']/'batches/fixture-target/manifest.json',{'changed':True})
        with self.assertRaisesRegex(ValueError,'inventory changed'):
            deletion.execute(self.c,dict(self.cmd,dry_run=False,delete_fingerprint=p['delete_fingerprint']),self.e)
        self.c.execute("UPDATE production_batches SET status='running' WHERE batch_id='fixture-target'")
        with self.assertRaisesRegex(ValueError,'stopped batch'):
            deletion.execute(self.c,self.cmd,self.e)

    def test_repeated_prompt_codes_do_not_own_other_batch_history(self):
        state=engine.read(self.review)
        state['batch']['outbox']={'keep-message':{'body':{'event_id':'keep-event',
            'command':{'batch_id':'fixture-keep','items':[{'title':'TST_261016_01',
            'idea_prompt':'Reuse fixture-target as text, not ownership'}]}}}}
        state['batch']['notifications']={'keep-message:result':{'bindings':{'fixture-keep':1},
            'text':'Draft fixture-keep includes TST_261016_01','message_id':'keep-card'}}
        engine.write(self.review,state)
        self.c.execute('INSERT INTO production_batch_events VALUES(?,?)',('keep-event',json.dumps(
            {'batch_id':'fixture-keep','items':[{'title':'TST_261016_01'}]})))
        p=deletion.plan(self.c,self.cmd,self.e)
        self.assertNotIn('production_batch_events',p['rows'])
        self.assertNotIn('keep-card',p['bot_messages'])
        kept=p['edits'][str(self.review.resolve())]['batch']
        self.assertEqual(kept['outbox'],state['batch']['outbox'])
        self.assertEqual(kept['notifications'],state['batch']['notifications'])

    def test_target_command_event_and_notification_are_removed_together(self):
        state=engine.read(self.review)
        state['batch'].update(outbox={'target-message':{'body':{'event_id':'target-event',
            'command':{'batch_id':'fixture-target'}}}},events={'target-event':'target-message'},
            notifications={'target-message:result':{'text':'draft','message_id':'target-card'}})
        engine.write(self.review,state)
        p=deletion.plan(self.c,self.cmd,self.e)
        kept=p['edits'][str(self.review.resolve())]['batch']
        self.assertEqual(kept['outbox'],{});self.assertEqual(kept['events'],{})
        self.assertEqual(kept['notifications'],{})
        self.assertEqual(p['bot_messages'],['target-card'])

    def test_delivered_batch_and_wrong_binding_are_refused(self):
        with self.assertRaisesRegex(ValueError,'fingerprint'):
            deletion.execute(self.c,dict(self.cmd,batch_fingerprint='wrong'),self.e)
        self.c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)',('TST_261016_01',1,'2026-10-18','now','fp'))
        with self.assertRaisesRegex(ValueError,'cloud reconciliation'):
            deletion.execute(self.c,self.cmd,self.e)

    def test_external_link_target_is_refused(self):
        outside=Path(self.tmp.name)/'outside';outside.mkdir();(outside/'keep.txt').write_text('keep')
        link=self.e['STORE']/'batches/fixture-target/link'
        try:link.symlink_to(outside,target_is_directory=True)
        except OSError:self.skipTest('Symlink privilege unavailable')
        # rglob may skip directory symlinks; any enumerated redirected file must be rejected.
        f=self.e['STORE']/'batches/fixture-target/file-link.txt';f.symlink_to(outside/'keep.txt')
        with self.assertRaisesRegex(ValueError,'outside exact'):
            deletion.execute(self.c,self.cmd,self.e)
        self.assertTrue((outside/'keep.txt').exists())


if __name__=='__main__':unittest.main()
