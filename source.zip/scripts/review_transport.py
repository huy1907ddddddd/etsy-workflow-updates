"""Selected human review transport; old Lark receipts remain unchanged."""
def config(e):
    pointer = e['ROOT'] / 'config/review-transport.json'
    choice = e['read'](pointer) if pointer.is_file() else {}
    if choice.get('provider') in ('telegram', 'web'):
        return e['read'](e['ROOT'] / ('config/' + choice['provider'] + '-review.private.json'))
    return e['read'](e['ROOT'] / 'config/lark-review.private.json')


def local_delivery(e):
    pointer = e['ROOT'] / 'config/review-transport.json'
    return pointer.is_file() and e['read'](pointer).get('delivery_backend') == 'local_v1'


def authorize(body, selected):
    if body.get('transport', 'lark') != selected.get('transport', 'lark'):
        raise ValueError('Review transport differs from the paired service')
    if body.get('sender_open_id') != selected['humanOpenId'] or body.get('chat_id') != selected['chatId']:
        raise ValueError('Review sender or chat is not authorized')
