"""Isolated shared-guide and portrait gates; no production generation or approval."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image, ImageDraw
import embroidery_layout as layout

spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('check-production-batch.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,batch,flow=fixture.engine,fixture.batch,fixture.flow
import production_profiles as profiles


class LayoutTests(fixture.BatchTests):
    def setUp(self):
        super().setUp()
        policy=patch.object(layout,'canvas_policy',return_value=None)
        policy.start();self.addCleanup(policy.stop)

    def native_policy(self):
        return {'mode':'keep_native_canvas','flow_aspect_ratio':'16:9','authority':'direct_user','reference':'Isolated fixture user relaxes sleeve crop'}

    def test_portrait_native_sleeves_keep_whole_frame_through_both_review_stages(self):
        policy={**self.native_policy(),'flow_aspect_ratio':'9:16'}
        with patch.object(layout,'canvas_policy',return_value=policy):
            self.start(self.command());self.cycle()
            for stage in ('2d','embroidery'):
                task=self.execute({'action':'browser_queue'})['tasks'][0]
                for image in task['payload']['images']:
                    if image['region'].endswith('sleeve'):
                        self.assertEqual((image['aspect_ratio'],image['output_aspect_ratio']),('9:16','9:16'))
                        self.assertIn('portrait 9:16',image['prompt']);self.assertNotIn('landscape 16:9',image['prompt'])
                        self.assertIn('not an exact pixel crop',image['prompt'])
                command=self.candidate(task)
                left=next(a for a in command['assets'] if a['image_key']=='left_sleeve')
                next(a for a in command['assets'] if a['image_key']=='right_sleeve').update(path=left['path'],sha256=left['sha256'])
                before=Path(left['path']).read_bytes()
                self.execute(command)
                self.assertEqual(Path(left['path']).read_bytes(),before)
                review=flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)
                self.assertEqual(review['stage'],stage)
                flow.apply_decision(self.c,self.decision(review),self.env)

    def test_reference_map_deduplicates_shared_sleeve_and_keeps_chest_separate(self):
        regions={'center_chest':{'path':'chest.png','sha256':'a'*64},'left_sleeve':{'path':'sleeve.png','sha256':'b'*64},'right_sleeve':{'path':'sleeve.png','sha256':'b'*64}}
        refs=profiles.region_references(regions)
        self.assertEqual(len(refs),2)
        self.assertEqual(refs[0]['regions'],['center_chest'])
        self.assertEqual(refs[1]['regions'],['left_sleeve','right_sleeve'])
        text=profiles.reference_manifest(refs)
        self.assertIn('Image 1: COMPLETE approved embroidery for center_chest ONLY',text)
        self.assertIn('Image 2: COMPLETE approved embroidery for left_sleeve, right_sleeve ONLY',text)
        self.assertIn('never move it sideways into a left-chest logo',text)
        self.assertNotIn('regions',regions['center_chest'])

    def command(self):
        return {**self.submit,'profile_version':3,'kind':'embroidery_prompts','mockup_set':'embroidery_10_v1',
                'positions':{'chest':'left_right','sleeves':True,'back':True},
                'items':[{'title':'Fixture portrait','designs':{r:'Own scene '+r for r in ('left_chest','right_chest','left_sleeve','back')}}]}

    def raw(self,wide=False,blank=False):
        file=engine.STORE/'original.png';im=Image.new('RGB',(180,320),'white')
        if not blank:ImageDraw.Draw(im).rectangle((10,20,170,300) if wide else (70,30,110,290),fill='green')
        im.save(file);return {'path':str(file),'sha256':engine.sha(file)}

    def test_white_margin_crop_is_lossless_exact_and_idempotent(self):
        raw=self.raw();before=Path(raw['path']).read_bytes();result,receipt=layout.normalize(raw,self.env)
        with Image.open(result['path']) as out,Image.open(raw['path']) as original:
            self.assertEqual(out.size,(84,312));self.assertTrue(layout.ratio_ok(*out.size,'7:26'))
            self.assertEqual(out.tobytes(),original.crop(receipt['crop_box']).tobytes())
            self.assertEqual(dict((color,count) for count,color in out.getcolors())[(0,128,0)],41*261)
        self.assertEqual(Path(raw['path']).read_bytes(),before)
        self.assertFalse(receipt['resized']);self.assertEqual(layout.normalize(raw,self.env),(result,receipt))
        self.assertEqual(layout.normalize(result,self.env),(result,None))
        self.assertFalse(layout.ratio_ok(100,101,'1:1'))

    def test_crop_refuses_overflow_blank_wrong_ratio_and_changed_hash(self):
        with self.assertRaisesRegex(ValueError,'exceeds'):layout.normalize(self.raw(wide=True),self.env)
        with self.assertRaisesRegex(ValueError,'blank'):layout.normalize(self.raw(blank=True),self.env)
        raw=self.raw();Image.new('RGB',(100,100),'green').save(raw['path']);raw['sha256']=engine.sha(Path(raw['path']))
        with self.assertRaisesRegex(ValueError,'9:16'):layout.normalize(raw,self.env)
        raw['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'hash'):layout.normalize(raw,self.env)

    def test_reference_cleanup_activates_only_after_prior_batch_completes_and_keeps_existing_approvals_and_tasks(self):
        from types import SimpleNamespace
        import production_design as design
        self.start(self.command());self.cycle();task=self.execute({'action':'browser_queue'})['tasks'][0]
        cmd=self.candidate(task);left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve');next(a for a in cmd['assets'] if a['image_key']=='right_sleeve').update(path=left['path'],sha256=left['sha256'])
        self.execute(cmd);flow.apply_decision(self.c,self.decision(flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)),self.env)
        prior=copy.deepcopy(self.command());prior['batch_id']='fixture-prior-batch';self.execute(prior)
        cleanup={'after_batch_id':prior['batch_id'],'authority':'direct_user','reference':'Fixture human waits until current batch finishes','instruction':'SOURCE CLEANUP: Do not embroider black exterior contour strokes; convert the intended solid color areas only.'}
        saved_tasks=[tuple(x) for x in self.c.execute('SELECT * FROM design_tasks')];saved_approvals=[tuple(x) for x in self.c.execute('SELECT * FROM design_approvals')]
        read=engine.read
        def configured(file):
            value=read(file)
            return dict(value,embroidery_reference_cleanup=cleanup) if Path(file)==engine.ROOT/'config/artwork-flow-prompts.json' else value
        with patch.object(engine,'read',side_effect=configured):
            job=design.job(self.c,task['brief_id']);e=SimpleNamespace(**self.env)
            before=design.flow_plan(self.c,job,'embroidery',e);self.assertNotIn('embroidery_reference_cleanup',before)
            for status in ('active','stopped','closed_partial','completed'):
                self.c.execute('UPDATE production_batches SET status=? WHERE batch_id=?',(status,prior['batch_id']))
                plan=design.flow_plan(self.c,job,'embroidery',e)
                if status!='completed':self.assertEqual(plan,before);continue
                self.assertEqual(plan['embroidery_reference_cleanup'],cleanup)
                for old,image in zip(before['images'],plan['images']):
                    self.assertEqual(old['references'],image['references']);self.assertIn(cleanup['instruction'],image['prompt'])
                    self.assertTrue(image['prompt'].endswith(read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']))
            self.assertNotIn('embroidery_reference_cleanup',design.flow_plan(self.c,job,'2d',e))
            cleanup['after_batch_id']=self.command()['batch_id'];self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id=?",(cleanup['after_batch_id'],))
            self.assertNotIn('embroidery_reference_cleanup',design.flow_plan(self.c,job,'embroidery',e))
        self.assertEqual([tuple(x) for x in self.c.execute('SELECT * FROM design_tasks')],saved_tasks)
        self.assertEqual([tuple(x) for x in self.c.execute('SELECT * FROM design_approvals')],saved_approvals)

    def test_native_canvas_keeps_entire_source_without_resizing_and_preserves_blank_hash_guards(self):
        with patch.object(layout,'canvas_policy',return_value=self.native_policy()):
            raw=self.raw(wide=True);before=Path(raw['path']).read_bytes();saved,receipt=layout.normalize(raw,self.env)
            self.assertEqual(saved,raw);self.assertEqual(Path(raw['path']).read_bytes(),before)
            self.assertEqual(receipt['operation'],'preserve_native_canvas');self.assertFalse(receipt['resized']);self.assertFalse(receipt['cropped'])
            with self.assertRaisesRegex(ValueError,'blank'):layout.normalize(self.raw(blank=True),self.env)
            raw['sha256']='0'*64
            with self.assertRaisesRegex(ValueError,'hash'):layout.normalize(raw,self.env)
            self.assertTrue(layout.output_ratio_ok(320,180,'7:26',self.env));self.assertFalse(layout.output_ratio_ok(100,100,'7:26',self.env))

    def test_landscape_sleeve_tasks_keep_composition_goal_and_exact_approval_gates(self):
        with patch.object(layout,'canvas_policy',return_value=self.native_policy()):
            self.start(self.command());self.cycle()
            for stage in ('2d','embroidery'):
                task=self.execute({'action':'browser_queue'})['tasks'][0]
                for image in task['payload']['images']:
                    if image['region'].endswith('sleeve'):
                        self.assertEqual((image['aspect_ratio'],image['output_aspect_ratio']),('16:9','16:9'))
                        self.assertIn('HEIGHT:WIDTH 26:7',image['prompt']);self.assertIn('not an exact pixel crop',image['prompt'])
                cmd=self.candidate(task);left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve');right=next(a for a in cmd['assets'] if a['image_key']=='right_sleeve');right.update(path=left['path'],sha256=left['sha256'])
                self.execute(cmd);review=flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)
                sleeve=next(a for a in review['images'] if a['path']==left['path']);self.assertEqual(sleeve['sha256'],left['sha256'])
                self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_approvals WHERE stage=?',(stage,)).fetchone()[0],0)
                flow.apply_decision(self.c,self.decision(review),self.env)

    def test_relaxed_policy_recovers_rejected_existing_preview_without_new_revision_or_2d_approval(self):
        self.start(self.command());self.cycle();task=self.execute({'action':'browser_queue'})['tasks'][0]
        cmd=self.candidate(task);left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve');next(a for a in cmd['assets'] if a['image_key']=='right_sleeve').update(path=left['path'],sha256=left['sha256'])
        self.execute(cmd);flow.apply_decision(self.c,self.decision(flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)),self.env)
        approvals=[tuple(r) for r in self.c.execute('SELECT * FROM design_approvals')]
        task=self.execute({'action':'browser_queue'})['tasks'][0];cmd=self.candidate(task);left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve')
        im=Image.new('RGB',(180,320),'white');ImageDraw.Draw(im).rectangle((10,20,170,300),fill='green');im.save(left['path']);left['sha256']=engine.sha(Path(left['path']));next(a for a in cmd['assets'] if a['image_key']=='right_sleeve').update(path=left['path'],sha256=left['sha256'])
        self.assertEqual(self.execute(cmd)['status'],'design_canvas_rejected')
        cmd=copy.deepcopy(cmd);cmd['assets']=[a for a in cmd['assets'] if a['image_key'].endswith('sleeve')]
        for key in ('images','prompt_provenance'):cmd['proof'][key]=[a for a in cmd['proof'][key] if a['image_key'].endswith('sleeve')]
        cmd['reference']='Fixture user accepts entire native sleeve frame'
        with patch.object(layout,'canvas_policy',return_value=self.native_policy()):
            result=self.execute(cmd);self.assertEqual(result['status'],'generated_candidate_awaiting_human_visual_review')
            self.assertEqual(self.execute(cmd),result)
            review=flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env);self.assertEqual(review['stage'],'embroidery');self.assertEqual(review['revision'],1)
            self.assertEqual([tuple(r) for r in self.c.execute('SELECT * FROM design_approvals')],approvals)

    def test_new_manifest_freezes_guides_and_old_replay_keeps_its_profile(self):
        cmd=self.command();result=self.execute(cmd);saved=batch.manifest(batch.batch(self.c,cmd['batch_id']))
        self.assertEqual(len(saved['layout_profile']['design']),5)
        self.assertEqual(len(saved['layout_profile']['placement']),30)
        self.assertEqual(self.execute(cmd)['batch_fingerprint'],result['batch_fingerprint'])
        self.assertEqual(saved['items'][0]['brief']['layout_profile'],saved['layout_profile'])
        old=copy.deepcopy(cmd);old['batch_id']='fixture-old'
        original=profiles.normalize
        with patch.object(profiles,'normalize',side_effect=lambda cmd,e,legacy:original(cmd,{**e,'shared_layout_profile':None},legacy)):prior=self.execute(old)
        self.assertNotIn('layout_profile',batch.manifest(batch.batch(self.c,old['batch_id'])))
        self.assertEqual(self.execute(old)['batch_fingerprint'],prior['batch_fingerprint'])
        bad=copy.deepcopy(saved['layout_profile']);bad['sleeve_output_aspect_ratio']='1:1'
        with self.assertRaisesRegex(ValueError,'changed'):layout.validate(bad,self.env)

    def test_overflow_keeps_valid_assets_and_revision_regenerates_only_rejected_sleeves(self):
        self.start(self.command());self.cycle();task=self.execute({'action':'browser_queue'})['tasks'][0]
        cmd=self.candidate(task)
        left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve')
        im=Image.new('RGB',(180,320),'white');ImageDraw.Draw(im).rectangle((10,20,170,300),fill='green');im.save(left['path']);left['sha256']=engine.sha(Path(left['path']))
        right=next(a for a in cmd['assets'] if a['image_key']=='right_sleeve');right.update(path=left['path'],sha256=left['sha256'])
        result=self.execute(cmd)
        self.assertEqual(result['status'],'design_canvas_rejected')
        self.assertEqual({r['image_key'] for r in result['rejected_images']},{'left_sleeve','right_sleeve'})
        self.assertEqual(self.execute(cmd),result)
        self.assertIsNone(flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env))
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='2d'").fetchone()[0],0)
        retained=set(result['retained_regions']);self.assertEqual(retained,{'left_chest','right_chest','back'})
        original={a['image_key']:(a['path'],a['sha256']) for a in cmd['assets'] if a['image_key'] in retained}
        with self.assertRaises(ValueError):self.execute({'action':'design_revise','brief_id':task['brief_id'],'revision':1,'stage':'2d','reason':'TAY only narrower','retain_regions':['left_sleeve'],**self.auth})
        self.execute({'action':'design_revise','brief_id':task['brief_id'],'revision':1,'stage':'2d','reason':'TAY only: narrow coherent scene. Preserve other regions.','retain_regions':sorted(retained),**self.auth})
        current=self.execute({'action':'browser_queue'})['tasks'][0]
        self.assertEqual(current['revision'],2);self.assertEqual(set(current['missing_regions']),{'left_sleeve','right_sleeve'})
        saved={r['region']:json.loads(r['payload']) for r in self.c.execute('SELECT region,payload FROM design_assets WHERE brief_id=? AND revision=2',(task['brief_id'],))}
        self.assertEqual({r:(a['path'],a['sha256']) for r,a in saved.items()},original)
        for image in current['payload']['images']:
            if image['region'].endswith('sleeve'):
                style=next(r for r in image['references'] if r['role']=='same_listing_fill_style_only')
                self.assertEqual((style['path'],style['sha256']),original['left_chest'])
                self.assertIn('never copy the chest motif',image['prompt'])
        for invalid in (0,3,True):
            with self.assertRaisesRegex(ValueError,'existing revision'):
                self.execute({'action':'design_revise','brief_id':task['brief_id'],'revision':2,'stage':'2d','reason':'retain original chest','retain_regions':sorted(retained),'retain_from_revision':invalid,**self.auth})
        self.execute({'action':'design_revise','brief_id':task['brief_id'],'revision':2,'stage':'2d','reason':'retain original chest','retain_regions':sorted(retained),'retain_from_revision':1,**self.auth})
        current=self.execute({'action':'browser_queue'})['tasks'][0]
        self.assertEqual(current['revision'],3)
        next_cmd=self.candidate(current);missing=set(current['missing_regions'])
        next_cmd['assets']=[a for a in next_cmd['assets'] if a['image_key'] in missing]
        for key in ('images','prompt_provenance'):next_cmd['proof'][key]=[p for p in next_cmd['proof'][key] if p['image_key'] in missing]
        left=next_cmd['assets'][0];next_cmd['assets'][1].update(path=left['path'],sha256=left['sha256'])
        self.execute(next_cmd)
        review=flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)
        self.assertEqual(len(review['images']),5);self.assertEqual(review['revision'],3)
        self.assertFalse(review['visual_qa']['passed'])
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='2d'").fetchone()[0],0)

    def test_native_two_stage_portrait_review_exact_refs_and_ten_square_mockups(self):
        self.start(self.command());self.cycle()
        rule=engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for stage in ('2d','embroidery'):
            task=self.execute({'action':'browser_queue'})['tasks'][0]
            self.assertEqual(task['payload']['stage'],stage)
            for image in task['payload']['images']:
                self.assertTrue(image['prompt'].endswith(rule))
                if image['region'].endswith('sleeve'):
                    self.assertEqual((image['aspect_ratio'],image['output_aspect_ratio']),('9:16','7:26'))
                    self.assertNotIn('Square 1:1.',image['prompt'])
                    if stage=='2d':
                        self.assertIn('never a stroked line drawing',image['prompt'])
                        self.assertTrue(image['references'][0]['path'].endswith('left-sleeve-transport-9x16-v2.png'))
                        with Image.open(image['references'][0]['path']) as guide:
                            self.assertEqual({color for count,color in guide.getcolors()}, {(255,255,255),(242,245,247)})
                            self.assertEqual(guide.getpixel((265,114)),guide.getpixel((450,800)))
                if stage=='2d':self.assertEqual(image['references'][0]['role'],'design_free_composition_guide')
                else:self.assertEqual([r['role'] for r in image['references']],['exact_locked_2d'])
            cmd=self.candidate(task)
            left=next(a for a in cmd['assets'] if a['image_key']=='left_sleeve')
            right=next(a for a in cmd['assets'] if a['image_key']=='right_sleeve');right.update(path=left['path'],sha256=left['sha256'])
            self.execute(cmd)
            review=flow.review_packet(self.c,{'brief_id':task['brief_id']},self.env)
            for image in review['images']:
                with Image.open(image['path']) as im:
                    self.assertTrue(layout.ratio_ok(*im.size,'7:26' if 'sleeve' in image['path'] else '1:1'))
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_approvals WHERE stage=?',(stage,)).fetchone()[0],0)
            # Fixture-only human authority, never submitted to the real workflow.
            flow.apply_decision(self.c,self.decision(review),self.env)
        plan=self.execute({'action':'design_plan','brief_id':task['brief_id'],'revision':task['revision']})['plan']
        self.assertNotIn('region_mapping_version',plan)
        self.assertEqual(plan['regions']['left_sleeve']['sha256'],plan['regions']['right_sleeve']['sha256'])
        shots=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan)},self.env)
        legacy={**plan,'region_mapping_version':1}
        with patch('embroidery_region_map.reference',side_effect=AssertionError('Retired map must not run')):
            self.assertEqual(profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(legacy)},self.env),shots)
            b=dict(self.c.execute('SELECT * FROM production_batches WHERE batch_id=?',('fixture-batch',)).fetchone())
            i=dict(self.c.execute('SELECT * FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1',('fixture-batch',)).fetchone())
            i.update(plan=json.dumps(legacy),images='{}')
            sample=batch.plan_images(self.c,b,i,True,self.env)
            self.assertEqual(sample['images'],shots['images'][:1])
        self.assertEqual(shots['aspect_ratio'],'1:1');self.assertEqual(len(shots['images']),10)
        for index,image in enumerate(shots['images']):
            self.assertTrue(image['prompt'].endswith(rule))
            if index!=6:self.assertIn('GARMENT-RELATIVE POSITION LOCK',image['prompt'])
            else:self.assertNotIn('GARMENT-RELATIVE POSITION LOCK',image['prompt'])
            artwork=[r for r in image['references'] if r.get('role')=='exact_locked_embroidery']
            self.assertEqual({r for a in artwork for r in a['regions']},set(image['visible_regions']))
            if index!=6:self.assertEqual(next(r for r in artwork if 'left_sleeve' in r['regions'])['regions'],['left_sleeve','right_sleeve'])
            else:self.assertEqual(len(artwork),1)
            self.assertIn('EXACT REFERENCE-TO-REGION MAP',image['prompt'])
            self.assertFalse(any(r.get('role')=='fold_framing_zoom_only' for r in image['references']))
            self.assertEqual(sum(r.get('role')=='design_free_fold_guide' for r in image['references']),1 if index<3 else 0)
            guides=[r for r in image['references'] if r.get('role')=='design_free_placement_guide']
            self.assertEqual(len(guides),0 if index==6 else 1)
            self.assertFalse(any(r.get('role')=='same_listing_region_map' for r in image['references']))
            self.assertNotIn('SAME-LISTING VISUAL REGION MAP',image['prompt'])
        other=layout.placement(plan['layout_profile'],'crewneck sweatshirt',{'left_sleeve':{}},False)
        chosen=layout.placement(plan['layout_profile'],'crewneck sweatshirt',plan['regions'],False)
        self.assertNotEqual(other['sha256'],chosen['sha256'])


if __name__=='__main__':
    suite=unittest.TestSuite(LayoutTests(name) for name in LayoutTests.__dict__ if name.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
