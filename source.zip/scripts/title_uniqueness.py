"""Read-only title ownership checks. Never rewrite existing titles or SKUs."""
import json
import re
import sqlite3
import unicodedata
from contextlib import closing
from pathlib import Path

STOPWORDS = set('a an the and or for of with to in on at by from as is it this that your our my new sku'.split())


def normalize_title(title):
    return ' '.join(unicodedata.normalize('NFKC', title).casefold().split())


def title_words(title):
    text = re.sub(r'\b[a-z]{2,6}_?\d{6}_\d{2,3}(?:_[a-z0-9]+)?\b', '', normalize_title(title))
    return frozenset(word for word in re.findall(r'\b[^\W\d_]+\b', text) if word not in STOPWORDS)


def sku_key(sku):
    value = sku.strip().casefold()
    return value[:-4] if value.endswith('_tqh') else value


def history(c, root):
    result = []
    for code, payload in c.execute("SELECT code,payload FROM artifacts WHERE kind='text'"):
        text = json.loads(payload)
        if isinstance(text.get('title'), str):
            result.append((code, text['title']))
    if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='thumbnail_items'").fetchone():
        for code, payload in c.execute('SELECT listing_code,text FROM thumbnail_items WHERE listing_code IS NOT NULL AND text IS NOT NULL'):
            text = json.loads(payload)
            if isinstance(text.get('title'), str):
                result.append((code, text['title']))
    config_file = Path(root) / 'config/title-uniqueness.json'
    if not config_file.exists():
        return result
    try:
        config = json.loads(config_file.read_text(encoding='utf-8-sig'))
        if config.get('history_file'):
            result.extend((row['sku'], row['title']) for row in json.loads(Path(config['history_file']).read_text(encoding='utf-8-sig'))['pairs'])
        if config.get('history_database'):
            database = Path(config['history_database']).resolve()
            with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True, timeout=5)) as external:
                for kind, payload in external.execute("SELECT kind,data FROM documents WHERE kind IN ('title_sku','catalog')"):
                    row = json.loads(payload)
                    if kind == 'catalog' and (not row.get('active', True) or not row.get('title') or not row.get('sku')):
                        continue
                    skus = row['skus'] if kind == 'title_sku' else [row['sku']]
                    result.extend((sku, row['title']) for sku in skus)
        if any(not isinstance(sku, str) or not sku.strip() or not isinstance(title, str) or not title.strip() for sku, title in result):
            raise ValueError('Invalid title history')
    except (OSError, sqlite3.Error, ValueError, KeyError, TypeError):
        raise ValueError('listing_title_history_unavailable') from None
    return result


def ensure_unique(c, code, title, root):
    if not isinstance(title, str) or not title_words(title):
        raise ValueError('listing_title_invalid')
    normalized, words, owner = normalize_title(title), title_words(title), sku_key(code)
    records = history(c, root)
    # A SKU may reuse its existing title; historical multi-SKU mappings stay intact.
    if any(sku_key(sku) == owner and normalize_title(old) == normalized for sku, old in records):
        return
    conflicts = {sku for sku, old in records if sku_key(sku) != owner and
                 (normalize_title(old) == normalized or title_words(old) == words)}
    if conflicts:
        error = ValueError('listing_title_conflict')
        error.conflicting_skus = sorted(conflicts)
        raise error
