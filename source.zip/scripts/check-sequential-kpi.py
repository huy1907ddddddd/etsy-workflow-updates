"""KPI scheduling checks using an isolated database; no Google or production writes."""
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

spec = importlib.util.spec_from_file_location('engine', Path(__file__).with_name('production-engine.py'))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)


class SequentialKpiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sequential-kpi-')
        self.addCleanup(self.temp.cleanup)
        self.c = engine.connect(Path(self.temp.name) / 'fixture.sqlite')
        self.addCleanup(self.c.close)
        self.c.execute("INSERT INTO config VALUES('kpi_activation',?)", (json.dumps({
            'activated_at': '2026-10-15T04:47:47+00:00', 'lead_days': 2}),))

    def completed(self, code, when='2027-02-10T09:00:00+00:00'):
        return engine.allocate_kpi(self.c, {'code': code, 'revision': 1}, 'approved-output', when)

    def seed(self, date, count):
        for n in range(count):
            self.c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)', (
                'OLD_261001_%02d_TQH' % (n + 1), 1, date,
                '2026-10-15T09:00:00+00:00', 'existing-proof'))

    def test_finish_partial_day_then_next_calendar_day_despite_delayed_completion(self):
        self.seed('2026-10-31', 8)
        dates = [self.completed('NEW_270210_%02d_TQH' % n)['target_date'] for n in range(1, 16)]
        self.assertEqual(dates, ['2026-10-31'] * 13 + ['2026-11-01'] * 2)

    def test_old_rows_are_preserved_and_only_current_row_is_extended(self):
        self.seed('2026-10-17', 4)
        self.c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)', (
            'END_261031_01_TQH', 1, '2026-10-31', '2026-10-29T00:00:00+00:00', 'proof'))
        before = list(self.c.execute('SELECT * FROM kpi ORDER BY code'))
        result = self.completed('NEW_270210_01_TQH')
        self.assertEqual(result['target_date'], '2026-10-31')
        for row in before:
            self.assertEqual(tuple(self.c.execute('SELECT * FROM kpi WHERE code=?', (row['code'],)).fetchone()), tuple(row))

    def test_empty_ledger_has_fixed_activation_seed_not_completion_date(self):
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'], '2026-10-17')

    def schedule(self, **overrides):
        return engine.execute(self.c, {'action':'set_kpi_schedule', 'authority':'direct_user',
            'reference':'User: KPI starts 1/11', 'start_date':'2026-11-01', **overrides})

    def test_explicit_start_skips_old_partial_row_and_preserves_it(self):
        self.seed('2026-10-31',8)
        before=[tuple(r) for r in self.c.execute('SELECT * FROM kpi ORDER BY code')]
        self.assertEqual(self.schedule()['next_target_date'],'2026-11-01')
        dates=[self.completed('NEW_270210_%02d_TQH'%n)['target_date'] for n in range(1,24)]
        self.assertEqual(dates,['2026-11-01']*21+['2026-11-02']*2)
        self.assertEqual([tuple(r) for r in self.c.execute("SELECT * FROM kpi WHERE code LIKE 'OLD_%' ORDER BY code")],before)

    def test_start_is_a_floor_and_retry_never_moves_old_listing(self):
        self.seed('2026-11-02',20)
        self.schedule()
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'],'2026-11-02')
        self.assertEqual(self.schedule()['next_target_date'],'2026-11-03')
        self.assertEqual(self.completed('OLD_261001_01_TQH')['target_date'],'2026-11-02')

    def test_explicit_start_on_empty_ledger_and_readback(self):
        self.schedule()
        self.assertEqual(engine.execute(self.c,{'action':'kpi_schedule'})['next_target_date'],'2026-11-01')
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'],'2026-11-01')

    def test_setting_schedule_requires_authority_and_valid_iso_date(self):
        for overrides in ({'authority':'worker'},{'reference':''},{'start_date':'1/11/2026'},{'start_date':'2026-02-30'}):
            with self.assertRaises(ValueError):self.schedule(**overrides)
        self.assertIsNone(self.c.execute("SELECT value FROM config WHERE key='kpi_schedule'").fetchone())

    def work_calendar(self, **overrides):
        return self.schedule(start_date='2026-11-02',calendar='mon_fri_alternate_sat',saturday_anchor='2026-11-07',**overrides)

    def test_working_calendar_three_weeks_and_21_slots_per_working_day(self):
        self.seed('2026-10-31',8)
        self.work_calendar()
        expected=['2026-11-%02d'%n for n in [2,3,4,5,6,7,9,10,11,12,13,16,17,18,19,20,21]]
        dates=[self.completed('NEW_270210_%03d_TQH'%n)['target_date'] for n in range(21*len(expected))]
        self.assertEqual(dates,[d for d in expected for _ in range(21)])
        self.assertEqual(self.completed('NEW_270210_999_TQH')['target_date'],'2026-11-23')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM kpi WHERE target_date='2026-10-31'").fetchone()[0],8)

    def test_partial_working_saturday_fills_before_skipping_sunday(self):
        self.seed('2026-11-07',20);self.work_calendar()
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'],'2026-11-07')
        self.assertEqual(self.completed('NEW_270210_02_TQH')['target_date'],'2026-11-09')
        self.assertEqual(self.completed('OLD_261001_01_TQH')['target_date'],'2026-11-07')

    def test_nonworking_historical_day_is_preserved_and_not_extended(self):
        self.seed('2026-11-14',4);self.work_calendar()
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'],'2026-11-16')
        self.assertEqual(self.completed('OLD_261001_01_TQH')['target_date'],'2026-11-14')

    def test_alternate_saturday_continues_across_month_and_year(self):
        for latest,expected in [('2026-11-27','2026-11-30'),('2026-12-04','2026-12-05'),('2027-01-01','2027-01-02')]:
            with self.subTest(latest=latest):
                self.c.execute('DELETE FROM kpi');self.seed(latest,21);self.work_calendar()
                self.assertEqual(engine.execute(self.c,{'action':'kpi_schedule'})['next_target_date'],expected)

    def test_invalid_calendar_or_non_saturday_anchor_is_rejected_without_changing_config(self):
        self.work_calendar();before=self.c.execute("SELECT value FROM config WHERE key='kpi_schedule'").fetchone()[0]
        for values in ({'calendar':'unknown'},{'calendar':'mon_fri_alternate_sat','saturday_anchor':'2026-11-02'},{'calendar':'mon_fri_alternate_sat','saturday_anchor':'7/11/2026'}):
            with self.assertRaises(ValueError):self.schedule(**values)
            self.assertEqual(self.c.execute("SELECT value FROM config WHERE key='kpi_schedule'").fetchone()[0],before)

    def test_retry_does_not_duplicate_or_move_record(self):
        first = self.completed('NEW_270210_01_TQH')
        again = self.completed('NEW_270210_01_TQH', '2028-12-20T22:00:00+00:00')
        self.assertEqual(again['status'], 'already_recorded')
        self.assertEqual(first['target_date'], again['target_date'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 1)

    def test_older_reservation_does_not_expire_and_is_updated_when_counted(self):
        code = 'NEW_261017_01_TQH'
        self.seed('2026-10-31', 8)
        self.c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', (
            'brief', code, 'NEW', '2026-10-17', 'reserved', 'User', engine.now()))
        result = self.completed(code)
        self.assertEqual(result['target_date'], '2026-10-31')
        row = self.c.execute('SELECT * FROM reservations WHERE code=?', (code,)).fetchone()
        self.assertEqual((row['status'], row['target_date']), ('counted', '2026-10-31'))

    def test_pending_reservations_do_not_leave_holes_in_completed_kpi(self):
        self.seed('2026-10-31', 20)
        for n in range(10):
            self.c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', (
                'brief-%d' % n, 'WAIT_261031_%02d_TQH' % n, 'WAIT', '2026-10-31', 'reserved', 'User', engine.now()))
        self.assertEqual(self.completed('NEW_270210_01_TQH')['target_date'], '2026-10-31')

    def test_invalid_reservation_still_blocks_counting(self):
        code = 'NEW_261017_01_TQH'
        self.c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', (
            'brief', code, 'NEW', '2026-10-17', 'cancelled', 'User', engine.now()))
        with self.assertRaises(ValueError):
            self.completed(code)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 0)

    def test_pilot_and_pre_activation_completion_are_not_counted(self):
        self.assertFalse(self.completed('NEW_270210_01_PILOT')['counted'])
        self.assertFalse(self.completed('NEW_261014_01_TQH', '2026-10-14T00:00:00+00:00')['counted'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 0)

    def test_advancing_old_code_keeps_artwork_gate_instead_of_forcing_new_date(self):
        j = {'code': 'NEW_261017_01_TQH', 'revision': 1, 'state': 'queued',
             'source_hash': 'a' * 64, 'plan': '{}', 'created_at': engine.now()}
        self.c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)', tuple(j.values()))
        self.c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', (
            'brief', j['code'], 'NEW', '2026-10-17', 'reserved', 'User', engine.now()))
        with patch.object(engine, 'current_source'), patch.object(engine, 'validate_plan'), patch.object(engine, 'approved', return_value=False):
            result = engine.advance(self.c, j)
        self.assertEqual(result['status'], 'awaiting_brief_approval')
        self.assertEqual(self.c.execute('SELECT code FROM reservations').fetchone()[0], j['code'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
