"""Isolated Flow/Lark transaction tests; no real browser, Lark or production DB."""
import copy
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))
spec = importlib.util.spec_from_file_location('isolated_flow_engine', SCRIPTS / 'production-engine.py')
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
import flow_lark_orchestration as flow


class FlowLarkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='flow-lark-isolated-')
        self.root = Path(self.tmp.name).resolve()
        self.addCleanup(self.tmp.cleanup)
        self.saved = {name: getattr(engine, name) for name in ('STORE', 'JOBS', 'scoped')}
        engine.STORE = self.root
        engine.JOBS = self.root / 'jobs'
        engine.JOBS.mkdir()
        engine.scoped = self.scoped
        self.addCleanup(lambda: [setattr(engine, k, v) for k, v in self.saved.items()])
        self.c = engine.connect(self.root / 'isolated.sqlite')
        self.addCleanup(self.c.close)
        self.env = dict(engine.__dict__)
        self.config = {'localToken': 'test-only-token-not-real', 'humanOpenId': 'ou_test_owner', 'chatId': 'oc_test_owner'}
        real_read = engine.read
        self.env['read'] = lambda p: self.config if str(p).endswith('lark-review.private.json') else {} if str(p).endswith('review-transport.json') else real_read(p)
        self.brief_id = 'isolated-flow-lark-PILOT'
        brief = {'brief_id': self.brief_id, 'topic_code': 'ANM', 'product_type': 'physical_apparel', 'product_id': 'test-only',
                 'garment': 'crewneck', 'color': 'cream', 'available_styles': ['crewneck sweatshirt'],
                 'motifs': {'center_chest': 'test flower', 'left_sleeve': 'test leaf', 'right_sleeve': 'test leaf'}, 'back_artwork': False,
                 'personalization': {'enabled': False}, 'sources': []}
        received = engine.execute(self.c, {'action': 'receive_brief', 'brief': brief})
        start = engine.execute(self.c, {'action': 'design_start', 'brief_id': self.brief_id,
                                      'brief_fingerprint': received['brief_fingerprint'],
                                      'authority': 'direct_user', 'reference': 'isolated test fixture only'})
        self.task = start['browser_task']
        image_path = Path(self.task['payload']['output_directory']) / 'center_chest.png'
        image_path.parent.mkdir(parents=True)
        Image.new('RGB', (100, 100), 'blue').save(image_path)
        self.asset = {'path': str(image_path), 'sha256': engine.sha(image_path)}
        screenshot = self.root / 'test-fixture-proof.png'
        Image.new('RGB', (10, 10), 'white').save(screenshot)
        self.proof = {'visually_verified': True, 'model': 'Nano Banana Pro',
                      'url': 'https://flow.google.com/project/test-fixture-only', 'screenshot_path': str(screenshot)}
        self.attachment = {'action': 'design_attach', 'brief_id': self.brief_id, 'revision': 1,
                           'stage': '2d', 'task_id': self.task['id'],
                           'assets': {region: copy.deepcopy(self.asset) for region in brief['motifs']}, 'proof': self.proof}

    def scoped(self, value, *args):
        p = Path(value).resolve()
        if not p.is_relative_to(self.root) or p == self.root:
            raise ValueError('Isolated test must not read/write production assets')
        return p

    def attach_command(self):
        return {'action': 'flow_attach', 'task_id': self.task['id'], 'revision': 1,
                'task_fingerprint': self.task['fingerprint'], 'attachment': copy.deepcopy(self.attachment)}

    def attached_packet(self):
        engine.execute(self.c, self.attachment)
        return flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)

    def decision(self, packet, **changes):
        return {'schema_version': 1, 'event_id': 'evt_test_001', 'message_id': 'om_human_test',
                **{k: copy.deepcopy(packet[k]) for k in ('review_id', 'entity', 'revision', 'stage', 'fingerprint')},
                'authority': 'direct_user', 'decision': 'approve', 'reason': '', 'text': 'DUYỆT',
                'reference': 'Lark message om_human_test; direct test human: DUYỆT',
                'sender_open_id': self.config['humanOpenId'], 'chat_id': self.config['chatId'], **changes}

    def test_no_review_until_all_assets_are_attached(self):
        self.assertIsNone(flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env))

    def test_packet_contains_exact_asset_hash_and_operator_evidence(self):
        p = self.attached_packet()
        self.assertEqual(p['images'][0]['sha256'], self.asset['sha256'])
        self.assertEqual(p['revision'], 1)
        self.assertEqual(p['stage'], '2d')
        self.assertTrue(p['visual_qa']['passed'])
        self.assertIn('events:', p['visual_qa']['reference'])
        self.assertEqual(p, flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env))

    def test_missing_or_false_visual_evidence_prevents_packet(self):
        self.attached_packet()
        self.c.execute("DELETE FROM design_events WHERE kind='assets_attached'")
        with self.assertRaisesRegex(ValueError, 'visual evidence'):
            flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        self.c.execute('INSERT INTO design_events(brief_id,revision,kind,payload,created_at) VALUES(?,?,?,?,?)',
                       (self.brief_id, 1, 'assets_attached', json.dumps({'stage': '2d', 'regions': ['center_chest'], 'proof': {'visually_verified': False}}), engine.now()))
        with self.assertRaises(ValueError):
            flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)

    def test_changed_artwork_file_prevents_packet(self):
        self.attached_packet()
        Image.new('RGB', (100, 100), 'red').save(self.asset['path'])
        with self.assertRaisesRegex(ValueError, 'changed'):
            flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)

    def test_canonical_fetch_authenticates_exact_loopback_event(self):
        body = self.decision(self.attached_packet())
        captured = []
        def fake_urlopen(request, timeout):
            captured.append((request, timeout))
            return io.BytesIO(json.dumps({'ok': True, 'envelope': {'status': 'pending', 'body': body}}).encode())
        with patch.object(flow.urllib.request, 'urlopen', fake_urlopen):
            self.assertEqual(flow.canonical_decision(body['event_id'], self.env), body)
        request, timeout = captured[0]
        self.assertEqual(request.full_url, 'http://127.0.0.1:8790/outbox/evt_test_001')
        self.assertEqual(request.get_header('X-review-token'), self.config['localToken'])
        self.assertEqual(timeout, 5)
        with self.assertRaises(ValueError):
            flow.canonical_decision('../forged?token=bad', self.env)

    def test_canonical_identity_and_outbox_status_must_match(self):
        valid = self.decision(self.attached_packet())
        for changes, status in [({'event_id': 'wrong'}, 'pending'), ({'authority': 'attached_document'}, 'pending'),
                                ({'sender_open_id': 'ou_attacker'}, 'pending'), ({'chat_id': 'oc_other'}, 'pending'),
                                ({}, 'cancelled'), ({}, 'rejected_stale')]:
            with self.subTest(changes=changes, status=status):
                response = {'ok': True, 'envelope': {'status': status, 'body': {**valid, **changes}}}
                with patch.object(flow.urllib.request, 'urlopen', lambda *a, **kw: io.BytesIO(json.dumps(response).encode())):
                    with self.assertRaises(ValueError):
                        flow.canonical_decision(valid['event_id'], self.env)

    def test_webhook_fields_cannot_replace_canonical_decision(self):
        valid = self.decision(self.attached_packet())
        with patch.object(flow, 'canonical_decision', lambda event_id, e: valid):
            result = flow.execute(self.c, {'action': 'lark_review_decision', 'event_id': valid['event_id'],
                                          'decision': 'reject', 'fingerprint': 'forged'}, self.env)
        self.assertTrue(result['accepted'])
        self.assertEqual(result['decision'], 'approve')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='2d'").fetchone()[0], 1)

    def test_stale_revision_fingerprint_stage_entity_or_id_never_approves(self):
        valid = self.decision(self.attached_packet())
        for changes in [{'revision': 2}, {'fingerprint': 'f' * 64}, {'stage': 'embroidery'},
                        {'review_id': 'flow-old-review'}, {'entity': {'brief_id': self.brief_id, 'listing_code': 'EXTRA'}}]:
            with self.subTest(changes=changes):
                result = flow.apply_decision(self.c, {**valid, **changes}, self.env)
                self.assertFalse(result['accepted'])
                self.assertEqual(result['code'], 'stale_review')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='2d'").fetchone()[0], 0)

    def test_duplicate_event_applies_only_once_even_after_gate_changed(self):
        body = self.decision(self.attached_packet())
        first = flow.apply_decision(self.c, body, self.env)
        second = flow.apply_decision(self.c, body, self.env)
        self.assertTrue(first['accepted'])
        self.assertEqual(second['status'], 'already_applied')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM lark_decisions').fetchone()[0], 1)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_events WHERE kind='approved'").fetchone()[0], 1)

    def test_revise_requires_reason_and_never_approves_current_design(self):
        body = self.decision(self.attached_packet(), decision='revise')
        with self.assertRaises(ValueError):
            flow.apply_decision(self.c, body, self.env)
        body['reason'] = 'test correction: remove exterior outline'
        body['text'] = 'SỬA: remove exterior outline'
        result = flow.apply_decision(self.c, body, self.env)
        self.assertTrue(result['accepted'])
        self.assertEqual(self.c.execute('SELECT revision FROM design_jobs').fetchone()[0], 2)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='2d'").fetchone()[0], 0)

    def test_explicit_reject_without_reason_pauses_and_never_generates_new_images(self):
        body = self.decision(self.attached_packet(), decision='reject', text='TỪ CHỐI', reason='')
        prior_tasks = self.c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0]
        result = flow.apply_decision(self.c, body, self.env)
        self.assertTrue(result['accepted'])
        self.assertEqual(self.c.execute('SELECT state FROM design_jobs').fetchone()[0], 'needs_design_revision')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0], prior_tasks)

    def test_flow_attach_preserves_exact_task_binding(self):
        cmd = self.attach_command()
        for changes in [{'revision': 2}, {'task_fingerprint': 'f' * 64}, {'task_id': 'not-current'}]:
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    flow.execute(self.c, {**cmd, **changes}, self.env)
        wrong = copy.deepcopy(cmd)
        wrong['attachment']['brief_id'] = 'wrong'
        with self.assertRaises(ValueError):
            flow.execute(self.c, wrong, self.env)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_assets').fetchone()[0], 0)

    def test_completed_flow_attach_retry_is_idempotent_and_changed_assets_refused(self):
        cmd = self.attach_command()
        first = flow.execute(self.c, cmd, self.env)
        second = flow.execute(self.c, cmd, self.env)
        self.assertEqual(second['fingerprint'], first['fingerprint'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_assets').fetchone()[0], 3)
        wrong = copy.deepcopy(cmd)
        wrong['attachment']['assets']['center_chest']['sha256'] = 'f' * 64
        with self.assertRaises(ValueError):
            flow.execute(self.c, wrong, self.env)

    def test_unsupported_decision_and_missing_evidence_fail_closed(self):
        body = self.decision(self.attached_packet())
        for changes in [{'decision': 'anything'}, {'reference': ''}, {'message_id': ''}]:
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    flow.apply_decision(self.c, {**body, **changes}, self.env)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM lark_decisions').fetchone()[0], 0)

    def test_review_refresh_keeps_artifacts_and_rejects_old_id(self):
        original = self.attached_packet()
        refreshed = flow.execute(self.c, {'action': 'lark_review_refresh', 'brief_id': self.brief_id,
                                          'review_id': original['review_id']}, self.env)['review']
        self.assertNotEqual(original['review_id'], refreshed['review_id'])
        for field in ('entity', 'revision', 'stage', 'fingerprint', 'images'):
            self.assertEqual(original[field], refreshed[field])
        self.assertEqual(refreshed, flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env))
        self.assertEqual(flow.apply_decision(self.c, self.decision(original), self.env)['code'], 'stale_review')
        with self.assertRaises(ValueError):
            flow.execute(self.c, {'action': 'lark_review_refresh', 'brief_id': self.brief_id,
                                  'review_id': original['review_id']}, self.env)
        accepted = flow.apply_decision(self.c, self.decision(refreshed, event_id='evt_refreshed'), self.env)
        self.assertTrue(accepted['accepted'])

    def test_completed_attachment_retry_rechecks_bytes_and_current_revision(self):
        cmd = self.attach_command()
        flow.execute(self.c, cmd, self.env)
        Image.new('RGB', (100, 100), 'red').save(self.asset['path'])
        with self.assertRaises(ValueError):
            flow.execute(self.c, cmd, self.env)
        Image.new('RGB', (100, 100), 'blue').save(self.asset['path'])
        self.c.execute('UPDATE design_jobs SET revision=2 WHERE brief_id=?', (self.brief_id,))
        with self.assertRaises(ValueError):
            flow.execute(self.c, cmd, self.env)

    def mockup_task(self):
        code = 'ANM_261015_99_PILOT'
        plan = {'regions': {'center_chest': self.asset}}
        self.c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)',
                       (code, 1, 'awaiting_browser_images', 'test-source', json.dumps(plan), engine.now()))
        payload = {'references': plan['regions']}
        fp = engine.digest(payload)
        self.c.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)',
                       ('mockup-task-test', code, 1, 'flow_images', fp, 'pending', json.dumps(payload), None, engine.now()))
        images = []
        for i, name in enumerate(engine.IMAGES):
            image_path = self.root / ('mockup-' + name)
            Image.new('RGB', (100, 100), (20 + i * 25, 90, 130)).save(image_path, 'JPEG')
            images.append({'name': name, 'path': str(image_path), 'sha256': engine.sha(image_path)})
        cmd = {'action': 'flow_attach', 'task_id': 'mockup-task-test', 'revision': 1,
               'task_fingerprint': fp, 'attachment': {'action': 'attach_images', 'listing_code': code, 'images': images},
               'proof': self.proof}
        return code, cmd

    def test_mockup_attach_requires_proof_and_locked_reference_hash(self):
        code, cmd = self.mockup_task()
        for proof in [{}, {**self.proof, 'model': 'Flash'}, {**self.proof, 'url': 'https://other.invalid/'}]:
            with self.subTest(proof=proof):
                with self.assertRaises(ValueError):
                    flow.execute(self.c, {**cmd, 'proof': proof}, self.env)
        Image.new('RGB', (100, 100), 'red').save(self.asset['path'])
        with self.assertRaisesRegex(ValueError, 'reference changed'):
            flow.execute(self.c, cmd, self.env)
        self.assertIsNone(engine.artifact(self.c, engine.job(self.c, code), 'images'))

    def test_six_mockup_attachment_retry_does_not_duplicate_visual_proof(self):
        code, cmd = self.mockup_task()
        first = flow.execute(self.c, cmd, self.env)
        again = flow.execute(self.c, cmd, self.env)
        self.assertEqual(first, again)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM events WHERE kind='flow_visual_checked'").fetchone()[0], 1)
        self.c.execute("UPDATE jobs SET state='awaiting_images_approval' WHERE code=?", (code,))
        review = flow.review_packet(self.c, {'listing_code': code}, self.env)
        self.assertEqual(len(review['images']), 6)
        self.assertEqual(review['fingerprint'], first['fingerprint'])
        changed = copy.deepcopy(cmd)
        changed['attachment']['images'][0]['sha256'] = 'f' * 64
        with self.assertRaises(ValueError):
            flow.execute(self.c, changed, self.env)
        accepted = flow.apply_decision(self.c, self.decision(review), self.env)
        self.assertTrue(accepted['accepted'])
        self.assertTrue(engine.approved(self.c, engine.job(self.c, code), 'images', review['fingerprint']))

    def test_full_design_review_gates_create_size_review_without_autoapproval(self):
        first = self.attached_packet()
        flow.apply_decision(self.c, self.decision(first), self.env)
        task = engine.execute(self.c, {'action': 'browser_queue'})['tasks'][0]
        self.assertEqual(task['kind'], 'flow_design_embroidery')
        output = Path(task['payload']['output_directory']) / 'embroidered-fixture.png'
        output.parent.mkdir(parents=True)
        Image.new('RGB', (100, 100), 'blue').save(output)
        embroidery_asset = {'path': str(output), 'sha256': engine.sha(output)}
        attachment = {'action': 'design_attach', 'brief_id': self.brief_id, 'revision': 1,
                      'stage': 'embroidery', 'task_id': task['id'],
                      'assets': {region: copy.deepcopy(embroidery_asset) for region in self.attachment['assets']},
                      'proof': self.proof}
        cmd = {'action': 'flow_attach', 'task_id': task['id'], 'revision': 1,
               'task_fingerprint': task['fingerprint'], 'attachment': attachment}
        flow.execute(self.c, cmd, self.env)
        second = flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        self.assertEqual(second['stage'], 'embroidery')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='embroidery'").fetchone()[0], 0)
        flow.apply_decision(self.c, self.decision(second, event_id='evt_embroidery'), self.env)
        sizes = flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        self.assertEqual(sizes['stage'], 'sizes')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_sizes').fetchone()[0], 1)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM design_approvals WHERE stage='sizes'").fetchone()[0], 0)
        flow.apply_decision(self.c, self.decision(sizes, event_id='evt_sizes'), self.env)
        self.assertEqual(self.c.execute('SELECT state FROM design_jobs').fetchone()[0], 'approved_artwork_and_sizes')
        self.assertIsNone(flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env))

    def test_repeat_visual_check_keeps_review_packet_immutable(self):
        code, cmd = self.mockup_task()
        attached = flow.execute(self.c, cmd, self.env)
        self.c.execute("UPDATE jobs SET state='awaiting_images_approval' WHERE code=?", (code,))
        initial = flow.review_packet(self.c, {'listing_code': code}, self.env)
        check = {'action': 'flow_visual_check', 'listing_code': code, 'revision': 1, 'stage': 'images',
                 'fingerprint': attached['fingerprint'], 'proof': {**self.proof, 'reference': 'Actual fixture observation only'}}
        flow.execute(self.c, check, self.env)
        flow.execute(self.c, check, self.env)
        self.assertEqual(initial, flow.review_packet(self.c, {'listing_code': code}, self.env))
        missing_screenshot = copy.deepcopy(check)
        missing_screenshot['proof'].pop('screenshot_path')
        with self.assertRaises((ValueError, KeyError)):
            flow.execute(self.c, missing_screenshot, self.env)

    def processed_fixture(self, code):
        images = []
        for i, name in enumerate(engine.IMAGES):
            image_path = self.root / ('processed-' + name)
            Image.new('RGB', (3000, 3000), (20 + i * 25, 90, 130)).save(image_path, 'JPEG')
            images.append({'name': name, 'path': str(image_path), 'sha256': engine.sha(image_path)})
        payload = {'images': images}
        fp = engine.put(self.c, engine.job(self.c, code), 'processed', payload)
        return fp

    def test_cycle_retains_processed_result_while_reporting_missing_visual_qa(self):
        self.attached_packet()
        code, cmd = self.mockup_task()
        attached = flow.execute(self.c, cmd, self.env)
        self.c.execute("UPDATE jobs SET state='awaiting_images_approval' WHERE code=?", (code,))
        j = engine.job(self.c, code)
        for stage, fp in [('brief', engine.digest(json.loads(j['plan']))), ('images', attached['fingerprint'])]:
            engine.execute(self.c, {'action': 'approve', 'listing_code': code, 'revision': 1, 'stage': stage,
                                   'fingerprint': fp, 'authority': 'direct_user', 'reference': 'isolated fixture only'})
        execute = self.env['execute']
        calls = []
        def fake_process(c, command):
            calls.append(command)
            if command['action'] == 'advance' and command.get('listing_code') == code:
                self.processed_fixture(code)
                self.c.execute("UPDATE jobs SET state='awaiting_processed_approval' WHERE code=?", (code,))
                return {'ok': True, 'status': 'awaiting_processed_approval'}
            return execute(c, command)
        env = {**self.env, 'execute': fake_process}
        result = flow.execute(self.c, {'action': 'flow_cycle'}, env)
        self.assertTrue(result['ok'])
        self.assertEqual(result['review_issues'][0]['entity'], {'listing_code': code})
        self.assertTrue(result['review_issues'][0]['requires_operator'])
        self.assertIsNotNone(engine.artifact(self.c, engine.job(self.c, code), 'processed'))
        self.c.commit()
        other = engine.connect(self.root / 'isolated.sqlite')
        try:
            self.assertEqual(other.execute('SELECT COUNT(*) FROM artifacts WHERE code=? AND kind=?', (code, 'processed')).fetchone()[0], 1)
        finally:
            other.close()

    def test_cycle_does_not_advance_already_approved_processed_to_seo_or_export(self):
        self.attached_packet()
        code, cmd = self.mockup_task()
        flow.execute(self.c, cmd, self.env)
        processed_fp = self.processed_fixture(code)
        self.c.execute("UPDATE jobs SET state='awaiting_images_approval' WHERE code=?", (code,))
        j = engine.job(self.c, code)
        for stage, fp in [('brief', engine.digest(json.loads(j['plan']))), ('processed', processed_fp)]:
            engine.execute(self.c, {'action': 'approve', 'listing_code': code, 'revision': 1, 'stage': stage,
                                   'fingerprint': fp, 'authority': 'direct_user', 'reference': 'isolated fixture only'})
        execute = self.env['execute']
        def forbid_advance(c, command):
            if command['action'] == 'advance' and command.get('listing_code') == code:
                self.fail('Image-only cycle must not cross into text/delivery/export')
            return execute(c, command)
        result = flow.execute(self.c, {'action': 'flow_cycle'}, {**self.env, 'execute': forbid_advance})
        self.assertTrue(result['ok'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM artifacts WHERE kind IN (?,?)', ('text', 'package')).fetchone()[0], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
