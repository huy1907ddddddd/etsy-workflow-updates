'use strict';
// Called only by the fingerprint-bound native batch deletion action.
const fs=require('node:fs'),path=require('node:path'),lark=require('@larksuiteoapi/node-sdk');
const read=f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/^\uFEFF/,''));
async function main(){
  const ids=JSON.parse(fs.readFileSync(0,'utf8'));
  if(!Array.isArray(ids)||ids.some(id=>!/^om_[A-Za-z0-9]+$/.test(id)))throw Error('invalid_message_ids');
  const config=read(path.resolve(__dirname,'../../config/lark-review.private.json'));
  const logger=Object.fromEntries(['trace','debug','info','warn','error','fatal'].map(k=>[k,()=>{}]));
  lark.defaultHttpInstance.defaults.timeout=15000;
  const client=new lark.Client({appId:config.appId,appSecret:config.appSecret,domain:lark.Domain.Lark,appType:lark.AppType.SelfBuild,logger});
  const result={requested:ids.length,deleted:0,failed_codes:[]};
  for(const message_id of ids){
    try{const r=await client.im.message.delete({path:{message_id}});if(r?.code===0)result.deleted++;else result.failed_codes.push(r?.code??'unknown');}
    catch(e){result.failed_codes.push(e.response?.data?.code??'transport_error');}
  }
  process.stdout.write(JSON.stringify(result));
}
main().catch(()=>{process.stdout.write(JSON.stringify({error:'batch_message_delete_failed'}));process.exitCode=1;});
