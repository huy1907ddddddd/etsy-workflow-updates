'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { ReviewStore, hash } = require('./review.cjs');
const { makeServer, authorized, uploadedImageKey } = require('./service.cjs');
test('image upload accepts the official SDK unwrapped success and rejects missing or failed keys', () => {
  assert.equal(uploadedImageKey({ image_key: 'img_v3_test_verified' }), 'img_v3_test_verified');
  for (const result of [null, {}, { code: 99991400 }, { code: 1, image_key: 'img_test' }, { image_key: '' }, { image_key: 'not-an-image-key' }]) assert.throws(() => uploadedImageKey(result), { code: 'lark_image_key_missing' });
});
function fixture(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lark-review-test-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const image = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aG0sAAAAASUVORK5CYII=', 'base64');
  const imagePath = path.join(dir, 'original.png'); fs.writeFileSync(imagePath, image);
  let time = 1760000000000;
  const config = { stateFile: path.join(dir, 'state.private.json'), chatId: 'oc_owner', humanOpenId: 'ou_owner', allowedImageRoots: [dir], localToken: 'x'.repeat(40) };
  const store = new ReviewStore(config, () => time);
  const input = { review_id: 'R-test-001', entity: { brief_id: 'TEST_PILOT' }, revision: 1, stage: '2d', fingerprint: 'a'.repeat(64), summary: 'Bản thử chương trình; không phải artwork đã duyệt.', images: [{ path: imagePath, sha256: hash(image), label: 'front' }], visual_qa: { passed: true, reference: 'test fixture, never production evidence' } };
  const sent = []; let failImage = false;
  const transport = { upload: async () => 'img_fake', send: async (chat, type, content, uuid) => { if (type === 'image' && failImage) { failImage = false; throw Error('simulated offline'); } sent.push({ chat, type, content, uuid }); return 'om_' + sent.length; } };
  const event = (text, overrides = {}) => ({ event_id: 'evt_' + (overrides.message_id || 'human1'), sender: { sender_type: 'user', sender_id: { open_id: config.humanOpenId } }, message: { message_id: 'human1', chat_id: config.chatId, message_type: 'text', parent_id: store.state.reviews[input.review_id]?.messages.find(x => x.slot === 'final')?.message_id, content: JSON.stringify({ text }), ...overrides } });
  return { dir, imagePath, config, store, input, sent, transport, event, advance: ms => time += ms, failImage: () => failImage = true };
}

test('shared sleeve original is sent once while three immutable region bindings remain intact',async t=>{
  const f=fixture(t);f.input.stage='embroidery';
  f.input.images=['center_chest','left_sleeve','right_sleeve'].map(label=>({...f.input.images[0],label}));
  f.store.create(f.input);await f.store.deliver(f.input.review_id,f.transport);
  assert.equal(f.sent.filter(x=>x.type==='image').length,2);
  assert.equal(f.store.state.reviews[f.input.review_id].images.length,3);
  await f.store.deliver(f.input.review_id,f.transport);assert.equal(f.sent.filter(x=>x.type==='image').length,2);
});

test('independent candidates retain pending visual QA and require explicit human approval', async t => {
  const f = fixture(t);
  f.input.visual_qa = { passed: false, status: 'awaiting_human_visual_review', executor: 'independent_flow_worker', native_candidate_id: 'candidate-' + 'c'.repeat(64), reference: 'isolated native candidate event' };
  const saved = f.store.create(f.input);
  assert.equal(saved.visual_qa.passed, false);
  await f.store.deliver(f.input.review_id, f.transport);
  assert.match(f.sent[0].content.text, /CHƯA được kiểm tra bằng mắt/);
  assert.equal(saved.status, 'pending');
  assert.equal(Object.keys(f.store.state.outbox).length, 0);
  assert.equal(f.store.receive(f.event('DUYỆT')).ok, true);
  assert.equal(Object.values(f.store.state.outbox)[0].body.authority, 'direct_user');
  const other = fixture(t);
  assert.throws(() => other.store.create({ ...other.input, visual_qa: { ...f.input.visual_qa, native_candidate_id: '' } }), /operator_visual_qa_required/);
});

test('worker alerts persist, deduplicate and retry with the same message uuid', async t => {
  const f = fixture(t);
  const body = { status: 'blocked', code: 'flow_login_required', task_id: 'task_1', message: 'Đăng nhập Chrome worker riêng rồi chạy lại.' };
  const record = f.store.workerStatus(body);
  const resumed = new ReviewStore(f.config);
  assert.equal(resumed.workerStatus(body).uuid, record.uuid);
  let firstUuid;
  await assert.rejects(resumed.deliverWorkerStatus({ send: async (...args) => { firstUuid = args[3]; throw Error('offline'); } }));
  await resumed.deliverWorkerStatus({ send: async (...args) => { assert.equal(args[3], firstUuid); return 'om_status'; } });
  assert.equal(resumed.workerStatus(body).pending, false);
  await resumed.deliverWorkerStatus({ send: async () => { throw Error('must not resend'); } });
  assert.throws(() => resumed.workerStatus({ ...body, message: 'x'.repeat(1201) }), /worker_status_invalid/);
});
test('image binding, visual QA and path boundaries fail closed', t => {
  const f = fixture(t);
  assert.throws(() => f.store.create({ ...f.input, visual_qa: { passed: false } }), /operator_visual_qa_required/);
  assert.throws(() => f.store.create({ ...f.input, images: [{ path: f.imagePath, sha256: 'b'.repeat(64) }] }), /image_hash_changed/);
  const outside = path.join(os.tmpdir(), 'not-owned-' + Date.now() + '.png'); fs.writeFileSync(outside, fs.readFileSync(f.imagePath)); t.after(() => fs.unlinkSync(outside));
  assert.throws(() => f.store.create({ ...f.input, images: [{ path: outside, sha256: hash(fs.readFileSync(outside)) }] }), /image_path_not_allowed/);
  fs.writeFileSync(f.imagePath, 'secret text disguised as PNG');
  assert.throws(() => f.store.create({ ...f.input, images: [{ path: f.imagePath, sha256: hash(fs.readFileSync(f.imagePath)) }] }), /image_bytes_invalid/);
});
test('partial image delivery resumes with stable ids and no repeated successful sends', async t => {
  const f = fixture(t); f.store.create(f.input); f.failImage();
  await assert.rejects(f.store.deliver(f.input.review_id, f.transport));
  assert.equal(f.sent.length, 1);
  const resumed = new ReviewStore(f.config);
  await resumed.deliver(f.input.review_id, f.transport);
  assert.equal(f.sent.length, 3); assert.equal(resumed.state.reviews[f.input.review_id].status, 'pending');
  assert.equal(new Set(f.sent.map(x => x.uuid)).size, 3);
});
test('exact authorized parent binds explicit approval; event persists and duplicates do not enqueue twice', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport);
  const event = f.event('DUYỆT'); const result = f.store.receive(event);
  assert.equal(result.ok, true);
  const restarted = new ReviewStore(f.config);
  assert.equal(restarted.receive(event).duplicate, true);
  assert.equal(Object.values(restarted.state.outbox).length, 1);
  const envelope = Object.values(restarted.state.outbox)[0].body;
  assert.equal(envelope.fingerprint, f.input.fingerprint); assert.match(envelope.reference, /DUYỆT/);
  assert.equal(envelope.revision, 1); assert.equal(envelope.authority, 'direct_user');
});
test('forged sender, chat, stale reply and unbound approvals cannot approve', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport);
  const badSender = f.event('DUYỆT'); badSender.sender.sender_id.open_id = 'ou_attacker';
  assert.equal(f.store.receive(badSender).code, 'sender_or_chat_not_authorized');
  assert.equal(f.store.receive(f.event('DUYỆT', { chat_id: 'oc_wrong' })).code, 'sender_or_chat_not_authorized');
  assert.equal(f.store.receive(f.event('DUYỆT', { parent_id: undefined, message_id: 'unbound' })).code, 'reply_binding_invalid');
  assert.equal(f.store.receive(f.event('DUYỆT R-test-001', { parent_id: 'om_unknown', message_id: 'wrongparent' })).code, 'reply_binding_invalid');
  f.store.supersede(f.input.review_id, 'new version');
  assert.equal(f.store.receive(f.event('DUYỆT', { message_id: 'stale' })).code, 'stale_review');
  assert.equal(Object.values(f.store.state.outbox).length, 0);
});
test('bare edit, mixed approval and revise without reason are never approval', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport);
  assert.equal(f.store.receive(f.event('bỏ mưa, giữ y nguyên', { message_id: 'edit' })).code, 'explicit_decision_required');
  assert.equal(f.store.receive(f.event('DUYỆT: nhưng đổi màu', { message_id: 'mixed' })).code, 'ambiguous_approval');
  assert.equal(f.store.receive(f.event('SỬA', { message_id: 'noreason' })).code, 'revision_reason_required');
  assert.equal(f.store.receive(f.event('SỬA R-test-001: bỏ viền ngoài', { message_id: 'revise' })).ok, true);
  const o = f.store.state.outbox.revise; assert.equal(o.body.decision, 'revise'); assert.equal(o.body.reason, 'bỏ viền ngoài');
});
test('explicit review id works without parent; mismatched review ID conflicts', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport);
  assert.equal(f.store.receive(f.event('DUYỆT R-other-001', { message_id: 'wrongid' })).code, 'reply_binding_invalid');
  assert.equal(f.store.receive(f.event('DUYỆT R-test-001', { parent_id: undefined, message_id: 'explicit' })).ok, true);
});
test('24 hour expiry rejects delayed approval', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport); f.advance(25 * 3600000);
  assert.equal(f.store.receive(f.event('DUYỆT')).code, 'stale_review');
});
test('replacement cancels unforwarded decision and revision rollback is refused', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport); f.store.receive(f.event('DUYỆT'));
  f.store.create({ ...f.input, review_id: 'R-test-002', revision: 2, fingerprint: 'b'.repeat(64) });
  assert.equal(f.store.state.outbox.human1.status, 'cancelled');
  assert.throws(() => f.store.create({ ...f.input, review_id: 'R-test-003' }), /old_or_changed_review/);
  let called = false; await f.store.flush(async () => { called = true; }); assert.equal(called, false);
});
test('n8n requires explicit durable acknowledgement, retries same frozen body, retains acknowledged event', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport); f.store.receive(f.event('DUYỆT'));
  const expected = JSON.stringify(f.store.state.outbox.human1.body); let calls = 0;
  await f.store.flush(async body => { calls++; assert.equal(JSON.stringify(body), expected); return { ok: true }; });
  assert.equal(f.store.state.outbox.human1.status, 'pending');
  f.advance(300000);
  await f.store.flush(async body => { calls++; assert.equal(JSON.stringify(body), expected); return { ok: true, accepted: true, execution_id: 'test-only' }; });
  assert.equal(calls, 2); assert.equal(f.store.state.outbox.human1.status, 'delivered');
  await f.store.flush(async () => { throw Error('should not reapply'); });
  assert.equal(f.store.state.reviews[f.input.review_id].status, 'accepted');
});
test('localhost API requires token and exposes canonical retained event, no fake-event endpoint', async t => {
  const f = fixture(t); f.store.create(f.input); await f.store.deliver(f.input.review_id, f.transport); f.store.receive(f.event('DUYỆT'));
  const server = makeServer(f.config, f.store, () => {});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); t.after(() => server.close());
  const base = 'http://127.0.0.1:' + server.address().port;
  assert.equal((await fetch(base + '/outbox/evt_human1')).status, 401);
  const response = await fetch(base + '/outbox/evt_human1', { headers: { 'x-review-token': f.config.localToken } });
  const body = await response.json(); assert.equal(body.envelope.body.review_id, f.input.review_id);
  const fake = await fetch(base + '/events', { method: 'POST', headers: { 'x-review-token': f.config.localToken, 'content-type': 'application/json' }, body: '{}' });
  assert.equal(fake.status, 404); assert.equal(authorized('wrong', f.config.localToken), false);
});
