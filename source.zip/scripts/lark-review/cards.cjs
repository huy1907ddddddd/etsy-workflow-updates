'use strict';
const UI='etsy_controls_v1';
const text=content=>({tag:'plain_text',content:String(content)});
const div=content=>({tag:'div',text:text(content)});
const card=(title,elements)=>({schema:'2.0',config:{update_multi:true,enable_forward:false},header:{title:text(title),template:'blue'},body:{elements}});
const value=(scope,binding,action)=>({bot_ui:UI,scope,...binding,action});
const button=(label,v,type='default',extra={})=>({tag:'button',text:text(label),type,behaviors:[{type:'callback',value:v}],...extra});
const ack=(content,type='info',data)=>({toast:{type,content},...(data?{card:{type:'raw',data}}:{})});
function interaction(data,config){
  const e=data.event||data,mid=e.context?.open_message_id||e.open_message_id,chat=e.context?.open_chat_id||e.open_chat_id;
  const eid=data.header?.event_id||e.event_id;
  if(e.operator?.open_id!==config.humanOpenId||chat!==config.chatId)throw Error('sender_or_chat_not_authorized');
  if(!/^[A-Za-z0-9_-]{1,200}$/.test(mid||'')||!/^[A-Za-z0-9_-]{1,200}$/.test(eid||''))throw Error('card_event_invalid');
  let v=e.action?.value;if(typeof v==='string'){try{v=JSON.parse(v);}catch{throw Error('card_action_invalid');}}
  if(e.action?.tag!=='button'||!v||v.bot_ui!==UI)throw Error('card_action_invalid');
  return {event_id:eid,message_id:mid,value:v,form:e.action.form_value||{}};
}
function reviewCard(r,mode='review',notice=''){
  const binding={review_id:r.review_id,binding:r.input_hash};
  const labels={'2d':'Thiết kế 2D',embroidery:'Preview thêu',sizes:'Số đo',images:'Bộ mockup',processed:'Ảnh đã xử lý',sample_mockup:'Mockup mẫu'};
  const elements=[div(`${Object.values(r.entity).join(' · ')} · bản ${r.revision}\n${labels[r.stage]||r.stage}`),div(r.summary)];
  const shown=new Set();for(const [i,k] of Object.entries(r.image_keys||{})){
    if(shown.has(k))continue;shown.add(k);elements.push({tag:'img',img_key:k,alt:text(r.images[Number(i)]?.label||'Ảnh cần duyệt'),preview:true});
  }
  if(r.batch_policy)elements.push(div(['images','sample_mockup'].includes(r.stage)?`Duyệt mẫu này cho phép tự hoàn thiện toàn bộ mẫu còn lại của đúng mẻ ${r.batch_policy.batch_id} (${r.batch_policy.item_count} mẫu).`:'Đây là bước duyệt mẫu đầu; hoàn thiện mẻ sau khi mockup đại diện được duyệt.'));
  if(notice)elements.push(div(notice));
  if(mode==='revise'){
    elements.push({tag:'form',name:'revision_form',elements:[{tag:'input',name:'revision_reason',required:true,input_type:'multiline_text',max_length:1000,label:text('Yêu cầu sửa — áp dụng cho cả mẻ này'),placeholder:text('Nêu vị trí hoặc góc ảnh cần sửa; giữ nội dung riêng từng mẫu')},button('Gửi yêu cầu sửa',value('review',binding,'submit_revision'),'primary',{name:'submit_revision',form_action_type:'submit'})]});
    elements.push(button('Quay lại',value('review',binding,'back')));
  }else if(mode==='review'){
    elements.push(div('Xem đủ ảnh trước khi duyệt. Thẻ có hiệu lực 24 giờ và hết hiệu lực khi có bản thay thế.'),button('✅ Duyệt và tiếp tục',value('review',binding,'approve'),'primary'),button('✏️ Yêu cầu sửa',value('review',binding,'revise')),button('❌ Từ chối',value('review',binding,'reject'),'danger',{confirm:{title:text('Từ chối bộ ảnh này?'),text:text('Mẫu này sẽ dừng để xử lý lại.')}}));
  }
  return card(mode==='revise'?'Yêu cầu sửa ảnh':'Đủ ảnh để duyệt',elements);
}
function batchCard(n){
  const elements=[div(n.text)];
  for(const x of n.bundle_images||[])elements.push(div(x.label),{tag:'img',img_key:x.image_key,alt:text(x.label),preview:true});
  for(const [key,a] of Object.entries(n.actions||{}))elements.push(button(a.label,value('batch',{card_id:n.uuid},key),a.type||'default',a.confirm?{confirm:{title:text(a.label+'?'),text:text(a.confirm)}}:{}));
  for(const link of n.destinations||[])if(/^https:\/\/[a-z0-9.-]+\.larksuite\.com\//i.test(link.url))elements.push({tag:'button',text:text(link.label),behaviors:[{type:'open_url',default_url:link.url}]});
  return card(n.title||'Điều khiển mẻ',elements);
}
function menuActions(){return {
  apparel:{label:'Áo 2D',mode:'apparel_2d'},embroidery:{label:'Áo thêu — chọn vị trí',selectPositions:true},pajama:{label:'Bộ pijama (áo + quần)',mode:'pajama_set'},pants:{label:'Quần ngủ',mode:'sleep_pants'},queue:{label:'Làm mới / Điều khiển mẻ',command:{action:'batch_status'}},cancel:{label:'Hủy nhập',cancel:true}
};}
function batchActions(command,result){
  const data=result.result||result,b=data.batch||data,id=b.batch_id||command.batch_id,fp=b.batch_fingerprint||b.fingerprint||command.batch_fingerprint;
  const actions={...menuActions(),queue:{label:'Xem tiến độ',command:{action:'batch_status'}}};
  if(command.action==='batch_submit')actions.run={label:'Lưu mẻ vào hàng chờ',type:'primary',command:{action:'batch_confirm',batch_id:id,batch_fingerprint:fp,card_expected_status:['submitted']}};
  else if(command.action==='batch_confirm'||command.action==='batch_stop')actions.run={label:command.action==='batch_stop'?'Tiếp tục':'Bắt đầu',type:'primary',command:{action:'batch_start',batch_id:id,batch_fingerprint:fp,card_expected_status:command.action==='batch_stop'?['stopped']:['confirmed','ready']}};
  else if(['batch_start','batch_confirm_start','batch_retry'].includes(command.action))actions.stop={label:'Tạm dừng',command:{action:'batch_stop',batch_id:id,batch_fingerprint:fp,card_expected_status:['ready','active']}};
  if(command.action==='batch_stop')actions.discard={label:'Xóa công việc chưa làm của mẻ này',command:{action:'batch_discard_remaining',batch_id:id,batch_fingerprint:fp,card_expected_status:['stopped']},confirm:'Chỉ hủy phần việc chưa làm của mẻ này. Giữ ảnh, phần đã làm, Docs và KPI. Không tự chạy mẻ khác.'};
  if(data.bundle_id)actions.approve_bundle={label:'Duyệt tất cả bộ ảnh đang hiển thị',type:'primary',command:{action:'batch_approve_bundle',bundle_id:data.bundle_id},confirm:'Duyệt đúng các mẻ và phiên bản ảnh đang hiển thị; chưa cấp quyền chạy mẻ ngoài danh sách.'};
  return actions;
}
module.exports={UI,card,div,ack,interaction,reviewCard,batchCard,menuActions,batchActions};
