'use strict';
const {fail}=require('./review.cjs');
const chestRegions={none:[],center:['center_chest'],left:['left_chest'],left_right:['left_chest','right_chest']};
const labels={center_chest:'NGỰC GIỮA',left_chest:'NGỰC TRÁI',right_chest:'NGỰC PHẢI',left_sleeve:'TAY',back:'LƯNG'};
function regions(p){
  if(!p||!Object.hasOwn(chestRegions,p.chest)||typeof p.sleeves!=='boolean'||typeof p.back!=='boolean')fail('batch_positions_invalid');
  return [...chestRegions[p.chest],...(p.sleeves?['left_sleeve']:[]),...(p.back?['back']:[])];
}
function parseDesigns(source,p){
  const keys=regions(p);if(!keys.length)fail('batch_position_required');
  const matches=[...source.matchAll(/^(NGỰC GIỮA|NGỰC TRÁI|NGỰC PHẢI|NGỰC|NGUC|CHEST|TAY|SLEEVE|LƯNG|LUNG|BACK)\s*:\s*/gimu)];
  if(!matches.length||matches[0].index!==0)fail('batch_design_labels_required');
  const designs={};
  for(const [i,m] of matches.entries()){
    let key=Object.keys(labels).find(k=>labels[k]===m[1].toUpperCase());
    if(!key)key=/^(NGỰC|NGUC|CHEST)$/iu.test(m[1])?(chestRegions[p.chest].length===1?chestRegions[p.chest][0]:null):/^(TAY|SLEEVE)$/iu.test(m[1])?'left_sleeve':'back';
    if(!keys.includes(key)||Object.hasOwn(designs,key))fail('batch_unselected_or_duplicate_design');
    const value=source.slice(m.index+m[0].length,matches[i+1]?.index??source.length).trim();
    if(!value||value.length>30000)fail('batch_prompt_empty_or_long');designs[key]=value;
  }
  if(Object.keys(designs).length!==keys.length)fail('batch_missing_selected_design');
  return designs;
}
function selectionActions(p){return {
  none:{label:(p.chest==='none'?'● ':'○ ')+'Không thêu ngực',position:{chest:'none'}},
  center:{label:(p.chest==='center'?'● ':'○ ')+'Ngực giữa',position:{chest:'center'}},
  left:{label:(p.chest==='left'?'● ':'○ ')+'Ngực trái',position:{chest:'left'}},
  both:{label:(p.chest==='left_right'?'● ':'○ ')+'Ngực trái + phải',position:{chest:'left_right'}},
  sleeves:{label:(p.sleeves?'☑ ':'☐ ')+'Hai tay dùng chung',togglePosition:'sleeves'},
  back:{label:(p.back?'☑ ':'☐ ')+'Lưng',togglePosition:'back'},
  ...(regions(p).length?{continue:{label:'Xác nhận vị trí và nhập design',finishPositions:true,type:'primary'}}:{}),
  menu:{label:'Về menu',menu:true}
};}
function dashboard(data){
  const list=data.batches||[],active=list.find(b=>b.status==='active');
  const run=data.run_plan;
  if(run?.mode==='selected_group'&&run.status==='preparing'){
    const selected=(run.entries||[]).map(e=>list.find(b=>b.batch_id===e.batch_id)).filter(Boolean);
    const ready=selected.filter(b=>b.status==='prepared').length;
    return `NHÓM ĐÃ CHỌN: ${ready}/${selected.length} mẻ đã duyệt.\nMẻ đã duyệt đứng chờ; chỉ chạy lần lượt khi tất cả đã duyệt.\n${selected.map((b,i)=>`${i+1}. ${b.batch_id}: ${b.status==='prepared'?'Đã duyệt — đang chờ':b.items?.[0]?.state==='awaiting_sample_approval'?'Chờ bạn duyệt mẫu':'Đang tạo hoặc sửa mẫu'}`).join('\n')}\n`;
  }
  if(!active)return 'ĐANG TRỐNG — chờ bạn chọn mẻ.\n';
  const done=active.items.filter(i=>i.state==='completed').length,now=active.items.find(i=>!['completed','cancelled'].includes(i.state));
  return `ĐANG XỬ LÝ: ${active.name||active.batch_id}\n${active.batch_id} · ${done}/${active.items.length} mẫu hoàn tất\n${now?'Mẫu '+now.item_id+' · '+now.state:''}\n`;
}
module.exports={regions,labels,parseDesigns,selectionActions,dashboard};
