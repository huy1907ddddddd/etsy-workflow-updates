'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const lark=require('@larksuiteoapi/node-sdk');
const {ReviewStore,hash}=require('./review.cjs'),{BatchStore}=require('./batch.cjs'),{UI,reviewCard,batchCard}=require('./cards.cjs');
function fixture(t){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'isolated-card-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  let time=1760000000000,serial=0;
  const config={stateFile:path.join(dir,'state.json'),chatId:'oc_owner',humanOpenId:'ou_owner',allowedImageRoots:[dir]};
  const store=new ReviewStore(config,()=>time),batch=new BatchStore(store),sent=[];
  const transport={upload:async()=> 'img_fixture',send:async(chat,type,content)=>{sent.push({chat,type,content});return 'om_'+sent.length;}};
  const callback=(v,mid,form)=>({schema:'2.0',header:{event_type:'card.action.trigger',event_id:'card_evt_'+(++serial)},event:{operator:{open_id:'ou_owner'},context:{open_chat_id:'oc_owner',open_message_id:mid},action:{tag:'button',value:v,...(form?{form_value:form}:{})}}});
  const review=async()=>{
    const image=Buffer.from('89504e470d0a1a0a','hex'),p=path.join(dir,'fixture.png');fs.writeFileSync(p,image);
    const r=store.create({review_id:'review-fixture-001',entity:{brief_id:'fixture-brief'},revision:1,stage:'2d',fingerprint:'a'.repeat(64),summary:'Isolated UI fixture only',images:[{path:p,sha256:hash(image)}],visual_qa:{passed:true,reference:'isolated fixture; no production claim'}});
    await store.deliver(r.review_id,transport);return r;
  };
  const rv=(r,action)=>({bot_ui:UI,scope:'review',review_id:r.review_id,binding:r.input_hash,action});
  return {dir,store,batch,config,sent,transport,callback,review,rv,advance:ms=>time+=ms};
}
test('real SDK event normalization dispatches a bound card approval without fabricating a user message',async t=>{
  const f=fixture(t),r=await f.review(),mid=r.messages.find(m=>m.slot==='final').message_id;
  assert.equal(f.sent.at(-1).type,'interactive');assert.match(JSON.stringify(reviewCard(r)),/Duyệt và tiếp tục/);
  const dispatcher=new lark.EventDispatcher({logger:{trace(){},debug(){},info(){},warn(){},error(){},fatal(){}}}).register({'card.action.trigger':e=>f.store.receiveCard(e)});
  const raw=f.callback(f.rv(r,'approve'),mid),response=await dispatcher.invoke(raw,{needCheck:false});
  assert.equal(response.toast.type,'success');
  const body=Object.values(f.store.state.outbox)[0].body;
  assert.equal(body.event_id,raw.header.event_id);assert.equal(body.message_id,mid);assert.equal(body.interaction_type,'card_action');assert.match(body.reference,/Lark card action/);
  await dispatcher.invoke(raw,{needCheck:false});f.store.receiveCard(f.callback(f.rv(r,'approve'),mid));assert.equal(Object.keys(f.store.state.outbox).length,1);
});
test('review cards reject another user/chat/message/binding, expired card and superseded revision',async t=>{
  for(const variant of ['user','chat','message','binding','expired','superseded']){
    const f=fixture(t),r=await f.review(),raw=f.callback(f.rv(r,'approve'),r.messages.find(m=>m.slot==='final').message_id);
    if(variant==='user')raw.event.operator.open_id='ou_stranger';if(variant==='chat')raw.event.context.open_chat_id='oc_stranger';
    if(variant==='message')raw.event.context.open_message_id='om_other';if(variant==='binding')raw.event.action.value.binding='b'.repeat(64);
    if(variant==='expired')f.advance(25*3600000);if(variant==='superseded')f.store.supersede(r.review_id,'new revision');
    assert.equal(f.store.receiveCard(raw).toast.type,'error',variant);assert.equal(Object.keys(f.store.state.outbox).length,0,variant);
  }
});
test('edit opens a form only; submitting requires a reason, binds the current image and queues revise',async t=>{
  const f=fixture(t),r=await f.review(),mid=r.messages.find(m=>m.slot==='final').message_id;
  const form=f.store.receiveCard(f.callback(f.rv(r,'revise'),mid));
  assert.match(JSON.stringify(form.card),/revision_reason/);assert.equal(Object.keys(f.store.state.outbox).length,0);
  assert.equal(f.store.receiveCard(f.callback(f.rv(r,'approve'),mid,{revision_reason:'Đổi màu'})).toast.type,'error');
  assert.equal(f.store.receiveCard(f.callback(f.rv(r,'submit_revision'),mid,{revision_reason:' '})).toast.type,'error');
  assert.equal(f.store.receiveCard(f.callback(f.rv(r,'submit_revision'),mid,{revision_reason:'Bỏ viền ngoài'})).toast.type,'success');
  const body=Object.values(f.store.state.outbox)[0].body;assert.equal(body.decision,'revise');assert.equal(body.reason,'Bỏ viền ngoài');assert.equal(body.fingerprint,r.fingerprint);
});
test('menu and batch buttons retain real operator events, immutable commands, durable dedup and single use',async t=>{
  const f=fixture(t);f.batch.menu('fixture-menu');await f.batch.deliver(f.transport);
  let n=f.batch.state.notifications['fixture-menu'];
  const raw=f.callback({bot_ui:UI,scope:'batch',card_id:n.uuid,action:'apparel'},n.message_id);
  assert.equal(f.batch.receiveCard(raw).toast.type,'success');assert.equal(f.batch.state.session.kind,'apparel_2d');assert.equal(Object.keys(f.batch.state.outbox).length,0);
  f.batch.notify('open-menu','Fixture',{menu:{label:'Nhập mẻ mới',menu:true}});await f.batch.deliver(f.transport);
  n=f.batch.state.notifications['open-menu'];assert.equal(f.batch.receiveCard(f.callback({bot_ui:UI,scope:'batch',card_id:n.uuid,action:'menu'},n.message_id)).toast.type,'success');
  assert.equal(Object.keys(f.batch.state.outbox).length,1);assert.equal(Object.values(f.batch.state.outbox)[0].body.command.action,'batch_status');
  f.batch.state.manifests['fixture-batch']={batch_fingerprint:'a'.repeat(64),version:1};
  f.batch.notify('fixture-run','Two fixture items',{run:{label:'Xác nhận và chạy',command:{action:'batch_confirm_start',batch_id:'fixture-batch',batch_fingerprint:'a'.repeat(64),card_expected_status:['submitted']}}});
  await f.batch.deliver(f.transport);n=f.batch.state.notifications['fixture-run'];
  const click=f.callback({bot_ui:UI,scope:'batch',card_id:n.uuid,action:'run',command:{action:'batch_delete'}},n.message_id);
  assert.equal(f.batch.receiveCard(click).toast.type,'success');f.batch.receiveCard(click);f.batch.receiveCard(f.callback(click.event.action.value,n.message_id));
  assert.equal(Object.keys(f.batch.state.outbox).length,2);const body=Object.values(f.batch.state.outbox).find(x=>x.body.command.action==='batch_confirm_start').body;
  assert.equal(body.command.action,'batch_confirm_start');assert.equal(body.event_id,click.header.event_id);assert.equal(body.interaction_type,'card_action');
  const resumed=new BatchStore(new ReviewStore(f.config,()=>1760000000000));assert.equal(resumed.receiveCard(click).toast.type,'success');assert.equal(Object.keys(resumed.state.outbox).length,2);
});
test('batch buttons cannot use another message, expired version or unpaired user',async t=>{
  const f=fixture(t);f.batch.state.manifests.b={batch_fingerprint:'a'.repeat(64),version:1};
  f.batch.notify('q','Fixture',{stop:{label:'Tạm dừng',command:{action:'batch_stop',batch_id:'b'}}});await f.batch.deliver(f.transport);
  const n=f.batch.state.notifications.q,click=()=>f.callback({bot_ui:UI,scope:'batch',card_id:n.uuid,action:'stop'},n.message_id);
  let e=click();e.event.operator.open_id='ou_other';assert.equal(f.batch.receiveCard(e).toast.type,'error');
  e=click();e.event.context.open_message_id='om_other';assert.equal(f.batch.receiveCard(e).toast.type,'error');
  f.batch.state.manifests.b.version=2;assert.equal(f.batch.receiveCard(click()).toast.type,'error');assert.equal(Object.keys(f.batch.state.outbox).length,0);
  assert.equal(batchCard(n).schema,'2.0');
});
test('only a durable n8n acknowledgement replaces approval buttons with the applied result',async t=>{
  const f=fixture(t),r=await f.review(),mid=r.messages.find(m=>m.slot==='final').message_id;
  f.store.receiveCard(f.callback(f.rv(r,'approve'),mid));
  await f.store.flush(async()=>({ok:true}));assert.equal(r.status,'decision_pending');
  f.advance(300000);await f.store.flush(async()=>({ok:true,accepted:true}));
  let updated;await f.store.deliverCardUpdates({update:async(id,content)=>{assert.equal(id,mid);updated=content;}});
  assert.match(JSON.stringify(updated),/n8n đã xác nhận/);assert.equal(updated.body.elements.some(e=>e.tag==='button'||e.tag==='form'),false);
});
