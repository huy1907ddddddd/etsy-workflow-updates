'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash, randomUUID } = require('node:crypto');
const { interaction, ack, reviewCard } = require('./cards.cjs');
const hash = x => createHash('sha256').update(x).digest('hex');
const fail = (code, status = 400) => { const e = new Error(code); e.code = code; e.status = status; throw e; };
const key = x => JSON.stringify(x.entity);
const fingerprint = /^[a-f0-9]{64}$/;

class ReviewStore {
  constructor(config, clock = () => Date.now()) {
    this.config = config; this.clock = clock;
    this.state = fs.existsSync(config.stateFile) ? JSON.parse(fs.readFileSync(config.stateFile, 'utf8')) : { schema_version: 1, reviews: {}, seen: {}, outbox: {} };
    if (this.state.schema_version !== 1) fail('state_schema_invalid');
  }
  save() {
    fs.mkdirSync(path.dirname(this.config.stateFile), { recursive: true });
    const temp = this.config.stateFile + '.tmp';
    fs.writeFileSync(temp, JSON.stringify(this.state), { mode: 0o600 });
    fs.renameSync(temp, this.config.stateFile);
  }
  validateImage(image) {
    if (!image || !fingerprint.test(image.sha256) || typeof image.path !== 'string') fail('image_invalid');
    const real = fs.realpathSync(image.path);
    const allowed = this.config.allowedImageRoots.some(root => {
      const relative = path.relative(fs.realpathSync(root), real);
      return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
    });
    if (!allowed || !/\.(png|jpe?g|webp)$/i.test(real)) fail('image_path_not_allowed');
    const stat = fs.statSync(real);
    if (!stat.isFile() || stat.size > 10 * 1024 * 1024) fail('image_size_invalid');
    const bytes = fs.readFileSync(real);
    if (hash(bytes) !== image.sha256) fail('image_hash_changed', 409);
    const png = bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'));
    const jpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    const webp = bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP';
    if (!png && !jpeg && !webp) fail('image_bytes_invalid');
    return bytes;
  }
  create(input) {
    if (!input || !/^[A-Za-z0-9_-]{6,100}$/.test(input.review_id) || !Number.isInteger(input.revision) || input.revision < 1 || !fingerprint.test(input.fingerprint)) fail('review_binding_invalid');
    const batchEntity = input.entity && Object.keys(input.entity).length === 2 && Object.keys(input.entity).every(k => ['batch_id', 'item_id'].includes(k)) && Object.values(input.entity).every(v => /^[A-Za-z0-9_-]{1,100}$/.test(v));
    const ordinaryEntity = input.entity && Object.keys(input.entity).length === 1 && ['brief_id', 'listing_code'].includes(Object.keys(input.entity)[0]) && /^[A-Za-z0-9_-]{1,100}$/.test(Object.values(input.entity)[0]);
    if (!batchEntity && !ordinaryEntity) fail('entity_invalid');
    if (!['2d', 'embroidery', 'sizes', 'images', 'processed', 'sample_mockup'].includes(input.stage)) fail('stage_invalid');
    if (input.batch_policy && (!/^[A-Za-z0-9_-]{1,100}$/.test(input.batch_policy.batch_id || '') || !fingerprint.test(input.batch_policy.batch_fingerprint || '') || input.batch_policy.scope !== 'representative_for_immutable_batch' || !['embroidery_brief', 'embroidery_prompts', 'apparel_2d','pajama_top','pajama_set','sleep_pants'].includes(input.batch_policy.kind) || !Number.isInteger(input.batch_policy.item_count) || input.batch_policy.item_count < 1 || input.batch_policy.item_count > 100)) fail('batch_review_policy_invalid');
    if (input.stage === 'sample_mockup' && (!batchEntity || input.batch_policy?.batch_id !== input.entity.batch_id)) fail('batch_sample_binding_required');
    if (batchEntity && input.stage !== 'sample_mockup') fail('batch_sample_stage_required');
    if (typeof input.summary !== 'string' || input.summary.length < 1 || input.summary.length > 6000) fail('summary_invalid');
    if (!Array.isArray(input.images) || input.images.length > 10 || (['2d', 'embroidery', 'images', 'processed', 'sample_mockup'].includes(input.stage) && !input.images.length) || (input.stage === 'sample_mockup' && input.images.length !== 1)) fail('images_invalid');
    const candidate = input.visual_qa?.passed === false && input.visual_qa.status === 'awaiting_human_visual_review' && input.visual_qa.executor === 'independent_flow_worker' && (/^candidate-[a-f0-9]{64}$/.test(input.visual_qa.native_candidate_id || '') || (batchEntity && input.stage === 'sample_mockup' && input.batch_policy));
    if (input.images.length && ((!candidate && input.visual_qa?.passed !== true) || typeof input.visual_qa.reference !== 'string' || !input.visual_qa.reference.trim())) fail('operator_visual_qa_required');
    input.images.forEach(x => this.validateImage(x));
    const immutable = structuredClone(input);
    const digest = hash(JSON.stringify(immutable));
    const existing = this.state.reviews[input.review_id];
    if (existing) {
      if (existing.input_hash !== digest) fail('review_id_conflict', 409);
      return existing;
    }
    const same = Object.values(this.state.reviews).filter(x => key(x) === key(input));
    if (same.some(x => x.revision > input.revision || (x.revision === input.revision && x.stage === input.stage && x.fingerprint !== input.fingerprint && x.status === 'accepted'))) fail('old_or_changed_review', 409);
    for (const old of same) {
      if (old.revision < input.revision || (old.revision === input.revision && old.stage === input.stage)) this.supersede(old.review_id, 'replacement_review', false);
    }
    const record = { ...immutable, input_hash: digest, status: 'sending', created_at: this.clock(), expires_at: this.clock() + 24 * 3600000, messages: [], image_keys: {}, message_uuids: { text: randomUUID(), final: randomUUID(), ...Object.fromEntries(input.images.map((_, i) => ['image_' + i, randomUUID()])) } };
    this.state.reviews[input.review_id] = record; this.save(); return record;
  }
  validateDocument(asset) {
    if (!asset || !fingerprint.test(asset.sha256 || '') || typeof asset.path !== 'string') fail('document_invalid');
    const real=fs.realpathSync(asset.path),allowed=this.config.allowedImageRoots.some(root=>{const rel=path.relative(fs.realpathSync(root),real);return rel===''||(!rel.startsWith('..')&&!path.isAbsolute(rel));});
    if(!allowed||! /\.(zip|csv|html|json)$/i.test(real)||!fs.statSync(real).isFile()||fs.statSync(real).size>50*1000*1000)fail('document_path_or_size_invalid');
    const bytes=fs.readFileSync(real);if(hash(bytes)!==asset.sha256)fail('document_hash_changed');
    return {bytes,name:path.basename(real)};
  }
  supersede(id, reason, persist = true) {
    const r = this.state.reviews[id]; if (!r) fail('review_not_found', 404);
    if (r.status !== 'accepted') r.status = 'superseded';
    r.superseded_reason = String(reason || 'current_state_changed').slice(0, 500);
    r.card_update_pending=true;
    for (const o of Object.values(this.state.outbox)) if (o.body.review_id === id && o.status === 'pending') o.status = 'cancelled';
    if (persist) this.save(); return r;
  }
  async deliver(id, transport) {
    const r = this.state.reviews[id]; if (!r || r.status !== 'sending') return r;
    const active = () => { if (r.status !== 'sending') fail('review_superseded', 409); };
    const send = async (slot, type, content) => {
      active(); if (r.messages.some(x => x.slot === slot)) return;
      const messageId = await transport.send(this.config.chatId, type, content, r.message_uuids[slot]);
      if (!messageId) fail('lark_message_id_missing', 502);
      r.messages.push({ slot, message_id: messageId }); this.save(); active();
    };
    const qa = r.visual_qa?.passed === false ? '\nẢnh do worker Flow tạo tự động, CHƯA được kiểm tra bằng mắt. Hãy kiểm tra viền ngoài, bố cục, màu, chi tiết và ảnh tham chiếu trước khi DUYỆT. Lời DUYỆT xác nhận bạn đã xem và chấp nhận chất lượng của đúng bộ ảnh này.' : '';
    const scope = r.batch_policy ? `\nMẫu đại diện của mẻ ${r.batch_policy.batch_id} · ${r.batch_policy.item_count} mẫu · fingerprint ${r.batch_policy.batch_fingerprint}.${['images', 'sample_mockup'].includes(r.stage) ? '\nDUYỆT mockup này cho phép hệ thống tự hoàn thiện toàn bộ mẫu còn lại trong đúng mẻ, không yêu cầu duyệt riêng từng mẫu. Chỉ áp dụng bộ yêu cầu và chuẩn của mẻ đã khóa này.' : '\nĐây là bước duyệt mẫu đầu. Hệ thống chỉ tự hoàn thiện phần còn lại sau khi bạn duyệt mockup đại diện của mẻ.'}` : '';
    await send('text', 'text', { text: `Yêu cầu xem: ${r.review_id}\n${Object.values(r.entity)[0]} · v${r.revision} · ${r.stage}\n${r.summary}\nFingerprint: ${r.fingerprint}${qa}${scope}\nẢnh đang gửi; hãy chờ tin nhắn “Đủ ảnh để duyệt”.` });
    for (let i = 0; i < r.images.length; i++) {
      if (['2d','embroidery','sizes'].includes(r.stage) && /sleeve/.test(r.images[i].label||'') && r.images.slice(0,i).some(image=>/sleeve/.test(image.label||'')&&image.sha256===r.images[i].sha256)) continue;
      active();
      if (!r.image_keys[i]) {
        r.image_keys[i] = await transport.upload(this.validateImage(r.images[i]));
        if (!r.image_keys[i]) fail('lark_image_key_missing', 502);
        this.save();
      }
      await send('image_' + i, 'image', { image_key: r.image_keys[i] });
    }
    if(!r.messages.some(m=>m.slot==='final'))r.interactive_card=true;
    await send('final', 'interactive', reviewCard(r));
    r.status = 'pending'; r.delivered_at = this.clock(); this.save(); return r;
  }
  receive(event) {
    const e = event.event || event;
    const message = e.message || {}, sender = e.sender || {};
    const mid = message.message_id, eid = event.header?.event_id || e.event_id || mid;
    if (!mid || !eid || sender.sender_type !== 'user' || sender.sender_id?.open_id !== this.config.humanOpenId || message.chat_id !== this.config.chatId) return { ok: false, code: 'sender_or_chat_not_authorized' };
    if (message.message_type !== 'text') return { ok: false, code: 'typed_reply_required' };
    if (this.state.seen[mid]) return { ...this.state.seen[mid], duplicate: true };
    if (Object.values(this.state.outbox).some(x => x.body.event_id === eid && x.body.message_id !== mid)) return { ok: false, code: 'event_id_conflict' };
    let text;
    try { text = JSON.parse(message.content).text; } catch { return { ok: false, code: 'message_invalid' }; }
    if (typeof text !== 'string' || text.length > 8000) return { ok: false, code: 'message_invalid' };
    text = text.replace(/@_user_\d+/g, '').trim();
    const match = /^(DUYỆT|APPROVE|SỬA|REVISE|TỪ CHỐI|REJECT)(?:\s+([A-Za-z0-9_-]{6,100}))?(?:\s*:\s*([\s\S]+))?$/iu.exec(text);
    const recordResult = result => { this.state.seen[mid] = result; this.save(); return result; };
    if (!match) return recordResult({ ok: false, code: 'explicit_decision_required' });
    const replyId = message.parent_id || message.root_id;
    const bound = replyId && Object.values(this.state.reviews).find(r => r.messages.some(m => m.message_id === replyId));
    const r = match[2] ? this.state.reviews[match[2]] : bound;
    if (!r || (match[2] && bound && r.review_id !== bound.review_id) || (replyId && !bound)) return recordResult({ ok: false, code: 'reply_binding_invalid' });
    if (r.status !== 'pending' || this.clock() > r.expires_at) return recordResult({ ok: false, code: 'stale_review' });
    const token = match[1].toUpperCase();
    const decision = ['DUYỆT', 'APPROVE'].includes(token) ? 'approve' : ['SỬA', 'REVISE'].includes(token) ? 'revise' : 'reject';
    if (decision === 'revise' && !match[3]?.trim()) return recordResult({ ok: false, code: 'revision_reason_required' });
    // Never treat a mixed approval/change request as approval.
    if (decision === 'approve' && match[3]) return recordResult({ ok: false, code: 'ambiguous_approval' });
    this.queueDecision(r,{event_id:eid,message_id:mid,decision,text,reason:match[3]?.trim()||'',reference:`${this.config.transport==='web'?'Web':this.config.transport==='telegram'?'Telegram':'Lark'} message ${mid}; review ${r.review_id}; direct user: ${text}`},mid);
    return recordResult({ ok: true, status: 'queued_for_n8n', review_id: r.review_id });
  }
  queueDecision(r,e,outboxKey){
    const body = { schema_version: 1, ...e, ...(this.config.transport?{transport:this.config.transport}:{}), review_id: r.review_id, sender_open_id: this.config.humanOpenId, chat_id: this.config.chatId, entity: structuredClone(r.entity), revision: r.revision, stage: r.stage, fingerprint: r.fingerprint, authority: 'direct_user', received_at: new Date(this.clock()).toISOString() };
    if (r.batch_policy) body.batch_policy = structuredClone(r.batch_policy);
    this.state.outbox[outboxKey] = { body, status: 'pending', attempts: 0, next_attempt: 0 };
    r.status = 'decision_pending'; r.decision_message_id = e.message_id;this.save();
  }
  receiveCard(data){
    try{
      const e=interaction(data,this.config),v=e.value;
      this.state.card_seen||={};if(this.state.card_seen[e.event_id])return this.state.card_seen[e.event_id];
      const r=this.state.reviews[v.review_id];
      if(v.scope!=='review'||!r||v.binding!==r.input_hash||!r.messages.some(m=>m.slot==='final'&&m.message_id===e.message_id))return ack('Nút không thuộc bộ ảnh này.','error');
      if(r.status!=='pending'||this.clock()>r.expires_at)return ack('Thẻ đã hết hiệu lực hoặc quyết định đã được nhận.','error');
      let response;
      if(v.action==='revise'){r.correction_form=true;response=ack('Nhập yêu cầu sửa bên dưới.','info',reviewCard(r,'revise'));}
      else if(v.action==='back'){r.correction_form=false;response=ack('Đã quay lại bộ ảnh.','info',reviewCard(r));}
      else{
        if(!['approve','reject','submit_revision'].includes(v.action))return ack('Nút không hợp lệ.','error');
        if(v.action!=='submit_revision'&&(r.correction_form||Object.keys(e.form).length))return ack('Đang nhập sửa; hãy gửi yêu cầu sửa hoặc quay lại trước khi duyệt.','error');
        const reason=v.action==='submit_revision'&&typeof e.form.revision_reason==='string'?e.form.revision_reason.trim():'';
        if(v.action==='submit_revision'&&(!r.correction_form||!reason||reason.length>6000))return ack('Vui lòng nhập yêu cầu sửa cụ thể.','error');
        const decision=v.action==='submit_revision'?'revise':v.action,label={approve:'Duyệt và tiếp tục',revise:'Yêu cầu sửa',reject:'Từ chối'}[decision];
        this.queueDecision(r,{event_id:e.event_id,message_id:e.message_id,decision,text:label,reason,interaction_type:'card_action',reference:`${this.config.transport==='web'?'Web':this.config.transport==='telegram'?'Telegram':'Lark'} card action ${e.event_id}; message ${e.message_id}; review ${r.review_id}; direct user: ${label}${reason?': '+reason:''}`},'card:'+e.event_id);
        response=ack('Đã nhận; n8n đang xử lý.','success',reviewCard(r,'received',`Đã nhận: ${label}. Đang chờ xác nhận từ n8n.`));
      }
      this.state.card_seen[e.event_id]=response;this.save();return response;
    }catch{return ack('Không nhận nút này: sai tài khoản, hội thoại hoặc sự kiện.','error');}
  }
  async flush(forward) {
    for (const o of Object.values(this.state.outbox)) {
      if (o.status !== 'pending' || o.next_attempt > this.clock()) continue;
      const r = this.state.reviews[o.body.review_id];
      if (r.status !== 'decision_pending' || this.clock() > r.expires_at) { o.status = 'cancelled'; this.save(); continue; }
      o.attempts++; this.save();
      try {
        const reply = await forward(o.body);
        if (reply.ok !== true || reply.accepted !== true) fail('n8n_not_acknowledged', 502);
        if (r.status !== 'decision_pending' || o.status !== 'pending') continue;
        o.status = 'delivered'; r.status = 'accepted'; r.decision = o.body.decision; r.n8n_ack = reply;r.card_update_pending=true; this.save();
      } catch (error) {
        if (error.code === 'stale_review') { o.status = 'rejected_stale'; r.status = 'superseded';r.card_update_pending=true; }
        else { o.next_attempt = this.clock() + Math.min(300000, 5000 * 2 ** Math.min(o.attempts, 6)); o.last_error = error.code || 'n8n_unavailable'; }
        this.save();
      }
    }
  }
  async deliverCardUpdates(transport){
    if(!transport.update)return;
    for(const r of Object.values(this.state.reviews)){
      if(!r.card_update_pending||!r.interactive_card)continue;
      const mid=r.messages.find(m=>m.slot==='final')?.message_id;if(!mid)continue;
      const notice=r.status==='accepted'?`n8n đã xác nhận: ${r.decision==='approve'?'Duyệt và tiếp tục':r.decision==='revise'?'Yêu cầu sửa':'Từ chối'}.`:'Thẻ đã hết hiệu lực; hãy dùng bộ ảnh mới nhất.';
      await transport.update(mid,reviewCard(r,'closed',notice));r.card_update_pending=false;this.save();
    }
  }
  workerStatus(input) {
    if (!input || !['blocked', 'recovered', 'stopped'].includes(input.status) || !/^[a-z0-9_-]{1,100}$/i.test(input.code || '') || typeof input.message !== 'string' || !input.message.trim() || input.message.length > 1200 || (input.task_id && !/^[A-Za-z0-9_-]{1,100}$/.test(input.task_id))) fail('worker_status_invalid');
    const body = { status: input.status, code: input.code, task_id: input.task_id || null, message: input.message };
    const digest = hash(JSON.stringify(body));
    if (this.state.worker_status?.digest === digest) return this.state.worker_status;
    this.state.worker_status = { ...body, digest, uuid: randomUUID(), pending: true, recorded_at: this.clock() };
    this.save(); return this.state.worker_status;
  }
  async deliverWorkerStatus(transport) {
    const record = this.state.worker_status;
    if (!record?.pending) return;
    const message = `Worker Flow · ${record.status}\n${record.code}${record.task_id ? '\nTask: ' + record.task_id : ''}\n${record.message}`;
    const id = await transport.send(this.config.chatId, 'text', { text: message, ...(['blocked','stopped'].includes(record.status)?{notification_kind:'workflow_stopped'}:{}) }, record.uuid);
    if (!id) fail('lark_message_id_missing', 502);
    if (this.state.worker_status === record) { record.pending = false; record.message_id = id; this.save(); }
  }
}
module.exports = { ReviewStore, hash, fail };
