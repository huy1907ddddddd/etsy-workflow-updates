'use strict';
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { timingSafeEqual } = require('node:crypto');
const lark = require('@larksuiteoapi/node-sdk');
const { ReviewStore, fail } = require('./review.cjs');
const { BatchStore, MAX_BYTES } = require('./batch.cjs');
const { interaction, ack } = require('./cards.cjs');

function uploadedImageKey(result) {
  // The pinned SDK unwraps image.create to data, unlike message.create.
  if ((result?.code !== undefined && result.code !== 0) || typeof result?.image_key !== 'string' || !/^img_[A-Za-z0-9_-]{1,250}$/.test(result.image_key)) fail('lark_image_key_missing', 502);
  return result.image_key;
}

function loadConfig() {
  const file = process.env.LARK_REVIEW_CONFIG || path.resolve(__dirname, '../../config/lark-review.private.json');
  const config = file ? JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')) : {};
  for (const [key, variable] of Object.entries({ appId: 'LARK_APP_ID', appSecret: 'LARK_APP_SECRET', chatId: 'LARK_REVIEW_CHAT_ID', humanOpenId: 'LARK_REVIEW_HUMAN_OPEN_ID', localToken: 'LARK_REVIEW_LOCAL_TOKEN', n8nToken: 'LARK_REVIEW_N8N_TOKEN' })) if (process.env[variable]) config[key] = process.env[variable];
  for (const key of ['appId', 'appSecret', 'chatId', 'humanOpenId', 'localToken', 'n8nToken', 'n8nWebhookUrl', 'stateFile']) if (typeof config[key] !== 'string' || !config[key].trim()) fail('config_missing_' + key);
  if (config.localToken.length < 32 || config.n8nToken.length < 32) fail('config_token_too_short');
  if (!Array.isArray(config.allowedImageRoots) || !config.allowedImageRoots.length) fail('config_image_roots_missing');
  config.allowedImageRoots.forEach(root => fs.realpathSync(root));
  config.port ||= 8790;
  const layout=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../../config/listing-layout.json'),'utf8').replace(/^\uFEFF/,''));
  config.cardDestinations=[{label:'Mở nội dung Docs',url:layout.url},{label:'Mở KPI',url:'https://local-workspace.invalid/wiki/LOCAL_DESTINATION_REQUIRED'}];
  if (!Number.isInteger(config.port) || config.port < 1024 || config.port > 65535) fail('config_port_invalid');
  const dest = new URL(config.n8nWebhookUrl);
  if (dest.protocol !== 'http:' || dest.hostname !== '127.0.0.1' || dest.port !== '5678' || !/^\/webhook\/[A-Za-z0-9_-]+$/.test(dest.pathname) || dest.username || dest.password || dest.search || dest.hash) fail('n8n_destination_must_be_local_webhook');
  config.n8nTokenHeader ||= 'x-review-token';
  if (!/^[a-z0-9-]+$/i.test(config.n8nTokenHeader)) fail('n8n_header_invalid');
  config.batchWebhookUrl ||= 'http://127.0.0.1:5678/webhook/etsy-batch-command';
  const batchDestination = new URL(config.batchWebhookUrl);
  if (batchDestination.protocol !== 'http:' || batchDestination.hostname !== '127.0.0.1' || batchDestination.port !== '5678' || batchDestination.pathname !== '/webhook/etsy-batch-command' || batchDestination.username || batchDestination.password || batchDestination.search || batchDestination.hash) fail('batch_destination_invalid');
  return config;
}
function authorized(received, token) {
  const a = Buffer.from(typeof received === 'string' ? received : ''), b = Buffer.from(token);
  return a.length === b.length && timingSafeEqual(a, b);
}
function makeServer(config, store, deliver, connectionStatus = () => 'not_started', notify = () => {}, batch = null) {
  const server = http.createServer(async (req, res) => {
    const respond = (status, body) => { res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(body)); };
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      if (req.method === 'GET' && url.pathname === '/health') return respond(200, { ok: true, version: 3, build:config.transport==='web'?'20261019-web':config.transport==='telegram'?'20261019-telegram':'20261018-selected-group', selected_group_run:true, product_profiles:3, grouped_reviews:true, manual_batch_selection:true, card_actions:true, supplied_listing_codes:true, transport: config.transport==='web'?'private_web':config.transport==='telegram'?'telegram_long_polling':'lark_websocket', websocket_state: connectionStatus(), pending_reviews: Object.values(store.state.reviews).filter(x => ['sending', 'pending', 'decision_pending'].includes(x.status)).length, pending_decisions: Object.values(store.state.outbox).filter(x => x.status === 'pending').length, pending_batch_commands: batch ? Object.values(batch.state.outbox).filter(x => x.status === 'pending').length : 0 });
      if (!authorized(req.headers['x-review-token'], config.localToken)) return respond(401, { ok: false, code: 'unauthorized' });
      const parts = url.pathname.split('/').filter(Boolean);
      if (req.method === 'GET' && parts[0] === 'batch-outbox' && batch) {
        const entries = Object.values(batch.state.outbox);
        if (parts.length === 1) return respond(200, { ok: true, commands: entries.filter(x => x.status === 'pending') });
        if (parts.length !== 2) fail('route_not_found', 404);
        const envelope = entries.find(x => x.body.event_id === parts[1]);
        if (!envelope) fail('event_not_found', 404);
        return respond(200, { ok: true, envelope });
      }
      if (req.method === 'GET' && parts[0] === 'reviews' && parts.length === 2) {
        const review = store.state.reviews[parts[1]]; if (!review) fail('review_not_found', 404);
        return respond(200, { ok: true, review });
      }
      if (req.method === 'GET' && parts[0] === 'outbox') {
        const entries = Object.values(store.state.outbox);
        if (parts.length === 1) return respond(200, { ok: true, decisions: entries.filter(x => x.status === 'pending') });
        const envelope = entries.find(x => x.body.event_id === parts[1]);
        if (!envelope) fail('event_not_found', 404);
        return respond(200, { ok: true, envelope });
      }
      if (req.method !== 'POST') fail('route_not_found', 404);
      if (req.headers['content-type']?.split(';')[0] !== 'application/json') fail('json_required', 415);
      let bytes = 0, chunks = [];
      for await (const chunk of req) { bytes += chunk.length; if (bytes > 100000) fail('request_too_large', 413); chunks.push(chunk); }
      let body; try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { fail('json_invalid'); }
      if (parts.length === 1 && parts[0] === 'batch-result' && batch) {
        if (!/^[A-Za-z0-9_-]{1,100}$/.test(body.batch_id || '') || typeof body.message !== 'string' || !body.message.trim() || body.message.length > 6000 || !/^[A-Za-z0-9_-]{1,150}$/.test(body.event_id || '')) fail('batch_result_invalid');
        if(body.documents){if(!['telegram','web'].includes(config.transport)||!Array.isArray(body.documents)||body.documents.length>10)fail('batch_documents_invalid');body.documents.forEach(a=>store.validateDocument(a));}
        batch.notify('native:' + body.batch_id + ':' + body.event_id, body.message);
        if(body.notification_kind==='workflow_stopped')batch.state.notifications['native:'+body.batch_id+':'+body.event_id].notification_kind='workflow_stopped';
        if(body.documents){batch.state.notifications['native:'+body.batch_id+':'+body.event_id].documents=body.documents;batch.save();}
        batch.save(); notify();
        return respond(202, { ok: true, status: 'notification_queued' });
      }
      if (parts.length === 1 && parts[0] === 'worker-status') {
        const record = store.workerStatus(body); notify();
        return respond(202, { ok: true, status: record.status, pending: record.pending });
      }
      if (parts[0] === 'reviews' && parts.length === 1) {
        const review = store.create(body); deliver(review.review_id);
        return respond(202, { ok: true, review_id: review.review_id, status: review.status });
      }
      if (parts[0] === 'reviews' && parts.length === 3 && parts[2] === 'supersede') {
        const review = store.supersede(parts[1], body.reason);
        return respond(200, { ok: true, review_id: review.review_id, status: review.status });
      }
      fail('route_not_found', 404);
    } catch (error) { respond(error.status || 500, { ok: false, code: error.code || 'internal_error' }); }
  });
  server.requestTimeout = 10000; server.headersTimeout = 10000;
  return server;
}
async function main() {
  const config = loadConfig();
  fs.mkdirSync(path.dirname(config.stateFile), { recursive: true });
  const lockFile = config.stateFile + '.lock';
  if (fs.existsSync(lockFile)) {
    const owner = Number(fs.readFileSync(lockFile, 'utf8'));
    if (!Number.isInteger(owner) || owner < 1) fail('lark_lock_invalid');
    try { process.kill(owner, 0); fail('lark_review_already_running'); }
    catch (error) { if (error.code !== 'ESRCH') throw error; }
    fs.unlinkSync(lockFile);
  }
  const lock = fs.openSync(lockFile, 'wx'); fs.writeFileSync(lock, String(process.pid));
  const stopFile = config.stateFile + '.stop.request';
  if (fs.existsSync(stopFile)) fs.unlinkSync(stopFile);
  const store = new ReviewStore(config);
  const batch = new BatchStore(store);
  // SDK payloads/errors can include credentials; log only stable status codes.
  const logger = Object.fromEntries(['trace', 'debug', 'info', 'warn', 'error', 'fatal'].map(level => [level, () => { if (level === 'error' || level === 'fatal') console.error('lark_transport_error'); }]));
  lark.defaultHttpInstance.defaults.timeout = 20000;
  const base = { appId: config.appId, appSecret: config.appSecret, domain: lark.Domain.Lark, appType: lark.AppType.SelfBuild, logger };
  const client = new lark.Client(base);
  const checked = (result, operation) => {
    if (result?.code !== 0) {
      const message = String(result?.msg || '').replace(/((?:app_secret|access_token|authorization)\s*[:=]\s*)[^\s,;]+/ig, '$1[redacted]').slice(0, 1500);
      fs.writeFileSync(path.join(path.dirname(config.stateFile), 'last-provider-error.private.json'), JSON.stringify({ operation, code: result?.code, message, at: new Date().toISOString() }, null, 2), { mode: 0o600 });
      fail('lark_api_failed', 502);
    }
    return result.data;
  };
  const transport = {
    upload: async bytes => uploadedImageKey(await client.im.image.create({ data: { image_type: 'message', image: bytes } })),
    send: async (chatId, type, content, uuid) => checked(await client.im.message.create({ params: { receive_id_type: 'chat_id' }, data: { receive_id: chatId, msg_type: type, content: JSON.stringify(content), uuid } }), 'send_' + type).message_id,
    update:async(message_id,card)=>checked(await client.im.message.patch({path:{message_id},data:{content:JSON.stringify(card)}}),'update_card')
  };
  const download = async (messageId, fileKey) => {
    const resource = await client.im.messageResource.get({ path: { message_id: messageId, file_key: fileKey }, params: { type: 'file' } });
    if (resource?.code !== undefined && resource.code !== 0) fail('lark_file_resource_failed', 502);
    if (typeof resource?.getReadableStream !== 'function' || /application\/json/i.test(resource.headers?.['content-type'] || '')) fail('lark_file_resource_failed', 502);
    const stream = resource.getReadableStream(), chunks = []; let count = 0;
    try { for await (const chunk of stream) { count += chunk.length; if (count > MAX_BYTES) fail('batch_txt_too_large'); chunks.push(Buffer.from(chunk)); } }
    finally { stream.destroy(); }
    return Buffer.concat(chunks);
  };
  let sends = Promise.resolve(), flushing = false;
  const deliver = id => { sends = sends.catch(() => {}).then(() => store.deliver(id, transport)).catch(error => console.error(error.code || 'review_delivery_failed')); };
  const notify = () => { sends = sends.catch(() => {}).then(async () => { await store.deliverWorkerStatus(transport); await store.deliverCardUpdates(transport); await batch.deliver(transport); }).catch(() => console.error('worker_status_delivery_failed')); };
  const forward = async body => {
    const response = await fetch(body.event_type === 'batch_command' ? config.batchWebhookUrl : config.n8nWebhookUrl, { method: 'POST', headers: { 'content-type': 'application/json', [config.n8nTokenHeader]: config.n8nToken }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000), redirect: 'error' });
    if (response.status === 409) { const data = await response.json(); if (data.code === 'stale_review') fail('stale_review', 409); }
    if (!response.ok) fail('n8n_http_' + response.status, 502);
    return response.json();
  };
  const flush = async () => { if (flushing) return; flushing = true; try { await batch.downloadFiles(download); await store.flush(forward); await batch.flush(forward); notify(); } finally { flushing = false; } };
  const dispatcher = new lark.EventDispatcher({ logger }).register({
    'im.message.receive_v1': data => {
      // Persist before returning; n8n work runs outside the 3-second WS acknowledgement.
      const incoming = batch.receive(data);
      const result = incoming.handled ? incoming : store.receive(data);
      if (result.ok || incoming.handled) setImmediate(() => { notify(); flush().catch(() => console.error('decision_delivery_failed')); });
      return {};
    },
    'card.action.trigger': data => {
      try {
        const e=interaction(data,config);
        const result=e.value.scope==='review'?store.receiveCard(data):batch.receiveCard(data);
        setImmediate(()=>{notify();flush().catch(()=>console.error('card_delivery_failed'));});
        return result;
      } catch { return ack('Chỉ tài khoản đã ghép trong đúng hội thoại mới dùng được nút.','error'); }
    }
  });
  const ws = new lark.WSClient(base);
  const server = makeServer(config, store, deliver, () => ws.getConnectionStatus().state, notify, batch);
  server.on('error', () => { console.error('local_service_failed'); cleanup(); process.exit(1); });
  let interval, closed = false;
  const stopWatch = fs.watch(path.dirname(config.stateFile), () => {
    if (fs.existsSync(stopFile)) { cleanup(); process.exit(0); }
  });
  const cleanup = () => { if (closed) return; closed = true; clearInterval(interval); stopWatch.close(); server.close(); ws.close({ force: true }); fs.closeSync(lock); fs.unlinkSync(lockFile); };
  process.once('SIGINT', () => { cleanup(); process.exit(0); });
  process.once('SIGTERM', () => { cleanup(); process.exit(0); });
  server.listen(config.port, '127.0.0.1', () => console.log('lark_review_listening_on_loopback:' + config.port));
  try { await ws.start({ eventDispatcher: dispatcher }); } catch (error) { cleanup(); throw error; }
  Object.values(store.state.reviews).filter(x => x.status === 'sending').forEach(x => deliver(x.review_id));
  batch.menu('controls-20261016-buttons1');notify();
  interval = setInterval(() => { Object.values(store.state.reviews).filter(x => x.status === 'sending').forEach(x => deliver(x.review_id)); notify(); flush().catch(() => console.error('decision_delivery_failed')); }, 15000);
  await flush();
}
if (require.main === module) main().catch(error => { console.error(error.code || 'lark_review_start_failed'); process.exitCode = 1; });
module.exports = { loadConfig, makeServer, authorized, uploadedImageKey };
