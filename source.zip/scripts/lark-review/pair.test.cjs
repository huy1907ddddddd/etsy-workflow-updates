'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pairingSession } = require('./pair.cjs');
function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lark-pair-fixture-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const file = path.join(root, 'config.private.json');
  const config = { appId: 'fake-app', appSecret: 'fake-private-fixture', chatId: '', humanOpenId: '', localToken: 'fake-token-kept', n8nToken: 'other-fake-token-kept' };
  fs.writeFileSync(file, JSON.stringify(config));
  let time = 1760000000000;
  const session = pairingSession(file, 'FIXTURE1234567890', () => time);
  const event = { message: { message_id: 'om_human', chat_id: 'oc_human', chat_type: 'p2p', message_type: 'text', content: JSON.stringify({ text: session.command }) }, sender: { sender_type: 'user', sender_id: { open_id: 'ou_human' } } };
  return { file, config, session, event, advance: ms => time += ms };
}
test('pair only exact one-time nonce from user p2p; preserves private fields', t => {
  const f = fixture(t);
  const wrong = structuredClone(f.event); wrong.message.content = JSON.stringify({ text: 'hello' });
  assert.equal(f.session.receive(wrong), false);
  assert.equal(fs.readFileSync(f.file, 'utf8'), JSON.stringify(f.config));
  for (const [section, field, value] of [['message', 'chat_type', 'group'], ['message', 'message_type', 'image'], ['sender', 'sender_type', 'app']]) {
    const invalid = structuredClone(f.event); invalid[section][field] = value; assert.equal(f.session.receive(invalid), false);
  }
  assert.equal(f.session.receive(f.event), true);
  const saved = JSON.parse(fs.readFileSync(f.file));
  assert.equal(saved.chatId, 'oc_human'); assert.equal(saved.humanOpenId, 'ou_human');
  assert.equal(saved.appSecret, f.config.appSecret); assert.equal(saved.localToken, f.config.localToken); assert.equal(saved.n8nToken, f.config.n8nToken);
  assert.equal(f.session.receive(f.event), false);
  assert.throws(() => pairingSession(f.file), /pairing_already_configured/);
});
test('expired nonce and concurrently changed config cannot enroll', t => {
  const f = fixture(t); f.advance(600001);
  assert.equal(f.session.receive(f.event), false);
  const another = pairingSession(f.file, 'FIXTURE1234567890');
  fs.writeFileSync(f.file, JSON.stringify({ ...f.config, chatId: 'already-owned' }));
  assert.throws(() => another.receive(f.event), /pairing_configuration_changed/);
});
