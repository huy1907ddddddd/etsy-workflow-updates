'use strict';
const { randomUUID } = require('node:crypto');
const { hash, fail } = require('./review.cjs');
const { interaction, ack, batchCard, menuActions, batchActions } = require('./cards.cjs');
const v3 = require('./workflow3.cjs');
const KINDS = { 'BRIEF': 'embroidery_brief', 'PROMPT 2D': 'embroidery_prompts', 'ÁO 2D': 'apparel_2d', 'AO 2D': 'apparel_2d', 'PIJAMA':'pajama_set', 'BỘ PIJAMA':'pajama_set', 'BO PIJAMA':'pajama_set', 'QUẦN NGỦ':'sleep_pants', 'QUAN NGU':'sleep_pants' };
const MAX_BYTES = 1024 * 1024;
const HELP = 'Nạp mẻ vào Bún Bò Huế:\nMẺ BRIEF: tên mẻ\nMẺ PROMPT 2D: tên mẻ\nMẺ ÁO 2D: tên mẻ\nSau đó dán nội dung hoặc gửi file .txt UTF-8. Ngăn từng mẫu bằng một dòng ---. Thêm MÃ: UST_261015_01_TQH đầu mỗi mẫu để giữ nguyên mã khi xuất file, Docs và KPI; TÊN: là tùy chọn. Cách TÊN: UST_261015_01_TQH | tên mẫu cũng được nhận. Mã phải khác nhau và đúng dạng CHỦĐỀ_YYMMDD_NN_TQH. Mẻ brief và prompt design cần NGỰC: và TAY: trong mỗi mẫu.\nBot tóm tắt mã rồi bạn gửi XÁC NHẬN <mã mẻ> để đưa vào hàng chờ. Chưa tự chạy.\nHÀNG CHỜ để xem; BẮT ĐẦU <mã mẻ> để chọn chạy; THỨ TỰ <mã mẻ 1>, <mã mẻ 2> để đổi thứ tự; HỦY NHẬP để thoát.\nÁo 2D: chỉ sweater, tạo mockup trực tiếp, không thông số hình. Áo thêu: duyệt mẫu đầu ở 2D → thêu →mockup; áo 2D: duyệt một mockup mẫu đầu. Duyệt mẫu đầu cho phép tự hoàn thiện phần còn lại của đúng mẻ.';
const LISTING_CODE = /^[A-Z]{2,5}_\d{6}_\d{2}_TQH$/;
function validListingCode(value) {
  if (!LISTING_CODE.test(value)) return false;
  const date=value.split('_')[1],year=2000+Number(date.slice(0,2)),month=Number(date.slice(2,4)),day=Number(date.slice(4,6));
  const actual=new Date(Date.UTC(year,month-1,day));
  return actual.getUTCFullYear()===year&&actual.getUTCMonth()===month-1&&actual.getUTCDate()===day;
}
function parseItems(kind, source, positions) {
  if (!(Object.values(KINDS).includes(kind)||kind==='pajama_top') || typeof source !== 'string' || Buffer.byteLength(source) > MAX_BYTES || source.includes('\0')) fail('batch_content_invalid');
  const text = source.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').trim();
  if (!text) fail('batch_content_empty');
  const blocks = text.split(/^\s*---\s*$/m);
  if (blocks.some(x => !x.trim()) || blocks.length > 100) fail('batch_items_limit_or_empty');
  const codes=new Set();
  return blocks.map((block, i) => {
    let content = block.trim(), title = `Mẫu ${i + 1}`, listingCode, named=false, codeLabeled=false;
    const bind=value=>{if(!validListingCode(value))fail('batch_listing_code_invalid_'+(i+1));if(listingCode&&listingCode!==value)fail('batch_listing_code_conflict_'+(i+1));listingCode=value;};
    let heading;
    while((heading=/^(TÊN|TEN|TITLE|MÃ|MA|CODE|ID)\s*:\s*([^\n]*)(?:\n|$)/iu.exec(content))){
      const value=heading[2].trim();content=content.slice(heading[0].length).trim();
      if(/^(MÃ|MA|CODE|ID)$/iu.test(heading[1])){if(codeLabeled)fail('batch_listing_code_duplicate_'+(i+1));codeLabeled=true;bind(value);}
      else{
        if(named||!value||value.length>120)fail('batch_item_title_invalid_'+(i+1));named=true;title=value;
        const coded=/^([^\s|]+)(?:\s*\|\s*(.*))?$/.exec(value);
        if(coded&&/^[A-Za-z]{2,5}_/.test(coded[1])){bind(coded[1]);title=coded[2]?.trim()||coded[1];}
      }
    }
    if(!listingCode){const first=/^([^\n]+)\n/.exec(content);if(first&&/^[A-Za-z]{2,5}_/.test(first[1])){bind(first[1].trim());content=content.slice(first[0].length).trim();}}
    if(listingCode&&codes.has(listingCode))fail('batch_listing_code_duplicate_'+(i+1));
    if(listingCode)codes.add(listingCode);
    const identity=listingCode?{listing_code:listingCode,item_id:listingCode,topic_code:listingCode.split('_')[0]}:{};
    if (!content || content.length > 65000) fail('batch_item_invalid_' + (i + 1));
    if (kind === 'embroidery_brief') return { title, ...identity, brief: content };
    if (['apparel_2d','pajama_top','pajama_set','sleep_pants'].includes(kind)) return { title, ...identity, idea_prompt: content };
    if (kind === 'embroidery_prompts' && positions) return {title,...identity,designs:v3.parseDesigns(content,positions)};
    const fields = [...content.matchAll(/^(NGỰC|NGUC|CHEST|TAY|SLEEVE)\s*:\s*/gimu)];
    if (fields.length !== 2 || fields[0].index !== 0) fail('batch_chest_and_sleeve_required_' + (i + 1));
    const values = {};
    fields.forEach((m, n) => {
      const field = /^(TAY|SLEEVE)$/iu.test(m[1]) ? 'sleeve_prompt' : 'chest_prompt';
      if (values[field]) fail('batch_prompt_field_duplicate_' + (i + 1));
      values[field] = content.slice(m.index + m[0].length, fields[n + 1]?.index ?? content.length).trim();
      if (!values[field] || values[field].length > 30000) fail('batch_prompt_empty_or_long_' + (i + 1));
    });
    if (!values.chest_prompt || !values.sleeve_prompt) fail('batch_chest_and_sleeve_required_' + (i + 1));
    return { title, ...identity, chest_region: 'center_chest', ...values };
  });
}
function parseCommand(text) {
  let m = /^(?:MẺ|ME)\s+(BRIEF|PROMPT 2D|ÁO 2D|AO 2D|BỘ PIJAMA|BO PIJAMA|PIJAMA|QUẦN NGỦ|QUAN NGU)(?:\s*:\s*([^\n]{1,120}))?$/iu.exec(text);
  if (m) return { type: 'mode', kind: KINDS[m[1].toUpperCase()], name: m[2]?.trim() || 'Mẻ mới' };
  if (/^(HƯỚNG DẪN|HUONG DAN|HELP|MENU|MẺ|ME)$/iu.test(text)) return { type: 'help' };
  if (/^(HỦY NHẬP|HUY NHAP)$/iu.test(text)) return { type: 'cancel' };
  if (/^(HÀNG CHỜ|HANG CHO)$/iu.test(text)) return { type: 'native', command: { action: 'batch_status' } };
  m=/^(CHUẨN BỊ|CHUAN BI|DUYỆT BỘ|DUYET BO|CHẠY ĐÊM|CHAY DEM)\s+([A-Za-z0-9_,\s-]+)$/iu.exec(text);
  if(m){const ids=m[2].split(/[\s,]+/).filter(Boolean);if(!ids.length||new Set(ids).size!==ids.length)fail('batch_plan_ids_invalid');return {type:'native',command:{action:/^(CHUẨN BỊ|CHUAN BI)$/iu.test(m[1])?'batch_prepare_reviews':/^(DUYỆT BỘ|DUYET BO)$/iu.test(m[1])?'batch_review_bundle':'batch_run_plan',batch_ids:ids}};}
  if (/^(NGHIỆM THU WORKFLOW|NGHIEM THU WORKFLOW)$/iu.test(text)) return { type: 'native', command: { action: 'batch_accept_workflow', workflow_accepted_by_user: true } };
  m = /^(?:XÁC NHẬN|XAC NHAN)\s+([A-Za-z0-9_-]{1,100})$/iu.exec(text);
  if (m) return { type: 'native', command: { action: 'batch_confirm', batch_id: m[1] } };
  m = /^(?:BẮT ĐẦU|BAT DAU|DỪNG|DUNG)\s+([A-Za-z0-9_-]{1,100})$/iu.exec(text);
  if (m) return { type: 'native', command: { action: /^(?:BẮT ĐẦU|BAT DAU)/iu.test(text) ? 'batch_start' : 'batch_stop', batch_id: m[1] } };
  m = /^(?:THỬ LẠI|THU LAI)\s+([A-Za-z0-9_-]{1,100})\s+([A-Za-z0-9_-]{1,100})$/iu.exec(text);
  if (m) return { type: 'native', command: { action: 'batch_retry', batch_id: m[1], item_id: m[2] } };
  m = /^(?:THỨ TỰ|THU TU)\s+([A-Za-z0-9_,\s-]+)$/iu.exec(text);
  if (m) { const ids = m[1].split(/[\s,]+/).filter(Boolean); if (!ids.length || ids.length > 100 || new Set(ids).size !== ids.length || ids.some(id => !/^[A-Za-z0-9_-]{1,100}$/.test(id))) fail('batch_order_invalid'); return { type: 'native', command: { action: 'batch_reorder', batch_ids: ids } }; }
  return null;
}
const errorText = code => `Chưa thực hiện yêu cầu (${code}). ${String(code).startsWith('batch_listing_code_')?'Mỗi mã phải khác nhau, có ngày hợp lệ và đúng dạng UST_261015_01_TQH. Đặt dòng MÃ: trước prompt. ':''}Hãy kiểm tra nội dung; gửi HƯỚNG DẪN để xem mẫu. Mẻ chưa được khởi chạy.`;
function renderResult(command, result) {
  const data = result.result || result;
  const batch = data.batch || data;
  if (command.action === 'batch_status') {
    const list = (data.batches || data.queue || []).filter(b=>!['completed','closed_partial','cancelled'].includes(b.status));
    return v3.dashboard(data)+`Hàng chờ (${list.length} mẻ):\n${list.map((b, i) => `${i + 1}. ${b.batch_id} · ${b.name || b.kind || ''} · ${b.status || b.state || 'queued'} · ${b.completed_count ?? b.completed ?? b.items?.filter(x => x.state === 'completed').length ?? 0}/${b.item_count ?? b.total ?? b.items?.length ?? '?'}${b.items?.filter(x => x.error).map(x => `\n   ${x.item_id}: ${x.state} · ${x.error}`).join('') || ''}`).join('\n') || 'Chưa có mẻ.'}\nChạy riêng: bấm Bắt đầu ở đúng mẻ. Chạy nhiều: chọn các mẻ theo thứ tự, bấm Chạy tất cả các mẻ đã chọn. Duyệt từng mẻ; khi tất cả đã duyệt mới chạy lần lượt.`;
  }
  const id = batch.batch_id || data.batch_id || command.batch_id || '';
  if(command.action==='batch_run_selected')return `Đã chọn chạy nhóm theo thứ tự: ${(data.batch_ids||[]).join(' → ')}.\nBot sẽ tạo và gửi mẫu đại diện riêng cho từng mẻ. Bạn duyệt từng mẻ; mẻ đã duyệt đứng chờ. Nếu cần sửa, chỉ tạo lại mẻ đó và áp nhận xét cho cả mẻ đó. Khi tất cả đã duyệt, các mẻ tự chạy lần lượt; không cần bấm thêm bước nào.`;
  if(command.action==='batch_review_bundle'&&data.status==='batch_reviews_not_ready')return `Chưa có ảnh đại diện sẵn sàng để duyệt.\nMẻ đã chọn: ${(data.batch_ids||[]).join(' → ')}\n${data.next_action==='batch_prepare_reviews'?'Các mẻ đang được lưu, chưa tạo mẫu. Bấm “Chuẩn bị mẫu các mẻ đã chọn” để tạo ảnh đại diện; có ảnh rồi mới mở duyệt bộ.':'Bấm “Xem tiến độ” để kiểm tra bước hiện tại. Nếu ảnh đang được tạo, chờ ảnh sẵn sàng rồi mở duyệt bộ.'}\nNội dung và mã đã được nhận đúng; không cần gửi lại prompt. Chưa có ảnh nào được duyệt.`;
  if(command.action==='batch_review_bundle')return `BỘ ẢNH CẦN DUYỆT · ${data.stage}\nMẻ: ${(data.batch_ids||[]).join(' → ')}\nChỉ nút duyệt bên dưới mới duyệt các ảnh đang hiển thị; các mẻ/bước khác giữ nguyên.`;
  if(command.action==='batch_prepare_reviews')return `Đã chọn chuẩn bị mẫu đại diện: ${(data.batch_ids||[]).join(' → ')}. Chưa giao chạy toàn bộ mẻ. Mở menu và chọn Xem và duyệt bộ ảnh nhiều mẻ khi ảnh sẵn sàng.`;
  if(command.action==='batch_run_plan')return `Đã giao danh sách chạy: ${(data.batch_ids||[]).join(' → ')}. Hết danh sách sẽ chờ; không chạy mẻ ngoài danh sách.`;
  if(command.action==='batch_approve_bundle')return `Đã duyệt đúng các bộ ảnh đã hiển thị: ${(data.batch_ids||[]).join(', ')}. Bước tiếp theo sẽ dùng đúng phiên bản này.`;
  if(command.action==='batch_discard_remaining')return `Đã hủy ${data.cancelled_items} mẫu chưa hoàn tất trong mẻ ${id}. Phần đã làm, ảnh, Docs và KPI được giữ; không tự chạy mẻ khác.`;
  if (command.action === 'batch_submit') return `Bản nháp ${id}\n${command.name} · ${command.items.length} mẫu · ${command.kind}\n${command.items.slice(0, 30).map((x, i) => `${i + 1}. ${x.listing_code ? x.listing_code+' | ' : '[chưa gửi mã — hệ thống sẽ cấp] '}${x.title}`).join('\n')}${command.items.length > 30 ? '\n... và ' + (command.items.length - 30) + ' mẫu.' : ''}\nMã bạn gửi được giữ nguyên ở file, Docs và KPI; ngày KPI tính riêng.\n${command.embroidery_mode==='prompt_to_mockup' ? 'Prompt → mockup áo thêu trực tiếp; không tạo ảnh 2D hoặc ảnh thêu riêng. Chọn vị trí như cũ, duyệt mockup mẫu trước; các góc còn lại theo mẫu đã duyệt.' : ['apparel_2d','pajama_top','pajama_set','sleep_pants'].includes(command.kind) ? 'Duyệt một mockup mẫu đầu; bộ 5 ảnh giữ cùng sản phẩm và màu, không thông số hình.' : 'Duyệt mẫu đầu ở ba bước: 2D → thêu → mockup.'}\nDuyệt mockup mẫu đầu cho phép tự hoàn thiện phần còn lại của đúng mẻ.\nGửi XÁC NHẬN ${id} để đưa vào hàng chờ. Chưa chạy hoặc duyệt ảnh.`;
  if (command.action === 'batch_confirm') return `Đã đưa mẻ vào hàng chờ: ${id}\nChưa tự chạy. Gửi BẮT ĐẦU ${id} để chọn bắt đầu, hoặc HÀNG CHỜ để xem các mẻ.`;
  if (command.action === 'batch_accept_workflow') return 'Đã ghi nhận nghiệm thu workflow và bật KPI. Hàng chờ tiếp tục cấp mã, xử lý, xuất listing và đồng bộ bảng KPI. Các mẻ sau không cần bật lại.';
  if(['batch_start','batch_confirm_start'].includes(command.action))return `Đã xác nhận chạy mẻ ${id}.\nMẻ đã vào hàng chờ. Bot sẽ gửi ảnh và nút duyệt khi đến bước cần bạn xem.`;
  if(command.action==='batch_stop')return `Đã tạm dừng mẻ ${id}. Ảnh, lịch sử duyệt và checkpoint được giữ để tiếp tục.`;
  if(command.action==='batch_retry')return `Đã yêu cầu tiếp tục mẫu ${command.item_id} của mẻ ${id}, giữ phiên bản và tài sản đã có.`;
  return `n8n đã nhận ${command.action} ${id}\nTrạng thái: ${batch.status || batch.state || data.status || 'đã xử lý'}.`;
}
class BatchStore {
  constructor(reviewStore) {
    this.owner = reviewStore; this.config = reviewStore.config; this.clock = reviewStore.clock;
    reviewStore.state.batch ||= { schema_version: 1, session: null, manifests: {}, seen: {}, inbox: {}, outbox: {}, notifications: {} };
    this.state = reviewStore.state.batch;
    this.state.manifests ||= {};
    this.state.events ||= {};
    if (this.state.schema_version !== 1) fail('batch_state_schema_invalid');
  }
  save() { this.owner.save(); }
  notify(key, text, actions) {
    if (!this.state.notifications[key]) this.state.notifications[key] = { uuid: randomUUID(), text, ...(actions?{actions,expires_at:this.clock()+24*3600000,bindings:Object.fromEntries(Object.values(actions).filter(a=>a.command?.batch_id).map(a=>[a.command.batch_id,this.state.manifests[a.command.batch_id]?.version||0]))}:{}), status: 'pending', attempts: 0, next_attempt: 0 };
  }
  menu(key='controls-v1'){this.notify(key,'Chọn loại mẻ, sau đó dán nội dung hoặc gửi TXT UTF-8. Bot sẽ cho bạn kiểm tra danh sách trước khi chạy.',menuActions());this.save();}
  envelope(event, command) {
    const source=this.config.transport==='web'?'Web':this.config.transport==='telegram'?'Telegram':'Lark';
    return { schema_version: 1, event_type: 'batch_command', event_id: event.event_id, message_id: event.message_id, ...(this.config.transport?{transport:this.config.transport}:{}), ...(event.interaction_type?{interaction_type:event.interaction_type}:{}), sender_open_id: this.config.humanOpenId, chat_id: this.config.chatId, authority: 'direct_user', reference: event.interaction_type==='card_action'?`${source} card action ${event.event_id}; message ${event.message_id}; direct user: ${event.label}`:`${source} message ${event.message_id}; explicit batch command`, received_at: new Date(this.clock()).toISOString(), command };
  }
  queue(event, command) {
    if (Object.values(this.state.outbox).some(x => x.body.event_id === event.event_id && x.body.message_id !== event.message_id)) fail('batch_event_id_conflict');
    if (['batch_confirm', 'batch_confirm_start', 'batch_start', 'batch_stop', 'batch_retry'].includes(command.action)) {
      const manifest = this.state.manifests[command.batch_id];
      if (!manifest || !/^[a-f0-9]{64}$/.test(manifest.batch_fingerprint || '')) fail('batch_manifest_not_loaded');
      if(command.batch_fingerprint&&command.batch_fingerprint!==manifest.batch_fingerprint)fail('batch_card_expired');
      command.batch_fingerprint = manifest.batch_fingerprint;
    }
    this.state.outbox[event.message_id] = { body: this.envelope(event, command), status: 'pending', attempts: 0, next_attempt: 0 };
    return { ok: true, handled: true, status: 'queued_for_n8n' };
  }
  receiveCard(data){
    try{
      const e=interaction(data,this.config),v=e.value;
      this.state.card_seen||={};if(this.state.card_seen[e.event_id])return this.state.card_seen[e.event_id];
      const n=Object.values(this.state.notifications).find(n=>n.uuid===v.card_id);
      const a=n?.actions?.[v.action];
      if(v.scope!=='batch'||!n||n.message_id!==e.message_id||n.status!=='delivered'||!a)return ack('Nút không thuộc thẻ này.','error');
      if(n.consumed||this.clock()>n.expires_at||Object.entries(n.bindings||{}).some(([bid,version])=>(this.state.manifests[bid]?.version||0)!==version))return ack('Thẻ đã hết hiệu lực; hãy mở Hàng chờ để lấy trạng thái mới.','error');
      let message;
      if(a.menu){this.queue({...e,interaction_type:'card_action',label:a.label},{action:'batch_status'});message='Đang lấy bảng điều khiển từ n8n.';}
      else if(a.selectPositions){this.state.session={type:'positions',kind:'embroidery_prompts',profile_version:3,name:'Mẻ áo thêu',positions:{chest:'none',sleeves:false,back:false},expires_at:this.clock()+24*3600000};message='Chọn một phương án ngực hoặc bỏ trống; tick thêm hai tay/lưng.';this.notify('positions:'+e.event_id,message,v3.selectionActions(this.state.session.positions));}
      else if(a.position||a.togglePosition||a.finishPositions){
        const s=this.state.session;if(!s||s.type!=='positions')fail('batch_positions_session_expired');
        if(a.position)s.positions={...s.positions,...a.position};if(a.togglePosition)s.positions[a.togglePosition]=!s.positions[a.togglePosition];
        if(a.finishPositions){const keys=v3.regions(s.positions);if(!keys.length)fail('batch_position_required');s.type='mode';message='Mỗi mẫu cần đúng '+keys.length+' design, dùng các nhãn: '+keys.map(k=>v3.labels[k]+':').join(' ')+'. Gửi nội dung hoặc TXT, ngăn các mẫu bằng dòng ---.';this.notify('positions:'+e.event_id,message,menuActions());}
        else{message='Chọn vị trí thêu; trái + phải là hai design riêng.';this.notify('positions:'+e.event_id,message,v3.selectionActions(s.positions));}
      }
      else if(a.toggleBatch){this.state.selected_batches||=[];const ids=this.state.selected_batches;this.state.selected_batches=ids.includes(a.toggleBatch)?ids.filter(id=>id!==a.toggleBatch):[...ids,a.toggleBatch];this.queue({...e,interaction_type:'card_action',label:a.label},{action:'batch_status'});message='Đã cập nhật danh sách mẻ được chọn.';}
      else if(a.selectedCommand){const ids=this.state.selected_batches||[];if(!ids.length)fail('batch_plan_select_batches');if(a.selectedCommand!=='batch_run_selected'){this.queue({...e,interaction_type:'card_action',label:a.label},{action:'batch_status'});message='Đã đổi sang một nút chạy nhóm. Đang mở bảng điều khiển mới để bạn bấm Chạy tất cả các mẻ đã chọn.';}else{this.queue({...e,interaction_type:'card_action',label:a.label},{action:a.selectedCommand,batch_ids:[...ids]});message='Đã gửi danh sách đã chọn cho n8n.';}}
      else if(a.mode){
        this.state.session={type:'mode',kind:a.mode,profile_version:3,name:'Mẻ mới',expires_at:this.clock()+24*3600000};
        message=`Đã chọn ${a.label}. Gửi nội dung hoặc TXT UTF-8; ngăn mỗi mẫu bằng dòng ---. Thêm MÃ: UST_261015_01_TQH đầu mỗi mẫu để giữ nguyên mã đầu ra.${a.mode==='embroidery_prompts'?' Mỗi mẫu có NGỰC: và TAY:.':''} Chưa khởi chạy mẻ.`;
        this.notify('card:'+e.event_id,message,menuActions());
      }else if(a.cancel){this.state.session=null;message='Đã hủy nhập. Các mẻ đã xác nhận vẫn giữ nguyên.';this.notify('card:'+e.event_id,message,menuActions());}
      else if(a.command){this.queue({...e,interaction_type:'card_action',label:a.label},structuredClone(a.command));message='Đã nhận: '+a.label+'. Đang chờ n8n xác nhận.';}
      else return ack('Nút không hợp lệ.','error');
      n.consumed=true;
      const response=ack(message,'success',batchCard({...n,text:message,actions:{}}));
      this.state.card_seen[e.event_id]=response;this.save();return response;
    }catch{return ack('Không nhận nút này: sai tài khoản, thẻ cũ hoặc sự kiện không hợp lệ.','error');}
  }
  stage(event, source) {
    const session = event.session || this.state.session;
    if (!session || session.expires_at < this.clock()) fail('batch_mode_required');
    if(session.embroidery_mode!==undefined&&(session.kind!=='embroidery_prompts'||!['artwork_stages','prompt_to_mockup'].includes(session.embroidery_mode)))fail('embroidery_mode_invalid');
    const items = parseItems(session.kind, source, session.positions);
    const id = 'batch-' + hash(JSON.stringify({ mid: event.message_id, session, items })).slice(0, 16);
    this.queue(event, { action: 'batch_submit', batch_id: id, kind: session.kind, name: session.name, items, ...(session.embroidery_mode==='prompt_to_mockup'?{embroidery_mode:'prompt_to_mockup'}:{}), ...(session.reference_image?{reference_image:session.reference_image}:{}), ...(session.mockup_prompt_set?{mockup_prompt_set:session.mockup_prompt_set}:{}), ...(session.profile_version===3?{profile_version:3,...(session.positions?{positions:session.positions}:{})}:{}) });
    if (JSON.stringify(this.state.session) === JSON.stringify(session)) this.state.session = null;
    return { ok: true, handled: true, status: 'draft_submitted_for_n8n', batch_id: id };
  }
  receive(event) {
    const e = event.event || event, message = e.message || {}, sender = e.sender || {};
    const mid = message.message_id, eid = event.header?.event_id || e.event_id || mid;
    if (!mid || !eid || sender.sender_type !== 'user' || sender.sender_id?.open_id !== this.config.humanOpenId || message.chat_id !== this.config.chatId) return { ok: false, handled: false, code: 'sender_or_chat_not_authorized' };
    if (typeof mid !== 'string' || typeof eid !== 'string' || !/^[A-Za-z0-9_-]{1,200}$/.test(mid) || !/^[A-Za-z0-9_-]{1,200}$/.test(eid)) return { ok: false, handled: true, code: 'batch_event_binding_invalid' };
    if (this.state.seen[mid]) return { ...this.state.seen[mid], duplicate: true };
    if (this.state.events[eid] && this.state.events[eid] !== mid) return { ok: false, handled: true, code: 'batch_event_id_conflict' };
    const bound = { message_id: mid, event_id: eid };
    let result;
    try {
      let content; try { content = JSON.parse(message.content); } catch { fail('batch_message_invalid'); }
      if (message.message_type === 'file') {
        if (!this.state.session) return { ok: false, handled: false };
        if (typeof content.file_name !== 'string' || !/\.txt$/i.test(content.file_name) || !/^file_[A-Za-z0-9_-]{1,250}$/.test(content.file_key || '')) fail('batch_utf8_txt_required');
        this.state.inbox[mid] = { ...bound, file_key: content.file_key, file_name: content.file_name, session: structuredClone(this.state.session), status: 'pending', attempts: 0, next_attempt: 0 };
        this.notify(mid + ':received', 'Đã nhận file TXT, đang kiểm tra nội dung. Chưa khởi chạy mẻ.');
        result = { ok: true, handled: true, status: 'file_download_pending' };
      } else if (message.message_type === 'text') {
        const text = typeof content.text === 'string' ? content.text.replace(/@_user_\d+/g, '').trim() : '';
        // Review decisions always go to the review binding validator, even during intake.
        if (/^(DUYỆT|APPROVE|SỬA|REVISE|TỪ CHỐI|REJECT)(?:\s|:|$)/iu.test(text)) return { ok: false, handled: false };
        const command = parseCommand(text);
        if (!command && !this.state.session) return { ok: false, handled: false };
        if (command?.type === 'help') { result=this.queue(bound,{action:'batch_status'}); }
        else if (command?.type === 'mode') { this.state.session = { ...command, expires_at: this.clock() + 24 * 3600000 }; this.notify(mid, `Đã chọn ${command.kind} · ${command.name}. Dán nội dung hoặc gửi TXT UTF-8, ngăn mỗi mẫu bằng dòng ---.${command.kind === 'embroidery_prompts' ? '\nMỗi mẫu phải có NGỰC: <prompt> và TAY: <prompt>.' : ''}\nChưa chạy; bot sẽ yêu cầu xác nhận số mẫu. HỦY NHẬP để thoát.`); result = { ok: true, handled: true }; }
        else if (command?.type === 'cancel') { this.state.session = null; this.notify(mid, 'Đã thoát nhập mẻ. Các mẻ đã xác nhận vẫn giữ nguyên.'); result = { ok: true, handled: true }; }
        else if (command?.type === 'native') result = this.queue(bound, command.command);
        else result = this.stage(bound, text);
      } else return { ok: false, handled: false };
    } catch (error) { result = { ok: false, handled: true, code: error.code || 'batch_input_invalid' }; this.notify(mid + ':error', errorText(result.code)); }
    this.state.seen[mid] = result; this.state.events[eid] = mid; this.save(); return result;
  }
  async downloadFiles(download) {
    for (const item of Object.values(this.state.inbox)) {
      if (item.status !== 'pending' || item.next_attempt > this.clock()) continue;
      item.attempts++; this.save();
      try {
        const bytes = await download(item.message_id, item.file_key);
        if (!Buffer.isBuffer(bytes) || bytes.length > MAX_BYTES) fail('batch_txt_too_large');
        let source; try { source = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch { fail('batch_txt_utf8_required'); }
        this.stage(item, source); item.status = 'staged'; this.save();
      } catch (error) {
        item.last_error = error.code || 'batch_file_download_failed';
        if (item.last_error.startsWith('batch_') && item.last_error !== 'batch_file_download_failed') item.status = 'rejected';
        else item.next_attempt = this.clock() + Math.min(300000, 5000 * 2 ** Math.min(item.attempts, 6));
        this.notify(item.message_id + ':error:' + item.last_error, errorText(item.last_error) + (item.status === 'pending' ? '\nBot sẽ thử tải file lại. Nếu quyền tải tài nguyên chưa được cấp, cần quản trị duyệt quyền trước.' : ''));
        this.save();
      }
    }
  }
  async flush(forward) {
    for (const entry of Object.values(this.state.outbox)) {
      if (entry.status !== 'pending' || entry.next_attempt > this.clock()) continue;
      entry.attempts++; this.save();
      try {
        const reply = await forward(entry.body);
        if (reply.ok === true && reply.accepted === false && reply.retryable === false) {
          entry.status = 'rejected'; entry.n8n_ack = reply;
          const code = /^[a-z0-9_-]{1,100}$/i.test(reply.code || '') ? reply.code : 'batch_command_rejected';
          this.notify(entry.body.message_id + ':rejected', errorText(code)); this.save(); continue;
        }
        if (reply.ok !== true || reply.accepted !== true) fail('n8n_not_acknowledged', 502);
        entry.status = 'delivered'; entry.n8n_ack = reply;
        const data = reply.result || reply, batch = data.batch || data;
        if (batch.batch_id) {
          const prior=this.state.manifests[batch.batch_id]||{},fp=batch.batch_fingerprint||batch.fingerprint||prior.batch_fingerprint;
          if(/^[a-f0-9]{64}$/.test(fp||''))this.state.manifests[batch.batch_id]={...prior,batch_fingerprint:fp,status:batch.status||batch.state,version:(prior.version||0)+1};
        }
        for (const b of data.batches || data.queue || []) if (b.batch_id && /^[a-f0-9]{64}$/.test(b.batch_fingerprint || b.fingerprint || '')) this.state.manifests[b.batch_id] = { ...this.state.manifests[b.batch_id],batch_fingerprint: b.batch_fingerprint || b.fingerprint, status: b.status || b.state };
        const actions=batchActions(entry.body.command,reply);
        const group=data.run_plan?.mode==='selected_group'&&['preparing','running'].includes(data.run_plan.status)?data.run_plan:null;
        for(const [i,b] of (data.batches||[]).filter(b=>!['completed','closed_partial','cancelled'].includes(b.status)).entries()){
          const common={batch_id:b.batch_id,batch_fingerprint:b.batch_fingerprint||b.fingerprint};
          if(!group&&['confirmed','ready','stopped','prepared'].includes(b.status))actions['run_'+i]={label:`${b.status==='stopped'?'Tiếp tục':'Bắt đầu'} mẻ ${i+1}`,type:'primary',command:{action:'batch_start',...common,card_expected_status:[b.status]}};
          if(b.status==='submitted')actions['run_'+i]={label:`Lưu mẻ ${i+1}`,command:{action:'batch_confirm',...common,card_expected_status:['submitted']}};
          if(!group&&['submitted','confirmed','stopped','prepared','preparing'].includes(b.status))actions['select_'+i]={label:((this.state.selected_batches||[]).includes(b.batch_id)?'☑ ':'☐ ')+`Chọn mẻ ${i+1}`,toggleBatch:b.batch_id};
          if(b.status==='stopped')actions['discard_'+i]={label:`Xóa việc chưa làm mẻ ${i+1}`,command:{action:'batch_discard_remaining',...common,card_expected_status:['stopped']},confirm:'Chỉ hủy việc chưa làm của đúng mẻ này, giữ file/Docs/KPI đã có.'};
          if(['ready','active'].includes(b.status))actions['stop_'+i]={label:`Tạm dừng mẻ ${i+1}`,command:{action:'batch_stop',...common,card_expected_status:['ready','active']}};
          for(const [j,item] of (b.items||[]).filter(x=>x.state==='failed').slice(0,3).entries())actions[`retry_${i}_${j}`]={label:`Tiếp tục mẫu ${item.item_id}`,command:{action:'batch_retry',...common,item_id:item.item_id,card_item_revision:item.revision,card_expected_status:['stopped','active','ready']}};
        }
        if(group){const b=(data.batches||[]).find(b=>b.batch_id===group.entries[0].batch_id);if(b)actions.stop_group={label:'Tạm dừng nhóm mẻ',command:{action:'batch_stop',batch_id:b.batch_id,batch_fingerprint:b.fingerprint}};}
        else if((this.state.selected_batches||[]).length)actions.run_selected={label:'Chạy tất cả các mẻ đã chọn',type:'primary',selectedCommand:'batch_run_selected'};
        const noticeKey=(entry.body.interaction_type==='card_action'?entry.body.event_id:entry.body.message_id)+':result';
        this.notify(noticeKey, renderResult(entry.body.command, reply),actions);
        if(entry.body.command.action==='batch_stop')this.state.notifications[noticeKey].notification_kind='workflow_stopped';
        if(data.images&&data.bundle_id)this.state.notifications[noticeKey].image_sources=data.images;
        if((data.batches||[]).some(b=>b.status==='completed'))this.state.notifications[noticeKey].destinations=this.config.cardDestinations;
        this.save();
      } catch (error) {
        entry.last_error = error.code || 'n8n_unavailable';
        entry.next_attempt = this.clock() + Math.min(300000, 5000 * 2 ** Math.min(entry.attempts, 6));
        this.notify(entry.body.message_id + ':error:' + entry.last_error, `Chưa xác nhận được từ n8n (${entry.last_error}). Lệnh vẫn được lưu để thử lại; không cần gửi lại mẻ.`); this.save();
      }
    }
  }
  async deliver(transport) {
    for (const [key, n] of Object.entries(this.state.notifications)) {
      if (n.status !== 'pending' || n.next_attempt > this.clock()) continue;
      n.attempts++; this.save();
      try {
        if(n.image_sources){n.bundle_images||=[];for(let i=n.bundle_images.length;i<n.image_sources.length;i++){const x=n.image_sources[i];const image_key=await transport.upload(this.owner.validateImage(x));n.bundle_images.push({label:x.label||x.name,image_key});this.save();}}
        n.message_id ||= await transport.send(this.config.chatId, n.actions?'interactive':'text', n.actions?{...batchCard(n),...(n.notification_kind?{notification_kind:n.notification_kind}:{})}:{ text: n.text,...(n.notification_kind?{notification_kind:n.notification_kind}:{}) }, n.uuid);
        if (!n.message_id) fail('lark_message_id_missing');this.save();
        if(n.documents){if(!transport.document)fail('document_transport_required');n.document_messages||=[];for(let i=n.document_messages.length;i<n.documents.length;i++){const id=await transport.document(this.config.chatId,this.owner.validateDocument(n.documents[i]),n.uuid+'-doc-'+i);if(!id)fail('document_message_id_missing');n.document_messages.push(id);this.save();}}
        n.status = 'delivered';
      }
      catch (error) { n.last_error = error.code || 'lark_message_failed'; n.next_attempt = this.clock() + Math.min(300000, 5000 * 2 ** Math.min(n.attempts, 6)); }
      this.save();
    }
  }
}
module.exports = { BatchStore, parseItems, parseCommand, renderResult, HELP, MAX_BYTES };
