'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {parseItems,parseCommand,renderResult}=require('./batch.cjs');
const {menuActions,batchActions}=require('./cards.cjs');
const v3=require('./workflow3.cjs');
test('position buttons persist a four-design selection and stage the exact versioned command',async t=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const {ReviewStore}=require('./review.cjs'),{BatchStore}=require('./batch.cjs'),{UI}=require('./cards.cjs');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'workflow3-controls-'));
 t.after(()=>{assert.ok(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep));fs.rmSync(dir,{recursive:true,force:true});});
 const config={stateFile:path.join(dir,'state.json'),chatId:'oc_fixture',humanOpenId:'ou_fixture',allowedImageRoots:[dir]};
 const store=new ReviewStore(config),batch=new BatchStore(store);let serial=0,sent=0;
 const transport={send:async()=> 'om_fixture_'+(++sent)};
 async function click(n,key){return batch.receiveCard({header:{event_id:'evt_fixture_'+(++serial)},event:{operator:{open_id:config.humanOpenId},context:{open_chat_id:config.chatId,open_message_id:n.message_id},action:{tag:'button',value:{bot_ui:UI,scope:'batch',card_id:n.uuid,action:key}}}});}
 const last=()=>Object.values(batch.state.notifications).at(-1);
 batch.menu('fixture');await batch.deliver(transport);assert.equal((await click(last(),'embroidery')).toast.type,'success');
 for(const key of ['both','sleeves','back','continue']){await batch.deliver(transport);assert.equal((await click(last(),key)).toast.type,'success');}
 assert.equal(batch.state.session.type,'mode');assert.equal(v3.regions(batch.state.session.positions).length,4);
 batch.stage({event_id:'evt_source',message_id:'om_source'},'TÊN: Fixture\nNGỰC TRÁI: small emblem\nNGỰC PHẢI: scene\nTAY: vertical scene\nLƯNG: back scene');
 const command=Object.values(batch.state.outbox).at(-1).body.command;
 assert.equal(command.profile_version,3);assert.equal(command.positions.chest,'left_right');assert.equal(Object.keys(command.items[0].designs).length,4);
});
test('position choices cover 15 combinations, both chest designs and one shared sleeve',()=>{
 let count=0;for(const chest of ['none','center','left','left_right'])for(const sleeves of [false,true])for(const back of [false,true]){
  const p={chest,sleeves,back},keys=v3.regions(p);if(!keys.length)continue;
  const source='TÊN: Fixture\n'+keys.map(k=>v3.labels[k]+': unique '+k).join('\n');
  const items=parseItems('embroidery_prompts',source,p);assert.equal(Object.keys(items[0].designs).length,keys.length);count++;
  assert.throws(()=>parseItems('embroidery_prompts',source+'\nTAY: duplicate or unselected',p));
 }assert.equal(count,15);assert.equal(v3.regions({chest:'left_right',sleeves:true,back:true}).length,4);
});
test('menu separates four products and only confirms a newly submitted batch',()=>{
 const actions=menuActions();assert.equal(Object.values(actions).filter(a=>a.mode||a.selectPositions).length,4);
 assert.ok(!actions.brief);assert.ok(actions.embroidery.selectPositions);
 for(const kind of ['pajama_top','pajama_set','sleep_pants'])assert.equal(parseItems(kind,'A single design idea')[0].idea_prompt,'A single design idea');
 const a=batchActions({action:'batch_submit',batch_id:'fixture'},{batch_id:'fixture',batch_fingerprint:'a'.repeat(64)});
 assert.equal(a.run.command.action,'batch_confirm');assert.match(a.run.label,/Lưu/);
 const stop=batchActions({action:'batch_stop',batch_id:'fixture'},{batch_id:'fixture',batch_fingerprint:'a'.repeat(64)});
 assert.equal(stop.discard.command.action,'batch_discard_remaining');
});
test('preparation, grouped review and night run use an explicit ordered list without a batch count cap',()=>{
 assert.equal(parseCommand('menu').type,'help');
 for(const [text,action] of [['CHUẨN BỊ','batch_prepare_reviews'],['DUYỆT BỘ','batch_review_bundle'],['CHẠY ĐÊM','batch_run_plan']]){
  assert.deepEqual(parseCommand(text+' batch-a, batch-b').command,{action,batch_ids:['batch-a','batch-b']});
  assert.deepEqual(parseCommand(text+' batch-a, batch-b, batch-c, batch-d').command,{action,batch_ids:['batch-a','batch-b','batch-c','batch-d']});
 }
 assert.match(renderResult({action:'batch_status'},{batches:[]}),/ĐANG TRỐNG/);
 const active={batch_id:'batch-a',name:'Night A',status:'active',items:[{item_id:'one',state:'completed'},{item_id:'two',state:'generating_mockups'}]};
 assert.match(renderResult({action:'batch_status'},{batches:[active]}),/ĐANG XỬ LÝ: Night A/);
});

test('group review without images explains preparation and exposes no approval',()=>{
 const command={action:'batch_review_bundle',batch_ids:['batch-a','batch-b']};
 const waiting={ok:true,status:'batch_reviews_not_ready',batch_ids:command.batch_ids,images:[],next_action:'batch_prepare_reviews'};
 const text=renderResult(command,waiting);
 assert.match(text,/Chưa có ảnh đại diện/);assert.match(text,/Chuẩn bị mẫu/);assert.match(text,/không cần gửi lại prompt/);
 assert.doesNotMatch(text,/batch_command_rejected|undefined|Hãy kiểm tra nội dung/);
 assert.ok(!batchActions(command,waiting).approve_bundle);
 const generating=renderResult(command,{...waiting,next_action:'batch_status'});
 assert.match(generating,/Xem tiến độ/);assert.doesNotMatch(generating,/chưa tạo mẫu/);
});

test('selected group uses one button and retains the click order in the real outbox',async t=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const {ReviewStore}=require('./review.cjs'),{BatchStore}=require('./batch.cjs'),{UI}=require('./cards.cjs');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'selected-group-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const config={stateFile:path.join(dir,'state.json'),chatId:'oc_fixture',humanOpenId:'ou_fixture',allowedImageRoots:[dir]};
 const store=new ReviewStore(config),batch=new BatchStore(store);
 batch.state.selected_batches=['batch-c','batch-a','batch-b'];
 batch.state.outbox.fixture={status:'pending',attempts:0,next_attempt:0,body:{event_id:'fixture-status',message_id:'om_fixture_status',command:{action:'batch_status'}}};
 await batch.flush(async()=>({ok:true,accepted:true,result:{ok:true,status:'batch_status',batches:[]}}));
 const notice=Object.values(batch.state.notifications).at(-1);
 assert.equal(notice.actions.run_selected.label,'Chạy tất cả các mẻ đã chọn');
 assert.ok(!notice.actions.prepare&&!notice.actions.bundle&&!notice.actions.night);
 await batch.deliver({send:async()=> 'om_fixture_group_card'});
 const click={header:{event_id:'fixture-group-start'},event:{operator:{open_id:config.humanOpenId},context:{open_chat_id:config.chatId,open_message_id:notice.message_id},action:{tag:'button',value:{bot_ui:UI,scope:'batch',card_id:notice.uuid,action:'run_selected'}}}};
 assert.equal(batch.receiveCard(click).toast.type,'success');
 const command=Object.values(batch.state.outbox).at(-1).body.command;
 assert.deepEqual(command,{action:'batch_run_selected',batch_ids:['batch-c','batch-a','batch-b']});
 assert.match(renderResult(command,{batch_ids:command.batch_ids}),/mẻ đã duyệt đứng chờ/);
 assert.match(renderResult(command,{batch_ids:command.batch_ids}),/không cần bấm thêm bước nào/);
 const batches=command.batch_ids.map((batch_id,i)=>({batch_id,fingerprint:'a'.repeat(64),status:i?'prepared':'preparing',items:[{state:i?'ready_mockups':'awaiting_sample_approval'}]}));
 batch.state.outbox.status_again={status:'pending',attempts:0,next_attempt:0,body:{event_id:'fixture-group-status',message_id:'om_group_status',command:{action:'batch_status'}}};
 await batch.flush(async()=>({ok:true,accepted:true,result:{ok:true,batch_ids:command.batch_ids,batches,run_plan:{mode:'selected_group',status:'preparing',entries:command.batch_ids.map(batch_id=>({batch_id}))}}}));
 const group=Object.values(batch.state.notifications).at(-1);
 assert.ok(group.actions.stop_group);assert.ok(!group.actions.run_selected);
 assert.ok(!Object.values(group.actions).some(a=>a.command?.action==='batch_start'||a.toggleBatch));
 assert.match(group.text,/2\/3 mẻ đã duyệt/);
});
