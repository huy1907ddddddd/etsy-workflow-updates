'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, timingSafeEqual } = require('node:crypto');
const { fail } = require('./review.cjs');
function pairingSession(configPath, nonce = randomBytes(8).toString('hex').toUpperCase(), clock = () => Date.now()) {
  const read = () => JSON.parse(fs.readFileSync(configPath, 'utf8').replace(/^\uFEFF/, ''));
  const initial = read();
  if (initial.chatId || initial.humanOpenId) fail('pairing_already_configured');
  const expires = clock() + 10 * 60000;
  let done = false;
  return {
    command: 'KET NOI ' + nonce, expires,
    receive(event) {
      if (done || clock() > expires) return false;
      const data = event.event || event, m = data.message || {}, s = data.sender || {};
      if (m.chat_type !== 'p2p' || m.message_type !== 'text' || s.sender_type !== 'user' || !s.sender_id?.open_id || !m.chat_id || !m.message_id) return false;
      let text; try { text = JSON.parse(m.content).text; } catch { return false; }
      if (typeof text !== 'string') return false;
      const a = Buffer.from(text.trim()), b = Buffer.from('KET NOI ' + nonce);
      if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
      const current = read();
      if (current.chatId || current.humanOpenId) fail('pairing_configuration_changed');
      if (current.appId !== initial.appId || current.appSecret !== initial.appSecret) fail('pairing_app_changed');
      current.chatId = m.chat_id; current.humanOpenId = s.sender_id.open_id;
      current.pairing = { paired_at: new Date(clock()).toISOString(), message_id: m.message_id, transport: 'official_lark_websocket_p2p' };
      const temporary = configPath + '.' + randomBytes(8).toString('hex') + '.tmp';
      fs.writeFileSync(temporary, JSON.stringify(current, null, 2) + '\n', { mode: 0o600 });
      fs.renameSync(temporary, configPath); done = true; return true;
    }
  };
}
async function main() {
  const lark = require('@larksuiteoapi/node-sdk');
  const configPath = process.env.LARK_REVIEW_CONFIG || path.resolve(__dirname, '../../config/lark-review.private.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8').replace(/^\uFEFF/, ''));
  if (!config.appId || !config.appSecret) fail('pairing_app_credentials_required');
  const session = pairingSession(configPath);
  const logger = Object.fromEntries(['trace', 'debug', 'info', 'warn', 'error', 'fatal'].map(level => [level, () => { if (level === 'error' || level === 'fatal') console.error('lark_pairing_transport_error'); }]));
  const ws = new lark.WSClient({ appId: config.appId, appSecret: config.appSecret, domain: lark.Domain.Lark, logger });
  let timer, finished = false;
  const close = () => { if (finished) return; finished = true; clearTimeout(timer); ws.close({ force: true }); };
  const dispatcher = new lark.EventDispatcher({ logger }).register({ 'im.message.receive_v1': data => {
    if (session.receive(data)) { console.log('Đã ghép đúng tài khoản và hội thoại vào cấu hình riêng. Chưa gửi ảnh hoặc duyệt nội dung.'); close(); }
    return {};
  } });
  console.log('Mở hội thoại riêng với bot Bún Bò Huế, gửi đúng dòng sau trong 10 phút:');
  console.log(session.command);
  timer = setTimeout(() => { console.log('Mã kết nối đã hết hạn; chưa thay đổi cấu hình.'); close(); }, 10 * 60000);
  process.once('SIGINT', close); process.once('SIGTERM', close);
  try { await ws.start({ eventDispatcher: dispatcher }); } catch (error) { close(); throw error; }
}
if (require.main === module) main().catch(error => { console.error(error.code || 'lark_pairing_failed'); process.exitCode = 1; });
module.exports = { pairingSession };
