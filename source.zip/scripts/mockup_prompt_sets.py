"""Validate complete saved mockup sets; only new batch snapshots opt in."""
import re


def validate(value, kind, names):
    if not isinstance(value,dict) or value.get('schema_version')!=1 or value.get('kind')!=kind:
        raise ValueError('Mockup prompt set product kind differs')
    if not isinstance(value.get('name'),str) or not 1<=len(value['name'].strip())<=100:
        raise ValueError('Mockup prompt set name required')
    source=value.get('source')
    if not isinstance(source,str) or len(source.encode('utf8'))>1000000:raise ValueError('Mockup prompt set exceeds 1 MB')
    parts=re.split(r'(?m)^===== ([0-9]{2}_[a-z_]+\.jpg) =====[ \t]*\r?\n',source.strip()+'\n')
    if parts[0].strip() or len(parts)!=1+2*len(names):raise ValueError('Supply the complete mockup prompt set')
    shots=dict(zip(parts[1::2],[p.strip() for p in parts[2::2]]))
    if list(shots)!=names or any(not p for p in shots.values()):raise ValueError('Mockup prompt set image names/order differ')
    flatlay='04_flatlay.jpg' if '04_flatlay.jpg' in names else '10_flatlay.jpg'
    if flatlay not in names:raise ValueError('A clean flatlay is required')
    return {'schema_version':1,'name':value['name'].strip(),'kind':kind,'source':source,'clean_flatlay':flatlay}


def shots(value):
    parts=re.split(r'(?m)^===== ([0-9]{2}_[a-z_]+\.jpg) =====[ \t]*\r?\n',value['source'].strip()+'\n')
    return dict(zip(parts[1::2],[p.strip() for p in parts[2::2]]))


def photo_lock(name,kind,garment_only=False,front_back=False):
    if kind in ('apparel_2d','pajama_top','pajama_set','sleep_pants'):
        role={'01_thumbnail.jpg':'Standing male front hero, full garment visible.',
              '02_female_angle.jpg':'Standing female three-quarter angle.',
              '03_female_seated.jpg':'Seated female, same framing and product coverage.',
              '04_flatlay.jpg':'Overhead fully unfolded flatlay, complete garment visible.',
              '05_print_closeup.jpg':'Tight print quality closeup, same camera angle and crop.'}[name]
    elif front_back:
        import embroidery_mockup_layout
        role=embroidery_mockup_layout.lock(name)
    elif garment_only:
        role={'01_thumbnail.jpg':'Overhead folded crewneck sweatshirt hero, sleeves and cuffs visible.',
              '02_hoodie_folded.jpg':'Overhead folded hoodie, sleeves and cuffs visible.',
              '04_sweatshirt_flatlay.jpg':'Overhead fully unfolded sweatshirt and sleeves.',
              '05_hoodie_flatlay.jpg':'Overhead fully unfolded hoodie, slight diagonal arrangement.',
              '07_embroidery_closeup.jpg':'Tight oblique macro of the exact primary embroidery only.',
              '10_flatlay.jpg':'Overhead fully unfolded quarterzip and sleeves.'}[name]
    else:
        role='Keep this exact established shot role: '+name+'.'
    return ('FIXED PHOTO SETUP: '+role+' Square 1:1 photorealistic product photograph; '
            'indirect window daylight, neutral white balance, same exposure, camera framing, pose and viewing direction as the standard shot. '
            'The saved choice changes BACKGROUND DECORATIONS ONLY, never the product, artwork, palette, garment construction, lighting or camera setup. '
            'Keep props behind and separate from the product, never covering or printed on it. '
            'Approved sample references control the product only; do not copy their background decorations. ')


CLEAN='CLEAN FLATLAY OVERRIDE: Fully unfolded overhead product flatlay on a plain undecorated neutral surface. No background decorations, props, foliage, holiday objects, packaging or ornaments. Preserve the exact garment and artwork. This clean flatlay instruction overrides any scenery requested in the saved prompt.'
