"""Isolated fixtures: never consume real input folders, call AI/Docs, reserve SKU or write live KPI."""
import copy,importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import thumbnail_copy as thumbnail

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('production-engine.py'))
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)


class ThumbnailTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='thumbnail-fixture-',dir=engine.STORE)
        self.prior=engine.STORE,engine.JOBS;engine.STORE=Path(self.tmp.name);engine.JOBS=engine.STORE/'jobs';engine.JOBS.mkdir()
        self.c=engine.connect(engine.STORE/'fixture.sqlite')
        self.root=engine.STORE/'input';self.folder=self.root/'batch1';self.folder.mkdir(parents=True)
        self.image=self.folder/'thumbnail.jpg';Image.new('RGB',(100,100),'white').save(self.image)
        self.cfg={'enabled':True,'input_root':str(self.root),'stable_seconds':0,'product_mode':'embroidered_apparel','authorization_reference':'Fixture user copy-only instruction','count_production_kpi':False}
        self.p=patch.object(thumbnail,'config',return_value=self.cfg);self.p.start()
    def tearDown(self):
        self.p.stop();self.c.close();engine.STORE,engine.JOBS=self.prior;self.tmp.cleanup()
    def execute(self,action,**fields):return engine.execute(self.c,dict(action=action,**fields))
    def intake(self):
        self.assertIsNone(self.execute('thumbnail_scan')['next_item'])
        return self.execute('thumbnail_scan')['next_item']['id']
    def facts(self,identifier,uncertainties=None):
        i=thumbnail.item(self.c,identifier);thumb=json.loads(i['thumbnail'])
        engine.write(engine.STORE/'thumbnail-copy/vision'/(identifier+'.json'),{'ok':True,'external_tools_used':False,'input_sha256':thumb['sha256'],
          'draft':{'motif_description':'Fixture otter holding a flower on the front chest.','garment_style':'crewneck sweatshirt','visible_text':'','uncertainties':uncertainties or []}})
        return self.execute('thumbnail_attach_facts',copy_id=identifier)
    def test_stable_intake_is_immutable_and_repeated_scan_does_not_duplicate_or_touch_production(self):
        identifier=self.intake();self.assertEqual(self.execute('thumbnail_scan')['next_item']['id'],identifier)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM thumbnail_items').fetchone()[0],1)
        for table in ['jobs','reservations','kpi','approvals']:self.assertEqual(self.c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0)
        before=json.loads(thumbnail.item(self.c,identifier)['thumbnail']);Image.new('RGB',(100,100),'red').save(self.image)
        self.execute('thumbnail_scan');self.execute('thumbnail_scan');self.assertEqual(self.c.execute('SELECT COUNT(*) FROM thumbnail_items').fetchone()[0],2)
        self.assertEqual(engine.sha(before['path']),before['sha256'])
    def test_facts_bind_to_the_exact_thumbnail_and_use_copy_authorization_instead_of_fake_approvals(self):
        self.execute('batch_enable_tqh',authority='direct_user',reference='Fixture TQH suffix instruction')
        identifier=self.intake();self.execute('thumbnail_prepare',copy_id=identifier)
        result=self.facts(identifier);registry=engine.read(engine.JOBS/'registry.json')['jobs'][result['listing_code']]
        self.assertTrue(result['listing_code'].endswith('_TQH'))
        self.assertEqual(registry['authorization']['scope'],'thumbnail_copy_only');self.assertNotIn('approval',registry)
        self.assertEqual(self.facts(identifier)['listing_code'],result['listing_code'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM jobs').fetchone()[0],0)
    def test_uncertainty_and_changed_snapshot_stop_before_writing_source_or_docs(self):
        identifier=self.intake()
        with self.assertRaisesRegex(ValueError,'ambiguous'):self.facts(identifier,['Unclear artwork'])
        deferred=self.execute('thumbnail_defer',copy_id=identifier);self.assertEqual(deferred['status'],'thumbnail_needs_review')
        self.assertIsNone(self.execute('thumbnail_scan')['next_item'])
        i=thumbnail.item(self.c,identifier);Path(json.loads(i['thumbnail'])['path']).write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'changed'):self.execute('thumbnail_prepare',copy_id=identifier)
    def test_copy_completion_requires_exact_cloud_readback_and_never_counts_kpi(self):
        identifier=self.intake();self.execute('thumbnail_prepare',copy_id=identifier);source=self.facts(identifier)
        evidence=[{'keyword':'fixture term '+str(n),'requested_filter':'physical','checked_at_utc':engine.now(),'evidence_status':'indexed_record','competition_level':'low','listing_count':80,'indexed_avg_listing_views':600,'indexed_avg_listing_views_24h':2,'provider_says_insufficient_data':False} for n in range(20)]
        text={'listing_code':source['listing_code'],'title':'Fixture otter flower embroidered sweatshirt woodland animal gift for nature lovers with a cozy casual everyday crewneck apparel design'.ljust(137,'!'),
          'description':'Fixture copy from visible artwork.','tags':[e['keyword'] for e in evidence[:13]],'keyword_evidence':evidence,
          'provenance':{'input_sha256':source['input_sha256']},'keyword_provenance':{'keyword_policy':'ai_first_20_to_13_v1','source_hash':source['input_sha256']}}
        self.execute('thumbnail_attach_copy',copy_id=identifier,text=text)
        task=json.loads(thumbnail.item(self.c,identifier)['task']);p=task['payload']['packet']
        proof={'ok':True,'task_fingerprint':task['fingerprint'],'document_url':engine.REVIEW_URL,'block_ids':['fixture-block'],
          'content':{'listing_code':p['listing_code'],'title':p['title'],'description':p['description'],'tags':p['tags'],'thumbnail_sha256':p['thumbnail']['sha256']}}
        class Response:
            def __init__(self,value):self.value=value
            def __enter__(self):
                import io
                return io.BytesIO(json.dumps(self.value).encode())
            def __exit__(self,*args):pass
        with patch('urllib.request.urlopen',return_value=Response({**proof,'content':{**proof['content'],'title':'changed'}})):
            with self.assertRaisesRegex(ValueError,'readback'):self.execute('thumbnail_finalize',copy_id=identifier)
        with patch('urllib.request.urlopen',return_value=Response(proof)):
            engine.write(self.folder/'thumbnail.needs-review.json',{'copy_id':identifier,'reasons':['Earlier resolved uncertainty']})
            r=self.execute('thumbnail_finalize',copy_id=identifier)
        self.assertEqual(engine.read(self.folder/'thumbnail.needs-review.json')['status'],'resolved')
        self.assertEqual(r['status'],'thumbnail_copy_completed');self.assertFalse(r['kpi_counted']);self.assertFalse(r['images_generated'])
        self.assertIsNone(self.execute('thumbnail_scan')['next_item'])
        for table in ['kpi','reservations','jobs','approvals']:self.assertEqual(self.c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0)

    def test_retry_preserves_held_vision_and_minor_uncertainties_are_omitted_not_guessed(self):
        identifier=self.intake()
        with self.assertRaisesRegex(ValueError,'ambiguous'):self.facts(identifier,['Unclear main motif'])
        self.execute('thumbnail_defer',copy_id=identifier)
        with self.assertRaisesRegex(ValueError,'Explicit retry'):self.execute('thumbnail_retry',copy_id=identifier)
        self.execute('thumbnail_retry',copy_id=identifier,authority='direct_user',reference='Fixture retry after vision prompt correction')
        self.assertEqual(len(list((engine.STORE/'thumbnail-copy/vision').glob('*.superseded-*.json'))),1)
        i=thumbnail.item(self.c,identifier);thumb=json.loads(i['thumbnail'])
        engine.write(engine.STORE/'thumbnail-copy/vision'/(identifier+'.json'),{'ok':True,'external_tools_used':False,'input_sha256':thumb['sha256'],
          'draft':{'motif_description':'An otter reads a book on the front chest.','garment_style':'crewneck sweatshirt','visible_text':'','copy_usable':True,'uncertainties':['Tiny accessory is unclear']}})
        result=self.execute('thumbnail_attach_facts',copy_id=identifier)
        source=engine.read(engine.JOBS/(result['listing_code']+'.json'))
        self.assertIn('Omit every uncertain detail',source['task'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],0)


if __name__=='__main__':unittest.main(verbosity=2)
