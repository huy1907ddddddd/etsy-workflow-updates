"""Explicit, fingerprint-bound removal of one stopped, undelivered batch."""
import json
import subprocess
from pathlib import Path


def plan(c, cmd, e):
    bid = cmd['batch_id']
    b = c.execute('SELECT * FROM production_batches WHERE batch_id=?', (bid,)).fetchone()
    if not b or b['status'] != 'stopped' or b['fingerprint'] != cmd.get('batch_fingerprint'):
        raise ValueError('Exact stopped batch fingerprint required for deletion')
    supervisor = e['ROOT'] / 'workspace/flow-worker/runtime/supervisor-status.json'
    if not supervisor.exists() or e['read'](supervisor).get('status') != 'stopped':
        raise ValueError('Stop supervisor-owned browser/review/batch workers before deleting their state')
    items = [dict(r) for r in c.execute('SELECT * FROM production_batch_items WHERE batch_id=?', (bid,))]
    codes = [i['listing_code'] for i in items if i['listing_code']]
    briefs = [i['brief_id'] for i in items]
    tasks = [r[0] for r in c.execute('SELECT id FROM production_batch_tasks WHERE batch_id=?', (bid,))]
    for code in codes:
        if c.execute('SELECT 1 FROM kpi WHERE code=?', (code,)).fetchone() or c.execute("SELECT 1 FROM artifacts WHERE code=? AND kind IN ('package','text')", (code,)).fetchone():
            raise ValueError('Delivered/text-bearing batch needs explicit cloud reconciliation before deletion')
    others = c.execute('SELECT brief_id,listing_code FROM production_batch_items WHERE batch_id<>?', (bid,)).fetchall()
    if any(r['brief_id'] in briefs or r['listing_code'] in codes for r in others):
        raise ValueError('Batch identities are shared; refuse deletion')
    ids = [bid, *briefs, *codes, *tasks]
    store, root, jobs = e['STORE'], e['ROOT'], e['JOBS']
    config = e['read'](root/'config/lark-review.private.json')
    review_path = Path(config['stateFile']).resolve()
    review = e['read'](review_path)
    def owns(value):
        # Prompt text and item titles can repeat across batches; they are not ownership.
        if isinstance(value,dict):
            if value.get('batch_id') and value['batch_id'] != bid: return False
            return any(owns(k) or owns(v) for k,v in value.items())
        if isinstance(value,list): return any(owns(v) for v in value)
        if not isinstance(value,str): return False
        if value in ids or any(k in ids for k in value.split(':')): return True
        if value.startswith(('{','[')):
            try: return owns(json.loads(value))
            except ValueError: pass
        return False
    review_ids = [k for k, v in review.get('reviews', {}).items() if owns(v)]
    ids += review_ids
    for key,value in review.get('batch',{}).get('outbox',{}).items():
        if owns(value):
            body=value.get('body',{})
            ids += [v for v in [key,body.get('event_id'),body.get('message_id')] if v]
    messages=[m['message_id'] for k in review_ids for m in review['reviews'][k].get('messages',[]) if m.get('message_id')]
    messages += [v['message_id'] for k,v in review.get('batch',{}).get('notifications',{}).items() if owns({k:v}) and v.get('message_id')]
    rows = {}
    tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    by_code = ['jobs','events','approvals','artifacts','tasks','kpi']
    by_brief = ['briefs','reservations','design_jobs','design_assets','design_approvals','design_tasks','design_events','design_sizes']
    for table in sorted(tables):
        if table.startswith('sqlite_'): continue
        selected = []
        for r in c.execute('SELECT rowid AS _delete_rowid,* FROM "'+table+'"'):
            d = dict(r)
            match = (table in by_code and d.get('code') in [bid,*codes]) or (table in by_brief and d.get('brief_id') in briefs)
            match = match or (table.startswith('production_batch') and (d.get('batch_id') == bid or (table == 'production_batch_events' and owns(d.get('result','')))))
            match = match or (table == 'config' and (any(k in d['key'] for k in [bid,*briefs,*codes]) or
                                                    (d['key'].startswith('flow_generation_retry:') and owns(d['value']))))
            match = match or (table in ['flow_candidates','flow_attachments','lark_decisions'] and owns(d))
            if match: selected.append(d)
        if selected: rows[table] = selected
    files = set()
    roots = [store, root/'workspace/flow-worker/runtime', root/'workspace/batch-worker/runtime',
             root/'workspace/codex-listing-engine', root/'workspace/codex-keyword-engine', jobs,
             jobs.parent/'current-state',
             root.parent/'Chưa xử lý/Áo 2D/UST', root.parent/'Đã xử lý/Áo 2D/UST']
    for base in roots:
        if not base.exists(): continue
        for f in base.rglob('*'):
            if f.is_file() and f.name not in ['production.sqlite','production.sqlite-wal','production.sqlite-shm'] and any(k in str(f.relative_to(base)) for k in ids):
                files.add(f.absolute())
    runtime = root/'workspace/flow-worker/runtime'
    for f in runtime.glob('task-*.json'):
        if owns(e['read'](f)):
            files.add(f.absolute())
            token = f.stem.removeprefix('task-')
            files.update(x.absolute() for x in runtime.glob('*'+token+'*') if x.is_file())
    edits = {}
    def edit(path, data):
        if path.exists() and data != e['read'](path): edits[str(path.resolve())] = data
    for p, key, remove in [(jobs/'registry.json','jobs',codes),
                          (root/'workspace/flow-worker/browser-profile/flow-worker-projects.json','projects',[bid])]:
        if p.exists():
            data=e['read'](p);data[key]={k:v for k,v in data.get(key,{}).items() if k not in remove};edit(p,data)
    p=root/'workspace/batch-worker/runtime/notices.json'
    if p.exists(): edit(p,{k:v for k,v in e['read'](p).items() if k!=bid})
    for p in [store/'intake-tests/latest-intake.json',runtime/'unusual-activity-cooldown.json']:
        if p.exists() and owns(e['read'](p)): files.add(p.absolute())
    review['reviews']={k:v for k,v in review.get('reviews',{}).items() if k not in review_ids}
    for key in ['seen','outbox','card_seen']:
        review[key]={k:v for k,v in review.get(key,{}).items() if not owns({k:v})}
    for key, value in list(review.get('batch',{}).items()):
        if isinstance(value,dict): review['batch'][key]={k:v for k,v in value.items() if not owns({k:v})}
        elif value is not None and owns(value): review['batch'][key]=None
    if owns(review.get('worker_status',{})): review.pop('worker_status',None)
    edit(review_path,review)
    for p in files:
        if any(x.is_symlink() or (hasattr(x,'is_junction') and x.is_junction()) for x in [p,*p.parents]) or not any(p.resolve().is_relative_to(base.resolve()) and p.resolve()!=base.resolve() for base in roots):
            raise ValueError('Delete target outside exact runtime/output roots')
    # Native preview rewrites its own current-state receipt. Bind its path, not those volatile bytes.
    current_state=(jobs.parent/'current-state').resolve()
    return {'batch_id':bid,'batch_fingerprint':b['fingerprint'],'rows':rows,'bot_messages':sorted(set(messages)),
            'files':[{'path':str(p),'sha256':None if p.resolve().is_relative_to(current_state) else e['sha'](p),
                      'bytes':0 if p.resolve().is_relative_to(current_state) else p.stat().st_size} for p in sorted(files)],'edits':edits}


def execute(c,cmd,e):
    e['design_module']().authority(cmd)
    p=plan(c,cmd,e);fp=e['digest'](p)
    summary={'ok':True,'status':'batch_delete_preview','batch_id':p['batch_id'],'delete_fingerprint':fp,
             'row_counts':{k:len(v) for k,v in p['rows'].items()},'file_count':len(p['files']),
             'file_bytes':sum(f['bytes'] for f in p['files']),'shared_files_updated':list(p['edits'])}
    summary['bot_message_count']=len(p['bot_messages'])
    if cmd.get('dry_run',True): return summary
    if cmd.get('delete_fingerprint')!=fp: raise ValueError('Deletion inventory changed; inspect a fresh preview')
    if p['bot_messages']:
        try:
            remote=subprocess.run(['node',str(e['ROOT']/'scripts/lark-review/delete-batch-messages.cjs')],input=json.dumps(p['bot_messages']),text=True,capture_output=True,timeout=180,check=True)
            summary['bot_messages']=json.loads(remote.stdout)
        except (subprocess.SubprocessError,ValueError,OSError):
            summary['bot_messages']={'requested':len(p['bot_messages']),'deleted':None,'error':'Check native private log; remote recall not verified'}
    for f in p['files']: Path(f['path']).unlink()
    for path,data in p['edits'].items(): e['write'](Path(path),data)
    for table,rows in p['rows'].items():
        for row in rows: c.execute('DELETE FROM "'+table+'" WHERE rowid=?',(row['_delete_rowid'],))
    folders=[e['STORE']/kind/p['batch_id'] for kind in ['batches','delegated-reviews','intake-tests']]
    codes=[r['listing_code'] for r in p['rows'].get('production_batch_items',[]) if r['listing_code']]
    folders += [e['STORE']/kind/code for kind in ['processed','artifacts','delivery-receipts','listing-content','output-history'] for code in codes]
    folders += [e['ROOT'].parent/state/'Áo 2D/UST'/code for state in ['Chưa xử lý','Đã xử lý'] for code in codes]
    for folder in folders:
        if folder.exists():
            for child in sorted(folder.rglob('*'),reverse=True):
                if child.is_dir() and not any(child.iterdir()):child.rmdir()
            if not any(folder.iterdir()):folder.rmdir()
    return dict(summary,status='batch_deleted',original_input_brief_preserved=True,other_batches_preserved=True)
