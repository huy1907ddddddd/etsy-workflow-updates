"""Frozen front/back photo layout for newly submitted embroidery batches."""
import hashlib
import json
import mockup_prompt_sets

VERSION = 'dual-front-back-neutral-v2'


def validate(value, e, names):
    body = {k:v for k,v in value.items() if k != 'fingerprint'}
    fingerprint = hashlib.sha256(json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if value.get('version') not in ('dual-front-back-v1', VERSION) or value.get('fingerprint') != fingerprint:
        raise ValueError('Mockup front/back layout changed')
    mockup_prompt_sets.validate(value['standard'], 'embroidery_prompts', names)
    for preset in value.get('preset_migrations', {}).values():
        mockup_prompt_sets.validate(preset, 'embroidery_prompts', names)
    base = (e['ROOT'] / 'config/embroidery-guides' / value['version']).resolve()
    if set(value['guides']) != {'crewneck sweatshirt','hoodie','quarter-zip pullover'}:
        raise ValueError('Mockup front/back garment guides missing')
    for ref in value['guides'].values():
        file = e['scoped'](ref['path'])
        if not file.resolve().is_relative_to(base) or e['sha'](file) != ref['sha256']:
            raise ValueError('Mockup front/back guide changed')
    return value


def load(e, names):
    return validate(e['read'](e['ROOT'] / 'config/embroidery-front-back-mockups-v2.json'), e, names)


def preset(value, layout, names):
    replacement = layout.get('preset_migrations', {}).get(hashlib.sha256(value['source'].encode()).hexdigest())
    return mockup_prompt_sets.validate(replacement or value, 'embroidery_prompts', names)


def lock(name):
    role = {
        '01_thumbnail.jpg': 'EXACTLY TWO identical garments in ONE continuous real scene: FRONT-UP folded torso with chest and BOTH full sleeves/cuffs unobscured, beside a FULLY UNFOLDED BACK-UP garment showing the entire back. Same style/color/size, no overlap, collage or panels. Chest sources belong only on the front garment; back source only on the back garment. Both complete sleeves are arranged visibly even when blank.',
        '02_hoodie_folded.jpg': 'EXACTLY ONE FRONT-UP folded garment; chest and BOTH full sleeves/cuffs visible, even when blank. Back artwork stays on the unseen underside.',
        '04_sweatshirt_flatlay.jpg': 'EXACTLY ONE FULLY UNFOLDED BACK-UP garment, complete back panel and both sleeves/cuffs visible. Chest artwork stays on the unseen underside.',
        '05_hoodie_flatlay.jpg': 'EXACTLY ONE FULLY UNFOLDED FRONT-UP garment, slight diagonal arrangement; chest and BOTH full sleeves/cuffs visible, even when blank. Back artwork stays on the unseen underside.',
        '07_embroidery_closeup.jpg': 'Tight oblique macro of the exact SINGLE PRIMARY REGION only, from its single isolated embroidery source; no other artwork, garment pair, palette, sample, guide or props.',
        '10_flatlay.jpg': 'EXACTLY ONE FULLY UNFOLDED BACK-UP garment, complete back panel and both sleeves/cuffs visible, plain clean undecorated surface. Chest artwork stays on the unseen underside.',
    }[name]
    return ('CURRENT SHOT COMPOSITION — takes precedence over any earlier pose/count/face in a saved preset or layout anchor: ' + role +
            ' Unselected chest and sleeves remain blank; sleeve visibility never authorizes extra embroidery. '
            'An approved two-garment thumbnail controls same-listing design continuity only; never copy its garment count into later single-garment shots. '
            'Assigned garment/color, neutral daylight and approved artwork remain unchanged. Guide fabric/color/background are not product or decoration authority. ')
