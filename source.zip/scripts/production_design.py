"""Durable Flow design stages, preceding dated listing/KPI allocation.

Assets and browser evidence must come from real UI work. No generation, approvals,
SKU reservation or KPI activation is performed automatically by this module.
"""
import json
import uuid
from types import SimpleNamespace

STAGES = ('2d', 'embroidery')


def prompt_body(text, rule):
    if not isinstance(text, str) or not text.strip() or len(text) > 30000 or '\x00' in text:
        raise ValueError('Each prompt must be nonblank text of at most 30000 characters')
    text = text.strip()
    while text.endswith(rule):
        text = text[:-len(rule)].rstrip()
    if not text:
        raise ValueError('A prompt must contain a design, not only the mandatory rule')
    if rule in text:
        raise ValueError('Keep the mandatory rule only at the end of the prompt')
    return text


def load_prompt_pack(c, cmd, row, source_revision, e):
    fp = cmd.get('prompt_pack_fingerprint')
    if not isinstance(fp, str) or len(fp) != 64 or any(x not in '0123456789abcdef' for x in fp):
        raise ValueError('A staged prompt pack fingerprint is required')
    saved = c.execute('SELECT value FROM config WHERE key=?', ('design_prompt_pack:' + row['brief_id'] + ':' + fp,)).fetchone()
    if not saved:
        raise ValueError('Prompt pack missing; stage it through design_prompt_pack first')
    pack = json.loads(saved['value'])['pack']
    if e.digest(pack) != fp or pack['brief_fingerprint'] != row['fingerprint'] or pack['source_revision'] != source_revision:
        raise ValueError('Prompt pack differs from the current brief/revision; stage it again')
    return {**pack, 'fingerprint': fp}


def stage_prompt_pack(c, cmd, e):
    authority(cmd)
    row, b = brief(c, cmd['brief_id'])
    if cmd.get('brief_fingerprint') != row['fingerprint']:
        raise ValueError('Prompt pack brief fingerprint differs')
    existing = c.execute('SELECT revision,state,references_json,brief_fingerprint FROM design_jobs WHERE brief_id=?', (row['brief_id'],)).fetchone()
    revision = existing['revision'] if existing else None
    if cmd.get('revision') != revision:
        raise ValueError('Prompt pack requires the current design revision, or no revision before start')
    if existing:
        refs = json.loads(existing['references_json'])
        if existing['brief_fingerprint'] != row['fingerprint'] or refs.get('left_sleeve', []) != refs.get('right_sleeve', []):
            raise ValueError('Two-prompt intake requires the unchanged brief and identical supporting sleeve references')
    data = cmd.get('prompt_pack')
    fields = {'chest_region', 'chest_prompt', 'sleeve_prompt', 'provider', 'aspect_ratio'}
    if not isinstance(data, dict) or set(data) - fields or not {'chest_region', 'chest_prompt', 'sleeve_prompt'} <= set(data):
        raise ValueError('Prompt pack accepts exactly one chest and one shared sleeve prompt; no references or other regions')
    chest = {'center_chest', 'left_chest'} & set(b['motifs'])
    if len(chest) != 1 or set(b['motifs']) != chest | {'left_sleeve', 'right_sleeve'} or data['chest_region'] not in chest:
        raise ValueError('Two-prompt intake requires the confirmed chest, both sleeves and no back artwork')
    if b['motifs']['left_sleeve'] != b['motifs']['right_sleeve']:
        raise ValueError('Two-prompt intake requires identical confirmed sleeve motifs')
    if data.get('provider', 'Flow Nano Banana Pro') != 'Flow Nano Banana Pro' or data.get('aspect_ratio', '1:1') != '1:1':
        raise ValueError('Prompt pack must use Flow Nano Banana Pro and a square 1:1 canvas')
    rule = e.read(e.ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    pack = {'brief_id': row['brief_id'], 'brief_fingerprint': row['fingerprint'], 'source_revision': revision,
            'chest_region': data['chest_region'], 'chest_prompt': prompt_body(data['chest_prompt'], rule),
            'sleeve_prompt': prompt_body(data['sleeve_prompt'], rule),
            'provider': 'Flow Nano Banana Pro', 'aspect_ratio': '1:1'}
    fp = e.digest(pack)
    c.execute('INSERT OR IGNORE INTO config(key,value) VALUES(?,?)',
              ('design_prompt_pack:' + row['brief_id'] + ':' + fp,
               json.dumps({'pack': pack, 'reference': cmd['reference'], 'created_at': e.now()}, ensure_ascii=False)))
    return {'ok': True, 'status': 'prompt_pack_staged', 'brief_id': row['brief_id'],
            'brief_fingerprint': row['fingerprint'], 'source_revision': revision,
            'job_state': existing['state'] if existing else None,
            'prompt_pack_fingerprint': fp, 'prompt_pack': pack,
            'generation_started': False, 'artwork_approved': False, 'kpi_counted': False}


def authority(cmd):
    if cmd.get('authority') != 'direct_user' or not str(cmd.get('reference', '')).strip():
        raise ValueError('Design changes/approval require direct user authority and reference')


def brief(c, brief_id):
    row = c.execute('SELECT * FROM briefs WHERE brief_id=?', (brief_id,)).fetchone()
    if not row:
        raise ValueError('Receive the research brief first')
    return dict(row), json.loads(row['payload'])


def job(c, brief_id):
    row = c.execute('SELECT * FROM design_jobs WHERE brief_id=?', (brief_id,)).fetchone()
    if not row:
        raise ValueError('Design job missing; start it after direct brief approval')
    return dict(row)


def event(c, j, kind, payload, e):
    c.execute('INSERT INTO design_events(brief_id,revision,kind,payload,created_at) VALUES(?,?,?,?,?)',
              (j['brief_id'], j['revision'], kind, json.dumps(payload, ensure_ascii=False), e.now()))


def assets(c, j, stage):
    return {r['region']: json.loads(r['payload']) for r in c.execute(
        'SELECT region,payload FROM design_assets WHERE brief_id=? AND revision=? AND stage=? ORDER BY region',
        (j['brief_id'], j['revision'], stage))}


def checked_assets(c, j, stage, e):
    from PIL import Image
    items = assets(c, j, stage)
    for a in items.values():
        path = e.scoped(a['path'])
        if not path.is_file() or e.sha(path) != a['sha256']:
            raise ValueError('Locked design asset missing/changed; revise and approve again')
        with Image.open(path) as im:
            im.verify()
    return items


def fingerprint(c, j, stage, e):
    row, b = brief(c, j['brief_id'])
    items = checked_assets(c, j, stage, e)
    if set(items) != set(b['motifs']):
        raise ValueError('All confirmed regions are required before stage approval')
    return e.digest({'brief_fingerprint': row['fingerprint'], 'revision': j['revision'],
                     'stage': stage, 'assets': items})


def approval(c, j, stage, fp):
    saved = c.execute('SELECT reference FROM design_approvals WHERE brief_id=? AND revision=? AND stage=? AND fingerprint=?',
                     (j['brief_id'], j['revision'], stage, fp)).fetchone()
    if saved:
        return saved
    import production_batch
    return production_batch.design_policy(c, j, stage)


def state(c, j, value, e):
    if j['state'] != value:
        c.execute('UPDATE design_jobs SET state=? WHERE brief_id=?', (value, j['brief_id']))
        event(c, j, 'state_changed', {'from': j['state'], 'to': value}, e)
    return {'ok': True, 'brief_id': j['brief_id'], 'revision': j['revision'], 'status': value,
            'listing_code': None, 'kpi_counted': False}


def task(c, j, stage, payload, e):
    fp = e.digest(payload)
    old = c.execute('SELECT * FROM design_tasks WHERE brief_id=? AND revision=? AND stage=? AND fingerprint=?',
                    (j['brief_id'], j['revision'], stage, fp)).fetchone()
    if old:
        return {**dict(old), 'payload': json.loads(old['payload'])}
    tid = str(uuid.uuid4())
    c.execute('INSERT INTO design_tasks VALUES(?,?,?,?,?,?,?,?)',
              (tid, j['brief_id'], j['revision'], stage, fp, 'pending', json.dumps(payload, ensure_ascii=False), e.now()))
    event(c, j, 'task_created', {'task_id': tid, 'stage': stage}, e)
    return {'id': tid, 'brief_id': j['brief_id'], 'revision': j['revision'], 'stage': stage,
            'kind': 'flow_design_' + stage, 'status': 'pending', 'fingerprint': fp, 'payload': payload}


def flow_plan(c, j, stage, e):
    row, b = brief(c, j['brief_id'])
    if row['fingerprint'] != j['brief_fingerprint']:
        raise ValueError('Brief changed after design start')
    settings = json.loads(j['settings'])
    refs = json.loads(j['references_json'])
    locked = checked_assets(c, j, '2d', e) if stage == 'embroidery' else {}
    retained_2d = checked_assets(c, j, '2d', e) if stage == '2d' else {}
    for group in refs.values():
        for ref in group:
            if e.sha(e.scoped(ref['path'])) != ref['sha256']:
                raise ValueError('Supporting reference changed; revise before continuing')
    if stage == 'embroidery' and not approval(c, j, '2d', fingerprint(c, j, '2d', e)):
        raise ValueError('The exact 2D stage requires user approval before preview generation')
    output = e.STORE / 'designs' / j['brief_id'] / ('v%03d' % j['revision']) / stage
    # Apply the current user-wide rule even when a job retained older prompt settings.
    current_prompts = e.read(e.ROOT / 'config/artwork-flow-prompts.json')
    outline_rule = current_prompts['mandatory_outline_rule']
    pack = settings.get('prompt_pack')
    if pack and (pack['brief_fingerprint'] != row['fingerprint'] or e.digest({k: v for k, v in pack.items() if k != 'fingerprint'}) != pack['fingerprint']):
        raise ValueError('Selected prompt pack changed')
    import production_profiles as profiles
    import production_batch as batch
    batch_row, _ = batch.linked(c, brief_id=j['brief_id'])
    batch_correction = profiles.corrections(c, batch_row['batch_id'], stage) if batch_row else ''
    cleanup = current_prompts.get('embroidery_reference_cleanup') if stage == 'embroidery' else None
    if cleanup:
        if cleanup.get('authority') != 'direct_user' or not cleanup.get('reference') or not cleanup.get('instruction', '').strip() or not cleanup.get('after_batch_id'):
            raise ValueError('Embroidery reference cleanup requires explicit user authority and activation batch')
        after = c.execute('SELECT status FROM production_batches WHERE batch_id=?', (cleanup['after_batch_id'],)).fetchone()
        if not after or after['status'] != 'completed' or (batch_row and batch_row['batch_id'] == cleanup['after_batch_id']):
            cleanup = None
    sleeve_template = (e.ROOT / 'workspace/chat-handoff/20261014-prompt-authoring/embroidered-sleeve-2d-vertical-master-v001.txt').read_text(encoding='utf-8-sig')
    result = {'provider': settings['provider'], 'aspect_ratio': '1:1', 'executor': 'independent_flow_worker',
        'requires_active_chrome_profile': 'Đức', 'brief_id': j['brief_id'], 'revision': j['revision'],
        'brief_fingerprint': row['fingerprint'], 'stage': stage, 'output_directory': str(output),
        'images': [{'region': r, 'name': r + '.png',
                    'prompt': ((prompt_body(pack['chest_prompt'] if r == pack['chest_region'] else pack['sleeve_prompt'], outline_rule)
                                if pack else settings['design_2d'] + '\nCONFIRMED REGION: ' + ('left_sleeve' if r == 'right_sleeve' and b['motifs'].get('left_sleeve') == b['motifs'][r] else r) + '\nCONFIRMED MOTIF: ' + b['motifs'][r])
                               if stage == '2d' else settings['embroidery_preview'])
                              + ('\nUSER REQUESTED CORRECTION: ' + settings.get('corrections', {}).get(stage, '')
                                 if settings.get('corrections', {}).get(stage) else '')
                              + '\n' + outline_rule,
                    'references': ([{'path': locked[r]['path'], 'sha256': locked[r]['sha256'], 'role': 'exact_locked_2d'}]
                                   if stage == 'embroidery' else refs.get(r, []))}
                   for r in b['motifs']],
        'complete_only_after': 'Download original files, visually inspect every region and attach real screenshot evidence.'}
    for image in result['images']:
        content = image['prompt'].removesuffix(outline_rule).rstrip()
        compact_sleeve = b.get('mockup_set') == profiles.GARMENT_SET and image['region'].endswith('sleeve')
        if stage == '2d' and image['region'].endswith('sleeve') and profiles.current(b) and not b.get('layout_profile') and not compact_sleeve:
            sleeve_rule = sleeve_template.removesuffix('\n').removesuffix(outline_rule).rstrip()
            sleeve_rule = sleeve_rule.replace('[INSERT THE SLEEVE DESIGN BRIEF FOR THIS ITEM]', b['motifs'][image['region']]).replace('[INSERT THE CURRENT APPROVED BATCH CORRECTIONS; OMIT THIS SECTION WHEN EMPTY]', '')
            content += '\nMANDATORY SHARED SLEEVE COMPOSITION:\n' + sleeve_rule
        if batch_correction:
            content += '\nHUMAN CORRECTIONS FOR THIS ENTIRE BATCH: apply general styling rules here, but a correction naming a different region must not change this region or copy another region\'s motifs.\n' + batch_correction
        if stage == '2d' and b.get('reference_image'):
            import batch_reference
            batch_reference.validate(b['reference_image'], vars(e))
            content += '\n' + batch_reference.GUIDANCE
        if b.get('layout_profile'):
            import embroidery_layout
            layout = embroidery_layout.validate(b['layout_profile'], vars(e))
            if stage == '2d' and not compact_sleeve:
                image['references'].append(embroidery_layout.sleeve_transport(vars(e)) if image['region'].endswith('sleeve') else embroidery_layout.design(layout, image['region']))
                content += '\n' + embroidery_layout.GUIDANCE
            if image['region'].endswith('sleeve'):
                policy = embroidery_layout.canvas_policy(vars(e))
                ratio = policy['flow_aspect_ratio'] if policy else '9:16'
                image.update(aspect_ratio=ratio, output_aspect_ratio=ratio if policy else '7:26')
                content = content.replace('Square 1:1.', '').replace('Tỷ lệ hình 1:1.', '')
                if policy and not compact_sleeve:
                    image['sleeve_canvas_policy'] = policy
                    content += ('\nLATEST USER CANVAS RULE: Aim for one complete upright sleeve composition, HEIGHT:WIDTH 26:7 (WIDTH:HEIGHT 7:26). '
                                f'The Flow canvas is {"portrait" if ratio == "9:16" else "landscape"} {ratio} and its full native output is retained. The composition ratio is a visual goal, '
                                'not an exact pixel crop or mandatory bounding box. Keep all artwork fully visible with natural proportions and clear margins; '
                                'never stretch, clip, add a frame, draw guide rails, or duplicate/mirror the scene. This overrides earlier fixed-margin and exact-crop instructions. ')
                if stage == '2d':
                    content += ('\nConstruct objects as solid filled color shapes without traced exterior edges. Never copy guide lines or pale guide fill. '
                                if policy or compact_sleeve else '\n' + embroidery_layout.SLEEVE)
                    style = next((retained_2d[r] for r in ('center_chest', 'left_chest', 'right_chest') if r in retained_2d), None)
                    if style:
                        image['references'].append({**style, 'role': 'same_listing_fill_style_only'})
                        content += ('\nThe retained chest image is a STYLE-ONLY reference: match its solid-fill construction and absence of exterior contour strokes. '
                                    + ('Keep this sleeve\'s own confirmed objects, counts, composition and palette; never copy the chest motif or arrange the sleeve like the chest. ' if compact_sleeve else
                                       'Keep this sleeve\'s own confirmed objects, counts, composition, palette and 7:26 layout; never copy the chest motif or arrange the sleeve like the chest. '))
                elif not policy and not compact_sleeve:
                    content += ('\nPreserve the entire exact approved 7:26 portrait artwork, no recomposition or extra copy. '
                                'Use a portrait 9:16 transport canvas with only empty white side margins outside the centered 7:26 artwork area. '
                                'The empty margins alone are cropped before review; never stretch, clip, add backing or change any design detail. ')
        if compact_sleeve:
            import embroidery_layout
            policy = embroidery_layout.canvas_policy(vars(e))
            if not policy or policy['flow_aspect_ratio'] != '9:16':
                raise ValueError('Compact sleeve artwork requires the authorized native portrait canvas')
            image.update(aspect_ratio='9:16', output_aspect_ratio='9:16', sleeve_canvas_policy=policy)
            content = content.replace('Square 1:1.', '').replace('Tỷ lệ hình 1:1.', '')
            content += ('\nCOMPACT SLEEVE COMPOSITION: one upright artwork shared unmirrored by both sleeves, on the native portrait 9:16 canvas with clear white margins. '
                        + ('Create broader motif clusters and a shorter overall composition, with natural proportions and balanced breathing gaps. Do not elongate stems, connectors or empty spacing to fill the arm. '
                           'No fixed 26:7 artwork ratio or required 26 cm height; the canvas ratio does not dictate the artwork bounding box. ' if stage == '2d' else
                           'Preserve the exact approved 2D artwork aspect ratio, layout and full content; do not recompose, lengthen, stretch or crop it. ')
                        + 'Keep the entire artwork visible. No visible frame, guide marks, extra motifs or exterior outlines; never rotate the design into a horizontal composition.')
        if cleanup:
            content += '\n' + cleanup['instruction']
        image['prompt'] = content + '\n' + outline_rule
    if cleanup:
        result['embroidery_reference_cleanup'] = cleanup
    if pack and stage == '2d':
        result['prompt_pack_fingerprint'] = pack['fingerprint']
    return result


def advance(c, j, e):
    if j['state'] in ('needs_design_revision', 'cancelled'):
        return state(c, j, j['state'], e)
    for stage in STAGES:
        row, b = brief(c, j['brief_id'])
        items = checked_assets(c, j, stage, e)
        if set(items) != set(b['motifs']):
            result = state(c, j, 'awaiting_design_' + stage, e)
            result['browser_task'] = task(c, j, stage, flow_plan(c, j, stage, e), e)
            result['missing_regions'] = sorted(set(b['motifs']) - set(items))
            return result
        fp = fingerprint(c, j, stage, e)
        if not approval(c, j, stage, fp):
            result = state(c, j, 'awaiting_design_' + stage + '_approval', e)
            result.update(stage=stage, fingerprint=fp, assets=items)
            return result
    if b.get('profile_version') == 3:
        return state(c, j, 'approved_artwork_ready', e)
    sizes=c.execute('SELECT fingerprint FROM design_sizes WHERE brief_id=? AND revision=?',(j['brief_id'],j['revision'])).fetchone()
    ready=bool(sizes and approval(c,j,'sizes',sizes['fingerprint']))
    return state(c, j, 'approved_artwork_and_sizes' if ready else 'approved_artwork_ready_for_sizes', e)


def design_browser_queue(c):
    rows = [dict(r) for r in c.execute('''SELECT t.* FROM design_tasks t JOIN design_jobs j
        ON j.brief_id=t.brief_id AND j.revision=t.revision WHERE t.status='pending'
        AND j.state=('awaiting_design_' || t.stage) ORDER BY t.created_at,t.id LIMIT 10''')]
    for r in rows:
        r['kind'] = 'flow_design_' + r['stage']
        r['payload'] = json.loads(r['payload'])
        present = assets(c, {'brief_id': r['brief_id'], 'revision': r['revision']}, r['stage'])
        r['missing_regions'] = [i['region'] for i in r['payload']['images'] if i['region'] not in present]
    return rows


def execute_design(c, cmd, engine, candidate=False):
    from PIL import Image
    e = SimpleNamespace(**engine)
    action = cmd['action']
    if action == 'design_prompt_pack':
        return stage_prompt_pack(c, cmd, e)
    if action == 'design_queue':
        return {'ok': True, 'jobs': [dict(r) for r in c.execute('SELECT brief_id,revision,state FROM design_jobs ORDER BY created_at,brief_id')],
                'tasks': design_browser_queue(c)}
    if action == 'design_start':
        authority(cmd)
        row, b = brief(c, cmd['brief_id'])
        if cmd.get('brief_fingerprint') != row['fingerprint']:
            raise ValueError('Brief approval fingerprint differs')
        old = c.execute('SELECT 1 FROM design_jobs WHERE brief_id=?', (cmd['brief_id'],)).fetchone()
        if old:
            existing=job(c,cmd['brief_id'])
            if 'prompt_pack_fingerprint' in cmd:
                selected = json.loads(existing['settings']).get('prompt_pack', {}).get('fingerprint')
                if cmd.get('revision') != existing['revision'] or cmd['prompt_pack_fingerprint'] != selected:
                    raise ValueError('Existing prompts/revision differ; use explicit design_revise')
            if 'references' in cmd and cmd['references'] != json.loads(existing['references_json']):
                raise ValueError('Existing references differ; use a new brief or explicit design revision')
            return advance(c, job(c, cmd['brief_id']), e)
        refs = cmd.get('references', {})
        if not isinstance(refs, dict) or not set(refs) <= set(b['motifs']):
            raise ValueError('References must belong to confirmed regions')
        for group in refs.values():
            if not isinstance(group, list):
                raise ValueError('Regional references must be lists')
            for a in group:
                path = e.scoped(a['path'])
                if e.sha(path) != a['sha256']:
                    raise ValueError('Reference changed')
                with Image.open(path) as im:
                    im.verify()
        settings = e.read(e.ROOT / 'config/artwork-flow-prompts.json')
        if 'prompt_pack_fingerprint' in cmd:
            if cmd.get('revision') is not None:
                raise ValueError('A new design has no source revision')
            if refs.get('left_sleeve', []) != refs.get('right_sleeve', []):
                raise ValueError('Two-prompt intake requires identical supporting sleeve references')
            settings['prompt_pack'] = load_prompt_pack(c, cmd, row, None, e)
        c.execute('INSERT INTO design_jobs VALUES(?,?,?,?,?,?,?)',
                  (b['brief_id'], 1, 'queued', row['fingerprint'], json.dumps(settings, ensure_ascii=False), json.dumps(refs, ensure_ascii=False), e.now()))
        j = job(c, b['brief_id'])
        c.execute('INSERT INTO design_approvals VALUES(?,?,?,?,?,?)',
                  (b['brief_id'], 1, 'brief', row['fingerprint'], cmd['reference'], e.now()))
        event(c, j, 'started', {'approval_reference': cmd['reference']}, e)
        return advance(c, j, e)
    j = job(c, cmd['brief_id'])
    if action in ('design_status', 'design_advance'):
        return advance(c, j, e)
    if cmd.get('revision') != j['revision']:
        raise ValueError('Current design revision required')
    if action == 'design_cancel':
        authority(cmd)
        if cmd.get('brief_fingerprint') != j['brief_fingerprint']:
            raise ValueError('Cancellation brief fingerprint differs')
        if j['state'].startswith('approved_artwork') or c.execute("SELECT 1 FROM reservations WHERE brief_id=? AND status IN ('reserved','counted')", (j['brief_id'],)).fetchone():
            raise ValueError('Cancel only unfinished, unallocated design work')
        cancelled = c.execute("UPDATE design_tasks SET status='superseded' WHERE brief_id=? AND status='pending'", (j['brief_id'],)).rowcount
        event(c, j, 'cancelled', {'reference': cmd['reference'], 'cancelled_tasks': cancelled}, e)
        return {**state(c, j, 'cancelled', e), 'cancelled_tasks': cancelled, 'existing_assets_approvals_preserved': True}
    if j['state'] == 'cancelled':
        raise ValueError('Cancelled design cannot be changed or resumed')
    stage = cmd.get('stage')
    if action not in ('design_plan','design_approve_sizes') and stage not in STAGES:
        raise ValueError('Stage must be 2d or embroidery')
    if action == 'design_approve':
        authority(cmd)
        existing_fp=fingerprint(c,j,stage,e)
        if cmd.get('fingerprint')==existing_fp and approval(c,j,stage,existing_fp):
            return advance(c,j,e)
        result = advance(c, j, e)
        if result['status'] != 'awaiting_design_' + stage + '_approval':
            raise ValueError('Design is not awaiting this stage approval')
        fp = fingerprint(c, j, stage, e)
        if cmd.get('fingerprint') != fp:
            raise ValueError('Design approval fingerprint differs')
        c.execute('INSERT OR REPLACE INTO design_approvals VALUES(?,?,?,?,?,?)',
                  (j['brief_id'], j['revision'], stage, fp, cmd['reference'], e.now()))
        event(c, j, 'approved', {'stage': stage, 'fingerprint': fp, 'reference': cmd['reference']}, e)
        return advance(c, job(c, j['brief_id']), e)
    if action == 'design_attach':
        t = c.execute('SELECT * FROM design_tasks WHERE id=?', (cmd['task_id'],)).fetchone()
        if not t or t['brief_id'] != j['brief_id'] or t['revision'] != j['revision'] or t['stage'] != stage or t['status'] not in ('pending','assets_attached'):
            raise ValueError('A current pending task for this exact brief/revision/stage is required')
        if t['status']=='assets_attached':
            present=checked_assets(c,j,stage,e)
            incoming=cmd.get('assets',{})
            specs={i['region']:i for i in json.loads(t['payload'])['images']}
            import embroidery_layout
            directory=(e.STORE/'designs'/j['brief_id']/('v%03d'%j['revision'])/stage).resolve()
            if any(not e.scoped(a['path']).is_relative_to(directory) for a in incoming.values()):
                raise ValueError('Keep new artwork in its brief/revision/stage output directory')
            incoming={r:embroidery_layout.normalize(a,vars(e))[0] if specs.get(r,{}).get('output_aspect_ratio') in ('7:26','9:16','16:9') else a for r,a in incoming.items()}
            if not incoming or any(r not in present or present[r]!={'path':str(e.scoped(a['path'])),'sha256':a['sha256']} for r,a in incoming.items()):
                raise ValueError('Completed attachment differs; revise before changing artwork')
            return advance(c,j,e)
        if j['state'] != 'awaiting_design_' + stage:
            raise ValueError('Design is not awaiting these assets')
        payload = json.loads(t['payload'])
        if e.digest(payload) != t['fingerprint']:
            raise ValueError('Task payload changed')
        if stage == 'embroidery':
            if not approval(c, j, '2d', fingerprint(c, j, '2d', e)):
                raise ValueError('2D approval missing/invalid')
            for item in payload['images']:
                for ref in item['references']:
                    if e.sha(e.scoped(ref['path'])) != ref['sha256']:
                        raise ValueError('Locked 2D reference changed')
        proof = cmd.get('proof', {})
        chatgpt_candidate = candidate and proof.get('executor') in ('independent_chatgpt_worker', 'codex_chatgpt_browser')
        if chatgpt_candidate:
            from chatgpt_image_orchestration import verify_proof
            verify_proof(proof, vars(e))
        elif candidate:
            from flow_lark_orchestration import verify_candidate_proof
            verify_candidate_proof(proof, vars(e), c)
        elif (not candidate and proof.get('visually_verified') is not True) or proof.get('model') != 'Nano Banana Pro' or not str(proof.get('url', '')).startswith('https://flow.google.com/'):
            raise ValueError('Real Flow UI proof and visual verification on Pro are required')
        if candidate and (proof.get('visually_verified') is True or proof.get('executor') not in ('independent_flow_worker', 'independent_chatgpt_worker', 'codex_chatgpt_browser')):
            raise ValueError('Independent candidate cannot claim operator visual verification')
        screenshot = e.scoped(proof['screenshot_path'])
        if not screenshot.is_file():
            raise ValueError('Flow screenshot missing')
        with Image.open(screenshot) as im:
            im.verify()
        incoming = cmd['assets']
        row, b = brief(c, j['brief_id'])
        if not isinstance(incoming, dict) or not incoming or not set(incoming) <= set(b['motifs']):
            raise ValueError('Assets must name confirmed regions')
        present = assets(c, j, stage)
        normalization = []
        for region, a in incoming.items():
            path = e.scoped(a['path'])
            if not path.is_relative_to((e.STORE / 'designs' / j['brief_id'] / ('v%03d' % j['revision']) / stage).resolve()):
                raise ValueError('Keep new artwork in its brief/revision/stage output directory')
            if e.sha(path) != a['sha256']:
                raise ValueError('Design asset hash differs')
            with Image.open(path) as im:
                im.verify()
            spec = next(i for i in payload['images'] if i['region'] == region)
            if spec.get('output_aspect_ratio') in ('7:26','9:16','16:9'):
                import embroidery_layout
                a, receipt = embroidery_layout.normalize(a, vars(e))
                path = e.scoped(a['path'])
                if receipt:
                    normalization.append(dict(receipt, region=region))
            with Image.open(path) as im:
                ratio = spec.get('output_aspect_ratio', '1:1')
                import embroidery_layout
                if not embroidery_layout.output_ratio_ok(im.width, im.height, ratio, vars(e)) or im.format not in ('PNG', 'JPEG', 'WEBP'):
                    raise ValueError('Flow design does not match its required raster aspect ratio')
            saved = {'path': str(path), 'sha256': a['sha256']}
            if region in present and present[region] != saved:
                raise ValueError('Do not replace an attached asset; revise the design first')
            if region not in present:
                c.execute('INSERT INTO design_assets VALUES(?,?,?,?,?,?)',
                          (j['brief_id'], j['revision'], stage, region, e.digest(saved), json.dumps(saved)))
        event(c, j, 'assets_attached', {'stage': stage, 'regions': list(incoming), 'proof': proof, 'canvas_normalization': normalization}, e)
        if set(assets(c, j, stage)) == set(b['motifs']):
            c.execute("UPDATE design_tasks SET status='assets_attached' WHERE id=?", (t['id'],))
        return advance(c, j, e)
    if action == 'design_revise':
        authority(cmd)
        if not str(cmd.get('reason', '')).strip():
            raise ValueError('Describe the requested correction')
        if c.execute("SELECT 1 FROM reservations WHERE brief_id=? AND status IN ('reserved','counted')", (j['brief_id'],)).fetchone():
            raise ValueError('Already linked to a dated listing; revise its source/plan through production before changing art')
        kept = None
        retained = {}
        retain_revision = cmd.get('retain_from_revision', j['revision'])
        if type(retain_revision) is not int or not 1 <= retain_revision <= j['revision'] or ('retain_from_revision' in cmd and not cmd.get('retain_regions')):
            raise ValueError('Retain assets only from an existing revision of this same brief')
        if cmd.get('retain_regions'):
            regions = cmd['retain_regions']
            if stage != '2d' or not isinstance(regions, list) or len(set(regions)) != len(regions):
                raise ValueError('Retain confirmed regions only while revising the 2D stage')
            present = checked_assets(c, dict(j, revision=retain_revision), '2d', e)
            if not set(regions) <= set(present):
                raise ValueError('Retained regions must already have verified native attachments')
            retained = {r: present[r] for r in regions}
        if stage == 'embroidery':
            fp = fingerprint(c, j, '2d', e)
            kept = approval(c, j, '2d', fp)
            if not kept:
                raise ValueError('Approved 2D is required to revise only the preview')
        settings = json.loads(j['settings'])
        if 'prompt_pack_fingerprint' in cmd:
            if stage != '2d':
                raise ValueError('A 2D prompt pack can only revise the 2D stage')
            row, b = brief(c, j['brief_id'])
            settings['prompt_pack'] = load_prompt_pack(c, cmd, row, j['revision'], e)
        settings.setdefault('corrections', {})[stage] = cmd['reason']
        import production_batch as batch
        import production_profiles as profiles
        batch_row, _ = batch.linked(c, brief_id=j['brief_id'])
        if batch_row:
            profiles.save_correction(c, batch_row['batch_id'], stage, cmd['reason'], cmd['reference'])
        if stage == '2d':
            settings['corrections'].pop('embroidery', None)
        c.execute('UPDATE design_jobs SET revision=revision+1,state=?,settings=? WHERE brief_id=?',
                  ('queued', json.dumps(settings, ensure_ascii=False), j['brief_id']))
        c.execute("UPDATE design_tasks SET status='superseded' WHERE brief_id=? AND revision=? AND status='pending'", (j['brief_id'], j['revision']))
        new = job(c, j['brief_id'])
        row, b = brief(c, j['brief_id'])
        c.execute('INSERT INTO design_approvals VALUES(?,?,?,?,?,?)',
                  (j['brief_id'], new['revision'], 'brief', row['fingerprint'], cmd['reference'], e.now()))
        for region, a in retained.items():
            c.execute('INSERT INTO design_assets VALUES(?,?,?,?,?,?)',
                      (j['brief_id'], new['revision'], '2d', region, e.digest(a), json.dumps(a)))
        if retained:
            for prior in c.execute("SELECT payload FROM design_events WHERE brief_id=? AND revision=? AND kind='assets_attached'", (j['brief_id'], retain_revision)).fetchall():
                payload = json.loads(prior['payload'])
                regions = sorted(set(payload.get('regions', [])) & set(retained))
                if payload.get('stage') == '2d' and regions:
                    event(c, new, 'assets_attached', dict(payload, regions=regions, retained_from_revision=retain_revision), e)
        if kept:
            for region, a in checked_assets(c, j, '2d', e).items():
                c.execute('INSERT INTO design_assets VALUES(?,?,?,?,?,?)',
                          (j['brief_id'], new['revision'], '2d', region, e.digest(a), json.dumps(a)))
            c.execute('INSERT INTO design_approvals VALUES(?,?,?,?,?,?)',
                      (j['brief_id'], new['revision'], '2d', fingerprint(c, new, '2d', e), kept[0], e.now()))
        event(c, new, 'revised', {'prior_revision': j['revision'], 'stage': stage, 'reason': cmd['reason'], 'reference': cmd['reference'], 'retained_from_revision': retain_revision if retained else None, 'retained_regions': sorted(retained)}, e)
        return advance(c, new, e)
    if action == 'design_approve_sizes':
        authority(cmd)
        result=execute_design(c,{'action':'design_plan','brief_id':j['brief_id'],'revision':j['revision']},engine)
        if cmd.get('fingerprint')!=result['size_fingerprint']:
            raise ValueError('Size approval must match the saved proposal')
        c.execute('INSERT OR REPLACE INTO design_approvals VALUES(?,?,?,?,?,?)',
                  (j['brief_id'],j['revision'],'sizes',result['size_fingerprint'],cmd['reference'],e.now()))
        event(c,j,'sizes_approved',{'fingerprint':result['size_fingerprint'],'reference':cmd['reference']},e)
        return execute_design(c,{'action':'design_plan','brief_id':j['brief_id'],'revision':j['revision']},engine)
    if action == 'design_plan':
        if advance(c, j, e)['status'] not in ('approved_artwork_ready_for_sizes','approved_artwork_and_sizes','approved_artwork_ready'):
            raise ValueError('Approve both exact design stages before resolving sizes')
        row, b = brief(c, j['brief_id'])
        if b.get('profile_version') == 3:
            import production_profiles
            functions = SimpleNamespace(fingerprint=fingerprint, approval=approval, checked_assets=checked_assets)
            return production_profiles.design_plan(c, j, b, functions, e)
        fp = fingerprint(c, j, 'embroidery', e)
        ref = approval(c, j, 'embroidery', fp)[0]
        cached=c.execute('SELECT * FROM design_sizes WHERE brief_id=? AND revision=?',(j['brief_id'],j['revision'])).fetchone()
        bounds=cmd.get('bounds_px',{})
        if not isinstance(bounds,dict) or not set(bounds)<=set(assets(c,j,'embroidery')):
            raise ValueError('Size bounds must belong to confirmed artwork regions')
        if cached and 'bounds_px' in cmd and bounds!=json.loads(cached['bounds_json']):
            authority(cmd)
            if c.execute("SELECT 1 FROM reservations WHERE brief_id=? AND status IN ('reserved','counted')",(j['brief_id'],)).fetchone():
                raise ValueError('Sizes already linked to a dated listing; revise through production')
            event(c,j,'size_bounds_revised',{'old_result':json.loads(cached['result']),'bounds':bounds,'reference':cmd['reference']},e)
            c.execute("DELETE FROM design_approvals WHERE brief_id=? AND revision=? AND stage='sizes'",(j['brief_id'],j['revision']))
            cached=None
        if not cached:
            artwork = checked_assets(c, j, 'embroidery', e)
            for region, a in artwork.items():
                a['artwork_approval_reference'] = ref
                a['design_brief_id'] = j['brief_id']
                a['design_revision'] = j['revision']
                a['design_fingerprint'] = fp
                if region in bounds:
                    a['bounds_px'] = bounds[region]
            result=e.resolve_plan(c, {'brief_id': j['brief_id'], 'artwork': artwork})
            size_fp=e.digest(result['plan'])
            c.execute('INSERT OR REPLACE INTO design_sizes VALUES(?,?,?,?,?,?)',
                      (j['brief_id'],j['revision'],size_fp,json.dumps(bounds),json.dumps(result,ensure_ascii=False),e.now()))
            event(c,j,'sizes_resolved_once',{'size_fingerprint':size_fp},e)
        else:
            result=json.loads(cached['result']);size_fp=cached['fingerprint']
        result['size_fingerprint']=size_fp
        size_ref=approval(c,j,'sizes',size_fp)
        if size_ref:
            result['status']='approved_artwork_and_sizes'
            for a in result['plan']['regions'].values():
                a['size_approval_reference']=size_ref[0]
            result['note']='Approved artwork and stored sizes are ready for production handoff; reuse without recalculating.'
        state(c,job(c,j['brief_id']),'approved_artwork_and_sizes' if size_ref else 'approved_artwork_ready_for_sizes',e)
        return result
    raise ValueError('Unknown design action')
