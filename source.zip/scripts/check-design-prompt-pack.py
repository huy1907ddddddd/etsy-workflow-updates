"""Isolated prompt intake checks; never call Flow or mutate live approvals."""
import copy
import importlib.util
import json
import tempfile
from pathlib import Path
from PIL import Image

spec = importlib.util.spec_from_file_location('engine', Path(__file__).with_name('production-engine.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
checks = []


def check(name, value):
    assert value, name
    checks.append(name)


def fails(cmd):
    try:
        m.execute(c, cmd)
    except (ValueError, KeyError):
        return True
    return False


with tempfile.TemporaryDirectory(prefix='prompt-pack-test-', dir=m.STORE) as tmp:
    m.STORE = Path(tmp)
    m.JOBS = m.STORE / 'jobs'
    m.JOBS.mkdir()
    c = m.connect(m.STORE / 'isolated.sqlite')
    b = {'brief_id': 'prompt-pack-fixture', 'topic_code': 'ANM', 'product_type': 'physical_apparel',
         'product_id': 'fixture', 'garment': 'crewneck', 'color': 'sand',
         'available_styles': ['crewneck sweatshirt'], 'motifs': {'center_chest': 'four otters',
         'left_sleeve': 'one connected bakery corner', 'right_sleeve': 'one connected bakery corner'},
         'back_artwork': False, 'personalization': {'enabled': False}, 'sources': []}
    received = m.execute(c, {'action': 'receive_brief', 'brief': b})
    stage = {'action': 'design_prompt_pack', 'brief_id': b['brief_id'],
             'brief_fingerprint': received['brief_fingerprint'], 'authority': 'direct_user',
             'reference': 'isolated fixture command, not real approval',
             'prompt_pack': {'chest_region': 'center_chest', 'chest_prompt': 'Exactly four bakery otters.',
                             'sleeve_prompt': 'A connected tall narrow bakery corner; art height:width 26:7.'}}
    rule = m.read(m.ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    check('Reject foreign brief fingerprint', fails({**stage, 'brief_fingerprint': 'wrong'}))
    check('Reject fabricated authority', fails({**stage, 'authority': 'attached_document'}))
    for label, data in [('blank', {'chest_prompt': '  '}), ('too long', {'sleeve_prompt': 'x' * 30001}),
                        ('references', {'references': []}), ('wrong chest', {'chest_region': 'left_chest'}),
                        ('model', {'provider': 'other'}), ('canvas', {'aspect_ratio': '26:7'}),
                        ('embedded rule', {'chest_prompt': rule + '\nDraw otters.'})]:
        check('Reject ' + label, fails({**stage, 'prompt_pack': {**stage['prompt_pack'], **data}}))
    pack = m.execute(c, stage)
    check('Staging is inert', pack['status'] == 'prompt_pack_staged' and pack['source_revision'] is None
          and not pack['generation_started'] and not pack['artwork_approved']
          and all(c.execute('SELECT COUNT(*) FROM ' + table).fetchone()[0] == 0
                  for table in ['design_jobs', 'design_tasks', 'design_approvals', 'reservations', 'kpi']))
    check('Retry preserves fingerprint and immutable stored record',
          m.execute(c, {**stage, 'reference': 'retry'})['prompt_pack_fingerprint'] == pack['prompt_pack_fingerprint']
          and c.execute("SELECT COUNT(*) FROM config WHERE key LIKE 'design_prompt_pack:%'").fetchone()[0] == 1)
    check('Duplicate final outline suffix normalizes once', m.execute(c, {**stage, 'prompt_pack': {
          **stage['prompt_pack'], 'chest_prompt': stage['prompt_pack']['chest_prompt'] + '\n' + rule + '\n' + rule}})
          ['prompt_pack_fingerprint'] == pack['prompt_pack_fingerprint'])
    start = {**stage, 'action': 'design_start', 'prompt_pack_fingerprint': pack['prompt_pack_fingerprint']}
    started = m.execute(c, start)
    images = started['browser_task']['payload']['images']
    check('Custom raw text reaches task without template additions', images[0]['prompt'] == stage['prompt_pack']['chest_prompt'] + '\n' + rule)
    check('Shared sleeves have identical text and refs', images[1]['prompt'] == images[2]['prompt']
          == stage['prompt_pack']['sleeve_prompt'] + '\n' + rule and images[1]['references'] == images[2]['references'])
    check('Task exposes selected immutable pack fingerprint', started['browser_task']['payload']['prompt_pack_fingerprint'] == pack['prompt_pack_fingerprint'])
    check('Existing start needs exact revision when selecting pack', fails(start))
    check('Explicit exact start retry reuses task', m.execute(c, {**start, 'revision': 1})['browser_task']['id'] == started['browser_task']['id'])
    check('Stage on existing job requires revision', fails(stage))
    next_stage = {**stage, 'revision': 1, 'prompt_pack': {**stage['prompt_pack'], 'chest_prompt': 'Four otters, new composition.'}}
    next_pack = m.execute(c, next_stage)
    check('Staging preserves live task and settings', c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0] == 1
          and json.loads(c.execute('SELECT settings FROM design_jobs').fetchone()[0])['prompt_pack']['fingerprint'] == pack['prompt_pack_fingerprint'])
    check('Cannot silently replace active prompt at start', fails({**start, 'revision': 1, 'prompt_pack_fingerprint': next_pack['prompt_pack_fingerprint']}))
    check('References cannot silently change on retry', fails({**start, 'revision': 1, 'references': {'center_chest': []}}))
    # Synthetic approved history proves a 2D revision does not copy old approvals downstream.
    for s in ('2d', 'embroidery'):
        c.execute('INSERT INTO design_approvals VALUES(?,?,?,?,?,?)', (b['brief_id'], 1, s, 'fixture-only', 'fixture-only', m.now()))
    revise = {**stage, 'action': 'design_revise', 'revision': 1, 'stage': '2d',
              'prompt_pack_fingerprint': next_pack['prompt_pack_fingerprint'], 'reason': 'Use the supplied replacement composition.'}
    check('Cannot select a 2D pack for embroidery', fails({**revise, 'stage': 'embroidery'}))
    revised = m.execute(c, revise)
    check('Explicit revision starts new 2D and supersedes pending history', revised['revision'] == 2
          and revised['status'] == 'awaiting_design_2d'
          and c.execute("SELECT status FROM design_tasks WHERE revision=1").fetchone()[0] == 'superseded'
          and c.execute("SELECT COUNT(*) FROM design_approvals WHERE revision=1 AND stage IN ('2d','embroidery')").fetchone()[0] == 2
          and c.execute("SELECT COUNT(*) FROM design_approvals WHERE revision=2 AND stage IN ('2d','embroidery')").fetchone()[0] == 0)
    check('Correction precedes one mandatory suffix', revised['browser_task']['payload']['images'][0]['prompt'] ==
          next_stage['prompt_pack']['chest_prompt'] + '\nUSER REQUESTED CORRECTION: ' + revise['reason'] + '\n' + rule)
    check('Stale stage/source pack rejected', fails(next_stage) and fails({**revise, 'revision': 2}))
    c.commit()
    c.close()
    c = m.connect(m.STORE / 'isolated.sqlite')
    check('Staged pack and current task survive DB reopen', m.execute(c, {'action': 'design_status', 'brief_id': b['brief_id']})['browser_task']['id'] == revised['browser_task']['id'])
    for label, alterations in [('back', {'back_artwork': True, 'motifs': {**b['motifs'], 'back': 'bakery sign'}}),
                               ('asymmetric', {'motifs': {**b['motifs'], 'right_sleeve': 'different'}}),
                               ('left chest', {'motifs': {'left_chest': 'otters', 'left_sleeve': 'same', 'right_sleeve': 'same'}})]:
        other = {**copy.deepcopy(b), **alterations, 'brief_id': 'fixture-' + label.replace(' ', '-')}
        r = m.execute(c, {'action': 'receive_brief', 'brief': other})
        s = {**stage, 'brief_id': other['brief_id'], 'brief_fingerprint': r['brief_fingerprint']}
        if label != 'left chest':
            check('Reject unsupported ' + label, fails(s))
        else:
            check('Maps exact confirmed left chest when requested', m.execute(c, {**s, 'prompt_pack': {**s['prompt_pack'], 'chest_region': 'left_chest'}})['prompt_pack']['chest_region'] == 'left_chest')
    legacy = {**copy.deepcopy(b), 'brief_id': 'fixture-legacy'}
    r = m.execute(c, {'action': 'receive_brief', 'brief': legacy})
    result = m.execute(c, {**stage, 'action': 'design_start', 'brief_id': legacy['brief_id'], 'brief_fingerprint': r['brief_fingerprint']})
    expected = m.read(m.ROOT / 'config/artwork-flow-prompts.json')['design_2d'] + '\nCONFIRMED REGION: center_chest\nCONFIRMED MOTIF: four otters\n' + rule
    check('Original brief template path remains unchanged', result['browser_task']['payload']['images'][0]['prompt'] == expected
          and 'prompt_pack_fingerprint' not in result['browser_task']['payload'])
    ref_brief = {**copy.deepcopy(b), 'brief_id': 'fixture-references'}
    r = m.execute(c, {'action': 'receive_brief', 'brief': ref_brief})
    ref_stage = {**stage, 'brief_id': ref_brief['brief_id'], 'brief_fingerprint': r['brief_fingerprint']}
    ref_pack = m.execute(c, ref_stage)
    ref_path = m.STORE / 'reference.png'
    Image.new('RGB', (20, 20), 'white').save(ref_path)
    reference = {'path': str(ref_path), 'sha256': m.sha(ref_path)}
    ref_start = {**ref_stage, 'action': 'design_start', 'prompt_pack_fingerprint': ref_pack['prompt_pack_fingerprint'],
                 'references': {'left_sleeve': [reference], 'right_sleeve': [reference]}}
    check('Reject two-image pack with different supporting sleeve refs', fails({**ref_start, 'references': {'left_sleeve': [reference]}}))
    ref_result = m.execute(c, ref_start)
    check('Valid shared reference remains exact for both sleeves', ref_result['browser_task']['payload']['images'][1]['references']
          == ref_result['browser_task']['payload']['images'][2]['references'] == [reference])
    ref_path.write_bytes(b'changed')
    check('Changed supporting file hash blocks current pack execution', fails({'action': 'design_advance', 'brief_id': ref_brief['brief_id']}))
    key = 'design_prompt_pack:' + b['brief_id'] + ':' + next_pack['prompt_pack_fingerprint']
    saved = json.loads(c.execute('SELECT value FROM config WHERE key=?', (key,)).fetchone()[0])
    saved['pack']['chest_prompt'] = 'tampered'
    c.execute('UPDATE config SET value=? WHERE key=?', (json.dumps(saved), key))
    check('Stored prompt pack tampering rejects fingerprint', fails({**revise, 'revision': 2}))
    c.close()
print(json.dumps({'ok': True, 'checks': len(checks), 'isolated_database': True, 'flow_called': False, 'live_approval_created': False}))
