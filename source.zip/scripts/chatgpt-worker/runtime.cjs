'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { FlowRuntime } = require('../flow-worker/runtime.cjs');
const { ChatGPTBrowser } = require('./browser.cjs');
const { atomic } = require('../flow-worker/native-n8n.cjs');
const { createHash } = require('node:crypto');
const hash = value => createHash('sha256').update(value).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
class ChatGPTRuntime extends FlowRuntime {
  status(value) { return super.status({ ...value, worker_provider: 'chatgpt_chat' }); }
  file(id) { return path.join(this.config.stateDir, 'chatgpt-task-' + hash(id) + '.json'); }
  async notifyLark(status) {
    const config = read(this.config.larkConfigFile);
    const response = await fetch(this.config.larkBaseUrl + '/worker-status', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': config.localToken },
      body: JSON.stringify({ ...status, message: 'Worker ChatGPT Chat: ' + status.code + '. Checkpoint Flow và ChatGPT được giữ nguyên.' }), signal: AbortSignal.timeout(5000), redirect: 'error' });
    if (!response.ok) throw Error('worker_notification_pending');
  }
  async tick({ readinessOnly = false } = {}) {
    const choice = JSON.parse(fs.readFileSync(path.join(this.config.stateDir, 'image-provider.json'), 'utf8'));
    if (choice.provider !== 'chatgpt') { await this.stop(); return this.status({ status: 'switching_to_flow' }); }
    if (['manual_login', 'extension', 'extension_production'].includes(choice.mode)) {
      if (this.browserStarted) { await this.adapter.close(); this.browserStarted = false; }
      if (choice.mode === 'extension_production') {
        const snapshot = await this.native.execute({ action: 'chatgpt_cycle' });
        if (snapshot.ok !== true || !Array.isArray(snapshot.tasks)) throw Error('native_snapshot_invalid');
        return this.status({ status: 'awaiting_browser_extension_session', browser_control_active: false,
          requires_active_codex_session: true, pending_jobs: snapshot.tasks.length,
          queue_issues: snapshot.queue_issues || [], native_observed_at: snapshot.observed_at });
      }
      return this.status({ status: choice.mode === 'extension' ? 'awaiting_browser_extension_session' : 'awaiting_manual_login', browser_control_active: false });
    }
    if (!this.browserStarted) { await this.adapter.start(); this.browserStarted = true; }
    const ready = await this.adapter.readiness();
    if (!ready.ready) return this.block(ready.code);
    const lark = await this.larkReadiness();
    if (!lark.ready) return this.block(lark.code);
    if(readinessOnly)return this.status({status:'ready',browser_control_active:true,readiness_only:true});
    const snapshot = await this.native.execute({ action: 'chatgpt_cycle' });
    if (snapshot.ok !== true || Date.now() - Date.parse(snapshot.observed_at) > this.config.maxSnapshotAgeMs) throw Error('native_snapshot_stale');
    if(!snapshot.tasks.length && snapshot.queue_issues?.length)return this.block('chatgpt_source_reconcile_required',snapshot.queue_issues[0].task_id);
    if (!snapshot.tasks.length) { await this.native.cycle(); return this.status({ status: 'idle', pending_reviews: snapshot.reviews.length }); }
    const job = snapshot.tasks[0];
    const quality = read(path.join(this.config.workflowRoot, 'config/artwork-approved-quality-standard.json'));
    (quality.assets || []).forEach(ref => this.asset(ref));
    if (!job.source_task.kind.startsWith('flow_design_')) read(path.join(this.config.workflowRoot, 'config/mockup-wardrobe-standard.json'));
    const file = this.file(job.id), identity = hash(JSON.stringify(job));
    const state = fs.existsSync(file) ? read(file) : { job_id: job.id, identity, source_fingerprint: job.source_task.fingerprint, images: {}, events: [] };
    if (state.identity !== identity) throw Error('checkpoint_task_identity_changed');
    if (!state.command) for (const item of job.images) {
      const key = item.region || item.name;
      if (state.images[key]?.status === 'acquired') { this.asset(state.images[key].asset); continue; }
      const refs = item.references || Object.entries(job.source_task.payload.references || {}).map(([region,ref])=>({...ref,region}));
      refs.forEach(ref => this.asset(ref));
      const rule = read(path.join(this.config.workflowRoot, 'config/artwork-flow-prompts.json')).mandatory_outline_rule;
      if (!item.prompt.trimEnd().endsWith(rule)) throw Error('mandatory_outline_rule_missing');
      const same = job.source_task.kind.startsWith('flow_design_') && job.images.find(other => state.images[other.region || other.name]?.status === 'acquired' && other.prompt === item.prompt && JSON.stringify((other.references || []).map(r=>r.sha256).sort()) === JSON.stringify(refs.map(r=>r.sha256).sort()));
      if (same) { state.images[key] = { ...state.images[same.region || same.name] }; atomic(file, state); continue; }
      this.status({ status: state.images[key]?.status === 'generation_started' ? 'waiting_generation' : 'preparing_chatgpt', task_id: job.id, image_key: key });
      const result = await this.adapter.generate(item, refs, job.output_directory, {
        resume: state.images[key] || null, jobId: job.id, chatPreferences:job.chat_preferences,
        beforeGenerate: async metadata => {
          const live = await this.native.execute({ action: 'chatgpt_cycle' });
          if (!live.tasks.some(t => t.id === job.id && hash(JSON.stringify(t)) === identity)) throw Error('task_changed_before_generation');
          state.images[key] = { status: 'generation_started', ...metadata }; atomic(file, state);
          this.status({ status: 'waiting_generation', task_id: job.id, image_key: key });
        },
        checkpoint: async record => { state.images[key] = { ...state.images[key], ...record }; atomic(file, state); },
      });
      const asset = this.asset(result.asset, job.output_directory);
      state.images[key] = { ...state.images[key], ...result, asset, status: 'acquired' }; atomic(file, state);
    }
    if (!state.command) {
      const assets = job.images.map(i => ({ image_key: i.region || i.name, ...state.images[i.region || i.name].asset }));
      if (!job.source_task.kind.startsWith('flow_design_') && new Set(assets.map(a=>a.sha256)).size !== assets.length) throw Error('mockup_originals_must_be_distinct');
      const records = job.images.map(i => ({ image_key: i.region || i.name, ...state.images[i.region || i.name].proof }));
      state.command = { action: 'chatgpt_image_attach', job_id: job.id, source_fingerprint: job.source_task.fingerprint, assets,
        proof: { ...records[0], images: records, prompt_provenance: records.map(r => ({ image_key: r.image_key, prompt_sha256: r.prompt_sha256, reference_sha256: r.reference_sha256 })) } };
      state.status = 'submit_pending'; atomic(file, state);
    }
    state.result = await this.native.execute(state.command); state.status = 'submitted'; atomic(file, state);
    await this.native.cycle();
    await this.recoverNotice();
    return this.status({ status: job.test_only ? 'chatgpt_test_completed' : 'awaiting_human_review', task_id: job.id, assets: state.command.assets });
  }
}
async function main(config) {
  const worker = new ChatGPTRuntime(config, { adapter: new ChatGPTBrowser(config) });
  process.once('SIGINT', () => worker.stop()); process.once('SIGTERM', () => worker.stop());
  await worker.run({ once: process.argv.includes('--once'), readinessOnly: process.argv.includes('--check') });
}
module.exports = { ChatGPTRuntime, main };
