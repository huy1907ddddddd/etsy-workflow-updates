'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash, randomUUID } = require('node:crypto');
const { atomic } = require('../flow-worker/native-n8n.cjs');
const hash = value => createHash('sha256').update(value).digest('hex');
const norm = text => text.replace(/\s+/g, ' ').trim();
const { FlowBrowser } = require('../flow-worker/flow-browser.cjs');
class ChatGPTBrowser extends FlowBrowser {
  composer() { return this.page.locator('[contenteditable="true"]:visible,textarea[aria-label="Ask ChatGPT"]:visible,textarea[aria-label="Hỏi ChatGPT"]:visible'); }
  async close() { await super.close(); this.context = undefined; this.chatStarted = false; }
  async start() {
    if (this.chatStarted) return;
    await this.launch();
    this.page = this.context.pages().find(p => /^https:\/\/chatgpt\.com\//.test(p.url())) || await this.context.newPage();
    this.page.setDefaultTimeout(this.timeout);
    this.attachDiagnosticEvents();
    if (!/^https:\/\/chatgpt\.com\//.test(this.page.url())) await this.page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded' });
    await this.page.bringToFront();
    this.chatStarted = true;
    await this.inspect();
  }
  async inspect() {
    if (!/^https:\/\/chatgpt\.com\//.test(this.page.url())) return;
    const text = await this.page.locator('body').innerText();
    const controls = await this.page.locator('button,a,input,textarea,[contenteditable="true"]').evaluateAll(es => es.filter(e => e.getClientRects().length).map(e => ({ tag: e.tagName, role: e.getAttribute('role'), label: e.getAttribute('aria-label'), text: e.textContent?.trim(), placeholder: e.getAttribute('placeholder'), id: e.id, testid: e.getAttribute('data-testid'), type: e.getAttribute('type'), href: e.getAttribute('href') })));
    fs.mkdirSync(this.config.logDir, { recursive: true });
    const messages = await this.page.locator('[data-message-author-role]').evaluateAll(es => es.filter(e=>e.getClientRects().length).map(e=>({role:e.getAttribute('data-message-author-role'),text:e.innerText,images:[...e.querySelectorAll('img')].map(i=>({alt:i.alt,width:i.naturalWidth,height:i.naturalHeight})),buttons:[...e.querySelectorAll('button')].map(b=>({label:b.getAttribute('aria-label'),text:b.innerText,testid:b.getAttribute('data-testid')}))})));
    const fileInputs = await this.page.locator('input[type="file"]').evaluateAll(es=>es.map(e=>({accept:e.accept,multiple:e.multiple,disabled:e.disabled})));
    fs.writeFileSync(path.join(this.config.logDir, 'chatgpt-ui.private.json'), JSON.stringify({ url: this.page.url(), text, controls, messages, fileInputs }, (_k,v) => typeof v === 'string' ? v.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig, '[email]') : v, 2));
    await this.page.screenshot({ path: path.join(this.config.logDir, 'chatgpt-ui.png') });
  }
  async readiness() {
    if (!this.page || this.page.isClosed()) return { ready: false, code: 'chatgpt_browser_closed' };
    if (!/^https:\/\/chatgpt\.com\//.test(this.page.url())) return { ready: false, code: 'chatgpt_login_required' };
    if (/just a moment|security verification/i.test(await this.page.title())) return { ready: false, code: 'chatgpt_human_verification_required' };
    await this.inspect();
    const text = await this.page.locator('body').innerText();
    if (/verify you are human|checking your browser|xác minh bạn là con người/i.test(text)) return { ready: false, code: 'chatgpt_human_verification_required' };
    if (await this.page.getByRole('button',{name:/^log in$|^đăng nhập$/i}).count()) return { ready: false, code: 'chatgpt_login_required' };
    if (/you.ve reached.*limit|image creation limit|try again after|đạt giới hạn/i.test(text)) return { ready: false, code: 'chatgpt_image_limit_required' };
    const composer = this.composer();
    if (await composer.count() !== 1 || !await composer.isVisible()) return { ready: false, code: 'chatgpt_ui_setup_pending' };
    return { ready: true };
  }
  async highestReasoning(preferences, proofDir, generationId) {
    if (preferences?.reasoning !== 'highest_available') return {};
    const chatMode=this.page.getByRole('button',{name:'Chuyển chế độ, chế độ hiện tại: ChatGPT',exact:true});
    if(await chatMode.count()!==1)throw Error('chatgpt_chat_mode_verification_required');
    const control=this.page.getByRole('button',{name:'Chọn mô hình ChatGPT',exact:true});
    if(await control.count()!==1)throw Error('chatgpt_reasoning_control_setup_required');
    await control.click();
    const menu=this.page.getByRole('menu',{name:'Chọn mô hình ChatGPT',exact:true});
    await menu.waitFor({state:'visible'});
    const status=menu.getByRole('status');
    if(await status.count()!==1)throw Error('chatgpt_reasoning_menu_changed');
    let selected;
    for(let attempt=0;attempt<6;attempt++) {
      const text=norm(await status.innerText());
      const match=text.match(/^(.+),\s*(\d+)\s+trên\s+(\d+)\.?$/u);
      if(!match)throw Error('chatgpt_reasoning_menu_changed');
      const position=Number(match[2]),levels=Number(match[3]);
      if(position<1||levels>6||position>levels)throw Error('chatgpt_reasoning_menu_changed');
      if(position===levels) {selected={reasoning_policy:'highest_available',reasoning_label:match[1],reasoning_menu_verified:true,reasoning_position:position,reasoning_levels:levels};break;}
      await menu.getByRole('menuitem',{name:'Năng lượng',exact:true}).press('ArrowRight');
      await menu.getByRole('status').filter({hasText:new RegExp(',\\s*'+(position+1)+'\\s+trên\\s+'+levels)}).waitFor({state:'visible'});
    }
    if(!selected)throw Error('chatgpt_highest_reasoning_not_selected');
    selected.reasoning_screenshot_path=path.join(proofDir,generationId+'-reasoning.png');
    await this.page.screenshot({path:selected.reasoning_screenshot_path});
    selected.reasoning_screenshot_sha256=hash(fs.readFileSync(selected.reasoning_screenshot_path));
    await menu.press('Escape');
    return selected;
  }
  async generate(item, refs, output, hooks) {
    fs.mkdirSync(output, { recursive: true });
    const proofDir = path.join(output, 'chatgpt-proof'); fs.mkdirSync(proofDir, { recursive: true });
    const key = item.region || item.name;
    let resume = hooks.resume;
    if (resume?.status === 'acquired') return { asset: resume.asset, proof: resume.proof };
    if (resume?.generation_id) {
      const reservationFile=path.join(proofDir,resume.generation_id+'.download.json');
      if(fs.existsSync(reservationFile)) {
        const reservation=JSON.parse(fs.readFileSync(reservationFile,'utf8'));
        if(reservation.marker!==resume.marker || reservation.prompt_sha256!==resume.prompt_sha256 || JSON.stringify(reservation.reference_sha256)!==JSON.stringify(resume.reference_sha256)) throw Error('chatgpt_download_reservation_changed');
        if(fs.existsSync(reservation.target)) {
          const result=this.finishDownload(reservation);
          await hooks.checkpoint({status:'acquired',...result});return result;
        }
      }
    }
    if (resume?.status === 'generation_started') {
      if (/^https:\/\/chatgpt\.com\/c\//.test(resume.url || '')) {
        if (this.page.url() !== resume.url) await this.page.goto(resume.url, { waitUntil: 'domcontentloaded' });
      } else {
        const pages = this.context.pages().filter(p=>/^https:\/\/chatgpt\.com\//.test(p.url()));
        const matches=[];
        for(const page of pages) if ((await page.locator('body').innerText()).includes(resume.marker)) matches.push(page);
        if(matches.length !== 1) throw Error('chatgpt_send_reconcile_required');
        this.page=matches[0];
      }
    } else {
      if (/\/c\//.test(this.page.url())) await this.page.getByRole('button',{name:/^(New chat|Trò chuyện mới)$/i}).click();
      const composer=this.composer(); await composer.waitFor({state:'visible'});
      const ready=await this.readiness();if(!ready.ready)throw Error(ready.code);
      const labels = refs.map((ref,index)=>({index:index+1,role:ref.role||'locked visual reference',region:ref.region||null,sha256:ref.sha256}));
      if(refs.length) {
        const inputs=this.page.locator('input[type="file"]');
        if(await inputs.count()!==1) {
          const add=this.page.getByRole('button',{name:'Add files and more',exact:true});
          if(await add.count()===1)await add.click();
          await this.inspect();throw Error('chatgpt_upload_control_setup_required');
        }
        const staged=path.join(proofDir,'uploads-'+randomUUID());fs.mkdirSync(staged);
        const files=refs.map((ref,index)=>{if(hash(fs.readFileSync(ref.path))!==ref.sha256)throw Error('asset_hash_changed');const file=path.join(staged,'reference-'+(index+1)+path.extname(ref.path));fs.copyFileSync(ref.path,file);return file;});
        await inputs.setInputFiles(files);
        for(const file of files) await this.page.getByText(path.basename(file),{exact:false}).first().waitFor({state:'visible',timeout:60000});
      }
      const marker='ETSY-IMAGE-'+randomUUID();
      const sent='Internal job tracking: '+marker+'. Do not draw this tracking text. Create exactly one image using the following brief. Attached files are locked visual references in this order: '+JSON.stringify(labels)+'.\n\n'+item.prompt;
      await composer.fill(sent);
      const composerText=await composer.getAttribute('contenteditable')==='true'?await composer.innerText():await composer.inputValue();
      if(norm(composerText)!==norm(sent))throw Error('chatgpt_prompt_changed');
      const generationId=randomUUID();
      const reasoning=await this.highestReasoning(hooks.chatPreferences,proofDir,generationId);
      const byTest=this.page.getByTestId('send-button');
      const send=await byTest.count()===1?byTest:this.page.getByRole('button',{name:/^(Send|Gửi)$/i});
      if(await send.count()!==1) {await this.inspect();throw Error('chatgpt_send_control_setup_required');}
      await send.click({trial:true});
      const modelButton=this.page.getByTestId('model-switcher-dropdown-button');
      const model=await modelButton.count()===1?norm(await modelButton.innerText()):reasoning.reasoning_label?'ChatGPT Chat — '+reasoning.reasoning_label:'ChatGPT Chat (model label not exposed)';
      resume={generation_id:generationId,marker,sent_prompt:sent,prompt_sha256:hash(item.prompt),reference_sha256:refs.map(r=>r.sha256).sort(),model,url:this.page.url(),...reasoning};
      await hooks.beforeGenerate(resume);
      try {await send.click({noWaitAfter:true});} catch { /* An uncertain send is reconciled using the visible marker, never resent. */ }
      try {await this.page.waitForURL('https://chatgpt.com/c/**',{timeout:30000});} catch {}
      resume.url=this.page.url();await hooks.checkpoint({...resume,status:'generation_started'});
    }
    const user=this.page.locator('[data-message-author-role="user"]').filter({hasText:resume.marker});
    await user.waitFor({state:'visible',timeout:60000});
    if(!norm(await user.innerText()).includes(norm(resume.sent_prompt)))throw Error('chatgpt_visible_prompt_mismatch');
    const assistant=this.page.locator('[data-message-author-role="assistant"]').last();
    const inlineDownload=assistant.getByRole('button',{name:/download|tải xuống/i});
    const imageButton=assistant.getByRole('button',{name:/^(Ảnh được tạo|Generated image) 1$/i});
    try {await inlineDownload.or(imageButton).first().waitFor({state:'visible',timeout:720000});} catch {
      await this.inspect();const ready=await this.readiness();throw Error(ready.ready?'chatgpt_generation_reconcile_required':ready.code);
    }
    let download=inlineDownload;
    if(await inlineDownload.count()===0) {
      if(await imageButton.count()!==1)throw Error('chatgpt_generated_image_ambiguous');
      await imageButton.click();
      const viewer=this.page.getByRole('dialog',{name:/^(Xem trước hình ảnh|Image preview)$/i});
      await viewer.waitFor({state:'visible'});
      download=viewer.getByRole('button',{name:/^(Download|Tải xuống)$/i});
    }
    if(await download.count()!==1)throw Error('chatgpt_download_ambiguous');
    if(await imageButton.count()!==1 && await assistant.locator('img').count()!==1)throw Error('chatgpt_generated_image_ambiguous');
    const label=await download.getAttribute('aria-label')||await download.innerText();
    const screenshot=path.join(proofDir,resume.generation_id+'.png');await this.page.screenshot({path:screenshot});
    const event=this.page.waitForEvent('download',{timeout:60000});await download.click();const original=await event;
    const ext=path.extname(original.suggestedFilename()).toLowerCase();
    if(!['.png','.jpg','.jpeg','.webp'].includes(ext))throw Error('chatgpt_original_format_invalid');
    const target=path.join(output,resume.generation_id+ext);
    if(fs.existsSync(target))throw Error('chatgpt_original_already_exists');
    const reservation={...resume,target,url:this.page.url(),screenshot_path:screenshot,download_button_label:label};
    atomic(path.join(proofDir,resume.generation_id+'.download.json'),reservation);
    await original.saveAs(target);if(await original.failure())throw Error('chatgpt_download_failed');
    const result=this.finishDownload(reservation);
    await hooks.checkpoint({status:'acquired',...result});return result;
  }
  finishDownload(reservation) {
    const {target,screenshot_path:screenshot}=reservation;
    if(!fs.statSync(target).size)throw Error('chatgpt_download_incomplete');
    const asset={path:target,sha256:hash(fs.readFileSync(target))};
    const receiptFile=path.join(path.dirname(screenshot),reservation.generation_id+'.receipt.json');
    const reasoning=Object.fromEntries(Object.entries(reservation).filter(([key])=>key.startsWith('reasoning_')));
    const receipt={url:reservation.url,model:reservation.model,prompt_sha256:reservation.prompt_sha256,reference_sha256:reservation.reference_sha256,sent_prompt:reservation.sent_prompt,...reasoning,
      user_prompt_visible:true,download_button_label:reservation.download_button_label,acquisition:'chatgpt_download',asset};atomic(receiptFile,receipt);
    const proof={executor:'independent_chatgpt_worker',acquisition:'chatgpt_download',model:reservation.model,url:reservation.url,...reasoning,screenshot_path:screenshot,screenshot_sha256:hash(fs.readFileSync(screenshot)),
      receipt_path:receiptFile,receipt_sha256:hash(fs.readFileSync(receiptFile)),prompt_sha256:reservation.prompt_sha256,reference_sha256:reservation.reference_sha256};
    return {asset,proof};
  }
}
module.exports = { ChatGPTBrowser };
