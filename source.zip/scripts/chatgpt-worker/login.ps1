$ErrorActionPreference = 'Stop'
$chatRoot = 'C:\Huy\etsy-workflow'
$chatConfig = Get-Content -LiteralPath (Join-Path $chatRoot 'config/flow-worker.private.json') -Raw | ConvertFrom-Json
$chatState = Get-Content -LiteralPath (Join-Path $chatConfig.stateDir 'status.json') -Raw | ConvertFrom-Json
if ($chatState.status -ne 'awaiting_manual_login' -or $chatState.browser_control_active -ne $false) { throw 'Pause browser control through n8n manual_login first.' }
$chatProfile = [IO.Path]::GetFullPath($chatConfig.profileDir)
$chatExpected = [IO.Path]::GetFullPath((Join-Path $chatRoot 'workspace/flow-worker')) + [IO.Path]::DirectorySeparatorChar
if (!$chatProfile.StartsWith($chatExpected,[StringComparison]::OrdinalIgnoreCase)) { throw 'Only the existing dedicated Flow profile is allowed.' }
$chatChrome = @('C:\Program Files\Google\Chrome\Application\chrome.exe','C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',(Join-Path $env:LOCALAPPDATA 'Google/Chrome/Application/chrome.exe')) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (!$chatChrome) { throw 'Official Chrome is missing.' }
Start-Process -FilePath $chatChrome -ArgumentList @('--user-data-dir="'+$chatProfile+'"','--no-first-run','--new-window','https://chatgpt.com/') -WindowStyle Normal
Write-Output 'Manual ChatGPT login opened in the existing Flow profile. Worker browser control is paused. Complete verification yourself, then close this Chrome window before resuming the worker.'
