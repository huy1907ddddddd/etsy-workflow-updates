'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {ChatGPTBrowser}=require('./browser.cjs');
const {ChatGPTRuntime}=require('./runtime.cjs');
const {defaults}=require('../flow-worker/runtime.cjs');
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'chatgpt-worker-'));
  t.after(()=>{const full=path.resolve(root);assert.ok(full.startsWith(path.resolve(os.tmpdir())+path.sep));fs.rmSync(full,{recursive:true,force:true});});
  const config=defaults(root);fs.mkdirSync(config.stateDir,{recursive:true});
  return {root,config};
}
test('manual login keeps browser entirely unowned while retaining supervisor process',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'chatgpt',mode:'manual_login'}));
  let starts=0,closes=0;
  const runtime=new ChatGPTRuntime(f.config,{native:{},adapter:{start:async()=>starts++,close:async()=>closes++},notify:async()=>{}});
  const result=await runtime.tick();assert.equal(result.status,'awaiting_manual_login');assert.equal(result.browser_control_active,false);assert.equal(starts,0);assert.equal(closes,0);
});
test('official extension mode never opens or controls a Playwright browser',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'chatgpt',mode:'extension'}));
  const runtime=new ChatGPTRuntime(f.config,{native:{},adapter:{start:async()=>assert.fail('must not open Playwright'),close:async()=>{}},notify:async()=>{}});
  const result=await runtime.tick();assert.equal(result.status,'awaiting_browser_extension_session');assert.equal(result.browser_control_active,false);
});
test('production extension queues native work without claiming browser automation',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'chatgpt',mode:'extension_production'}));
  let cycles=0;
  const runtime=new ChatGPTRuntime(f.config,{native:{execute:async command=>{
    assert.equal(command.action,'chatgpt_cycle');cycles++;return {ok:true,tasks:[{id:'pending'}],queue_issues:[],observed_at:new Date().toISOString()};
  }},adapter:{start:async()=>assert.fail('must not open Playwright')},notify:async()=>{}});
  const result=await runtime.tick();assert.equal(cycles,1);assert.equal(result.pending_jobs,1);
  assert.equal(result.status,'awaiting_browser_extension_session');assert.equal(result.requires_active_codex_session,true);
  assert.equal(result.browser_control_active,false);
});
test('readiness check never claims a task or generates even in production mode',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'chatgpt',mode:'production'}));
  const runtime=new ChatGPTRuntime(f.config,{native:{execute:async()=>assert.fail('readiness must not claim work')},
    adapter:{start:async()=>{},readiness:async()=>({ready:true}),generate:async()=>assert.fail('readiness must not generate')},notify:async()=>{}});
  runtime.larkReadiness=async()=>({ready:true});
  const result=await runtime.tick({readinessOnly:true});assert.equal(result.status,'ready');assert.equal(result.readiness_only,true);
});
test('unresolved source is blocked explicitly instead of reporting an idle queue',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'chatgpt',mode:'production'}));
  const runtime=new ChatGPTRuntime(f.config,{native:{execute:async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[],queue_issues:[{task_id:'unresolved'}]})},
    adapter:{start:async()=>{},readiness:async()=>({ready:true})},notify:async()=>{}});
  runtime.larkReadiness=async()=>({ready:true});
  const result=await runtime.tick();assert.equal(result.status,'blocked');assert.equal(result.code,'chatgpt_source_reconcile_required');assert.equal(result.task_id,'unresolved');
});
test('highest Chat reasoning advances the observed power menu and records actual maximum',async t=>{
  const f=fixture(t);let position=1,arrows=0,closed=false;
  const status={count:async()=>1,innerText:async()=>['','Nhanh','Tiêu chuẩn','Cao'][position]+', '+position+' trên 3.',filter:()=>({waitFor:async()=>{}})};
  const menu={waitFor:async()=>{},getByRole:role=>role==='status'?status:{press:async key=>{assert.equal(key,'ArrowRight');arrows++;position++;}},press:async key=>{assert.equal(key,'Escape');closed=true;}};
  const page={getByRole:(role,opts)=>role==='menu'?menu:{count:async()=>1,click:async()=>{}},screenshot:async({path:file})=>fs.writeFileSync(file,'fixture-screenshot-only')};
  const browser=new ChatGPTBrowser(f.config,{page});
  const result=await browser.highestReasoning({reasoning:'highest_available'},f.root,'fixture');
  assert.equal(arrows,2);assert.equal(closed,true);assert.equal(result.reasoning_label,'Cao');assert.equal(result.reasoning_position,3);assert.equal(result.reasoning_levels,3);assert.equal(result.reasoning_menu_verified,true);
  status.innerText=async()=> 'Unknown menu layout';
  await assert.rejects(browser.highestReasoning({reasoning:'highest_available'},f.root,'changed'),/chatgpt_reasoning_menu_changed/);
});
test('Chat startup launches its own UI without depending on a Flow project',async t=>{
  const f=fixture(t);let launched=0;
  const page={url:()=> 'https://chatgpt.com/',setDefaultTimeout:()=>{},bringToFront:async()=>{}};
  const browser=new ChatGPTBrowser(f.config);
  browser.launch=async()=>{launched++;browser.page=page;browser.context={pages:()=>[page]};};
  browser.inspect=async()=>{};
  await browser.start();assert.equal(launched,1);assert.equal(browser.chatStarted,true);
});
test('result viewer downloads the existing generation and preserves High evidence without resending',async t=>{
  const f=fixture(t);let opened=0,downloads=0;
  const url='https://chatgpt.com/c/existing';
  const imageButton={count:async()=>1,click:async()=>opened++};
  const inline={count:async()=>0,or:()=>({first:()=>({waitFor:async()=>{}})})};
  const download={count:async()=>1,getAttribute:async()=> 'Tải xuống',click:async()=>downloads++};
  const assistant={getByRole:(_role,{name})=>name.test('Tải xuống')?inline:imageButton,locator:()=>({count:async()=>1})};
  const user={filter(){return this;},waitFor:async()=>{},innerText:async()=> 'existing-sent-prompt'};
  const page={url:()=>url,locator:selector=>selector.includes('user')?user:{last:()=>assistant},getByRole:()=>({waitFor:async()=>{},getByRole:()=>download}),
    screenshot:async({path:file})=>fs.writeFileSync(file,'fixture-ui'),waitForEvent:async()=>({suggestedFilename:()=> 'original.png',saveAs:async file=>fs.writeFileSync(file,'fixture-original'),failure:async()=>null})};
  const browser=new ChatGPTBrowser(f.config,{page});let final;
  const resume={status:'generation_started',url,generation_id:'existing',marker:'existing',sent_prompt:'existing-sent-prompt',prompt_sha256:'prompt-hash',reference_sha256:[],model:'ChatGPT Chat — Cao',reasoning_policy:'highest_available',reasoning_label:'Cao',reasoning_menu_verified:true};
  const result=await browser.generate({name:'thumbnail'},[],f.root,{resume,checkpoint:async x=>final=x,beforeGenerate:async()=>assert.fail('must not resend')});
  assert.equal(opened,1);assert.equal(downloads,1);assert.equal(final.status,'acquired');assert.equal(result.proof.reasoning_label,'Cao');
  const receipt=JSON.parse(fs.readFileSync(result.proof.receipt_path,'utf8'));assert.equal(receipt.reasoning_policy,'highest_available');assert.equal(receipt.download_button_label,'Tải xuống');
});
test('missing unknown-send conversation blocks without any new send or generation',async t=>{
  const f=fixture(t);const browser=new ChatGPTBrowser(f.config,{page:{},context:{pages:()=>[]}});
  await assert.rejects(browser.generate({name:'test'},[],f.root,{resume:{status:'generation_started',generation_id:'existing',marker:'existing-marker'},checkpoint:async()=>assert.fail('must not generate')}),/chatgpt_send_reconcile_required/);
});
test('crash after download reuses reserved original and receipt without browser interaction',async t=>{
  const f=fixture(t),proofDir=path.join(f.root,'chatgpt-proof');fs.mkdirSync(proofDir);
  const target=path.join(f.root,'existing.png'),screenshot=path.join(proofDir,'existing.png');fs.writeFileSync(target,'existing-original');fs.writeFileSync(screenshot,'existing-proof');
  const resume={status:'generation_started',generation_id:'existing',marker:'existing-marker',prompt_sha256:'prompt-hash',reference_sha256:['ref-hash']};
  fs.writeFileSync(path.join(proofDir,'existing.download.json'),JSON.stringify({...resume,target,screenshot_path:screenshot,url:'https://chatgpt.com/c/test',model:'observed-model',download_button_label:'Download'}));
  const browser=new ChatGPTBrowser(f.config,{page:{}});let checkpoint;
  const result=await browser.generate({name:'test'},[],f.root,{resume,checkpoint:async r=>checkpoint=r});
  assert.equal(result.asset.path,target);assert.equal(checkpoint.status,'acquired');assert.equal(result.proof.acquisition,'chatgpt_download');assert.equal(fs.readFileSync(target,'utf8'),'existing-original');
});
test('auth pages are left to human and never inspected by browser readiness',async t=>{
  const f=fixture(t);const browser=new ChatGPTBrowser(f.config,{page:{isClosed:()=>false,url:()=> 'https://auth.openai.com/log-in/password'}});
  browser.inspect=async()=>assert.fail('must not inspect authentication fields');
  assert.equal((await browser.readiness()).code,'chatgpt_login_required');
});
test('Cloudflare challenge title blocks before composer inspection or any action',async t=>{
  const f=fixture(t);const browser=new ChatGPTBrowser(f.config,{page:{isClosed:()=>false,url:()=> 'https://chatgpt.com/',title:async()=> 'Just a moment...'}});
  browser.inspect=async()=>assert.fail('challenge must stop before composer inspection');
  assert.equal((await browser.readiness()).code,'chatgpt_human_verification_required');
});
