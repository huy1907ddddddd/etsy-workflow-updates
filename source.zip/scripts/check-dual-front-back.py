"""Isolated front/back mockup contracts; no live generation, approval or KPI writes."""
import copy
import hashlib
import importlib.util
import itertools
import json
import unittest
from pathlib import Path
from PIL import Image

spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('check-workflow3.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,profiles,batch,flow=fixture.engine,fixture.profiles,fixture.batch,fixture.flow
import embroidery_mockup_layout as layout
import embroidery_layout
import mockup_prompt_sets


class FrontBackTests(fixture.Workflow3Tests):
    def sources(self,regions):
        refs={}
        for n,region in enumerate(regions):
            if region=='right_sleeve':continue
            file=engine.STORE/(region+'.png');Image.new('RGB',(32,32),(n*30,60,120)).save(file)
            refs[region]={'path':str(file),'sha256':engine.sha(file)}
        if 'left_sleeve' in regions:refs['right_sleeve']=refs['left_sleeve']
        return refs

    def images(self,p):
        return profiles.image_plan({'code':'FIXTURE','revision':1,'plan':json.dumps(p)},self.env)

    def test_selected_region_matrix_dual_cover_balanced_views_and_blank_sleeves(self):
        for chest,sleeves in itertools.product(['none','center','left','left_right'],[False,True]):
            regions=profiles.selected({'chest':chest,'sleeves':sleeves,'back':True})
            if sleeves:regions.append('right_sleeve')
            refs=self.sources(regions)
            p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':refs,'mockup_layout':layout.load(self.env,profiles.GARMENT_SIX),'layout_profile':embroidery_layout.load(self.env)}
            images=self.images(p)['images'];self.assertEqual([x['name'] for x in images],profiles.GARMENT_SIX)
            self.assertEqual(set(images[0]['visible_regions']),set(regions));self.assertIn('EXACTLY TWO identical garments',images[0]['prompt'])
            guide=[r for r in images[0]['references'] if r.get('role')=='design_free_dual_front_back_guide'];self.assertEqual(len(guide),1)
            self.assertNotIn('folded-blank-v1',json.dumps(images[0]['references']))
            for n in (1,3):
                self.assertNotIn('back',images[n]['visible_regions']);self.assertIn('EXACTLY ONE',images[n]['prompt']);self.assertIn('FRONT-UP',images[n]['prompt'])
                self.assertIn('even when blank',images[n]['prompt'])
            for n in (2,5):
                self.assertIn('back',images[n]['visible_regions']);self.assertFalse(any('chest' in r for r in images[n]['visible_regions']))
                self.assertIn('EXACTLY ONE',images[n]['prompt']);self.assertIn('BACK-UP',images[n]['prompt'])
            self.assertIn('CLEAN',images[5]['prompt']);self.assertEqual(len(images[4]['references']),1)
            self.assertEqual(len(images[4]['visible_regions']),1)
            self.assertFalse(any(r.get('role')=='design_free_dual_front_back_guide' for i in images[1:] for r in i['references']))
            for i in images:
                self.assertEqual({r for ref in i['references'] for r in ref.get('regions',[])},set(i['visible_regions']))
                self.assertTrue(i['prompt'].endswith(engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']))

    def test_new_batch_freezes_layout_and_replay_of_old_batch_preserves_old_default(self):
        command=self.embroidery({'chest':'center','sleeves':True,'back':True})
        preview=self.execute(command);saved=batch.manifest(batch.batch(self.c,preview['batch_id']))
        self.assertEqual(saved['mockup_layout']['version'],layout.VERSION)
        self.assertEqual(saved['items'][0]['brief']['mockup_layout'],saved['mockup_layout'])
        self.assertEqual(self.execute(command)['batch_fingerprint'],preview['batch_fingerprint'])
        old=copy.deepcopy(command);old['batch_id']='fixture-old'
        with __import__('unittest.mock',fromlist=['patch']).patch.object(layout,'load',side_effect=AssertionError('old intake must not read new defaults')):
            legacy=batch.normalize(old,{**self.env,'shared_mockup_layout':None})
        self.assertNotIn('mockup_layout',legacy)
        for record in legacy['items']:self.assertNotIn('mockup_layout',record['brief'])
        original=profiles.normalize
        with __import__('unittest.mock',fromlist=['patch']).patch.object(profiles,'normalize',side_effect=lambda cmd,e,fn:original(cmd,{**e,'shared_mockup_layout':None},fn)):
            previous=self.execute(old)
        self.assertEqual(self.execute(old)['batch_fingerprint'],previous['batch_fingerprint'])

    def test_layout_survives_artwork_approvals_sample_gate_and_remaining_shots(self):
        command=self.embroidery({'chest':'center','sleeves':True,'back':True});self.start(command);self.cycle()
        for stage in ['2d','embroidery']:
            t=self.execute({'action':'browser_queue'})['tasks'][0];self.assertEqual(t['stage'],stage)
            self.execute(self.candidate(t));review=flow.review_packet(self.c,{'brief_id':t['brief_id']},self.env)
            flow.apply_decision(self.c,self.decision(review),self.env)
        sample=self.cycle()['tasks'][0]
        self.assertEqual(sample['payload']['mockup_layout']['version'],layout.VERSION)
        self.assertIn('back',sample['payload']['images'][0]['visible_regions']);self.assertEqual(len(sample['payload']['images']),1)
        self.execute(self.candidate(sample));review=self.cycle()['reviews'][0]
        self.assertEqual(batch.item(self.c,sample['batch_id'],sample['item_id'])['state'],'awaiting_sample_approval')
        flow.apply_decision(self.c,self.decision(review),self.env)
        rest=self.cycle()['tasks'][0];self.assertEqual(len(rest['payload']['images']),5)
        macro=next(i for i in rest['payload']['images'] if i['name']=='07_embroidery_closeup.jpg');self.assertEqual(len(macro['references']),1)

    def test_legacy_payloads_and_no_back_photos_remain_byte_exact(self):
        oldfile=engine.ROOT/'workspace/maintenance/versions/20261103-dual-front-back1/before/scripts/production_profiles.py'
        spec=importlib.util.spec_from_file_location('old_profiles',oldfile);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        for back,sleeves in itertools.product([False,True],repeat=2):
            regions=['center_chest']+(['back'] if back else [])+(['left_sleeve','right_sleeve'] if sleeves else [])
            p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':self.sources(regions),'layout_profile':embroidery_layout.load(self.env)}
            for custom in [False,True]:
                if custom:p['mockup_prompt_set']={'schema_version':1,'kind':'embroidery_prompts','name':'Legacy','source':'\n'.join('===== '+n+' =====\nLegacy complete pose and decorations' for n in profiles.GARMENT_SIX)}
                j={'code':'FIXTURE','revision':1,'plan':json.dumps(p)}
                self.assertEqual(profiles.image_plan(j,self.env),old.image_plan(j,self.env))

    def test_saved_preset_migration_replaces_whole_source_and_clean_flatlay_stays_clean(self):
        current=layout.load(self.env,profiles.GARMENT_SIX)
        old={'schema_version':1,'kind':'embroidery_prompts','name':'Old fixture','source':'\n'.join('===== '+n+' =====\nOld front-only pose' for n in profiles.GARMENT_SIX)}
        replacement={**current['standard'],'name':'New Noel fixture','source':current['standard']['source'].replace('BACKGROUND: Plain undecorated matte light-neutral studio surface.','BACKGROUND: Pine wreath outside the garment.')}
        current['preset_migrations']={hashlib.sha256(old['source'].encode()).hexdigest():replacement}
        converted=layout.preset(old,current,profiles.GARMENT_SIX);self.assertEqual(converted['source'],replacement['source'])
        self.assertNotIn('Old front-only pose',converted['source'])
        p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':self.sources(['center_chest','back']),'mockup_layout':layout.load(self.env,profiles.GARMENT_SIX),'mockup_prompt_set':converted}
        images=self.images(p)['images'];self.assertIn('Pine wreath',images[0]['prompt']);self.assertNotIn('Pine wreath',images[-1]['prompt'])
        self.assertIn('EXACTLY TWO identical garments',images[0]['prompt']);self.assertNotIn('Overhead folded crewneck sweatshirt hero',images[0]['prompt'])

    def test_neutral_daylight_all_shots_and_only_the_assigned_garment_guide(self):
        current=layout.load(self.env,profiles.GARMENT_SIX)
        self.assertEqual(current['version'],'dual-front-back-neutral-v2')
        p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':self.sources(['center_chest','back']),'mockup_layout':current}
        for image in self.images(p)['images']:
            self.assertIn('Use ONLY soft diffused natural window daylight',image['prompt'])
            self.assertIn('No yellow, amber, orange or cream lighting cast',image['prompt'])
            self.assertIn('beige fabric stays beige',image['prompt'])
            guides=[r for r in image['references'] if r.get('role')=='design_free_dual_front_back_guide']
            self.assertEqual(len(guides),1 if image['name']=='01_thumbnail.jpg' else 0)
            if guides:self.assertEqual(guides[0],current['guides'][image['wardrobe']['garment']])
        for ref in current['guides'].values():
            with Image.open(ref['path']) as picture:
                pixels=[picture.convert('RGB').getpixel((x,25)) for x in (25,picture.width//2,picture.width-25)]
                self.assertTrue(all(max(rgb)-min(rgb)<15 for rgb in pixels))

    def test_prior_front_back_snapshot_keeps_its_exact_prompts_and_guides(self):
        previous=engine.read(engine.ROOT/'config/embroidery-front-back-mockups-v1.json')
        p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':self.sources(['center_chest','back']),'mockup_layout':previous}
        oldfile=engine.ROOT/'workspace/maintenance/versions/20261103-neutral-daylight1/before/scripts/production_profiles.py'
        spec=importlib.util.spec_from_file_location('prior_profiles',oldfile);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        j={'code':'FIXTURE','revision':1,'plan':json.dumps(p)}
        self.assertEqual(self.images(p),old.image_plan(j,self.env))

    def test_layout_rejects_changed_guide_hash_prompt_or_use_without_back(self):
        current=layout.load(self.env,profiles.GARMENT_SIX)
        broken=copy.deepcopy(current);broken['standard']['source']+='changed'
        with self.assertRaisesRegex(ValueError,'layout changed'):layout.validate(broken,self.env,profiles.GARMENT_SIX)
        broken=copy.deepcopy(current);broken['guides']['hoodie']['sha256']='0'*64
        body={k:v for k,v in broken.items() if k!='fingerprint'};broken['fingerprint']=hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        with self.assertRaisesRegex(ValueError,'guide changed'):layout.validate(broken,self.env,profiles.GARMENT_SIX)
        with self.assertRaisesRegex(ValueError,'requires back'):self.images({'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':self.sources(['center_chest']),'mockup_layout':current})


if __name__=='__main__':
    suite=unittest.TestSuite(FrontBackTests(n) for n in FrontBackTests.__dict__ if n.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
