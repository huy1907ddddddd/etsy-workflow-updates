"""Verified local listing reports and KPI exports, executed only by native n8n."""
import base64
import csv
import html
import io
import json
import zipfile
from pathlib import Path


def export_kpi(c, e):
    rows = [dict(r) for r in c.execute("SELECT code,revision,target_date,completed_at,fingerprint FROM kpi WHERE code NOT LIKE '%_PILOT' ORDER BY target_date,completed_at,code")]
    directory = e['STORE'] / 'local-reports'
    directory.mkdir(parents=True, exist_ok=True)
    stream = io.StringIO(newline='')
    writer = csv.writer(stream)
    writer.writerow(['Ngày KPI', 'Mã listing', 'Phiên bản', 'Hoàn tất'])
    for r in rows:
        writer.writerow([r['target_date'], e['public_code'](c, r['code']), r['revision'], r['completed_at']])
    file = directory / 'KPI.csv'
    data = stream.getvalue().encode('utf-8-sig')
    temporary = file.with_suffix('.tmp'); temporary.write_bytes(data); temporary.replace(file)
    if file.read_bytes() != data:
        raise ValueError('Local KPI readback differs from the canonical ledger')
    readback = list(csv.reader(io.StringIO(file.read_text(encoding='utf-8-sig'))))
    if len(readback) != len(rows) + 1:
        raise ValueError('Local KPI row count mismatch')
    return {'path': str(file), 'sha256': e['sha'](file), 'rows_fingerprint': e['digest'](rows), 'listing_count': len(rows)}


def publish(c, j, processed, text, fingerprint, e):
    import production_profiles
    e['verify_assets'](processed['payload']['images'], True, expected_names=production_profiles.names(json.loads(j['plan'])))
    content = e['validate_text'](j, text['payload'])
    public = e['public_code'](c, j['code'])
    directory = e['STORE'] / 'local-reports' / public / ('v%03d' % j['revision'])
    directory.mkdir(parents=True, exist_ok=True)
    thumb = processed['payload']['images'][0]
    image = e['scoped'](thumb['path'])
    mime = 'image/png' if image.read_bytes().startswith(b'\x89PNG') else 'image/jpeg'
    document = '<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>' + html.escape(public) + '</title><style>body{max-width:960px;margin:32px auto;padding:16px;font:16px/1.6 system-ui}img{max-width:420px;width:100%}pre{white-space:pre-wrap;font:inherit}</style><h1>' + html.escape(public) + '</h1><img alt="Approved thumbnail" src="data:' + mime + ';base64,' + base64.b64encode(image.read_bytes()).decode() + '"><h2>Title</h2><pre>' + html.escape(content['title']) + '</pre><h2>Mô tả</h2><pre>' + html.escape(content['description']) + '</pre><h2>Tags</h2><pre>' + html.escape(', '.join(content['tags'])) + '</pre></html>'
    file = directory / 'listing.html'
    e['write'](directory / 'listing.json', {'listing_code': public, 'title': content['title'], 'description': content['description'], 'tags': content['tags']})
    temporary = file.with_suffix('.tmp'); temporary.write_text(document, encoding='utf-8'); temporary.replace(file)
    if file.read_text(encoding='utf-8') != document or e['read'](directory / 'listing.json')['title'] != content['title']:
        raise ValueError('Local listing content readback mismatch')
    package = e['package_listing'](c, j, processed, text, fingerprint)
    allocation = e['allocate_kpi'](c, j, fingerprint, package['completed_at'])
    if not allocation['counted'] and not j['code'].endswith('_PILOT'):
        raise ValueError('Local delivery still requires the existing KPI activation gate')
    kpi = export_kpi(c, e)
    proof = {'backend': 'local_v1', 'verified_after_readback': True, 'review_fingerprint': fingerprint,
             'report': {'path': str(file), 'sha256': e['sha'](file)}, 'content': {'path': str(directory / 'listing.json'), 'sha256': e['sha'](directory / 'listing.json')},
             'kpi': kpi, 'completed_at': package['completed_at']}
    e['put'](c, j, 'local_delivery', proof)
    e['event'](c, j, 'local_listing_and_kpi_verified', proof)
    return e['state'](c, j, 'completed', package=package, kpi=allocation, local_delivery=proof)


def verified(c, j, e):
    proof = e['artifact'](c, j, 'local_delivery')
    if not proof or proof['payload'].get('backend') != 'local_v1' or proof['payload'].get('verified_after_readback') is not True:
        return False
    for name in ('report', 'content'):
        asset = proof['payload'][name]
        file = e['scoped'](asset['path'])
        if not file.is_file() or e['sha'](file) != asset['sha256']:
            raise ValueError('Verified local delivery changed: ' + name)
    return True


def bundle(c, bid, jobs, e):
    sources = {}
    codes = []
    for j in jobs:
        if not verified(c, j, e):
            raise ValueError('Local report bundle requires verified listing content')
        p = e['artifact'](c, j, 'local_delivery')['payload']
        for name in ('report', 'content'):
            file = e['scoped'](p[name]['path'])
            sources[e['public_code'](c, j['code']) + '/' + file.name] = file.read_bytes()
        codes.append(j['code'])
    csv_file = io.StringIO(newline=''); writer = csv.writer(csv_file)
    writer.writerow(['Ngày KPI', 'Mã listing', 'Hoàn tất'])
    for r in c.execute('SELECT * FROM kpi ORDER BY target_date,completed_at,code'):
        if r['code'] in codes:
            writer.writerow([r['target_date'], e['public_code'](c, r['code']), r['completed_at']])
    sources['KPI.csv'] = csv_file.getvalue().encode('utf-8-sig')
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(sources.items()):
            info = zipfile.ZipInfo(name); info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    data = stream.getvalue()
    file = e['STORE'] / 'local-reports' / 'batches' / (bid + '.zip')
    file.parent.mkdir(parents=True, exist_ok=True)
    if file.exists() and file.read_bytes() != data:
        raise ValueError('Completed report bundle changed; preserve the existing version')
    if not file.exists():
        temporary = file.with_suffix('.tmp'); temporary.write_bytes(data); temporary.replace(file)
    return {'path': str(file), 'sha256': e['sha'](file), 'name': file.name}
