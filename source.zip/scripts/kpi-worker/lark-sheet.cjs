'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { atomic } = require('../flow-worker/native-n8n.cjs');
const OFFICIAL = 'https://open.larksuite.com';
const TARGET = 'https://local-workspace.invalid/wiki/LOCAL_DESTINATION_REQUIRED';
const HEADERS = ['Ngày KPI', 'Số listing', 'Mã listing'];
const WIDE_HEADERS=['Ngày KPI','Số listing',...Array.from({length:21},(_,i)=>'Listing '+String(i+1).padStart(2,'0'))];
const WIDE_TITLE='KPI - mỗi ô một listing';
function fail(code) { const error = Error(code); error.code = code; throw error; }
function date(value) {
  let normalized;
  if (Number.isInteger(value) && value > 30000 && value < 100000) normalized = new Date(Date.UTC(1899, 11, 30) + value * 86400000).toISOString().slice(0, 10);
  else if (typeof value === 'string') {
    const text = value.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(text)) normalized = text;
    const match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (match) normalized = match[3] + '-' + match[2].padStart(2, '0') + '-' + match[1].padStart(2, '0');
  }
  if (!normalized || !Number.isFinite(Date.parse(normalized)) || new Date(normalized).toISOString().slice(0, 10) !== normalized) fail('kpi_sheet_date_invalid');
  return normalized;
}
const blank = value => value === null || value === undefined || value === '';
function row(raw, index,wide=false) {
  if (raw.slice(0,wide?23:3).every(blank)) return null;
  if (raw.slice(0,wide?23:3).some(v => typeof v === 'string' && v.trim().startsWith('='))) fail('kpi_sheet_formula_conflict');
  const cells=wide?raw.slice(2,23).filter(v=>!blank(v)):null;
  if(wide&&cells.some(v=>typeof v!=='string'||/[,;\r\n]/.test(v)||!v.trim()))fail('kpi_one_listing_per_cell_required');
  const codes = wide?cells.map(v=>v.trim()):blank(raw[2]) ? [] : typeof raw[2] === 'string' ? raw[2].split(/[,;\r\n]+/).map(v => v.trim()).filter(Boolean) : fail('kpi_sheet_codes_invalid');
  const count = blank(raw[1]) ? 0 : typeof raw[1] === 'number' || typeof raw[1] === 'string' ? Number(raw[1]) : NaN;
  if (!Number.isInteger(count) || count < 0 || count !== codes.length || new Set(codes).size !== codes.length) fail('kpi_sheet_count_conflict');
  return { date: date(raw[0]), count, listing_codes: codes, row_index: index + 1, values: wide?Array.from({length:23},(_,i)=>raw[i]??''):[raw[0], raw[1] ?? '', raw[2] ?? ''] };
}
function parse(values,wide=false) {
  const headers=wide?WIDE_HEADERS:HEADERS;
  if (!Array.isArray(values) || JSON.stringify(values[0]?.slice(0, headers.length)) !== JSON.stringify(headers)) fail('kpi_sheet_headers_changed');
  const entries = values.slice(1).map((raw, index) => row(raw, index + 1,wide)).filter(Boolean);
  if (new Set(entries.map(r => r.date)).size !== entries.length) fail('kpi_sheet_duplicate_date');
  return entries;
}
function canonical(rows) {
  if (!Array.isArray(rows) || !rows.length) fail('kpi_rows_missing');
  const result = rows.map(r => {
    if (!Array.isArray(r.listing_codes) || !Number.isInteger(r.count) || r.count < 1 || r.count > 21 || r.count !== r.listing_codes.length || new Set(r.listing_codes).size !== r.count || r.listing_codes.some(code => typeof code !== 'string' || !/^[A-Z]{2,5}_\d{6}_\d{2}(?:_TQH)?$/.test(code))) fail('kpi_rows_invalid');
    return { date: date(r.date), count: r.count, listing_codes: [...r.listing_codes] };
  });
  if (new Set(result.map(r => r.date)).size !== result.length) fail('kpi_rows_duplicate_date');
  return result;
}
function plan(rows, entries, capacity,wide=false) {
  let nextRow = Math.max(1, ...entries.map(r => r.row_index)) + 1;
  return rows.flatMap(expected => {
    const existing = entries.find(r => r.date === expected.date);
    if (existing && existing.listing_codes.some(code => !expected.listing_codes.includes(code) && !expected.listing_codes.includes(code+'_TQH'))) fail('kpi_sheet_legacy_conflict');
    if (existing && existing.count === expected.count && JSON.stringify(existing.listing_codes) === JSON.stringify(expected.listing_codes)) return [];
    const index = existing?.row_index || nextRow++;
    if (index > capacity) fail('kpi_sheet_capacity_exceeded');
    // Preserve the existing date cell and its format; write only B:C when the date exists.
    const cells=wide?[expected.count,...expected.listing_codes,...Array(21-expected.count).fill('')]:[expected.count,expected.listing_codes.join(', ')];
    return [{ row_index: index, date: expected.date, start: existing ? 'B' : 'A', values: existing ? cells : [expected.date,...cells] }];
  });
}
class KpiSheet {
  constructor(config, deps = {}) {
    this.config = config; this.client = deps.client; this.now = deps.now || Date.now;
    if ((config.targetUrl || TARGET) !== TARGET) fail('kpi_sheet_target_changed');
  }
  connect() {
    if (this.client) return;
    const config = JSON.parse(fs.readFileSync(this.config.larkConfigFile, 'utf8').replace(/^\uFEFF/, ''));
    if (!config.appId || !config.appSecret) fail('lark_setup_pending');
    const lark = require('../lark-review/node_modules/@larksuiteoapi/node-sdk');
    const logger = Object.fromEntries(['trace', 'debug', 'info', 'warn', 'error', 'fatal'].map(level => [level, () => {}]));
    this.client = new lark.Client({ appId: config.appId, appSecret: config.appSecret, domain: lark.Domain.Lark, appType: lark.AppType.SelfBuild, logger });
  }
  async request(method, url, extras = {}) {
    this.connect();
    let response;
    try { response = await this.client.request({ method, url: OFFICIAL + url, timeout: 20000, maxRedirects: 0, ...extras }); }
    catch (error) {
      const code = error.response?.data?.code;
      if ([99991672, 99991663, 99991679].includes(code)) fail('kpi_sheet_scope_required');
      if ([403, 400].includes(error.response?.status)) fail('kpi_sheet_access_required');
      fail('kpi_sheet_api_unavailable');
    }
    if (response?.code !== 0) fail(response?.code === 99991672 ? 'kpi_sheet_scope_required' : 'kpi_sheet_api_rejected');
    return response;
  }
  layout(){const file=path.join(this.config.workflowRoot,'config/kpi-layout.json');return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{};}
  async identify(ignoreLayout=false) {
    const resolved = await this.request('GET', '/open-apis/wiki/v2/spaces/get_node', { params: { token: 'CnUWwzcj8iWaAWkKYAwlBkNPghh' } });
    const node = resolved.data?.node;
    if (node?.obj_type !== 'sheet' || !/^[A-Za-z0-9]+$/.test(node.obj_token || '')) fail('kpi_wiki_is_not_sheet');
    if (this.config.spreadsheetToken && node.obj_token !== this.config.spreadsheetToken) fail('kpi_spreadsheet_identity_changed');
    const token = node.obj_token;
    const metadata = await this.request('GET', '/open-apis/sheets/v3/spreadsheets/' + token + '/sheets/query');
    const sheets = metadata.data?.sheets;
    const layout=ignoreLayout?{}:this.layout(),sheetId=layout.sheet_id||this.config.sheetId;
    if(layout.spreadsheet_token&&layout.spreadsheet_token!==token)fail('kpi_layout_spreadsheet_changed');
    const matches = sheets?.filter(s => sheetId ? s.sheet_id === sheetId : s.title === (this.config.sheetTitle || 'Sheet1'));
    if (matches?.length !== 1 || !/^[A-Za-z0-9_]+$/.test(matches[0].sheet_id || '')) fail('kpi_worksheet_identity_required');
    const sheet = matches[0], capacity = sheet.grid_properties?.row_count;
    if (!Number.isInteger(capacity) || capacity < 2 || capacity > 10000) fail('kpi_sheet_capacity_unsupported');
    if ((sheet.grid_properties?.column_count || 0) < 3) fail('kpi_sheet_columns_missing');
    return { token, sheetId: sheet.sheet_id, capacity,wide:layout.layout==='one_listing_per_cell_v1' };
  }
  async read(identity) {
    const range = identity.sheetId + '!A1:'+(identity.wide?'W':'C') + identity.capacity;
    const response = await this.request('GET', '/open-apis/sheets/v2/spreadsheets/' + identity.token + '/values/' + encodeURIComponent(range), { params: { valueRenderOption: 'Formula', dateTimeRenderOption: 'FormattedString' } });
    const values = response.data?.valueRange?.values;
    const entries = parse(values,identity.wide);
    return { identity, entries, values, readback: { target_url: TARGET, spreadsheet_token: identity.token, sheet_id: identity.sheetId, official_api_origin: OFFICIAL,
      range,layout:identity.wide?'one_listing_per_cell_v1':'legacy_aggregate', readback_at: new Date(this.now()).toISOString(), read_response: { code: response.code }, rows: entries.map(({ date, count, listing_codes }) => ({ date, count, listing_codes })) } };
  }
  async inspect() { return (await this.read(await this.identify())).readback; }
  async readiness() { try { const readback = await this.inspect(); return { ready: true, spreadsheet_token: readback.spreadsheet_token, sheet_id: readback.sheet_id, rows: readback.rows.length }; } catch (error) { return { ready: false, code: error.code || 'kpi_sheet_not_ready' }; } }
  backup(label, data) {
    const directory = this.config.readbackDir || path.join(this.config.workflowRoot, 'workspace/kpi-worker/readback');
    atomic(path.join(directory, 'sheet-' + label + '-' + randomUUID() + '.private.json'), data);
  }
  async sync(input, hooks = {}) {
    const expected = canonical(input);
    if (typeof hooks.beforeWrite !== 'function') fail('kpi_native_before_write_required');
    const identity = await this.identify();
    const before = await this.read(identity);
    this.backup('before', before.readback);
    let writeCode = 0, writes = 0;
    const changes = plan(expected, before.entries, identity.capacity,identity.wide);
    for (const change of changes) {
      const range = identity.sheetId + '!' + change.start + change.row_index + ':'+(identity.wide?'W':'C') + change.row_index;
      // A fresh read avoids overwriting an intervening edit; the provider has no CAS.
      const current = await this.read(identity);
      const fresh = plan(expected, current.entries, identity.capacity,identity.wide).find(r => r.date === change.date);
      if (!fresh) continue;
      if (fresh.row_index !== change.row_index || fresh.start !== change.start) fail('kpi_sheet_changed_before_write');
      this.backup('write-intent', { range, values: change.values, before: current.readback });
      await hooks.beforeWrite({ range, values: change.values });
      if (hooks.checkpoint) await hooks.checkpoint({ event: 'sheet_write_started', range, date: change.date });
      const response = await this.request('PUT', '/open-apis/sheets/v2/spreadsheets/' + identity.token + '/values', { data: { valueRange: { range, values: [change.values] } } });
      writeCode = response.code; writes++;
    }
    const after = await this.read(identity);
    for (const expectedRow of expected) {
      const actual = after.entries.find(r => r.date === expectedRow.date);
      if (!actual || actual.count !== expectedRow.count || JSON.stringify(actual.listing_codes) !== JSON.stringify(expectedRow.listing_codes)) fail('kpi_sheet_readback_mismatch');
    }
    const protectedRows = before.entries.filter(r => !expected.some(e => e.date === r.date));
    if (protectedRows.some(old => JSON.stringify(after.entries.find(r => r.date === old.date)?.values) !== JSON.stringify(old.values))) fail('kpi_sheet_unrelated_rows_changed');
    const readback = { ...after.readback, write_response: { code: writeCode, writes, reconciled_without_write: writes === 0 } };
    this.backup('after', readback);
    if (hooks.checkpoint) await hooks.checkpoint({ event: 'sheet_readback_verified', writes });
    return { readback, proof: { executor: 'independent_lark_sheets_worker', verified_after_readback: true, url: TARGET } };
  }
  async migrateLayout(rows){
    canonical(rows);
    if(this.layout().layout==='one_listing_per_cell_v1')return {ok:true,layout:'one_listing_per_cell_v1',sheet_id:this.layout().sheet_id,url:TARGET+'?sheet='+this.layout().sheet_id,...await this.sync(rows,{beforeWrite:async()=>{}})};
    const identity={...await this.identify(true),wide:true},range=identity.sheetId+'!A1:W'+identity.capacity;
    const current=await this.request('GET','/open-apis/sheets/v2/spreadsheets/'+identity.token+'/values/'+encodeURIComponent(range),{params:{valueRenderOption:'Formula',dateTimeRenderOption:'FormattedString'}});
    const values=current.data?.valueRange?.values||[];
    const alreadyWide=JSON.stringify(values[0]?.slice(0,23))===JSON.stringify(WIDE_HEADERS);
    const before=parse(values,alreadyWide);this.backup('before-per-cell-layout',{identity,values,entries:before});
    if(!alreadyWide){
      if(values.some(r=>r.slice(3,23).some(v=>!blank(v))))fail('kpi_extra_columns_contain_user_data');
      if(before.some(r=>r.count>21))fail('kpi_legacy_day_exceeds_21_slots');
      const matrix=Array.from({length:Math.max(1,...before.map(r=>r.row_index))},()=>Array(23).fill(''));matrix[0]=WIDE_HEADERS;
      for(const r of before)matrix[r.row_index-1]=[r.values[0],r.count,...r.listing_codes,...Array(21-r.count).fill('')];
      await this.request('PUT','/open-apis/sheets/v2/spreadsheets/'+identity.token+'/values',{data:{valueRange:{range:identity.sheetId+'!A1:W'+matrix.length,values:matrix}}});
    }
    const after=await this.read(identity);
    for(const old of before){const now=after.entries.find(r=>r.date===old.date);if(!now||now.count!==old.count||JSON.stringify(now.listing_codes)!==JSON.stringify(old.listing_codes))fail('kpi_layout_legacy_readback_mismatch');}
    atomic(path.join(this.config.workflowRoot,'config/kpi-layout.json'),{layout:'one_listing_per_cell_v1',spreadsheet_token:identity.token,sheet_id:identity.sheetId,sheet_title:'KPI - mỗi ô một listing',legacy_sheet_id:identity.sheetId});
    const result=await this.sync(rows,{beforeWrite:async()=>{}});
    return {ok:true,layout:'one_listing_per_cell_v1',sheet_id:identity.sheetId,url:TARGET+'?sheet='+identity.sheetId,...result};
  }}
module.exports = { KpiSheet, TARGET, HEADERS,WIDE_HEADERS, date, parse, canonical, plan };
