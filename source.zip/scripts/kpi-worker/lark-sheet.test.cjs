'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { KpiSheet, TARGET, HEADERS,WIDE_HEADERS, parse, date, canonical } = require('./lark-sheet.cjs');
const wanted = [{ date: '2026-10-16', count: 2, listing_codes: ['ANM_261016_01', 'ANM_261016_02'] }];

test('TQH identities remain separate cells and replace only their exact prior IDs',async t=>{
 const f=fixture(t,[HEADERS,['2026-10-16',2,'ANM_261016_01, ANM_261016_02']]);
 const rows=[{...wanted[0],listing_codes:wanted[0].listing_codes.map(x=>x+'_TQH')}];
 const a=await f.sheet.sync(rows,{beforeWrite:async()=>{}});assert.deepEqual(a.readback.rows[0].listing_codes,rows[0].listing_codes);
 await f.sheet.sync(rows,{beforeWrite:async()=>{}});assert.equal(f.writes(),1);
 await assert.rejects(f.sheet.sync([{...rows[0],listing_codes:['OTHER_261016_01_TQH','ANM_261016_02_TQH']}],{beforeWrite:async()=>{}}),/legacy_conflict/);
});
function fixture(t, data = [HEADERS, ['2026-10-15', 1, 'OLD_261015_01']]) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kpi-sheet-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  let values = structuredClone(data), writes = 0;
  const calls = [];
  const client = { request: async request => {
    calls.push(request);
    if (request.url.endsWith('/spaces/get_node')) return { code: 0, data: { node: { obj_type: 'sheet', obj_token: 'shtTestOnly' } } };
    if (request.url.endsWith('/sheets/query')) return { code: 0, data: { sheets: [{ sheet_id: 'sheetTest', title: 'Sheet1', grid_properties: { row_count: 1000, column_count: 26 } }] } };
    if (request.method === 'PUT') {
      writes++;
      const match = request.data.valueRange.range.match(/!([AB])(\d+):[CW]\d+$/), index = Number(match[2]) - 1;
      const start = match[1] === 'A' ? 0 : 1;
      values[index] ||= []; request.data.valueRange.values[0].forEach((cell, offset) => { values[index][start + offset] = cell; });
      return { code: 0, data: { revision: writes } };
    }
    return { code: 0, data: { valueRange: { values: structuredClone(values) } } };
  } };
  const sheet = new KpiSheet({ workflowRoot: root, targetUrl: TARGET }, { client });
  return { sheet, client, calls, values: () => values, writes: () => writes, replace: data => { values = structuredClone(data); } };
}
test('official API upserts only the required day and independently reads all cells back', async t => {
  const f = fixture(t); let authorized = 0;
  const result = await f.sheet.sync(wanted, { beforeWrite: async () => { authorized++; } });
  assert.equal(authorized, 1); assert.equal(f.writes(), 1);
  assert.deepEqual(f.values()[1], ['2026-10-15', 1, 'OLD_261015_01']);
  assert.deepEqual(f.values()[2], ['2026-10-16', 2, 'ANM_261016_01, ANM_261016_02']);
  assert.equal(result.readback.rows.length, 2); assert.equal(result.readback.read_response.code, 0);
  assert.equal(result.readback.write_response.code, 0); assert.equal(result.proof.verified_after_readback, true);
  assert.equal(f.calls.every(r => r.url.startsWith('https://open.larksuite.com/') && r.maxRedirects === 0), true);
  assert.equal(f.calls.at(-1).method, 'GET');
});

test('wide layout stores exactly one code per cell, preserves date and replays without another write',async t=>{
  const existing=['16/10/2026',1,wanted[0].listing_codes[0],...Array(20).fill('')];
  const f=fixture(t,[WIDE_HEADERS,existing]);f.sheet.layout=()=>({layout:'one_listing_per_cell_v1',sheet_id:'sheetTest'});
  await f.sheet.sync(wanted,{beforeWrite:async()=>{}});
  assert.deepEqual(f.values()[1].slice(0,4),['16/10/2026',2,...wanted[0].listing_codes]);
  assert.equal(f.values()[1].length,23);assert.equal(f.calls.find(r=>r.method==='PUT').data.valueRange.range,'sheetTest!B2:W2');
  await f.sheet.sync(wanted,{beforeWrite:async()=>{throw Error('duplicate write');}});assert.equal(f.writes(),1);
  assert.throws(()=>parse([WIDE_HEADERS,['2026-10-16',2,wanted[0].listing_codes.join(', ')]],true),/one_listing_per_cell/);
  assert.throws(()=>parse([WIDE_HEADERS,['2026-10-16',1,'','','=A1']],true),/formula/);
});

test('layout migration preserves dates and all old codes while enabling future per-cell writes',async t=>{
 const f=fixture(t);const legacy=[HEADERS,['2026-10-15',1,'OLD_261015_01']],store={sheetTest:structuredClone(legacy)};let added=0;
 f.client.request=async req=>{
  if(req.url.includes('get_node'))return {code:0,data:{node:{obj_type:'sheet',obj_token:'shtTestOnly'}}};
  if(req.url.endsWith('/sheets/query'))return {code:0,data:{sheets:Object.keys(store).map(id=>({sheet_id:id,title:id==='sheetTest'?'Sheet1':'KPI - mỗi ô một listing',grid_properties:{row_count:1000,column_count:26}}))}};
  if(req.url.endsWith('sheets_batch_update')){added++;store.wideTest=[];return {code:0,data:{}};}
  if(req.method==='PUT'){const vr=req.data.valueRange,id=vr.range.split('!')[0],m=vr.range.match(/!([AB])(\d+)/);vr.values.forEach((row,i)=>{const index=Number(m[2])-1+i;store[id][index]||=[];row.forEach((v,n)=>store[id][index][n+(m[1]==='B'?1:0)]=v);});return {code:0,data:{}};}
  const id=decodeURIComponent(req.url).split('/values/')[1].split('!')[0];return {code:0,data:{valueRange:{values:structuredClone(store[id])}}};
 };
 const result=await f.sheet.migrateLayout(wanted);assert.equal(result.layout,'one_listing_per_cell_v1');
 assert.deepEqual(store.sheetTest[0],WIDE_HEADERS);assert.equal(store.sheetTest[1][0],legacy[1][0]);assert.equal(store.sheetTest[1][2],legacy[1][2]);
 assert.deepEqual(store.sheetTest[2].slice(2,4),wanted[0].listing_codes);
 await f.sheet.migrateLayout(wanted);assert.equal(added,0);
});
test('exact remote row after an unknown write outcome is reconciled without another PUT', async t => {
  const f = fixture(t, [HEADERS, ['2026-10-16', 2, wanted[0].listing_codes.join(', ')]]);
  const result = await f.sheet.sync(wanted, { beforeWrite: async () => { throw Error('must_not_write'); } });
  assert.equal(f.writes(), 0); assert.equal(result.readback.write_response.reconciled_without_write, true);
});
test('growing an owned day preserves its existing formatted date cell', async t => {
  const f = fixture(t, [HEADERS, ['16/10/2026', 1, 'ANM_261016_01']]);
  await f.sheet.sync(wanted, { beforeWrite: async () => {} });
  assert.equal(f.values()[1][0], '16/10/2026');
  assert.equal(f.calls.find(r => r.method === 'PUT').data.valueRange.range, 'sheetTest!B2:C2');
});
test('unknown legacy codes, duplicate dates, count mismatch and formula cells never get overwritten', async t => {
  for (const data of [
    [HEADERS, ['2026-10-16', 1, 'OLD_261016_01']],
    [HEADERS, ['2026-10-16', 0, ''], ['16/10/2026', 0, '']],
    [HEADERS, ['2026-10-16', 10, '']],
    [HEADERS, ['2026-10-16', '=COUNTA(C2)', '']]
  ]) {
    const f = fixture(t, data);
    await assert.rejects(() => f.sheet.sync(wanted, { beforeWrite: async () => {} }), /conflict|duplicate/);
    assert.equal(f.writes(), 0);
  }
});
test('native authorization runs after the latest remote read and can stop a stale write', async t => {
  const f = fixture(t);
  await assert.rejects(() => f.sheet.sync(wanted, { beforeWrite: async () => {
    assert.equal(f.calls.at(-1).method, 'GET'); throw Error('native_task_superseded');
  } }), /superseded/);
  assert.equal(f.writes(), 0);
});
test('remote failed readback prevents completion even if provider acknowledged the write', async t => {
  const f = fixture(t), original = f.client.request;
  f.client.request = async request => {
    const result = await original(request);
    if (request.method === 'PUT') f.replace([HEADERS]);
    return result;
  };
  await assert.rejects(() => f.sheet.sync(wanted, { beforeWrite: async () => {} }), /readback_mismatch/);
});
test('pinned spreadsheet/header identity and authoritative pilot exclusion are enforced', async t => {
  assert.throws(() => new KpiSheet({ targetUrl: 'https://other.example/wiki/test' }), /target_changed/);
  assert.throws(() => parse([['Other', 'Số listing', 'Mã listing']]), /headers_changed/);
  assert.throws(() => canonical([{ ...wanted[0], count: 1, listing_codes: ['ANM_261016_01_PILOT'] }]), /rows_invalid/);
  assert.equal(date(46311), '2026-10-16');
  assert.throws(() => date('31/02/2026'), /date_invalid/);
  const f = fixture(t); f.sheet.config.spreadsheetToken = 'differentToken';
  assert.equal((await f.sheet.readiness()).code, 'kpi_spreadsheet_identity_changed');
});
