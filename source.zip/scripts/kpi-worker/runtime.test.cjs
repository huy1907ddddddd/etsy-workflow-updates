'use strict';
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { KpiRuntime, defaults, validateConfig, hash } = require('./runtime.cjs');
function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kpi-runtime-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const config = { ...defaults(root), n8nCli: __filename }, now = Date.now();
  const rows = [{ date: '2026-10-16', count: 1, listing_codes: ['ANM_261016_01'] }];
  const task = { id: 'test-task', revision: 1, fingerprint: 'a'.repeat(64), kind: 'lark_kpi', status: 'pending', payload: { url: config.targetUrl, rows } };
  const calls = { writes: 0, readiness: 0, commands: [], notices: [] };
  let value = { ok: true, observed_at: new Date(now).toISOString(), kpi_active: true, rows, rows_fingerprint: 'b'.repeat(64), tasks: [task],
    task_states: [{ id: task.id, status: 'pending', revision: 1, current_revision: 1, fingerprint: task.fingerprint }] };
  const native = { execute: async command => { calls.commands.push(structuredClone(command)); return command.action === 'kpi_sync_cycle' ? structuredClone(value) : { ok: true, status: 'verified' }; } };
  const adapter = { readiness: async () => { calls.readiness++; return { ready: true }; }, sync: async (actual, hooks) => {
    await hooks.beforeWrite(); calls.writes++; await hooks.checkpoint({ event: 'row_written' });
    return { readback: { rows: actual, readback_at: new Date(now).toISOString(), spreadsheet_token: 'test-spreadsheet', sheet_id: 'test-sheet', range: 'test-sheet!A1:C201', official_api_origin: 'https://open.larksuite.com', write_response: { code: 0 }, read_response: { code: 0 } },
      proof: { executor: 'independent_lark_sheets_worker', verified_after_readback: true, url: config.targetUrl } };
  } };
  const runtime = new KpiRuntime(config, { native, adapter, now: () => now, notify: async notice => calls.notices.push(notice) });
  return { root, config, runtime, native, adapter, calls, task, rows, snapshot: () => value, set: next => { value = next; } };
}
test('writes current bound rows, saves actual readback and submits through native only', async t => {
  const f = fixture(t); assert.equal((await f.runtime.tick()).status, 'synced'); assert.equal(f.calls.writes, 1);
  const command = f.calls.commands.find(command => command.action === 'kpi_sync_verified');
  const bytes = fs.readFileSync(command.proof.path), proof = JSON.parse(bytes);
  assert.equal(hash(bytes), command.proof.sha256); assert.equal(proof.task_id, f.task.id); assert.deepEqual(proof.rows, f.rows);
  assert.equal(command.proof.verified_after_readback, true); assert.equal(f.calls.commands.filter(command => command.action === 'kpi_sync_cycle').length, 4);
});
test('KPI inactive and empty queue never touch Sheets readiness or API', async t => {
  const f = fixture(t); f.snapshot().kpi_active = false; await f.runtime.tick(); assert.equal(f.calls.readiness, 0);
  f.snapshot().kpi_active = true; f.snapshot().tasks = []; await f.runtime.tick(); assert.equal(f.calls.writes, 0); assert.equal(f.calls.readiness, 0);
});

test('shared native lock contention is quiet while real KPI blockers still notify and recover', async t => {
  const f = fixture(t);
  f.runtime.notice = { last: 'native_execution_busy:', blocked: true };
  assert.equal((await f.runtime.block('native_execution_busy')).status, 'waiting_native_execution');
  await f.runtime.recovered(); assert.equal(f.calls.notices.length, 0);
  await f.runtime.block('permission_required');
  const saved = JSON.stringify(f.runtime.notice);
  await f.runtime.block('native_execution_busy'); assert.equal(JSON.stringify(f.runtime.notice), saved);
  await f.runtime.recovered();
  assert.deepEqual(f.calls.notices.map(n => n.code), ['permission_required', 'kpi_worker_recovered']);
});
test('stale snapshot and pilot rows fail before any external write', async t => {
  const f = fixture(t); f.snapshot().observed_at = '2000-01-01T00:00:00Z'; await assert.rejects(() => f.runtime.tick(), /snapshot_stale/);
  f.snapshot().observed_at = new Date().toISOString(); f.rows[0].listing_codes[0] += '_PILOT'; await assert.rejects(() => f.runtime.tick(), /rows_invalid/); assert.equal(f.calls.writes, 0);
});
test('every changed row gets fresh native binding; revision changes stop next write', async t => {
  const f = fixture(t); f.adapter.sync = async (_rows, hooks) => {
    await hooks.beforeWrite(); f.calls.writes++; f.snapshot().rows_fingerprint = 'c'.repeat(64);
    await hooks.beforeWrite(); f.calls.writes++;
  };
  await assert.rejects(() => f.runtime.tick(), /task_changed_before_write/); assert.equal(f.calls.writes, 1);
});
test('readback mismatch never submits a verified command', async t => {
  const f = fixture(t), sync = f.adapter.sync; f.adapter.sync = async (...args) => { const value = await sync(...args); value.readback.rows = []; return value; };
  await assert.rejects(() => f.runtime.tick(), /verified_readback_required/); assert.equal(f.calls.commands.some(command => command.action === 'kpi_sync_verified'), false);
});
test('unknown native submission retries exactly same command without repeating Sheets writes', async t => {
  const f = fixture(t), execute = f.native.execute; let failed = false;
  f.native.execute = async command => { if (command.action === 'kpi_sync_verified' && !failed) { failed = true; f.calls.commands.push(structuredClone(command)); throw Error('unknown_submission'); } return execute(command); };
  await assert.rejects(() => f.runtime.tick(), /unknown_submission/); const old = f.calls.commands.at(-1);
  await f.runtime.tick(); assert.equal(f.calls.writes, 1); assert.deepEqual(f.calls.commands.at(-1), old);
});
test('superseded task keeps unknown submission proof and never resubmits stale decision', async t => {
  const f = fixture(t), execute = f.native.execute;
  f.native.execute = async command => command.action === 'kpi_sync_verified' ? Promise.reject(Error('unknown')) : execute(command);
  await assert.rejects(() => f.runtime.tick(), /unknown/); const before = JSON.parse(fs.readFileSync(f.runtime.file(f.task.id)));
  f.snapshot().tasks = []; f.snapshot().task_states[0].status = 'superseded'; await f.runtime.tick();
  assert.equal(JSON.parse(fs.readFileSync(f.runtime.file(f.task.id))).status, 'superseded'); assert.ok(fs.existsSync(before.command.proof.path)); assert.equal(f.calls.writes, 1);
});
test('modified readback evidence blocks unknown submission retry', async t => {
  const f = fixture(t), execute = f.native.execute;
  f.native.execute = async command => command.action === 'kpi_sync_verified' ? Promise.reject(Error('unknown')) : execute(command);
  await assert.rejects(() => f.runtime.tick(), /unknown/); const state = JSON.parse(fs.readFileSync(f.runtime.file(f.task.id)));
  fs.appendFileSync(state.command.proof.path, ' '); await assert.rejects(() => f.runtime.tick(), /readback_changed/); assert.equal(f.calls.writes, 1);
});
test('permission blocker notification retries failure then deduplicates across restart', async t => {
  const f = fixture(t); let attempts = 0; f.runtime.notify = async () => { if (++attempts === 1) throw Error('offline'); };
  f.adapter.readiness = async () => ({ ready: false, code: 'lark_sheet_permission_required' });
  await f.runtime.tick(); await f.runtime.tick(); await f.runtime.tick(); assert.equal(attempts, 2);
  const restart = new KpiRuntime(f.config, { native: f.native, adapter: f.adapter, notify: f.runtime.notify }); await restart.tick(); assert.equal(attempts, 2);
});
test('recovery alert uses bot accepted status and retries a failed recovery', async t => {
  const f = fixture(t); await f.runtime.block('permission_required'); let tries = 0;
  f.runtime.notify = async notice => { assert.equal(notice.status, 'recovered'); if (++tries === 1) throw Error('offline'); };
  await f.runtime.recovered(); assert.equal(f.runtime.notice.blocked, true); await f.runtime.recovered(); assert.equal(f.runtime.notice.blocked, false); assert.equal(tries, 2);
});
test('check mode cannot write and unsafe target or unshared native lock cannot start', async t => {
  const f = fixture(t); await f.runtime.tick({ readinessOnly: true }); assert.equal(f.calls.writes, 0);
  assert.equal(validateConfig(f.config), f.config);
  assert.throws(() => validateConfig({ ...f.config, targetUrl: 'https://attacker.test' }), /target_identity/);
  assert.throws(() => validateConfig({ ...f.config, executionLockFile: path.join(f.config.stateDir, 'lock') }), /shared_native_lock/);
});
test('check mode cannot replay a pending native commit', async t => {
  const f = fixture(t), execute = f.native.execute;
  f.native.execute = async command => command.action === 'kpi_sync_verified' ? Promise.reject(Error('unknown')) : execute(command);
  await assert.rejects(() => f.runtime.tick(), /unknown/); f.native.execute = execute;
  const count = f.calls.commands.length; await f.runtime.tick({ readinessOnly: true });
  assert.equal(f.calls.commands.slice(count).some(command => command.action === 'kpi_sync_verified'), false); assert.equal(f.calls.writes, 1);
});
test('legacy other dates remain in readback evidence', async t => {
  const f = fixture(t), sync = f.adapter.sync; f.adapter.sync = async (...args) => { const result = await sync(...args); result.readback.rows = [...result.readback.rows, { date: '2025-01-01', count: 1, listing_codes: ['LEGACY'] }]; return result; };
  await f.runtime.tick(); const command = f.calls.commands.at(-1); assert.equal(JSON.parse(fs.readFileSync(command.proof.path)).rows.length, 2);
});
test('runtime integrates real SDK adapter with isolated fake official transport and preserves legacy rows', async t => {
  const f = fixture(t); const { KpiSheet, HEADERS } = require('./lark-sheet.cjs');
  const cells = [HEADERS, ['2025-01-01', 1, 'LEGACY'], ['2026-10-16', 0, '']]; let puts = 0;
  const client = { request: async request => {
    if (request.url.includes('get_node')) return { code: 0, data: { node: { obj_type: 'sheet', obj_token: 'testToken' } } };
    if (request.url.includes('/sheets/query')) return { code: 0, data: { sheets: [{ sheet_id: 'testSheet', title: 'Sheet1', grid_properties: { row_count: 201, column_count: 3 } }] } };
    if (request.method === 'GET') return { code: 0, data: { valueRange: { values: structuredClone(cells) } } };
    assert.equal(request.method, 'PUT'); assert.equal(f.calls.commands.at(-1).action, 'kpi_sync_cycle');
    assert.equal(request.data.valueRange.range, 'testSheet!B3:C3'); puts++; cells[2][1] = request.data.valueRange.values[0][0]; cells[2][2] = request.data.valueRange.values[0][1];
    return { code: 0 };
  } };
  f.runtime.adapter = new KpiSheet(f.config, { client });
  assert.equal((await f.runtime.tick()).status, 'synced'); assert.equal(puts, 1); assert.deepEqual(cells[1], ['2025-01-01', 1, 'LEGACY']);
  const command = f.calls.commands.at(-1); assert.equal(JSON.parse(fs.readFileSync(command.proof.path)).rows.length, 2);
});
test('canonical receipt allows exact submission replay after aggregate grows without new API write', async t => {
  const f = fixture(t), execute = f.native.execute;
  f.native.execute = async command => command.action === 'kpi_sync_verified' ? Promise.reject(Error('unknown')) : execute(command);
  await assert.rejects(() => f.runtime.tick(), /unknown/); f.snapshot().rows_fingerprint = 'c'.repeat(64); f.snapshot().task_states[0].receipt = { ok: true };
  f.snapshot().task_states[0].status = 'verified'; f.native.execute = execute; await f.runtime.tick(); assert.equal(f.calls.writes, 1);
});
test('daemon starts readback endpoint before native cycle and closes owned listener exactly once', async t => {
  const f = fixture(t); let started = 0, closed = 0; const execute = f.native.execute;
  f.runtime.startReadback = async (config, adapter) => { assert.equal(config, f.config); assert.equal(adapter, f.adapter); started++; return { close: callback => { closed++; callback(); } }; };
  f.native.execute = async command => { assert.equal(started, 1); return execute(command); };
  await f.runtime.run({ once: true }); await f.runtime.stop(); assert.equal(started, 1); assert.equal(closed, 1);
  assert.equal(fs.existsSync(path.join(f.config.stateDir, 'worker.lock')), false);
});
test('port already occupied blocks before native cycles or Sheets writes and never controls external listener', async t => {
  const f = fixture(t); f.runtime.startReadback = async () => { const error = Error('occupied'); error.code = 'EADDRINUSE'; throw error; };
  await f.runtime.run({ once: true }); const status = JSON.parse(fs.readFileSync(path.join(f.config.stateDir, 'status.json')));
  assert.equal(status.code, 'kpi_readback_port_in_use'); assert.equal(f.calls.commands.length, 0); assert.equal(f.calls.writes, 0);
});
test('check mode does not bind readback endpoint', async t => {
  const f = fixture(t); f.runtime.startReadback = async () => { throw Error('check must not open listener'); };
  await f.runtime.run({ readinessOnly: true }); assert.equal(JSON.parse(fs.readFileSync(path.join(f.config.stateDir, 'status.json'))).status, 'ready'); assert.equal(f.calls.writes, 0);
});
test('stop during readback startup closes late owned listener and never starts cycle', async t => {
  const f = fixture(t); let closed = 0;
  f.runtime.startReadback = async () => { await f.runtime.stop(); return { close: callback => { closed++; callback(); } }; };
  await f.runtime.run({ once: true }); assert.equal(closed, 1); assert.equal(f.calls.commands.length, 0);
});
