'use strict';
const fs = require('node:fs');
const http = require('node:http');
const { timingSafeEqual } = require('node:crypto');
function makeReadbackServer(config, adapter) {
  const lark = JSON.parse(fs.readFileSync(config.larkConfigFile, 'utf8').replace(/^\uFEFF/, ''));
  if (typeof lark.localToken !== 'string' || lark.localToken.length < 32) throw Error('kpi_readback_auth_required');
  const token = Buffer.from(lark.localToken);
  const server = http.createServer(async (req, res) => {
    const reply = (status, value) => { res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(value)); };
    const received = Buffer.from(typeof req.headers['x-review-token'] === 'string' ? req.headers['x-review-token'] : '');
    if (received.length !== token.length || !timingSafeEqual(received, token)) return reply(401, { ok: false, code: 'unauthorized' });
    if(req.method==='POST'&&req.url==='/kpi-layout'){
      try{let body='';for await(const b of req){body+=b;if(body.length>200000)throw Error('kpi_layout_request_too_large');}
        const input=JSON.parse(body);return reply(200,await adapter.migrateLayout(input.rows));
      }catch(error){return reply(409,{ok:false,code:error.code||error.message||'kpi_layout_failed'});}
    }
    if (req.method !== 'GET' || req.url !== '/kpi-sheet') return reply(404, { ok: false, code: 'route_not_found' });
    try { reply(200, { ok: true, readback: await adapter.inspect() }); }
    catch (error) { reply(503, { ok: false, code: /^[a-z0-9_]+$/i.test(error.code || '') ? error.code : 'kpi_readback_unavailable' }); }
  });
  server.requestTimeout = 10000; server.headersTimeout = 10000;
  return server;
}
async function startReadbackServer(config, adapter) {
  const server = makeReadbackServer(config, adapter);
  // The runtime owns this listener; it exposes fresh provider reads, never supplied receipts.
  await new Promise((resolve, reject) => {
    const failed = error => { const failure = Error(error.code === 'EADDRINUSE' ? 'kpi_readback_port_occupied' : 'kpi_readback_server_failed'); failure.code = error.code; reject(failure); };
    server.once('error', failed);
    server.listen(8791, '127.0.0.1', () => { server.off('error', failed); resolve(); });
  });
  return server;
}
module.exports = { startReadbackServer, makeReadbackServer };
