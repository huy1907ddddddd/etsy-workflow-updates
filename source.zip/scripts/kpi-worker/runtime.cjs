'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { isDeepStrictEqual } = require('node:util');
const { NativeN8n, atomic, claimProcessLock } = require('../flow-worker/native-n8n.cjs');
const { defaults: flowDefaults } = require('../flow-worker/runtime.cjs');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const targetUrl = 'https://local-workspace.invalid/wiki/LOCAL_DESTINATION_REQUIRED';
function rowsMatch(actual, expected) {
  if (!Array.isArray(actual)) return false;
  const dates = new Set(expected.map(row => row.date)), matched = actual.filter(row => dates.has(row.date));
  if (matched.length !== expected.length || new Set(matched.map(row => row.date)).size !== matched.length) return false;
  return expected.every(row => { const found = matched.find(item => item.date === row.date);
    return found && found.count === row.count && Array.isArray(found.listing_codes) && found.listing_codes.length === row.count
      && isDeepStrictEqual([...found.listing_codes].sort(), [...row.listing_codes].sort()); });
}
function defaults(root = 'C:/Huy/etsy-workflow') {
  return { ...flowDefaults(root), stateDir: path.join(root, 'workspace/kpi-worker/runtime'), logDir: path.join(root, 'logs/kpi-worker'),
    readbackDir: path.join(root, 'workspace/kpi-worker/readback'), executionLockFile: path.join(root, 'workspace/flow-worker/runtime/native-execution.lock'),
    targetUrl, spreadsheetToken: '', sheetId: '' };
}
function validateConfig(config) {
  if (config.targetUrl !== targetUrl || config.mainWorkflowId !== 'DpZkxoKm7B6jrFQi' || config.larkBaseUrl !== 'http://127.0.0.1:8790') throw Error('kpi_target_identity_invalid');
  for (const key of ['stateDir', 'readbackDir']) {
    const rel = path.relative(path.resolve(config.workflowRoot, 'workspace/kpi-worker'), path.resolve(config[key]));
    if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) throw Error('kpi_dedicated_directory_required');
  }
  if (path.resolve(config.executionLockFile) !== path.resolve(config.workflowRoot, 'workspace/flow-worker/runtime/native-execution.lock')) throw Error('shared_native_lock_required');
  for (const key of ['pollIntervalMs', 'nativeTimeoutMs', 'maxSnapshotAgeMs']) if (!Number.isInteger(config[key]) || config[key] < 1000) throw Error('kpi_timeout_invalid');
  if (!fs.existsSync(config.n8nCli)) throw Error('n8n_cli_missing');
  return config;
}
class KpiRuntime {
  constructor(config, deps = {}) {
    this.config = config; this.native = deps.native || new NativeN8n(config); this.adapter = deps.adapter; this.now = deps.now || Date.now;
    this.notify = deps.notify || this.notifyLark.bind(this); this.stopping = false;
    this.startReadback = deps.readbackServer || ((config, adapter) => require('./readback-server.cjs').startReadbackServer(config, adapter));
    this.readbackServer = null; this.serverClosing = null;
    fs.mkdirSync(config.stateDir, { recursive: true });
    this.noticeFile = path.join(config.stateDir, 'notice.json'); this.notice = fs.existsSync(this.noticeFile) ? read(this.noticeFile) : { last: null, blocked: false };
  }
  async notifyLark(value) {
    const lark = read(this.config.larkConfigFile);
    const response = await fetch(this.config.larkBaseUrl + '/worker-status', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': lark.localToken },
      body: JSON.stringify({ status: value.status, code: value.code, task_id: value.task_id, message: value.status === 'recovered' ? 'Worker KPI đã hoạt động lại.' : 'Worker KPI: ' + value.code }), signal: AbortSignal.timeout(5000), redirect: 'error' });
    if (!response.ok) throw Error('kpi_notification_pending');
  }
  status(value) { const result = { ...value, pid: process.pid, updated_at: new Date(this.now()).toISOString() }; atomic(path.join(this.config.stateDir, 'status.json'), result); return result; }
  async block(code, task_id = null) {
    if (code === 'native_execution_busy') return this.status({ status: 'waiting_native_execution', code, task_id });
    const value = this.status({ status: 'blocked', code, task_id }), key = code + ':' + (task_id || '');
    this.notice.blocked = true;
    if (this.notice.last !== key) {
      this.notice.pending = value; atomic(this.noticeFile, this.notice);
      try { await this.notify(value); this.notice.last = key; delete this.notice.pending; } catch { value.notification_pending = true; }
    }
    atomic(this.noticeFile, this.notice); return value;
  }
  async recovered() {
    if (!this.notice.blocked) return;
    if (this.notice.last === 'native_execution_busy:') {
      this.notice = { last: null, blocked: false }; atomic(this.noticeFile, this.notice); return;
    }
    try { await this.notify({ status: 'recovered', code: 'kpi_worker_recovered' }); this.notice = { last: null, blocked: false }; atomic(this.noticeFile, this.notice); } catch { /* Retry next healthy cycle. */ }
  }
  cycle() { return this.native.execute({ action: 'kpi_sync_cycle' }); }
  snapshot(value) {
    const stamp = Date.parse(value?.observed_at);
    if (value?.ok !== true || typeof value.kpi_active !== 'boolean' || !Array.isArray(value.tasks) || !Array.isArray(value.task_states) || !Array.isArray(value.rows)
      || !Number.isFinite(stamp) || stamp > this.now() + 1000 || this.now() - stamp > this.config.maxSnapshotAgeMs) throw Error('kpi_snapshot_stale');
    if (!/^[a-f0-9]{64}$/.test(value.rows_fingerprint || '')) throw Error('kpi_rows_identity_invalid');
    return value;
  }
  task(snapshot, id) {
    this.snapshot(snapshot);
    if (!snapshot.kpi_active) throw Error('kpi_inactive');
    const task = snapshot.tasks.find(item => item.id === id);
    if (!task || task.kind !== 'lark_kpi' || task.status !== 'pending') throw Error('kpi_task_no_longer_pending');
    if (!Number.isInteger(task.revision) || task.revision < 1 || !/^[a-f0-9]{64}$/.test(task.fingerprint || '') || task.payload?.url !== this.config.targetUrl
      || !isDeepStrictEqual(task.payload.rows, snapshot.rows) || !snapshot.rows.length) throw Error('kpi_task_identity_invalid');
    for (const row of snapshot.rows) if (!/^\d{4}-\d{2}-\d{2}$/.test(row.date || '') || !Number.isInteger(row.count) || row.count < 1 || row.count !== row.listing_codes?.length
      || new Set(row.listing_codes).size !== row.count || row.listing_codes.some(code => typeof code !== 'string' || code.endsWith('_PILOT'))) throw Error('kpi_rows_invalid');
    if (new Set(snapshot.rows.map(row => row.date)).size !== snapshot.rows.length) throw Error('kpi_duplicate_date');
    return task;
  }
  file(id) { return path.join(this.config.stateDir, 'task-' + hash(id) + '.json'); }
  save(state) { atomic(this.file(state.task_id), state); }
  async current(state) {
    if (this.stopping) throw Error('kpi_worker_stopping');
    const snapshot = this.snapshot(await this.cycle()), task = this.task(snapshot, state.task_id);
    if (task.revision !== state.revision || task.fingerprint !== state.fingerprint || snapshot.rows_fingerprint !== state.rows_fingerprint || !isDeepStrictEqual(task.payload, state.payload)) throw Error('kpi_task_changed_before_write');
    return snapshot;
  }
  proof(state) {
    const file = fs.realpathSync(state.command.proof.path), base = fs.realpathSync(this.config.readbackDir), rel = path.relative(base, file);
    if (!rel || rel.startsWith('..') || path.isAbsolute(rel) || hash(fs.readFileSync(file)) !== state.command.proof.sha256) throw Error('kpi_readback_changed');
    const proof = read(file);
    if (proof.task_id !== state.task_id || proof.revision !== state.revision || proof.task_fingerprint !== state.fingerprint || proof.rows_fingerprint !== state.rows_fingerprint
      || proof.target_url !== this.config.targetUrl || !rowsMatch(proof.rows, state.payload.rows)) throw Error('kpi_readback_identity_invalid');
  }
  async tick({ readinessOnly = false } = {}) {
    if (require('../review-transport.cjs').choice(this.config.workflowRoot).delivery_backend === 'local_v1') return this.status({ status: 'idle', delivery_backend: 'local_v1', remote_api_calls: false });
    const snapshot = this.snapshot(await this.cycle());
    // Resolve unknown native submission before any new remote write.
    for (const name of fs.readdirSync(this.config.stateDir).filter(name => !readinessOnly && /^task-[a-f0-9]{64}\.json$/.test(name))) {
      const state = read(path.join(this.config.stateDir, name));
      if (state.status !== 'submit_pending') continue;
      const live = snapshot.task_states.find(task => task.id === state.task_id);
      if (live && (live.status === 'superseded' || live.revision !== state.revision || live.current_revision !== state.revision || live.fingerprint !== state.fingerprint)) { state.status = 'superseded'; this.save(state); continue; }
      if (!live?.receipt && (snapshot.rows_fingerprint !== state.rows_fingerprint || !snapshot.kpi_active)) return this.status({ status: 'idle', code: 'kpi_submission_waiting_for_canonical_state', task_id: state.task_id });
      this.proof(state);
      state.result = await this.native.execute(state.command); state.status = 'submitted'; this.save(state); await this.recovered();
      return this.status({ status: 'synced', task_id: state.task_id });
    }
    if (!snapshot.kpi_active || !snapshot.tasks.length || !snapshot.rows.length) { await this.recovered(); return this.status({ status: 'idle', kpi_active: snapshot.kpi_active }); }
    const ready = await this.adapter.readiness();
    if (!ready.ready) return this.block(ready.code || 'kpi_sheet_setup_pending');
    if (readinessOnly) return this.status({ status: 'ready', ready: true, writes_performed: false });
    const task = this.task(snapshot, snapshot.tasks[0].id);
    const state = fs.existsSync(this.file(task.id)) ? read(this.file(task.id)) : { task_id: task.id, revision: task.revision, fingerprint: task.fingerprint,
      rows_fingerprint: snapshot.rows_fingerprint, payload: task.payload, status: 'claimed', events: [] };
    if (state.revision !== task.revision || state.fingerprint !== task.fingerprint || state.rows_fingerprint !== snapshot.rows_fingerprint || !isDeepStrictEqual(state.payload, task.payload)) throw Error('kpi_checkpoint_identity_changed');
    this.save(state);
    await this.current(state);
    const result = await this.adapter.sync(task.payload.rows, {
      beforeWrite: async () => { await this.current(state); state.status = 'writing'; state.events.push({ event: 'write_authorized', at: new Date(this.now()).toISOString() }); this.save(state); },
      checkpoint: async record => { state.events.push({ ...record, at: new Date(this.now()).toISOString() }); this.save(state); }
    });
    if (result?.proof?.executor !== 'independent_lark_sheets_worker' || result.proof.verified_after_readback !== true || result.proof.url !== this.config.targetUrl
      || !rowsMatch(result.readback?.rows, task.payload.rows) || result.readback.write_response?.code !== 0 || result.readback.read_response?.code !== 0) throw Error('kpi_verified_readback_required');
    const readbackTime = Date.parse(result.readback.readback_at);
    if (!Number.isFinite(readbackTime) || readbackTime > this.now() + 1000 || this.now() - readbackTime > this.config.maxSnapshotAgeMs
      || result.readback.official_api_origin !== 'https://open.larksuite.com' || !result.readback.spreadsheet_token || !result.readback.sheet_id || !result.readback.range) throw Error('kpi_readback_metadata_invalid');
    await this.current(state);
    const readback = { ...result.readback, task_id: state.task_id, revision: state.revision, task_fingerprint: state.fingerprint, rows_fingerprint: state.rows_fingerprint,
      target_url: this.config.targetUrl, executor: result.proof.executor, verified_after_readback: true };
    const file = path.join(this.config.readbackDir, hash(task.id) + '-' + state.rows_fingerprint + '.json'); atomic(file, readback);
    state.command = { action: 'kpi_sync_verified', task_id: state.task_id, revision: state.revision, task_fingerprint: state.fingerprint, rows_fingerprint: state.rows_fingerprint,
      target_url: this.config.targetUrl, proof: { executor: result.proof.executor, verified_after_readback: true, path: file, sha256: hash(fs.readFileSync(file)) } };
    state.status = 'submit_pending'; this.save(state); this.proof(state);
    state.result = await this.native.execute(state.command); state.status = 'submitted'; this.save(state); await this.recovered();
    return this.status({ status: 'synced', task_id: state.task_id });
  }
  async run({ once = false, readinessOnly = false } = {}) {
    const release = claimProcessLock(path.join(this.config.stateDir, 'worker.lock'), 'kpi-worker'), stopFile = path.join(this.config.stateDir, 'stop.request');
    const watcher = fs.watch(this.config.stateDir, () => { if (fs.existsSync(stopFile)) this.stop(); });
    try {
      while (!this.stopping && !fs.existsSync(stopFile)) {
        try {
          if (!readinessOnly && !this.readbackServer) {
            try { this.readbackServer = await this.startReadback(this.config, this.adapter); }
            catch (error) { if (error.code === 'EADDRINUSE') throw Error('kpi_readback_port_in_use'); throw Error(error.code || 'kpi_readback_server_unavailable'); }
            if (this.stopping) { await this.closeReadback(); break; }
          }
          await this.tick({ readinessOnly });
        } catch (error) { await this.block(error.message || 'kpi_worker_failed'); }
        if (once || readinessOnly) break;
        await new Promise(resolve => { this.wake = resolve; this.timer = setTimeout(resolve, this.config.pollIntervalMs); }); clearTimeout(this.timer); this.wake = null;
      }
    } finally { watcher.close(); try { await this.closeReadback(); } finally { this.native.stop?.(); release(); } if (!once && !readinessOnly) this.status({ status: 'stopped' }); }
  }
  closeReadback() {
    if (this.serverClosing) return this.serverClosing;
    if (!this.readbackServer) return Promise.resolve();
    const server = this.readbackServer; this.readbackServer = null;
    this.serverClosing = new Promise(resolve => { server.close(() => resolve()); server.closeIdleConnections?.(); });
    return this.serverClosing;
  }
  stop() { this.stopping = true; clearTimeout(this.timer); this.wake?.(); return this.closeReadback(); }
}
async function main() {
  const root = 'C:/Huy/etsy-workflow', configFile = process.env.KPI_WORKER_CONFIG || path.join(root, 'config/kpi-worker.private.json');
  const flowFile = process.env.FLOW_WORKER_CONFIG || path.join(root, 'config/flow-worker.private.json');
  const flow = fs.existsSync(flowFile) ? read(flowFile) : {}, specific = fs.existsSync(configFile) ? read(configFile) : {};
  const config = validateConfig({ ...defaults(flow.workflowRoot || root), ...Object.fromEntries(['n8nCli', 'commandFile', 'brokerPort', 'larkConfigFile'].filter(key => flow[key] !== undefined).map(key => [key, flow[key]])), ...specific });
  const { KpiSheet } = require('./lark-sheet.cjs'); const runtime = new KpiRuntime(config, { adapter: new KpiSheet(config) });
  process.once('SIGINT', () => runtime.stop()); process.once('SIGTERM', () => runtime.stop());
  await runtime.run({ once: process.argv.includes('--once'), readinessOnly: process.argv.includes('--check') });
  if (process.argv.includes('--check') || process.argv.includes('--once')) console.log(JSON.stringify(read(path.join(config.stateDir, 'status.json'))));
}
if (require.main === module) main().catch(() => { console.error(JSON.stringify({ ok: false, code: 'kpi_worker_start_failed' })); process.exitCode = 1; });
module.exports = { KpiRuntime, defaults, validateConfig, hash };
