"""Isolated native KPI gates: no live SQL, Sheets calls, allocations or activation."""
import copy
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
spec = importlib.util.spec_from_file_location('kpi_test_engine', Path(__file__).with_name('production-engine.py'))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
import kpi_sync_orchestration as kpi


class KpiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='native-kpi-isolated-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.saved = {key: getattr(engine, key) for key in ('ROOT', 'STORE', 'scoped')}
        engine.ROOT = self.root
        engine.STORE = self.root / 'workspace/production'
        engine.scoped = self.scoped
        self.addCleanup(lambda: [setattr(engine, key, value) for key, value in self.saved.items()])
        self.c = engine.connect(engine.STORE / 'isolated.sqlite')
        self.addCleanup(self.c.close)
        self.url = 'https://csg2m8jcr9dn.sg.larksuite.com/sheets/IsolatedTestOnly'
        self.c.execute('INSERT INTO config VALUES(?,?)', ('kpi_activation', json.dumps({'activated_at': '2026-01-01T00:00:00+00:00'})))
        self.c.execute('INSERT INTO config VALUES(?,?)', ('kpi_sheet', json.dumps({'url': self.url})))
        self.add_listing('ANM_261014_01')
        self.canonical = None
        self.stub = patch.object(kpi, 'canonical_readback', side_effect=lambda _: copy.deepcopy(self.canonical))
        self.stub.start()
        self.addCleanup(self.stub.stop)

    def scoped(self, value, roots=None):
        p = Path(value).resolve()
        allowed = roots or (self.root,)
        if not any(p.is_relative_to(Path(root).resolve()) and p != Path(root).resolve() for root in allowed):
            raise ValueError('Test path outside fixture roots')
        return p

    def add_listing(self, code, revision=1):
        self.c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)', (code, revision, 'awaiting_kpi_sync', 'a' * 64, '{}', engine.now()))
        file = self.root / (code + '.txt')
        file.write_text('test delivered file only', encoding='utf8')
        review_fp = engine.digest({'code': code, 'revision': revision})
        completed = '2026-10-14T00:00:00+00:00'
        j = engine.job(self.c, code)
        engine.put(self.c, j, 'package', {'listing_code': code, 'revision': revision, 'review_fingerprint': review_fp,
            'completed_at': completed, 'files': [{'path': str(file), 'sha256': engine.sha(file)}]})
        self.c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)', (code, revision, '2026-10-16', completed, review_fp))
        task = engine.task(self.c, j, 'lark_review', {'url': engine.REVIEW_URL, 'packet': {'review_fingerprint': review_fp}})
        screenshot = self.root / (code + '-ui.png')
        screenshot.write_bytes(b'legacy screenshot fixture only')
        proof = {'verified_after_reload': True, 'url': engine.REVIEW_URL, 'content_fingerprint': review_fp, 'screenshot_path': str(screenshot)}
        self.c.execute("UPDATE tasks SET status='verified',proof=? WHERE id=?", (json.dumps(proof), task['id']))

    def cycle(self):
        return engine.execute(self.c, {'action': 'kpi_sync_cycle'})

    def command(self):
        snapshot = self.cycle()
        task = snapshot['tasks'][0]
        cmd = {'action': 'kpi_sync_verified', 'task_id': task['id'], 'revision': task['revision'],
               'task_fingerprint': task['fingerprint'], 'rows_fingerprint': snapshot['rows_fingerprint'], 'target_url': self.url}
        evidence = {key: value for key, value in cmd.items() if key != 'action'}
        evidence.update(executor=kpi.EXECUTOR, verified_after_readback=True, rows=snapshot['rows'],
            readback_at=engine.now(), spreadsheet_token='fixture-token', sheet_id='fixture-sheet', range='fixture-sheet!A1:C100',
            official_api_origin='https://open.larksuite.com', write_response={'code': 0}, read_response={'code': 0})
        self.canonical = copy.deepcopy(evidence)
        file = self.root / 'workspace/kpi-worker/readback' / (task['id'] + '.json')
        engine.write(file, evidence)
        cmd['proof'] = {'executor': kpi.EXECUTOR, 'verified_after_readback': True, 'path': str(file), 'sha256': engine.sha(file)}
        return cmd

    def test_inactive_cycle_is_readonly_and_never_allocates_or_activates(self):
        self.c.execute("DELETE FROM config WHERE key='kpi_activation'")
        before = self.c.total_changes
        result = self.cycle()
        self.assertFalse(result['kpi_active'])
        self.assertEqual(result['tasks'], [])
        self.assertEqual(self.c.total_changes, before)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 1)

    def test_pilot_is_never_counted_even_if_legacy_ledger_contains_it(self):
        self.add_listing('ANM_261014_02_PILOT')
        result = self.cycle()
        self.assertEqual(result['rows'][0]['count'], 1)
        self.assertEqual(result['rows'][0]['listing_codes'], ['ANM_261014_01'])
        self.assertEqual([t['code'] for t in result['tasks']], ['ANM_261014_01'])

    def test_stale_aggregate_task_is_reconciled_without_new_allocation(self):
        old = self.cycle()['tasks'][0]
        self.add_listing('ANM_261014_02')
        current = self.cycle()
        self.assertEqual(current['rows'][0]['count'], 2)
        self.assertEqual(next(t for t in current['task_states'] if t['id'] == old['id'])['status'], 'superseded')
        self.assertNotEqual(old['fingerprint'], current['tasks'][0]['fingerprint'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 2)

    def test_exact_official_readback_completes_only_current_kpi_gate(self):
        cmd = self.command()
        result = engine.execute(self.c, cmd)
        self.assertEqual(result['completed_listing_codes'], ['ANM_261014_01'])
        self.assertEqual(engine.job(self.c, 'ANM_261014_01')['state'], 'completed')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 1)
        identity = next(t for t in self.cycle()['task_states'] if t['id'] == cmd['task_id'])
        self.assertEqual(identity['receipt'], result)

    def test_unknown_outcome_retry_returns_durable_receipt_without_remote_write(self):
        cmd = self.command()
        first = engine.execute(self.c, cmd)
        self.canonical = None
        self.assertEqual(engine.execute(self.c, cmd), first)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi_sync_receipts').fetchone()[0], 1)

    def test_stale_aggregate_proof_cannot_complete_new_rows(self):
        cmd = self.command()
        self.add_listing('ANM_261014_02')
        self.cycle()
        with self.assertRaises(ValueError):
            engine.execute(self.c, cmd)
        self.assertEqual(engine.job(self.c, 'ANM_261014_01')['state'], 'awaiting_kpi_sync')
        self.assertEqual(engine.job(self.c, 'ANM_261014_02')['state'], 'awaiting_kpi_sync')

    def test_same_current_receipt_survives_later_aggregate_rows_change(self):
        cmd = self.command()
        first = engine.execute(self.c, cmd)
        self.add_listing('ANM_261014_02')
        self.cycle()
        self.canonical = None
        self.assertEqual(engine.execute(self.c, cmd), first)
        self.assertEqual(engine.job(self.c, 'ANM_261014_02')['state'], 'awaiting_kpi_sync')

    def test_receipt_retry_revalidates_current_package_bytes(self):
        cmd = self.command()
        engine.execute(self.c, cmd)
        (self.root / 'ANM_261014_01.txt').write_text('changed', encoding='utf8')
        with self.assertRaises(ValueError): engine.execute(self.c, cmd)

    def test_one_readback_completes_matching_pending_jobs_without_allocation(self):
        self.add_listing('ANM_261014_02')
        cmd = self.command()
        result = engine.execute(self.c, cmd)
        self.assertEqual(set(result['completed_listing_codes']), {'ANM_261014_01', 'ANM_261014_02'})
        self.assertEqual(len(result['verified_task_ids']), 2)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0], 2)

    def test_hash_stale_task_wrong_destination_and_forged_origin_rejected(self):
        baseline = self.command()
        for field in ('revision', 'task_fingerprint', 'rows_fingerprint', 'target_url', 'proof_hash', 'executor'):
            cmd = copy.deepcopy(baseline)
            if field == 'proof_hash': cmd['proof']['sha256'] = 'a' * 64
            elif field == 'executor': cmd['proof']['executor'] = 'browser_operator'
            else: cmd[field] = 9 if field == 'revision' else 'wrong'
            with self.subTest(field=field), self.assertRaises(ValueError):
                engine.execute(self.c, cmd)
        self.assertEqual(engine.job(self.c, 'ANM_261014_01')['state'], 'awaiting_kpi_sync')

    def test_fabricated_json_cannot_replace_actual_canonical_readback(self):
        cmd = self.command()
        self.canonical['rows'][0]['listing_codes'] = ['ANM_261014_99']
        with self.assertRaises(ValueError):
            engine.execute(self.c, cmd)
        self.assertEqual(engine.job(self.c, 'ANM_261014_01')['state'], 'awaiting_kpi_sync')

    def test_duplicate_remote_date_and_wrong_counts_rejected(self):
        for mode in ('duplicate', 'count', 'pilot'):
            cmd = self.command()
            if mode == 'duplicate': self.canonical['rows'].append(copy.deepcopy(self.canonical['rows'][0]))
            if mode == 'count': self.canonical['rows'][0]['count'] = 2
            if mode == 'pilot': self.canonical['rows'][0]['listing_codes'] = ['ANM_261014_01_PILOT']
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                engine.execute(self.c, cmd)

    def test_unrelated_dates_are_preserved_and_do_not_affect_native_match(self):
        cmd = self.command()
        self.canonical['rows'].append({'date': 'old-baseline', 'count': 'legacy', 'listing_codes': None})
        self.assertTrue(engine.execute(self.c, cmd)['ok'])

    def test_changed_package_or_missing_current_lark_review_blocks_sync(self):
        self.c.execute("UPDATE tasks SET status='pending' WHERE kind='lark_review'")
        with self.assertRaises(ValueError): self.cycle()

    def test_changed_package_bytes_and_stale_ledger_revision_block_sync(self):
        file = self.root / 'ANM_261014_01.txt'
        file.write_text('mutated package', encoding='utf8')
        with self.assertRaises(ValueError): self.cycle()
        file.write_text('test delivered file only', encoding='utf8')
        self.c.execute("UPDATE jobs SET revision=2 WHERE code='ANM_261014_01'")
        with self.assertRaises(ValueError): self.cycle()

    def test_unscoped_readback_proof_is_rejected_even_with_correct_hash(self):
        cmd = self.command()
        outside = self.root / 'outside-kpi-worker.json'
        outside.write_bytes(Path(cmd['proof']['path']).read_bytes())
        cmd['proof']['path'] = str(outside)
        with self.assertRaises(ValueError): engine.execute(self.c, cmd)

    def test_legacy_screenshot_task_verified_still_requires_legacy_proof(self):
        task = self.cycle()['tasks'][0]
        with self.assertRaises(ValueError):
            engine.execute(self.c, {'action': 'task_verified', 'task_id': task['id'], 'proof': {'verified_after_readback': True}})
        self.assertEqual(self.c.execute('SELECT status FROM tasks WHERE id=?', (task['id'],)).fetchone()[0], 'pending')

    def test_canonical_reader_uses_authenticated_readonly_kpi_port(self):
        observed = {}
        def open_fixture(request, timeout):
            observed.update(url=request.full_url, method=request.get_method(),
                            token=request.get_header('X-review-token'), timeout=timeout)
            return io.StringIO(json.dumps({'ok': True, 'readback': {'rows': []}}))
        self.stub.stop()
        with patch.object(kpi, 'urlopen', side_effect=open_fixture):
            result = kpi.canonical_readback({'ROOT': self.root, 'read': lambda _: {'localToken': 'fixture-only'}})
        self.assertEqual(result, {'rows': []})
        self.assertEqual(observed, {'url': 'http://127.0.0.1:8791/kpi-sheet', 'method': 'GET',
                                    'token': 'fixture-only', 'timeout': 35})


if __name__ == '__main__':
    unittest.main()
