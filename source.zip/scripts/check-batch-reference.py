"""Isolated images and approvals are fixtures only; never touch real batches."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path
from PIL import Image

spec = importlib.util.spec_from_file_location('fixture', Path(__file__).with_name('check-production-batch.py'))
fixture = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture)
engine, batch, flow = fixture.engine, fixture.batch, fixture.flow
import batch_reference
import production_profiles as profiles


class ReferenceTests(fixture.BatchTests):
    def reference(self):
        file = engine.STORE / 'batch-references/reference.png'
        file.parent.mkdir(parents=True, exist_ok=True)
        Image.new('RGB', (32, 32), 'green').save(file)
        return {'path': str(file), 'sha256': engine.sha(file), 'role': 'batch_style_reference'}

    def test_printed_reference_reaches_whole_batch_without_replacing_each_idea(self):
        ref = self.reference()
        self.submit.update(profile_version=3, reference_image=ref)
        self.start(); task = self.cycle()['tasks'][0]
        b = batch.batch(self.c, 'fixture-batch')
        self.assertTrue(all(r['brief']['reference_image'] == ref for r in batch.manifest(b)['items']))
        self.assertIn(ref, task['payload']['images'][0]['references'])
        self.assertIn('An otter bakery corner.', task['payload']['images'][0]['prompt'])
        second = batch.item(self.c, b['batch_id'], '0002')
        plan = batch.plan_images(self.c, b, second, True, self.env)
        self.assertIn('An otter garden.', plan['images'][0]['prompt'])
        self.assertNotIn('An otter bakery corner.', plan['images'][0]['prompt'])
        rule = engine.read(engine.ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        self.assertTrue(all(i['prompt'].endswith(rule) for i in plan['images']))
        self.assertIn(batch_reference.GUIDANCE, plan['images'][0]['prompt'])

    def test_embroidered_reference_cannot_replace_exact_approved_2d(self):
        ref = self.reference()
        self.submit.update(profile_version=3, kind='embroidery_prompts', reference_image=ref,
                           positions={'chest': 'left', 'sleeves': True, 'back': False},
                           items=[{'title': 'Fixture otter', 'designs': {'left_chest': 'Otter bakery', 'left_sleeve': 'Vertical otter garden'}}])
        self.start(); self.cycle()
        task = self.execute({'action': 'browser_queue'})['tasks'][0]
        self.assertTrue(all(ref in i['references'] and len(i['references']) == 2 and any(r['role']=='design_free_composition_guide' for r in i['references']) for i in task['payload']['images']))
        self.execute(self.candidate(task))
        review = flow.review_packet(self.c, {'brief_id': task['brief_id']}, self.env)
        flow.apply_decision(self.c, self.decision(review), self.env)
        preview = self.execute({'action': 'browser_queue'})['tasks'][0]
        self.assertTrue(all(len(i['references']) == 1 and i['references'][0]['role'] == 'exact_locked_2d' for i in preview['payload']['images']))
        self.assertTrue(all(i['references'][0]['sha256'] != ref['sha256'] for i in preview['payload']['images']))
        candidate = self.candidate(preview)
        left = next(a for a in candidate['assets'] if a['image_key'] == 'left_sleeve')
        right = next(a for a in candidate['assets'] if a['image_key'] == 'right_sleeve')
        right.update(path=left['path'], sha256=left['sha256'])
        self.execute(candidate)
        review = flow.review_packet(self.c, {'brief_id': task['brief_id']}, self.env)
        flow.apply_decision(self.c, self.decision(review), self.env)
        plan = self.execute({'action': 'design_plan', 'brief_id': task['brief_id'], 'revision': task['revision']})['plan']
        self.assertEqual(plan['reference_image'], ref)
        shots = profiles.image_plan({'code': 'fixture', 'revision': 1, 'plan': json.dumps(plan)}, self.env)['images']
        self.assertTrue(all(ref in i['references'] for i in shots))
        self.assertTrue(all(any(a['sha256'] == plan['regions']['left_chest']['sha256'] for a in i['references']) for i in shots))

    def test_reference_is_immutable_and_rejects_other_directories(self):
        ref = self.reference()
        self.assertEqual(batch_reference.validate(ref, self.env), ref)
        bad = copy.deepcopy(ref); bad['path'] = str(engine.STORE / 'outside.png')
        Path(bad['path']).write_bytes(Path(ref['path']).read_bytes())
        with self.assertRaises(ValueError): batch_reference.validate(bad, self.env)
        self.submit.update(profile_version=3, reference_image=ref)
        self.start()
        Path(ref['path']).write_bytes(b'changed')
        result = self.cycle()
        self.assertEqual(result['status'], 'batch_item_failed')
        self.assertIn('reference', result['error'].lower())
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0], 0)


if __name__ == '__main__':
    suite = unittest.TestSuite(ReferenceTests(name) for name in ReferenceTests.__dict__ if name.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
