"""Isolated native prompt-to-mockup lifecycle; zero production generation or approval."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path

spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('check-production-batch.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,batch,flow=fixture.engine,fixture.batch,fixture.flow
import embroidery_direct as direct
import production_profiles as profiles


class DirectTests(fixture.BatchTests):
    def command(self):
        return {**self.submit,'profile_version':3,'kind':'embroidery_prompts','embroidery_mode':direct.MODE,
                'positions':{'chest':'left','sleeves':True,'back':False},
                'items':[{'title':'Botanical name','designs':{'left_chest':'Three daisies above the exact name LUNA; cream petals and green leaves.','left_sleeve':'Five upright fern leaves, complete slender composition.'}}]}

    def test_direct_sample_skips_artwork_tasks_and_keeps_real_mockup_review_then_reuses_master(self):
        self.start(self.command());snapshot=self.cycle();task=snapshot['tasks'][0]
        self.assertEqual((task['kind'],task['stage']),('flow_batch_images','sample_mockup'))
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_jobs').fetchone()[0],0)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0],0)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_approvals').fetchone()[0],0)
        image=task['payload']['images'][0]
        self.assertIn('PROMPT TO EMBROIDERED GARMENT',image['prompt'])
        for part in ('Three daisies','LUNA','Five upright fern leaves','Tatami','Satin','no separate 2D'):
            self.assertIn(part,image['prompt'])
        rule=engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        self.assertTrue(image['prompt'].endswith(rule))
        self.assertEqual(task['payload']['references'],{})
        self.assertFalse(any(r.get('role') in ('exact_locked_embroidery','exact_locked_2d','same_listing_region_map') for r in image['references']))
        self.execute(self.candidate(task));review=self.cycle()['reviews'][0]
        self.assertEqual(review['stage'],'sample_mockup')
        self.assertFalse(review['visual_qa']['passed'])
        self.assertEqual(self.cycle()['tasks'],[])
        flow.apply_decision(self.c,self.decision(review),self.env)
        rest=self.cycle()['tasks'][0]
        self.assertEqual(len(rest['payload']['images']),5)
        for image in rest['payload']['images']:
            anchors=[r for r in image['references'] if r.get('role')=='same_listing_layout_anchor']
            self.assertEqual(len(anchors),1)
            self.assertIn('visual master for all motif details',image['prompt'])
            self.assertTrue(image['prompt'].endswith(rule))
        macro=next(i for i in rest['payload']['images'] if i['name']=='07_embroidery_closeup.jpg')
        self.assertEqual(macro['visible_regions'],['left_chest'])
        self.assertNotIn('Five upright fern leaves',macro['prompt'])
        self.execute(self.candidate(rest));self.cycle()
        i=dict(self.c.execute('SELECT * FROM production_batch_items').fetchone())
        images=json.loads(i['images'])
        self.execute({'action':'batch_accept_workflow','workflow_accepted_by_user':True,**self.auth})
        batch.handoff(self.c,batch.batch(self.c,'fixture-batch'),i,[images[name] for name in profiles.names(json.loads(i['plan']))],self.env)
        i=dict(self.c.execute('SELECT * FROM production_batch_items').fetchone())
        plan=json.loads(i['plan']);self.assertEqual(plan['embroidery_mode'],direct.MODE)
        self.assertEqual(plan['regions'],{})
        self.assertIn('approved_sample',plan)
        engine.validate_plan(plan)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_approvals').fetchone()[0],0)
        source=engine.read(engine.JOBS/(i['listing_code']+'.json'))
        self.assertEqual(source['packet']['confirmed_product_brief']['embroidery_mode'],direct.MODE)
        self.assertEqual(source['packet']['approved_assets'][0]['name'],'approved_garment_sample')
        self.assertTrue(any('LEFT CHEST' in label for label in source['packet']['maximum_embroidery_labels']))

    def test_positions_front_back_and_old_mode_are_explicit_and_bound(self):
        command=self.command();command['positions']={'chest':'left_right','sleeves':False,'back':True}
        command['items'][0]['designs']={'left_chest':'One red flower.','right_chest':'Two blue leaves.','back':'One large green tree.'}
        normalized=batch.normalize(command,self.env)
        plan=direct.plan(normalized['items'][0]['brief'])
        shots=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan)},self.env)
        self.assertEqual(set(shots['images'][0]['visible_regions']),{'left_chest','right_chest','back'})
        for image in shots['images']:
            self.assertNotIn('same_listing_region_map',[r.get('role') for r in image['references']])
            if 'back' not in image['visible_regions']:
                self.assertNotIn('One large green tree',image['prompt'])
        old=self.command();old.pop('embroidery_mode')
        self.start(old);self.cycle();task=self.execute({'action':'browser_queue'})['tasks'][0]
        self.assertEqual(task['kind'],'flow_design_2d')
        self.assertNotIn('embroidery_mode',batch.manifest(batch.batch(self.c,'fixture-batch')))

    def test_direct_mode_rejects_unknown_mode_wrong_product_wrong_regions_or_fake_assets(self):
        with self.assertRaisesRegex(ValueError,'current product profile'):
            batch.normalize({**self.command(),'profile_version':1},self.env)
        for mode,kind in [('unknown','embroidery_prompts'),(direct.MODE,'apparel_2d')]:
            with self.assertRaisesRegex(ValueError,'creation mode'):
                batch.normalize({**self.command(),'embroidery_mode':mode,'kind':kind},self.env)
        plan=direct.plan(batch.normalize(self.command(),self.env)['items'][0]['brief'])
        for change in ({'regions':{'left_chest':{'path':'fake.png'}}},{'motifs':{'left_chest':'Only one region'}},{'back_artwork':True}):
            with self.assertRaises(ValueError):
                direct.validate({**plan,**change})
        with self.assertRaises(ValueError):
            engine.validate_plan(plan)  # a final listing requires its real approved garment sample

    def test_revising_direct_sample_preserves_mode_original_asset_and_real_review_gate(self):
        self.start(self.command());task=self.cycle()['tasks'][0];candidate=self.candidate(task)
        self.execute(candidate);review=self.cycle()['reviews'][0]
        original=Path(candidate['assets'][0]['path']);before=original.read_bytes()
        flow.apply_decision(self.c,self.decision(review,'revise','Move the chest motif slightly lower, keep the selected regions.'),self.env)
        revised=self.cycle()['tasks'][0]
        self.assertEqual(revised['revision'],2)
        self.assertIn('LATEST CONFIRMED MOCKUP CORRECTION',revised['payload']['images'][0]['prompt'])
        self.assertIn('Move the chest motif slightly lower',revised['payload']['images'][0]['prompt'])
        self.assertEqual(original.read_bytes(),before)
        self.assertFalse(flow.apply_decision(self.c,self.decision(review),self.env)['accepted'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_tasks').fetchone()[0],0)


if __name__=='__main__':
    suite=unittest.TestSuite(DirectTests(name) for name in DirectTests.__dict__ if name.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
