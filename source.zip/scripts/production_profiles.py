"""Versioned product layouts. Existing batches retain their original six-photo contract."""
import hashlib
import json
import re
from pathlib import Path

LEGACY = ['01_thumbnail.jpg', '02_model_front.jpg', '03_model_angle.jpg', '04_embroidery_closeup.jpg', '05_embroidery_dimensions.jpg', '06_flatlay.jpg']
PRINT = ['01_thumbnail.jpg', '02_female_angle.jpg', '03_female_seated.jpg', '04_flatlay.jpg', '05_print_closeup.jpg']
EMBROIDERY = ['01_thumbnail.jpg', '02_hoodie_folded.jpg', '03_quarterzip_folded.jpg', '04_male_front.jpg', '05_female_angle.jpg', '06_female_seated.jpg', '07_embroidery_closeup.jpg', '08_maximum_dimensions.jpg', '09_gift_packaging.jpg', '10_flatlay.jpg']
EMBROIDERY_SIX = [EMBROIDERY[n] for n in (0, 1, 3, 4, 6, 9)]
SIX_SET = 'embroidery_6_v1'
GARMENT_SET = 'embroidery_6_flatlay_v1'
GARMENT_SIX = ['01_thumbnail.jpg', '02_hoodie_folded.jpg', '04_sweatshirt_flatlay.jpg', '05_hoodie_flatlay.jpg', '07_embroidery_closeup.jpg', '10_flatlay.jpg']
PRINT_KINDS = ('apparel_2d', 'pajama_top', 'pajama_set', 'sleep_pants')
LIMITS = {'center_chest': (26, 26), 'left_chest': (9, 9), 'right_chest': (26, 26), 'back': (26, 26), 'left_sleeve': (7, 26), 'right_sleeve': (7, 26)}
LABELS = {'center_chest': 'NGỰC GIỮA', 'left_chest': 'NGỰC TRÁI', 'right_chest': 'NGỰC PHẢI', 'back': 'LƯNG', 'left_sleeve': 'TAY'}


def current(value):
    return value.get('profile_version') == 3


def names(value):
    original = LEGACY if not current(value) else PRINT if value.get('product_kind', value.get('kind')) in PRINT_KINDS else EMBROIDERY
    if value.get('mockup_set') is not None:
        if not current(value) or value.get('product_kind', value.get('kind')) != 'embroidery_prompts' or value['mockup_set'] not in (SIX_SET, GARMENT_SET, 'embroidery_10_v1'):
            raise ValueError('Unknown embroidery mockup set')
        if value['mockup_set'] == SIX_SET:
            original = EMBROIDERY_SIX
        elif value['mockup_set'] == GARMENT_SET:
            original = GARMENT_SIX
    skipped = value.get('skipped_mockups', [])
    if not isinstance(skipped, list) or len(set(skipped)) != len(skipped) or any(n not in original for n in skipped) or len(skipped) >= len(original):
        raise ValueError('Skipped mockups must be unique known views and leave at least one image')
    return [n for n in original if n not in skipped]


def category(plan):
    return {'pajama_top': 'Áo pijama', 'pajama_set': 'Bộ pijama', 'sleep_pants': 'Quần ngủ', 'apparel_2d': 'Áo 2D'}.get(plan.get('product_kind'), 'Áo 2D' if plan.get('rendering_mode') == 'apparel_2d' else 'Áo thêu')


def selected(options):
    if not isinstance(options, dict) or set(options) != {'chest', 'sleeves', 'back'}:
        raise ValueError('Choose chest, sleeves and back explicitly')
    chest = options['chest']
    if chest not in ('none', 'center', 'left', 'left_right') or type(options['sleeves']) is not bool or type(options['back']) is not bool:
        raise ValueError('Invalid embroidery selection')
    regions = {'none': [], 'center': ['center_chest'], 'left': ['left_chest'], 'left_right': ['left_chest', 'right_chest']}[chest][:]
    if options['sleeves']:
        regions.append('left_sleeve')
    if options['back']:
        regions.append('back')
    if not regions:
        raise ValueError('Choose at least one embroidery position')
    return regions


def normalize(cmd, e, legacy):
    import embroidery_direct
    embroidery_direct.mode(cmd)
    kind = cmd.get('kind')
    if kind not in ('embroidery_prompts', *PRINT_KINDS):
        raise ValueError('Choose embroidery, sweater, pajama set, legacy top or sleep pants')
    keys = selected(cmd.get('positions')) if kind == 'embroidery_prompts' else []
    inputs = cmd.get('items')
    if not isinstance(inputs, list) or not inputs:
        raise ValueError('Supply batch items')
    converted = []
    for data in inputs:
        if not isinstance(data, dict):
            raise ValueError('Invalid batch item')
        d = dict(data)
        if keys:
            designs = d.get('designs')
            if not isinstance(designs, dict) or set(designs) != set(keys):
                raise ValueError('Supply exactly one design for each selected position; left+right chest requires two')
            rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
            d['designs'] = {r: e['design_module']().prompt_body(text, rule) for r, text in designs.items()}
            d['idea_prompt'] = '\n'.join(d['designs'].values())
        converted.append(d)
    legacy_command = {k:v for k,v in cmd.items() if k != 'embroidery_mode'}
    result = legacy({**legacy_command, 'profile_version': 1, 'kind': 'apparel_2d', 'items': converted}, e)
    result.update(profile_version=3, kind=kind, product_kind=kind, positions=cmd.get('positions'), sizing_policy='maximum_limits_only', completion_policy='human_first_sample_authorizes_bound_batch')
    if embroidery_direct.enabled(cmd):
        result['embroidery_mode'] = embroidery_direct.MODE
    if kind == 'pajama_set':
        import pajama_set
        result['product_bundle'] = dict(pajama_set.CONTRACT)
    if kind == 'embroidery_prompts':
        result['mockup_set'] = cmd.get('mockup_set', GARMENT_SET)
        names(result)
        if result['mockup_set'] == GARMENT_SET and 'back' in keys:
            import embroidery_mockup_layout
            layout = e.get('shared_mockup_layout', 'current')
            if layout:
                result['mockup_layout'] = embroidery_mockup_layout.load(e, GARMENT_SIX) if layout == 'current' else embroidery_mockup_layout.validate(layout, e, GARMENT_SIX)
    if cmd.get('mockup_prompt_set') is not None:
        import mockup_prompt_sets
        result['mockup_prompt_set']=mockup_prompt_sets.validate(cmd['mockup_prompt_set'],kind,names(result))
        if result.get('mockup_layout'):
            result['mockup_prompt_set']=embroidery_mockup_layout.preset(result['mockup_prompt_set'],result['mockup_layout'],GARMENT_SIX)
    if keys and e.get('shared_layout_profile', 'current'):
        import embroidery_layout
        chosen = e.get('shared_layout_profile', 'current')
        result['layout_profile'] = embroidery_layout.load(e) if chosen == 'current' else embroidery_layout.validate(chosen, e)
    if cmd.get('reference_image'):
        import batch_reference
        result['reference_image'] = batch_reference.validate(cmd['reference_image'], e)
    for record, original in zip(result['items'], converted):
        b = record['brief']
        b.update(profile_version=3, product_kind=kind)
        if embroidery_direct.enabled(cmd):
            b['embroidery_mode'] = embroidery_direct.MODE
        if kind == 'embroidery_prompts':
            b['mockup_set'] = result['mockup_set']
        if result.get('mockup_layout'):
            b['mockup_layout'] = result['mockup_layout']
        if result.get('layout_profile'):
            b['layout_profile'] = result['layout_profile']
        if result.get('reference_image'):
            b['reference_image'] = dict(result['reference_image'])
        if result.get('mockup_prompt_set'):
            b['mockup_prompt_set'] = result['mockup_prompt_set']
        if keys:
            motifs = dict(original['designs'])
            if 'left_sleeve' in motifs:
                motifs['right_sleeve'] = motifs['left_sleeve']
            b.pop('idea_prompt', None)
            b.pop('rendering_mode', None)
            b.update(motifs=motifs, positions=cmd['positions'], back_artwork='back' in motifs,
                     available_styles=['crewneck sweatshirt', 'hoodie', 'quarter-zip pullover'])
        else:
            b['available_styles'] = [{'apparel_2d': 'crewneck sweatshirt', 'pajama_top': 'pajama top', 'pajama_set': 'matching pajama set (top and pants)', 'sleep_pants': 'sleep pants'}[kind]]
        if kind == 'pajama_set':
            b.update(garment='pajama_set', product_bundle=dict(pajama_set.CONTRACT))
        e['validate_brief'](b)
    return result


def validate_brief(b):
    import embroidery_direct
    embroidery_direct.mode(b)
    if b.get('product_kind') == 'pajama_set':
        import pajama_set
        pajama_set.validate(b)
        if b.get('garment') != 'pajama_set':
            raise ValueError('Pajama set is not a crewneck or a separate top')
    if b.get('product_kind') in PRINT_KINDS:
        expected = {'apparel_2d': 'crewneck sweatshirt', 'pajama_top': 'pajama top', 'pajama_set': 'matching pajama set (top and pants)', 'sleep_pants': 'sleep pants'}[b['product_kind']]
        if b.get('rendering_mode') != 'apparel_2d' or b.get('motifs') != {} or b.get('back_artwork') is not False or b.get('available_styles') != [expected] or not str(b.get('idea_prompt', '')).strip():
            raise ValueError('Printed product must have its own idea and product type')
    else:
        keys = set(selected(b.get('positions')))
        if 'left_sleeve' in keys:
            keys.add('right_sleeve')
        motifs = b.get('motifs', {})
        if set(motifs) != keys or any(not isinstance(x, str) or not x.strip() for x in motifs.values()) or b.get('back_artwork') != ('back' in keys):
            raise ValueError('Embroidery motifs must exactly match selected positions')
        if 'left_sleeve' in keys and motifs['left_sleeve'] != motifs['right_sleeve']:
            raise ValueError('Both sleeves reuse one unmirrored design')
    return b


def validate_plan(p, e):
    from PIL import Image
    import embroidery_direct
    embroidery_direct.mode(p)
    direct = embroidery_direct.enabled(p)
    if direct:
        embroidery_direct.validate(p)
    names(p)
    if p.get('mockup_layout'):
        import embroidery_mockup_layout
        if p.get('mockup_set') != GARMENT_SET or 'back' not in (p.get('motifs', {}) if direct else p.get('regions', {})):
            raise ValueError('Front/back mockup layout requires the current garment set and back artwork')
        embroidery_mockup_layout.validate(p['mockup_layout'],e,GARMENT_SIX)
    if p.get('mockup_prompt_set'):
        import mockup_prompt_sets
        mockup_prompt_sets.validate(p['mockup_prompt_set'],p['product_kind'],names({k:v for k,v in p.items() if k!='skipped_mockups'}))
    if p.get('product_kind') == 'pajama_set':
        import pajama_set
        pajama_set.validate(p)
    if p.get('product_kind') in PRINT_KINDS:
        assets = {'sample': p.get('approved_sample')}
        if p.get('regions') != {} or not p.get('idea_prompt'):
            raise ValueError('Printed product requires its own approved sample')
    elif direct:
        assets = {'sample': p.get('approved_sample')}
    else:
        regions = set(selected(p.get('positions')))
        if 'left_sleeve' in regions:
            regions.add('right_sleeve')
        assets = p.get('regions', {})
        if set(assets) != regions:
            raise ValueError('Artwork must match the selected positions')
        if 'left_sleeve' in assets and assets['left_sleeve']['sha256'] != assets['right_sleeve']['sha256']:
            raise ValueError('Both sleeves must reuse one approved file')
    for region, asset in assets.items():
        if not isinstance(asset, dict) or e['sha'](e['scoped'](asset['path'])) != asset.get('sha256'):
            raise ValueError('Approved artwork changed: ' + region)
        if region != 'sample' and not asset.get('artwork_approval_reference'):
            raise ValueError('Exact embroidery approval required')
        with Image.open(e['scoped'](asset['path'])) as im:
            im.verify()
    return p


def design_plan(c, j, b, d, e):
    fp = d.fingerprint(c, j, 'embroidery', e)
    ref = d.approval(c, j, 'embroidery', fp)
    if not ref:
        raise ValueError('Approve the exact embroidery set first')
    artwork = {r: {**a, 'artwork_approval_reference': ref[0], 'design_brief_id': j['brief_id'], 'design_revision': j['revision'], 'design_fingerprint': fp} for r, a in d.checked_assets(c, j, 'embroidery', e).items()}
    plan = {k: b[k] for k in ('profile_version', 'product_kind', 'positions', 'garment', 'color', 'back_artwork', 'product_id')}
    plan.update(regions=artwork, dimension_policy='maximum_limits_only')
    if b.get('mockup_set'):
        plan['mockup_set'] = b['mockup_set']
    if b.get('mockup_layout'):
        plan['mockup_layout'] = b['mockup_layout']
    if b.get('reference_image'):
        plan['reference_image'] = b['reference_image']
    if b.get('layout_profile'):
        plan['layout_profile'] = b['layout_profile']
    if b.get('mockup_prompt_set'):
        plan['mockup_prompt_set'] = b['mockup_prompt_set']
    return {'ok': True, 'status': 'approved_artwork_ready', 'plan': plan, 'individual_dimensions_required': False}


def corrections(c, bid, stage):
    row = c.execute('SELECT value FROM config WHERE key=?', ('batch_corrections:' + bid,)).fetchone()
    data = json.loads(row[0]) if row else []
    return '\n'.join(x['reason'] for x in data if x['stage'] == stage)


def save_correction(c, bid, stage, reason, reference):
    key = 'batch_corrections:' + bid
    row = c.execute('SELECT value FROM config WHERE key=?', (key,)).fetchone()
    data = json.loads(row[0]) if row else []
    entry = {'stage': stage, 'reason': reason.strip(), 'reference': reference}
    if entry not in data:
        data.append(entry)
        c.execute('DELETE FROM production_batch_policies WHERE batch_id=?', (bid,))
    c.execute('INSERT OR REPLACE INTO config VALUES(?,?)', (key, json.dumps(data, ensure_ascii=False)))


def maximum_labels(regions):
    lines = ['MAXIMUM EMBROIDERY AREA']
    for r in regions:
        if r == 'right_sleeve':
            continue
        w, h = LIMITS[r]
        label = 'EACH SLEEVE' if r == 'left_sleeve' else r.replace('_', ' ').upper()
        lines.append(f'{label}: MAX {w/2.54:.2f} W × {h/2.54:.2f} H in')
    return lines


def region_references(regions):
    """One ingredient per source; keep its intended regions in the prompt manifest."""
    refs = []
    for region in ('center_chest', 'left_chest', 'right_chest', 'back', 'left_sleeve', 'right_sleeve'):
        if region not in regions:
            continue
        asset = regions[region]
        ref = next((r for r in refs if r['sha256'] == asset['sha256']), None)
        if ref is None:
            ref = {**asset, 'role': 'exact_locked_embroidery', 'regions': []}
            refs.append(ref)
        ref['regions'].append(region)
    return refs


def reference_manifest(refs, visible_regions=None):
    lines = ['EXACT REFERENCE-TO-REGION MAP (numbering follows attached image order):']
    for number, ref in enumerate(refs, 1):
        if ref.get('regions'):
            regions = ', '.join(ref['regions'])
            lines.append(f'Image {number}: COMPLETE approved embroidery for {regions} ONLY. Transfer every element, not a selected fragment; preserve layout, lettering, counts and colors. Never put this artwork in another region.')
        elif ref.get('role') == 'same_listing_layout_anchor':
            lines.append(f'Image {number}: same-listing product photo for artwork placement, relative scale and continuity ONLY. The isolated approved embroidery files remain the design authority. Change garment style/color and camera to this shot; never copy this photo\'s folding, background or framing into a different shot.')
        else:
            lines.append(f'Image {number}: {ref.get("role", "style_only")}; construction/color/position guidance ONLY, never a source of product artwork or text.')
    visible = set(visible_regions if visible_regions is not None else [r for ref in refs for r in ref.get('regions', [])])
    lines.append('Each isolated embroidery source belongs ONLY to its mapped region; never substitute, blend, recompose, recolor or redraw it. Preserve exact letter order, font, object counts, connections, silhouette and relative positions inside that source. No extra personalization or lettering absent from the approved source.')
    if {'left_sleeve', 'right_sleeve'} <= visible:
        lines.append('Both sleeves use the entire SAME sleeve image, unmirrored, upright along each sleeve and at the same garment-relative height. Adapt the fold, arm pose or framing, never omit components to fit.')
    if 'center_chest' in visible:
        lines.append('center_chest is centered on the torso vertical midline in EVERY garment style. On quarterzip place the whole design BELOW the zipper endpoint; never move it sideways into a left-chest logo. Left/right chest means the wearer\'s side only when that position is explicitly selected.')
    return '\n'.join(lines)


def image_plan(j, e):
    p = json.loads(j['plan'])
    import embroidery_direct
    embroidery_direct.mode(p)
    direct = embroidery_direct.enabled(p)
    if direct:
        embroidery_direct.validate(p)
    root = e['ROOT'] / 'workspace/chat-handoff/20261014-prompt-authoring'
    rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    kind = p['product_kind']
    import mockup_prompt_sets
    preset=mockup_prompt_sets.validate(p['mockup_prompt_set'],kind,names({k:v for k,v in p.items() if k!='skipped_mockups'})) if p.get('mockup_prompt_set') else None
    custom=mockup_prompt_sets.shots(preset) if preset else {}
    if kind == 'pajama_set':
        import pajama_set
        pajama_set.validate(p)
    references = dict(p.get('regions', {}))
    if p.get('approved_sample'):
        references['approved_sample'] = p['approved_sample']
    common = ('One separate square 1:1 photorealistic product photo, simple matte light-neutral studio, indirect window daylight, neutral white balance. '
              'Keep the same design, lettering, motif counts, colors and proportions from the approved sources. No mirror, collage, watermark or exterior artwork outline. '
              'Apply batch corrections to every relevant item, but a correction naming a different shot or region must not replace this shot role or add artwork here. ')
    model_rule = 'Adult models only, crop below the neck with no face or chin; natural hands clear of the design. '
    if preset:
        common=('One separate square 1:1 photorealistic product photo, indirect window daylight, neutral white balance. '
                'Keep the exact same approved product, lettering, motif counts, colors, proportions and construction. '
                'No mirror, collage, watermark or exterior artwork outline. ')
    if kind in PRINT_KINDS:
        if kind != 'pajama_set':
            common += model_rule
        if kind == 'pajama_set':
            import pajama_set
            prompts = pajama_set.prompts(p['idea_prompt'], bool(p.get('approved_sample')))
        else:
            prefix = {'apparel_2d': 'sweater', 'pajama_top': 'pajama-top', 'sleep_pants': 'sleep-pants'}[kind]
            source = (root / (prefix + '-2d-five-photo-individual-prompts-v001.txt')).read_text(encoding='utf-8-sig')
            parts = re.split(r'(?m)^===== .+ =====\s*\n', source)
            prompts = [x.strip().removesuffix(rule).rstrip() for x in parts if x.strip()]
            if len(prompts) != 5:
                raise ValueError('Five-photo product template changed')
            if not p.get('approved_sample'):
                common += 'CREATE THE FIRST PRODUCT SAMPLE FROM THIS CONFIRMED IDEA: ' + p['idea_prompt'] + '. Use only construction and material facts supplied in that idea; do not invent material claims. References A/B named below apply only when actually attached. '
        if preset:
            prompts=[(prompt if name==preset['clean_flatlay'] else custom[name])+'\n'+mockup_prompt_sets.photo_lock(name,kind) for name,prompt in zip(PRINT,prompts)]
            if kind=='pajama_set':
                common+=' ONE PAJAMA SET: both the confirmed top and matching full-length pants together, one sales unit. Show both pieces completely in the hero/angle/seated/flatlay; detail shows top beside pants. No invented fabric, sizes or construction. '
                common+=('APPROVED SAME-LISTING MASTER: reproduce exactly the approved product. ' if p.get('approved_sample') else 'CREATE FROM THIS CONFIRMED IDEA: '+p['idea_prompt']+' ')
        images = [{'name': name, 'prompt': common + prompt + '\n' + p.get('image_correction', '') + '\n' + rule, 'status': 'pending'} for name, prompt in zip(PRINT, prompts)]
    else:
        garment_only = p.get('mockup_set') == GARMENT_SET
        front_back = None
        if p.get('mockup_layout'):
            import embroidery_mockup_layout
            front_back = embroidery_mockup_layout.validate(p['mockup_layout'],e,GARMENT_SIX)
            if not garment_only or 'back' not in (p['motifs'] if direct else p['regions']):
                raise ValueError('Front/back mockup layout requires back artwork')
            standard_shots = mockup_prompt_sets.shots(front_back['standard'])
        output_names = dict(zip(EMBROIDERY_SIX, GARMENT_SIX)) if garment_only else {}
        plan = e['read'](root / 'embroidered-apparel-10-photo-plan-v001.json')
        wardrobe = e['read'](e['ROOT'] / 'config/mockup-wardrobe-standard.json')
        if len(plan['shots'])!=10 or len({x['color'] for x in plan['shots']})!=10 or any(x['color'] not in wardrobe['palettes'][x['style']] for x in plan['shots']):
            raise ValueError('Fixed embroidery styles/colors no longer match approved palettes')
        source = (root / 'embroidered-apparel-10-photo-master-v001.txt').read_text(encoding='utf-8-sig')
        shots = re.findall(r'(?ms)^((?:0[1-9]|10) — .+?)\n(.*?)(?=^(?:0[1-9]|10) — |^FINAL CHECK)', source)
        if len(shots) != 10:
            raise ValueError('Ten-photo embroidery template changed')
        regions = set(p['motifs'] if direct else p['regions'])
        primary = next((r for r in ('center_chest', 'left_chest', 'right_chest', 'back', 'left_sleeve') if r in regions), None)
        if not primary:
            raise ValueError('Approved embroidery is missing')
        common += ('Machine embroidery, clean Tatami/Satin faithful to approved files, no print or bulky patch. '
                   'No individual artwork dimensions are claimed, calculated or printed. Preserve approved artwork proportions and consistent placement. ')
        if garment_only:
            common += 'GARMENT ONLY: the garment rests on a flat surface, unfolded or folded as specified. No people, body parts, hands, mannequins or worn clothing in any photo. '
        images = []
        for n, ((heading, text), shot) in enumerate(zip(shots, plan['shots'])):
            name = output_names.get(EMBROIDERY[n], EMBROIDERY[n])
            if name not in names(p):
                continue
            rear = ('back' in regions and n in (5,9)) or (primary == 'back' and n in (0,1,2,3,4,8))
            visible = {primary} if n == 6 else {r for r in regions if (r == 'back' if rear else r != 'back') or r.endswith('sleeve')}
            dual = bool(front_back and n == 0)
            if front_back:
                rear = n in (3,9)
                visible = regions if dual else {primary} if n == 6 else {r for r in regions if (r == 'back' if rear else r != 'back') or r.endswith('sleeve')}
            # The source supplies approved pose/role; selected regions override its original chest+two-sleeve assumption.
            text = text.replace('physical size', 'visual proportions').replace('physical dimensions', 'visual proportions')
            if n == 7:
                text = 'Full unfolded overhead flatlay; add ONLY these maximum-area labels in empty background space: ' + ' | '.join(maximum_labels(sorted(regions))) + '. These are maximum limits, not measurements of this artwork. Do not anchor maximum arrows to smaller artwork, enlarge it to maximum, or label garment dimensions.'
            if n in (0, 1, 2):
                face = 'back' if primary == 'back' else 'front'
                text += f' SELECTED POSITION OVERRIDE: folded {face} view; show all selected embroidery on this visible face and both sleeve designs only if selected. No invented chest or sleeve artwork.'
            if n == 5 and 'back' in regions:
                text = 'Different adult female B seated, rear three-quarter view showing the full approved back artwork and selected sleeve artwork, collar-down crop, plain stool, natural daylight.'
            if primary=='back' and n in (3,4):
                text=('Adult male standing straight rear view.' if n==3 else 'Adult female A standing rear three-quarter left view.')+' Show the approved back embroidery and selected sleeve embroidery, collar-down to thigh crop, natural daylight, plain studio background.'
            if primary=='back' and n==8:
                text=text.replace('chest embroidery','back embroidery')
            if n == 6:
                text = ('TIGHT QUALITY MACRO OF ' + primary.upper() + ' ONLY. Show the complete exact embroidery from its single isolated reference, with a small plain fabric margin. '
                        'The embroidery and its Tatami/Satin thread directions fill the frame; use an oblique close camera, not a whole garment photograph. '
                        'Show no other embroidered region, folded arms, cuffs, neckline, model, props or added design. Do not invent the sleeve design on the torso. '
                        'Keep the exact source composition, lettering, object count and colors; only the fabric and camera change.')
            if n == 9 and 'back' in regions:
                text += ' SELECTED POSITION OVERRIDE: fully unfolded BACK-UP garment, showing the approved back design, never add front artwork to the back.'
            if garment_only and n != 6:
                face = 'back-up' if rear else 'front-up'
                heading = {'01':'folded sweatshirt thumbnail','02':'folded hoodie','04':'unfolded sweatshirt flatlay','05':'unfolded hoodie flatlay','10':'unfolded quarterzip flatlay'}[shot['id']]
                text = (f'Overhead product photograph of one {face} garment resting on a matte neutral flat surface. '
                        + ('Neatly fold the torso, lay both sleeves separately beside it with the outer sleeve surfaces facing the camera and the cuffs visible. ' if n in (0,1) else
                           'Fully unfold the torso and both sleeves, with gentle natural spacing and outer sleeve surfaces facing the camera; show the entire garment and both cuffs. ')
                        + ('Use a slight diagonal arrangement on the surface; keep the camera above the garment. ' if n==4 else '')
                        + 'Show every selected artwork on this visible face in full, with identical sleeve artwork at matching garment-relative heights when selected. '
                        'Keep the exact approved artwork aspect ratio; do not stretch it along the sleeve, enlarge it to fill the sleeve length, wrap it around a seam or hide it in a fold. Unselected regions remain blank. No invented embroidery.')
            if front_back:
                text = standard_shots[name].removesuffix(rule).rstrip()
                heading = 'dual front-folded and back-flatlay cover' if dual else heading
            if preset and name!=preset['clean_flatlay']:
                text=(custom[name].removesuffix(rule).rstrip() if front_back else custom[name])+'\n'+mockup_prompt_sets.photo_lock(name,kind,garment_only,bool(front_back))
                if not front_back:
                    text+=(' Show approved BACK artwork only on the back-up/rear view. ' if rear else ' Show only approved front/sleeve artwork selected for this view. ')
            if front_back:
                text += '\n' + embroidery_mockup_layout.lock(name)
                if front_back.get('lighting_rule'):
                    text += '\n' + front_back['lighting_rule']
            text += '\nVISIBLE REGIONS FOR THIS SHOT ONLY: ' + ', '.join(sorted(visible)) + '. Other embroidered regions remain outside the camera crop; do not bring them into this shot.'
            if n != 6:
                text += ' On quarterzip keep the entire chest artwork below the lowest zipper endpoint with at least 1 inch clearance; hoodie artwork above pocket with drawstrings clear. Adapt the garment fold and camera to show the complete selected artwork.'
            refs=region_references({r:a for r,a in references.items() if r in visible})
            if (n != 6 or direct) and p.get('approved_sample'):
                refs.append({**p['approved_sample'], 'role':'same_listing_layout_anchor'})
            if dual:
                refs.append(front_back['guides'][shot['style']])
                text += ' The blank dual guide controls the two-garment pose only; never copy blankness over selected approved embroidery. '
            elif n in (0,1,2):
                import embroidery_layout
                refs.append(embroidery_layout.folded_guide(shot['style'], e))
                text += ' Use the design-free folded garment schematic for folding/framing only. Keep both complete forearm designs and the selected chest design separately visible, with cuffs visible; widen the framing or loosen the fold instead of hiding, cropping or substituting artwork.'
            for ref in plan['references']:
                if n != 6 and ((ref['role']=='sweatshirt_palette' and shot['style']=='crewneck sweatshirt') or (ref['role']=='hoodie_quarterzip_palette' and shot['style']!='crewneck sweatshirt')):
                    if e['sha'](e['scoped'](ref['path']))!=ref['sha256']:raise ValueError('Mockup reference changed')
                    refs.append(ref)
            reference_rule='' if n == 6 else ' Design-free garment schematics control folding/placement only. Their garment is blank: add product embroidery ONLY from the explicitly mapped approved artwork. Palette references control garment color only, not artwork or scenery. Never reproduce guide strokes, boxes, labels or diagram texture.'
            images.append({'name': name, 'wardrobe': {'garment': shot['style'], 'color': shot['color']}, 'visible_regions':sorted(visible), 'references':refs, 'prompt': common + (model_rule if n != 6 and not garment_only else '') + reference_rule + '\nSHOT ID: '+shot['id']+' / '+heading+'\nFIXED GARMENT: ' + shot['color'] + ' ' + shot['style'] + '\n' + text.strip() + '\n' + p.get('image_correction', '') + '\n' + rule, 'status': 'pending'})
            if p.get('layout_profile') and n != 6:
                import embroidery_layout
                layout = embroidery_layout.validate(p['layout_profile'], e)
                images[-1]['references'].append(embroidery_layout.placement(layout, shot['style'], regions, rear))
                if dual:
                    images[-1]['references'].append(embroidery_layout.placement(layout, shot['style'], regions, True))
                placement_rule = (' GARMENT-RELATIVE POSITION LOCK: ' + layout['placement_rule'] +
                    ' The design-free schematic controls placement only, never camera angle, folding, garment color or artwork. '
                    'Apply only selected positions; ignore all other zones. No guide strokes, boxes, labels or backing panels in the product photo. '
                    'Keep the identical approved narrow upright sleeve design in every view; never substitute a square upper-arm badge. '
                    'Follow this shot role; the diagram does not turn a fold, macro or model shot into a flatlay. ')
                if garment_only:
                    placement_rule = placement_rule.replace('narrow upright sleeve design', 'approved sleeve design at its exact natural proportions').replace('fold, macro or model shot', 'fold or macro shot')
                    placement_rule += ' Schematic boxes locate maximum safe zones only; never match their aspect ratio or fill their full height. The approved artwork determines its own proportions. '
                images[-1]['prompt'] = images[-1]['prompt'].removesuffix(rule).rstrip() + '\n' + placement_rule + '\n' + rule
    if preset:
        for image in images:
            if image['name']==preset['clean_flatlay']:
                image['prompt']=image['prompt'].removesuffix(rule).rstrip()+'\n'+mockup_prompt_sets.CLEAN+'\n'+rule
    if p.get('reference_image'):
        import batch_reference
        ref = batch_reference.validate(p['reference_image'], e)
        references['batch_reference'] = ref
        for image in images:
            if image.get('name') == EMBROIDERY[6] and kind not in PRINT_KINDS:
                continue
            image.setdefault('references', list(references.values()))
            if ref not in image['references']:
                image['references'].append(ref)
            image['prompt'] = image['prompt'].removesuffix(rule).rstrip() + '\n' + batch_reference.GUIDANCE + '\n' + rule
    if kind not in PRINT_KINDS:
        for image in images:
            manifest = embroidery_direct.instructions(p,image,e) if direct else reference_manifest(image['references'],image['visible_regions'])
            image['prompt'] = image['prompt'].removesuffix(rule).rstrip() + '\n' + manifest + '\n' + rule
            if p.get('mockup_set') == GARMENT_SET and image['name'] != EMBROIDERY[6] and any(r.endswith('sleeve') for r in image['visible_regions']):
                image['prompt'] = image['prompt'].removesuffix(rule).rstrip() + '\n' + (
                    'CUFF-ANCHORED SLEEVE PLACEMENT: On each selected sleeve, place the lowest visible stitched element of the COMPLETE approved artwork '
                    'immediately above the seam joining the ribbed wrist cuff to the main sleeve fabric, with only a narrow natural sewing clearance. '
                    'Keep the entire ribbed cuff blank; no stitches on the ribbing or across that seam. Anchor the actual stitched motif, not the white padding of its source image. '
                    'The bottom of the approved composition is nearest the wrist; the rest extends upward toward the elbow at its unchanged aspect ratio and consistent relative scale. '
                    'Never center the artwork along the full sleeve, float its bottom at mid-forearm, shift it toward the upper arm, or stretch/enlarge it to fill the sleeve. '
                    'Match the small cuff-relative clearance on both sleeves even when they lie diagonally, straight or beside a folded torso; keep each cuff seam and lowest motif visible and unobscured. '
                    'This cuff anchor overrides sleeve placement in the sample photo, style reference or schematic if it leaves a long blank gap above the cuff. '
                    'All other approved regions, artwork details, proportions and unmirrored upright orientation remain locked.'
                ) + '\n' + rule
    return {'provider': 'Flow Nano Banana Pro', 'aspect_ratio': '1:1', 'executor': 'independent_flow_worker', 'requires_active_chrome_profile': 'Đức', 'listing_code': j['code'], 'revision': j['revision'], 'references': references, 'sizes_in': {}, 'dimension_policy': 'maximum_limits_only' if kind not in PRINT_KINDS else 'no_artwork_dimensions', 'product_kind': kind, 'profile_version': 3, **({'embroidery_mode':embroidery_direct.MODE} if direct else {}), **({'product_bundle': p['product_bundle']} if kind == 'pajama_set' else {}), **({'mockup_set':p['mockup_set']} if p.get('mockup_set') else {}), **({'mockup_layout':p['mockup_layout']} if p.get('mockup_layout') else {}), 'images': images}
