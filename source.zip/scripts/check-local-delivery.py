"""Isolated Telegram/local delivery checks. No real messages, approvals or KPI changes."""
import csv
import importlib.util
import json
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('local_fixture',Path(__file__).with_name('check-production-batch.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,batch=fixture.engine,fixture.batch
import local_delivery
import review_transport


class LocalDeliveryTests(fixture.BatchTests):
    def test_two_local_listings_complete_after_native_file_readback_without_any_lark_task(self):
        self.submit['profile_version']=3
        for n,entry in enumerate(self.submit['items'],1):entry['listing_code']='UST_261019_%02d_TQH'%n
        self.finish_images()
        self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        original_scope=engine.scoped
        def scoped(value,*roots):
            normalized=str(value).replace('\\','/')
            for folder in ['Chưa xử lý','Đã xử lý']:
                prefix='C:/Huy/'+folder+'/'
                if normalized.startswith(prefix):value=engine.STORE/'fixture-deliveries'/folder/normalized[len(prefix):];break
            return original_scope(value,*roots)
        with patch('review_transport.local_delivery',return_value=True),patch.object(engine,'scoped',side_effect=scoped),patch('urllib.request.urlopen',side_effect=AssertionError('Local delivery attempted an external request')):
            codes=[]
            for unused in range(2):
                code=self.cycle()['production_jobs'][0]['listing_code'];codes.append(code)
                j=engine.job(self.c,code);self.assertEqual(json.loads(j['plan'])['delivery_backend'],'local_v1')
                self.assertEqual(self.execute({'action':'advance','listing_code':code})['status'],'needs_text')
                keywords=[{'keyword':'fixture term '+str(n),'requested_filter':'physical','checked_at_utc':engine.now(),'evidence_status':'indexed_record','competition_level':'low','listing_count':80,'indexed_avg_listing_views':600,'indexed_avg_listing_views_24h':2,'provider_says_insufficient_data':False} for n in range(20)]
                text={'listing_code':code,'title':'Fixture cozy animal sweater gift for woodland lovers and friends with a colorful design for everyday outfits'.ljust(137,'!'),
                      'description':'<script>Fixture escaped text</script>','tags':[x['keyword'] for x in keywords[:13]],'keyword_evidence':keywords,
                      'provenance':{'input_sha256':j['source_hash']},'keyword_provenance':{'keyword_policy':'ai_first_20_to_13_v1','source_hash':j['source_hash']}}
                self.execute({'action':'attach_text','listing_code':code,'text':text})
                result=self.execute({'action':'advance','listing_code':code});self.assertEqual(result['status'],'completed')
                proof=engine.artifact(self.c,j,'local_delivery')['payload'];report=Path(proof['report']['path'])
                self.assertIn('&lt;script&gt;',report.read_text(encoding='utf-8'));self.assertTrue(local_delivery.verified(self.c,j,self.env))
                self.assertEqual(len(engine.artifact(self.c,j,'package')['payload']['files']),5)
                self.cycle()
            self.assertEqual(self.cycle()['status'],'batch_completed')
            snapshot=self.cycle();self.assertEqual(snapshot['status'],'batch_idle')
            self.assertEqual(len(snapshot['completion_reports']),1)
            report=snapshot['completion_reports'][0];self.assertEqual(report['kpi_count'],2)
            bundle=report['documents'][0]
            with zipfile.ZipFile(bundle['path']) as z:
                self.assertEqual(len(z.namelist()),5)
                self.assertIn('KPI.csv',z.namelist())
                self.assertEqual(len(list(csv.reader(z.read('KPI.csv').decode('utf-8-sig').splitlines()))),3)
            self.assertEqual(self.c.execute("SELECT COUNT(*) FROM tasks WHERE kind IN ('lark_review','lark_kpi')").fetchone()[0],0)
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0],2)
            self.assertEqual(self.cycle()['completion_reports'][0]['documents'][0],bundle)
            local=self.execute({'action':'kpi_sync_cycle'});self.assertEqual(local['delivery_backend'],'local_v1');self.assertFalse(local['remote_api_calls'])
            j=engine.job(self.c,codes[0]);p=engine.artifact(self.c,j,'local_delivery')['payload'];Path(p['report']['path']).write_text('changed',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'changed'):local_delivery.verified(self.c,j,self.env)

    def test_transport_authority_never_treats_a_telegram_event_as_lark(self):
        legacy={'humanOpenId':'owner','chatId':'chat'}
        review_transport.authorize({'sender_open_id':'owner','chat_id':'chat'},legacy)
        with self.assertRaises(ValueError):review_transport.authorize({'transport':'telegram','sender_open_id':'owner','chat_id':'chat'},legacy)
        telegram={**legacy,'transport':'telegram'}
        with self.assertRaises(ValueError):review_transport.authorize({'sender_open_id':'owner','chat_id':'chat'},telegram)


if __name__=='__main__':
    suite=unittest.TestSuite(LocalDeliveryTests(n) for n in LocalDeliveryTests.__dict__ if n.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
