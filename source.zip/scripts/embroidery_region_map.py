"""A position-only reference composed from this listing's locked artwork."""
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw, ImageOps
import embroidery_layout as layout


def reference(profile, style, regions, rear, e):
    guide = layout.placement(profile, style, regions, rear)
    visible = {r: a for r, a in regions.items() if (r == 'back' if rear else r != 'back') or r.endswith('sleeve')}
    identity = {'version': 1, 'guide': guide['sha256'], 'regions': {r: a['sha256'] for r, a in sorted(visible.items())}}
    target = e['STORE'] / 'mockup-region-maps' / (layout.digest(identity) + '.png')
    with Image.open(e['scoped'](guide['path'])) as source:
        image = source.convert('RGB')
    draw = ImageDraw.Draw(image)
    # Coordinates match shared-guides-v1; the map illustrates regions, not product measurements.
    y = 104 if style == 'crewneck sweatshirt' else 132
    cy = 110 if style == 'crewneck sweatshirt' else 144
    by = 99 if style == 'crewneck sweatshirt' else 145
    ry = 104 if style == 'crewneck sweatshirt' else 144
    boxes = {'left_chest': (227,y,259,y+32), 'right_chest': (125,ry,207,ry+82),
             'center_chest': (153,cy,247,cy+94), 'back': (150,by,250,by+100),
             'left_sleeve': ((303 if not rear else 62),166,(338 if not rear else 97),296),
             'right_sleeve': ((62 if not rear else 303),166,(97 if not rear else 338),296)}
    for region, asset in visible.items():
        file = e['scoped'](asset['path'])
        if e['sha'](file) != asset['sha256']:
            raise ValueError('Region map source hash changed')
        with Image.open(file) as source:
            art = source.convert('RGB')
        difference = ImageChops.difference(art, Image.new('RGB', art.size, 'white'))
        mask = ImageChops.lighter(ImageChops.lighter(*difference.split()[:2]), difference.split()[2])
        bounds = mask.point(lambda value: 255 if value > 24 else 0).getbbox()
        if not bounds:
            raise ValueError('Region map source is blank')
        x1,y1,x2,y2 = boxes[region]
        box = (x1*3,y1*3+20,x2*3,y2*3+20)
        draw.rectangle(box, fill='#ededed')
        art = ImageOps.contain(art.crop(bounds), (box[2]-box[0]-8, box[3]-box[1]-8), Image.Resampling.LANCZOS)
        top = box[3]-4-art.height if region.endswith('sleeve') else box[1]+(box[3]-box[1]-art.height)//2
        image.paste(art, (box[0]+(box[2]-box[0]-art.width)//2, top))
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        with Image.open(target) as prior:
            if prior.convert('RGB').tobytes() != image.tobytes() or prior.size != image.size:
                raise ValueError('Locked region map changed')
    else:
        image.save(target, format='PNG')
    return {'path': str(target), 'sha256': e['sha'](target), 'role': 'same_listing_region_map',
            'mapped_regions': sorted(visible), 'source_sha256': identity['regions']}
