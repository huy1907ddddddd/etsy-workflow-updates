"""Copy-only intake: immutable thumbnail snapshots, existing SEO workers, verified Docs; no SKU/KPI."""
import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
import urllib.request


def tables(c):
    c.execute('CREATE TABLE IF NOT EXISTS thumbnail_observations(folder TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,observed_at TEXT NOT NULL)')
    c.execute('''CREATE TABLE IF NOT EXISTS thumbnail_items(id TEXT PRIMARY KEY,source_key TEXT UNIQUE NOT NULL,folder TEXT NOT NULL,
      source_path TEXT NOT NULL,thumbnail TEXT NOT NULL,profile TEXT NOT NULL,state TEXT NOT NULL,listing_code TEXT,source_hash TEXT,
      text TEXT,task TEXT,proof TEXT,created_at TEXT NOT NULL)''')


def config(e):
    cfg=e['read'](e['ROOT']/'config/thumbnail-copy.json')
    if not cfg.get('authorization_reference') or cfg.get('count_production_kpi') is not False:
        raise ValueError('Explicit copy-only authorization and disabled production KPI required')
    return cfg


def item(c,identifier):
    row=c.execute('SELECT * FROM thumbnail_items WHERE id=?',(identifier,)).fetchone()
    if not row:raise ValueError('Thumbnail item not found')
    return dict(row)


def context(e,i):
    value={'copy_id':i['id'],'thumbnail':json.loads(i['thumbnail']),'profile':json.loads(i['profile'])}
    file=e['STORE']/'thumbnail-copy/tasks'/(i['id']+'.json');e['write'](file,value)
    return value


def scan(c,e):
    from PIL import Image
    cfg=config(e)
    if not cfg.get('enabled'):return {'ok':True,'status':'thumbnail_copy_disabled','next_item':None}
    root=Path(cfg['input_root']).resolve();root.mkdir(parents=True,exist_ok=True)
    for folder in sorted(p for p in root.iterdir() if p.is_dir() and not p.is_symlink()):
        files=sorted(p for p in folder.iterdir() if p.suffix.lower() in ('.png','.jpg','.jpeg','.webp'))
        if not files:continue
        if len(files)>100:raise ValueError('At most 100 thumbnails per folder')
        profile={'product_mode':cfg['product_mode']}
        if (folder/'profile.json').exists():profile=e['read'](folder/'profile.json')
        if set(profile)!={'product_mode'} or profile['product_mode'] not in ('embroidered_apparel','apparel_2d'):raise ValueError('Choose embroidered_apparel or apparel_2d in profile.json')
        assets=[]
        for path in files:
            if path.is_symlink() or not path.resolve().is_relative_to(root) or path.stat().st_size>20*1024*1024:raise ValueError('Thumbnail must be a local image under the input folder, at most 20 MB')
            with Image.open(path) as im:im.verify()
            assets.append({'path':str(path.resolve()),'sha256':e['sha'](path)})
        fp=e['digest']({'assets':assets,'profile':profile});old=c.execute('SELECT * FROM thumbnail_observations WHERE folder=?',(str(folder),)).fetchone()
        if not old or old['fingerprint']!=fp:
            c.execute('INSERT OR REPLACE INTO thumbnail_observations VALUES(?,?,?)',(str(folder),fp,e['now']()));continue
        if (datetime.now(timezone.utc)-datetime.fromisoformat(old['observed_at'])).total_seconds()<cfg['stable_seconds']:continue
        for asset in assets:
            key=e['digest']({'source':asset,'profile':profile})
            if c.execute('SELECT 1 FROM thumbnail_items WHERE source_key=?',(key,)).fetchone():continue
            identifier='thumb-'+uuid.uuid4().hex;dest=e['STORE']/'thumbnail-copy/assets'/identifier/Path(asset['path']).name;dest.parent.mkdir(parents=True)
            shutil.copy2(asset['path'],dest)
            if e['sha'](dest)!=asset['sha256']:raise ValueError('Thumbnail changed during intake')
            c.execute('INSERT INTO thumbnail_items VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(identifier,key,str(folder),asset['path'],json.dumps({'path':str(dest),'sha256':asset['sha256']}),json.dumps(profile),'queued',None,None,None,None,None,e['now']()))
    row=c.execute("SELECT id,state FROM thumbnail_items WHERE state NOT IN ('completed','needs_review') ORDER BY created_at,id LIMIT 1").fetchone()
    return {'ok':True,'status':'thumbnail_copy_ready' if row else 'thumbnail_copy_idle','next_item':dict(row) if row else None,'input_root':str(root),'kpi_counted':False}


def execute(c,cmd,e):
    tables(c);action=cmd['action'];cfg=config(e)
    if action=='thumbnail_scan':return scan(c,e)
    i=item(c,cmd['copy_id']);thumbnail=json.loads(i['thumbnail'])
    if e['sha'](e['scoped'](thumbnail['path']))!=thumbnail['sha256']:raise ValueError('Locked thumbnail changed')
    if action=='thumbnail_retry':
        if cmd.get('authority')!='direct_user' or not cmd.get('reference') or i['state']!='needs_review' or i['source_hash']:raise ValueError('Explicit retry of a held thumbnail before text only')
        file=e['STORE']/'thumbnail-copy/vision'/(i['id']+'.json')
        if file.exists():file.rename(file.with_name(i['id']+'.superseded-'+uuid.uuid4().hex+'.json'))
        c.execute("UPDATE thumbnail_items SET state='queued',proof=NULL WHERE id=?",(i['id'],))
        return {'ok':True,'status':'thumbnail_requeued','copy_id':i['id'],'previous_evidence_preserved':True,'kpi_counted':False}
    if action=='thumbnail_defer':
        file=e['STORE']/'thumbnail-copy/vision'/(i['id']+'.json');proof=e['read'](file) if file.exists() else {}
        facts=proof.get('draft',{});reasons=facts.get('uncertainties',[]) if facts.get('copy_usable') is not True else []
        if facts.get('copy_usable') is False and not reasons:reasons=['Main motif or garment is not clear enough for accurate copy']
        if json.loads(i['profile'])['product_mode']=='apparel_2d' and facts.get('garment_style') not in (None,'crewneck sweatshirt'):reasons=[*reasons,'Apparel 2D profile requires a crewneck thumbnail']
        if reasons:
            c.execute("UPDATE thumbnail_items SET state='needs_review',proof=? WHERE id=?",(json.dumps({'reasons':reasons}),i['id']))
            e['write'](Path(i['folder'])/(Path(i['source_path']).stem+'.needs-review.json'),{'copy_id':i['id'],'reasons':reasons,'source_preserved':True})
        return {'ok':True,'status':'thumbnail_needs_review' if reasons else 'thumbnail_pending_retry','copy_id':i['id'],'reasons':reasons,'kpi_counted':False}
    if action=='thumbnail_prepare':
        return {'ok':True,'status':'thumbnail_context_ready',**context(e,i),'completed':i['state']=='completed','kpi_counted':False}
    if action=='thumbnail_attach_facts':
        if i['source_hash']:return {'ok':True,'status':'thumbnail_source_ready','copy_id':i['id'],'listing_code':i['listing_code'],'input_sha256':i['source_hash'],'preflight_only':False}
        file=e['STORE']/'thumbnail-copy/vision'/(i['id']+'.json');proof=e['read'](file)
        if proof.get('ok') is not True or proof.get('external_tools_used') is not False or proof.get('input_sha256')!=thumbnail['sha256']:raise ValueError('Real thumbnail vision result required')
        facts=proof['draft'];motif=facts.get('motif_description','').strip();style=facts.get('garment_style')
        if not motif or facts.get('copy_usable',not facts.get('uncertainties')) is not True or style not in ('crewneck sweatshirt','hoodie','quarter-zip pullover'):raise ValueError('Thumbnail is ambiguous; supply a clearer apparel image before writing')
        profile=json.loads(i['profile']);stamp=datetime.now().strftime('%y%m%d')
        used={r[0] for r in c.execute('SELECT listing_code FROM thumbnail_items WHERE listing_code IS NOT NULL')};number=1
        while 'TXT_'+stamp+'_%02d'%number in used or e['public_code'](c,'TXT_'+stamp+'_%02d'%number) in used:number+=1
        if number>99:raise ValueError('Daily copy-only identifier capacity reached')
        code=e['public_code'](c,'TXT_'+stamp+'_%02d'%number)
        garment={'crewneck sweatshirt':'crewneck','hoodie':'hoodie','quarter-zip pullover':'quarter_zip'}[style]
        brief={'brief_id':i['id'],'product_id':i['id'],'topic_code':'TXT','garment':garment,'color':'visible thumbnail garment',
          'available_styles':[style],'back_artwork':False,'personalization':{'enabled':False},'motifs':{'center_chest':motif},'sources':[]}
        plan={'regions':{}}
        if profile['product_mode']=='apparel_2d':
            if style!='crewneck sweatshirt':raise ValueError('Apparel 2D profile is crewneck only')
            brief.update(rendering_mode='apparel_2d',idea_prompt=motif);plan['approved_sample']=thumbnail
        source=e['create_listing_source'](brief,plan,code,i['created_at'],'thumbnail_copy_only_no_sku_no_kpi')
        source['packet']['scope']='thumbnail_copy_only';source['packet']['thumbnail_observations']={**facts,'provenance':'AI visual observation of user-supplied thumbnail, not individual product approval'}
        source['task']+='\nWrite only from confidently visible thumbnail observations and confirmed shop specifications. Omit every uncertain detail listed in thumbnail_observations.uncertainties from the title, description, keywords and tags. Do not guess what an unclear object is. Do not invent unseen artwork, text, colors for sale, back artwork, personalization or extra garment styles.'
        dest=e['JOBS']/(code+'.json')
        if dest.exists():raise ValueError('Copy source path already occupied')
        e['write'](dest,source);source_hash=e['sha'](dest)
        registry=e['read'](e['JOBS']/'registry.json') if (e['JOBS']/'registry.json').exists() else {'version':1,'jobs':{}}
        registry['jobs'][code]={'status':'ready_for_title_description','input_sha256':source_hash,
          'authorization':{'scope':'thumbnail_copy_only','reference':cfg['authorization_reference']}}
        e['write'](e['JOBS']/'registry.json',registry)
        c.execute("UPDATE thumbnail_items SET listing_code=?,source_hash=?,state='needs_text' WHERE id=?",(code,source_hash,i['id']))
        return {'ok':True,'status':'thumbnail_source_ready','copy_id':i['id'],'listing_code':code,'input_sha256':source_hash,'preflight_only':False}
    if action=='thumbnail_attach_copy':
        text=cmd['text'];source=e['read'](e['JOBS']/(i['listing_code']+'.json'))
        e['validate_text']({'code':i['listing_code'],'source_hash':i['source_hash'],'plan':json.dumps({'rendering_mode':source['packet']['confirmed_product_brief'].get('rendering_mode')})},text)
        e['ensure_title_unique'](c,{'code':i['listing_code']},text['title'])
        packet={'listing_code':i['listing_code'],'revision':1,'title':text['title'],'description':text['description'],'tags':text['tags'],'thumbnail':thumbnail}
        packet['review_fingerprint']=e['digest'](packet)
        task={'id':i['id'],'code':i['listing_code'],'revision':1,'status':'pending','kind':'lark_review','payload':{'url':e['review_url'](c),'layout':e['review_layout'](c),'packet':packet,'scope':'thumbnail_copy_only'}};task['fingerprint']=e['digest'](task['payload'])
        if i['text'] and e['digest'](json.loads(i['text']))!=e['digest'](text):raise ValueError('Copy changed after it was locked')
        c.execute("UPDATE thumbnail_items SET text=?,task=?,state='docs_pending' WHERE id=?",(json.dumps(text),json.dumps(task),i['id']))
        e['write'](e['STORE']/'thumbnail-copy/tasks'/(i['id']+'.delivery.json'),task)
        return {'ok':True,'status':'thumbnail_docs_ready','copy_id':i['id'],'task_fingerprint':task['fingerprint'],'kpi_counted':False}
    if action=='thumbnail_finalize':
        task=json.loads(i['task']);token=e['read'](e['ROOT']/'config/lark-review.private.json')['localToken']
        req=urllib.request.Request('http://127.0.0.1:8792/thumbnail-readback/'+i['id'],headers={'x-review-token':token})
        with urllib.request.urlopen(req,timeout=45) as response:proof=json.load(response)
        p=task['payload']['packet'];expected={'listing_code':p['listing_code'],'title':p['title'],'description':p['description'],'tags':p['tags'],'thumbnail_sha256':thumbnail['sha256']}
        if proof.get('ok') is not True or proof.get('task_fingerprint')!=task['fingerprint'] or proof.get('content')!=expected:raise ValueError('Actual thumbnail copy Docs readback required')
        out=e['STORE']/'thumbnail-copy/outputs'/i['listing_code'];out.mkdir(parents=True,exist_ok=True)
        e['write'](out/'listing.json',expected);(out/'listing.md').write_text('# '+p['listing_code']+'\n\n## Title\n\n'+p['title']+'\n\n## Mô tả\n\n'+p['description']+'\n\n## Tags\n\n'+', '.join(p['tags'])+'\n',encoding='utf-8')
        c.execute("UPDATE thumbnail_items SET proof=?,state='completed' WHERE id=?",(json.dumps(proof),i['id']))
        rows=[]
        for row in c.execute('SELECT source_path,listing_code,state,proof FROM thumbnail_items WHERE folder=? ORDER BY created_at,id',(i['folder'],)):
            saved=json.loads(row['proof']) if row['proof'] else {}
            rows.append({'image':Path(row['source_path']).name,'copy_id':row['listing_code'],'status':row['state'],
              'url':saved.get('document_url','')+('#'+saved['block_ids'][0] if saved.get('block_ids') else '')})
        index=Path(i['folder'])/'KET_QUA_NOI_DUNG.json'
        if index.exists() and e['read'](index).get('generator')!='etsy-thumbnail-copy-v1':raise ValueError('Result filename occupied by user data')
        e['write'](index,{'generator':'etsy-thumbnail-copy-v1','items':rows,'kpi_counted':False})
        held=Path(i['folder'])/(Path(i['source_path']).stem+'.needs-review.json')
        if held.exists():
            note=e['read'](held)
            if note.get('copy_id')==i['id']:
                e['write'](held,{**note,'status':'resolved','result_url':proof['document_url']+'#'+proof['block_ids'][0]})
        return {'ok':True,'status':'thumbnail_copy_completed','copy_id':i['id'],'listing_code':i['listing_code'],'output_directory':str(out),'url':proof['document_url']+'#'+proof['block_ids'][0],'kpi_counted':False,'images_generated':False}
    raise ValueError('Unsupported thumbnail copy action')
