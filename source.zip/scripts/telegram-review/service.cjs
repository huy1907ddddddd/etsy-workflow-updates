'use strict';
const fs=require('node:fs'),path=require('node:path');
const {createHash,timingSafeEqual}=require('node:crypto');
const {atomic,claimProcessLock}=require('../flow-worker/native-n8n.cjs');
const {ReviewStore}=require('../lark-review/review.cjs');
const {BatchStore,MAX_BYTES}=require('../lark-review/batch.cjs');
const {makeServer}=require('../lark-review/service.cjs');
const hash=x=>createHash('sha256').update(x).digest('hex');
const read=f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/^\uFEFF/,''));
const fail=code=>{throw Object.assign(Error(code),{code});};
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const internal=(chat,mid)=>`tg_${chat}_${mid}`;
function parts(mid){const m=/^tg_(\d+)_(\d+)$/.exec(mid||'');if(!m)fail('telegram_message_identity_invalid');return {chat_id:m[1],message_id:Number(m[2])};}
class TelegramApi{
  constructor(config,deps={}){this.config=config;this.fetch=deps.fetch||fetch;this.lastSend=0;this.stop=new AbortController();}
  async call(method,input={}){
    if(!['getMe','getWebhookInfo','getUpdates','getFile','sendMessage','sendDocument','editMessageText','answerCallbackQuery'].includes(method))fail('telegram_method_invalid');
    if(['sendMessage','sendDocument','editMessageText'].includes(method)){await pause(Math.max(0,1100-(Date.now()-this.lastSend)));this.lastSend=Date.now();}
    let response,data;
    try{response=await this.fetch(`https://api.telegram.org/bot${this.config.botToken}/${method}`,{method:'POST',body:input instanceof FormData?input:JSON.stringify(input),headers:input instanceof FormData?{}:{'content-type':'application/json'},redirect:'error',signal:AbortSignal.any([this.stop.signal,AbortSignal.timeout(method==='getUpdates'?35000:60000)])});data=await response.json();}
    catch{fail('telegram_network_result_uncertain');}
    if(!response.ok||data.ok!==true){const e=Error(data.error_code===429?'telegram_rate_limited':'telegram_api_rejected');e.code=e.message;e.definite=true;e.retry_after=data.parameters?.retry_after;throw e;}
    return data.result;
  }
  async download(file_id){const f=await this.call('getFile',{file_id});if(!/^[A-Za-z0-9_./-]+$/.test(f.file_path||'')||f.file_path.includes('..')||f.file_size>MAX_BYTES)fail('telegram_input_file_invalid');
    let r;try{r=await this.fetch(`https://api.telegram.org/file/bot${this.config.botToken}/${f.file_path}`,{redirect:'error',signal:AbortSignal.timeout(20000)});}catch{fail('telegram_file_download_pending');}
    if(!r.ok)fail('telegram_file_download_pending');const data=Buffer.from(await r.arrayBuffer());if(data.length>MAX_BYTES)fail('batch_txt_too_large');return data;
  }
}
class TelegramTransport{
  constructor(config,state,save,api){this.config=config;this.state=state;this.save=save;this.api=api;state.sent||={};state.callbacks||={};state.uploads||={};}
  async upload(bytes){const digest=hash(bytes),key='img_tg_'+digest,dir=path.join(path.dirname(this.config.stateFile),'uploads');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,digest+(bytes[0]===137?'.png':'.jpg'));if(!fs.existsSync(file))fs.writeFileSync(file,bytes);this.state.uploads[key]={path:file,sha256:digest};this.save();return key;}
  render(card,uuid,mid){
    const lines=[card.header?.title?.content||'Workflow'],buttons=[];let form;
    const visit=n=>{if(!n||typeof n!=='object')return;if(n.tag==='button'){
      const cb=n.behaviors?.find(b=>b.type==='callback'),url=n.behaviors?.find(b=>b.type==='open_url');
      if(cb){if(n.form_action_type==='submit'){form={value:cb.value,message_id:mid,expires_at:Date.now()+15*60000};return;}
        const key='cb_'+hash(uuid+':'+buttons.length+':'+JSON.stringify(cb.value)).slice(0,40);this.state.callbacks[key]={value:cb.value,uuid,origin:mid,confirm:n.confirm?.text?.content,expires_at:Date.now()+24*3600000};buttons.push([{text:n.text?.content||'Chọn',callback_data:key}]);}
      else if(url&&/^https:\/\//.test(url.default_url||''))buttons.push([{text:n.text?.content||'Mở',url:url.default_url}]);return;
    }if(n.tag==='input'){lines.push(n.label?.content||'Nhập yêu cầu sửa bằng tin nhắn tiếp theo.');return;}if(n.tag==='div')lines.push(n.text?.content||'');for(const v of Object.values(n))if(Array.isArray(v))v.forEach(visit);};
    (card.body?.elements||[]).forEach(visit);
    if(form){this.state.form=form;lines.push('Nhắn nội dung cần sửa vào cuộc trò chuyện này. Chọn Quay lại để hủy nhập sửa.');}else if(this.state.form?.message_id===mid)delete this.state.form;
    this.save();return {text:lines.join('\n').slice(0,4000),reply_markup:{inline_keyboard:buttons}};
  }
  async transmit(method,input,uuid,bytes,name){
    const digest=hash(JSON.stringify(input)+(bytes?hash(bytes):''));let saved=this.state.sent[uuid];
    if(saved&&saved.digest!==digest)fail('telegram_send_identity_changed');
    if(saved?.status==='sent')return saved.message_id;
    if(saved?.status==='sending')fail('telegram_send_result_uncertain');
    saved=this.state.sent[uuid]={status:'sending',digest,method,text:input.text||'',...saved};saved.status='sending';this.save();
    let body=input;if(bytes){body=new FormData();for(const [k,v]of Object.entries(input))body.set(k,typeof v==='object'?JSON.stringify(v):String(v));body.set('document',new Blob([bytes]),name);}
    try{const result=await this.api.call(method,body);saved.status='sent';saved.message_id=internal(result.chat.id,result.message_id);this.save();return saved.message_id;}
    catch(e){if(e.definite){saved.status='retryable';this.save();}throw e;}
  }
  async send(chat,type,content,uuid){
    if(chat!==this.config.chatId||!/^tg_\d+$/.test(chat))fail('telegram_chat_not_paired');const chat_id=chat.slice(3);
    if(type==='image'){const a=this.state.uploads[content.image_key];if(!a)fail('telegram_image_missing');const bytes=fs.readFileSync(a.path);if(hash(bytes)!==a.sha256)fail('image_hash_changed');return this.transmit('sendDocument',{chat_id},uuid,bytes,path.basename(a.path));}
    const body=type==='interactive'?this.render(content,uuid):{text:content.text};const chunks=String(body.text).match(/[\s\S]{1,4000}/g)||['Workflow'];let id;
    for(let i=0;i<chunks.length;i++)id=await this.transmit('sendMessage',{chat_id,text:chunks[i],...(i===chunks.length-1&&body.reply_markup?{reply_markup:body.reply_markup}:{}),link_preview_options:{is_disabled:true}},uuid+'-part-'+i);
    for(const entry of Object.values(this.state.callbacks))if(entry.uuid===uuid&&!entry.origin)entry.origin=id;
    this.save();return id;
  }
  async update(mid,card){const body=this.render(card,'update-'+mid,mid);try{await this.api.call('editMessageText',{...parts(mid),...body,link_preview_options:{is_disabled:true}});}catch(e){if(e.definite&&e.code==='telegram_api_rejected')return;throw e;}}
  document(chat,document,uuid){if(chat!==this.config.chatId)fail('telegram_chat_not_paired');return this.transmit('sendDocument',{chat_id:chat.slice(3)},uuid,document.bytes,document.name);}
  reconcile(message){if(message.from?.id!==this.config.botId)return;const mid=internal(message.chat.id,message.message_id);for(const saved of Object.values(this.state.sent))if(saved.status==='sending'&&saved.text&&saved.text===message.text){saved.status='sent';saved.message_id=mid;}this.save();}
}
function normalized(config,update,text){const m=update.message;return {header:{event_id:'tg_update_'+update.update_id},event:{sender:{sender_type:'user',sender_id:{open_id:'tg_'+m.from.id}},message:{message_id:internal(m.chat.id,m.message_id),chat_id:'tg_'+m.chat.id,message_type:'text',content:JSON.stringify({text:text??m.text??''})}}};}
function authorized(config,m){return m?.chat?.type==='private'&&'tg_'+m.chat.id===config.chatId&&'tg_'+m.from?.id===config.humanOpenId&&!m.from?.is_bot;}
class TelegramService{
  constructor(config,deps={}){this.config=config;this.api=deps.api||new TelegramApi(config);this.store=deps.store||new ReviewStore(config);this.batch=deps.batch||new BatchStore(this.store);this.state=this.store.state.telegram||={offset:0,inbox:[]};this.save=()=>this.store.save();this.transport=new TelegramTransport(config,this.state,this.save,this.api);this.flushBusy=false;this.connectedAt=0;}
  async flush(){if(this.flushBusy||!this.config.humanOpenId)return;this.flushBusy=true;try{
    await this.batch.downloadFiles(async(_mid,key)=>{const id=this.state.files?.[key];if(!id)fail('telegram_file_binding_missing');return this.api.download(id);});
    const forward=async body=>{let r;try{r=await fetch(body.event_type==='batch_command'?this.config.batchWebhookUrl:this.config.n8nWebhookUrl,{method:'POST',headers:{'content-type':'application/json',[this.config.n8nTokenHeader||'x-review-token']:this.config.n8nToken},body:JSON.stringify(body),signal:AbortSignal.timeout(20000),redirect:'error'});}catch{fail('n8n_unavailable');}if(!r.ok)fail(r.status===409?'stale_review':'n8n_unavailable');return r.json();};
    await this.store.flush(forward);await this.batch.flush(forward);
    for(const r of Object.values(this.store.state.reviews))if(r.status==='sending')await this.store.deliver(r.review_id,this.transport);
    await this.store.deliverWorkerStatus(this.transport);await this.store.deliverCardUpdates(this.transport);await this.batch.deliver(this.transport);
  }finally{this.flushBusy=false;}}
  async handle(update){
    const m=update.message,q=update.callback_query;
    if(m&&/^\/start(?:\s|$)/.test(m.text||'')){
      if(m.chat.type!=='private'||m.from.is_bot)return;
      if(!this.config.humanOpenId){const token=m.text.split(/\s+/)[1]||'',wanted=this.config.pairingCode||'';if(!wanted||token.length!==wanted.length||!timingSafeEqual(Buffer.from(token),Buffer.from(wanted)))return;
        this.config.humanOpenId='tg_'+m.from.id;this.config.chatId='tg_'+m.chat.id;this.config.pairingCode='';atomic(this.config.configFile,this.config);}
      if(!authorized(this.config,m))return;
      this.batch.receive(normalized(this.config,update,'MENU'));return;
    }
    if(q){const context={...q.message,from:q.from};if(!authorized(this.config,context)||q.message?.from?.id!==this.config.botId)return;const action=this.state.callbacks[q.data];if(!action||Date.now()>action.expires_at)return;
      const sent=this.state.sent[action.uuid+'-part-0'];if(sent?.status==='sending'){sent.status='sent';sent.message_id=internal(q.message.chat.id,q.message.message_id);this.save();await this.flush();}
      const mid=action.origin||internal(q.message.chat.id,q.message.message_id);
      if(action.cancel){await this.transport.update(internal(q.message.chat.id,q.message.message_id),{header:{title:{content:'Đã hủy'}},body:{elements:[]}});return;}
      if(action.confirm&&!action.confirmed){const yes='yes_'+hash(q.id).slice(0,32),no='no_'+hash(q.id).slice(0,32);this.state.callbacks[yes]={...action,confirm:null,confirmed:true,origin:mid};this.state.callbacks[no]={...action,cancel:true};this.save();await this.transport.transmit('sendMessage',{chat_id:String(q.message.chat.id),text:action.confirm,reply_markup:{inline_keyboard:[[{text:'Xác nhận',callback_data:yes},{text:'Hủy',callback_data:no}]]}},'confirm-'+update.update_id);return;}
      const data={header:{event_id:'tg_update_'+update.update_id},event:{operator:{open_id:this.config.humanOpenId},context:{open_chat_id:this.config.chatId,open_message_id:mid},action:{tag:'button',value:action.value}}};
      const response=action.value.scope==='review'?this.store.receiveCard(data):this.batch.receiveCard(data);
      if(response.card?.data)await this.transport.update(mid,response.card.data);
      try{await this.api.call('answerCallbackQuery',{callback_query_id:q.id,text:response.toast?.content||'Đã nhận'});}catch{}return;
    }
    if(!m||!authorized(this.config,m))return;
    if(m.reply_to_message)this.transport.reconcile(m.reply_to_message);
    let event=normalized(this.config,update);
    if(m.document){const key='file_tg_'+hash(m.document.file_id);this.state.files||={};this.state.files[key]=m.document.file_id;this.save();event.event.message.message_type='file';event.event.message.content=JSON.stringify({file_key:key,file_name:m.document.file_name});}
    if(m.text&&this.state.form&&Date.now()<this.state.form.expires_at&&!/^\/?menu$/i.test(m.text.trim())){
      const form=this.state.form,r=this.store.state.reviews[form.value.review_id];if(!r||r.input_hash!==form.value.binding||r.status!=='pending')fail('stale_review');
      event=normalized(this.config,update,`SỬA ${r.review_id}: ${m.text}`);this.store.receive(event);
      for(const entry of Object.values(this.store.state.outbox))if(entry.body.event_id==='tg_update_'+update.update_id){entry.body.source_text=m.text;entry.body.reference=`Telegram message ${event.event.message.message_id}; review ${r.review_id}; direct user revision reply: ${m.text}`;}
      delete this.state.form;this.save();return;
    }
    if(m.text&&/^\/menu(?:@\w+)?$/i.test(m.text.trim()))event=normalized(this.config,update,'MENU');
    const result=this.batch.receive(event);if(!result.handled)this.store.receive(event);
  }
  async run(){
    const me=await this.api.call('getMe');this.config.botId=me.id;this.config.botUsername=me.username;atomic(this.config.configFile,this.config);
    if((await this.api.call('getWebhookInfo')).url)fail('telegram_existing_webhook_requires_review');
    let stopping=false;const stopFile=this.config.stateFile+'.stop.request';if(fs.existsSync(stopFile))fs.unlinkSync(stopFile);
    const stop=()=>{stopping=true;this.api.stop.abort();server.close();};const watch=fs.watch(path.dirname(this.config.stateFile),()=>{if(fs.existsSync(stopFile))stop();});
    const server=makeServer(this.config,this.store,()=>{this.flush().catch(()=>{});},()=>this.config.humanOpenId&&Date.now()-this.connectedAt<90000?'connected':'pairing_required',()=>{this.flush().catch(()=>{});},this.batch);
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(this.config.port||8790,'127.0.0.1',resolve);});
    process.once('SIGINT',stop);process.once('SIGTERM',stop);
    try{while(!stopping){try{
      if(!this.state.inbox.length){const updates=await this.api.call('getUpdates',{offset:this.state.offset,timeout:20,allowed_updates:['message','callback_query']});this.connectedAt=Date.now();this.state.inbox=updates;this.save();}
      while(this.state.inbox.length&&!stopping){const u=this.state.inbox[0];await this.handle(u);this.state.offset=u.update_id+1;this.state.inbox.shift();this.save();await this.flush();}
      await this.flush();
    }catch(e){if(stopping)break;atomic(path.join(path.dirname(this.config.stateFile),'status.json'),{status:'blocked',code:e.code||'telegram_service_failed',updated_at:new Date().toISOString()});await pause(Math.min(60000,Math.max(2000,(e.retry_after||5)*1000)));}}}
    finally{watch.close();server.close();}
  }
}
async function main(){const file=process.env.TELEGRAM_REVIEW_CONFIG||'C:/Huy/etsy-workflow/config/telegram-review.private.json',config={...read(file),configFile:file};if(!/^\d{5,20}:[A-Za-z0-9_-]{25,}$/.test(config.botToken||''))fail('telegram_bot_token_required');fs.mkdirSync(path.dirname(config.stateFile),{recursive:true});const release=claimProcessLock(config.stateFile+'.lock','telegram-review');try{await new TelegramService(config).run();}finally{release();}}
module.exports={TelegramApi,TelegramTransport,TelegramService,normalized,authorized};
if(require.main===module)main().catch(e=>{console.error(e.code||'telegram_service_start_failed');process.exitCode=1;});
