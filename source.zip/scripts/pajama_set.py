"""Two coordinated garments sold and reviewed as one listing; legacy tops stay separate."""
CONTRACT = {'sales_unit': 'set', 'listing_units': 1, 'components': ['top', 'pants']}
STYLE = 'matching pajama set (top and pants)'
LABEL = 'Bộ pijama (áo + quần)'


def validate(value):
    if value.get('product_bundle') != CONTRACT:
        raise ValueError('Pajama listing requires one complete top-and-pants set')


def prompts(idea, approved):
    common = (
        'ONE MATCHING PAJAMA SET: sell ONE product/listing containing ONE pajama top AND ONE pair of sleep pants. '
        'Neither piece is an optional separate purchase. Coordinate the palette, repeat motifs, customer-face identity and personalization across BOTH pieces exactly as this listing brief specifies. '
        'Use only the garment construction confirmed in the brief or approved same-listing sample: preserve collar/lapels, button placket, pockets, sleeve length, waistband, drawstring and leg cut when supported. '
        'Never replace a confirmed button-front lapel shirt with a crewneck sweatshirt, omit the pants, add unsupported pockets/cuffs/accessories or invent fabric composition, size, measurements or pricing. '
        'No decorative text, logos or faces from style photos unless explicitly part of the confirmed design. Customer photo placeholders do not establish a real customer identity. '
        'Photorealistic flat decoration integrated with fabric folds; no embroidery or raised decoration. One square 1:1 photograph, matte neutral studio, soft indirect daylight, natural proportions, no collage, watermark or measurement labels. '
        'The original style photo guides supported construction only; it must not overwrite this listing\'s own motifs, palette or customer identity. '
    )
    common += ('APPROVED SAME-LISTING MASTER: reproduce BOTH garments from the exact approved sample. Keep their artwork, lettering, palette, repeat scale and construction consistent in all later views; change only pose, camera and natural drape. '
               if approved else 'CREATE THE FIRST COMPLETE-SET SAMPLE FROM THIS CONFIRMED IDEA: ' + idea + '\nBoth top and pants must be visible together for actual human approval. ')
    shots = [
        '01 — COMPLETE SET HERO. One adult wearing BOTH pieces. Front view, arms relaxed away from the print. Crop above the collar and below both pant hems: no face/chin, both sleeves/cuffs and full pants visible. Widen framing to fit the complete outfit in the square; never use a thigh crop that hides the pants.',
        '02 — COMPLETE SET ANGLED VIEW. A different adult female, standing at a gentle three-quarter angle. Show BOTH garments from collar to both pant hems, with hands clear of artwork and waistband. No face/chin. Keep the entire coordinated set legible, not an isolated top.',
        '03 — COMPLETE SET SEATED VIEW. A different adult female on a plain stool, gentle opposite three-quarter angle. Show the whole top, waistband, both legs and pant hems with natural seated folds. No face/chin, hands away from the pattern. Do not crop the lower legs or sell a different bottom.',
        '04 — COMPLETE SET FLATLAY. True overhead view. Lay the top fully unfolded beside its matching pants, both front-up on the same neutral surface. Show complete collar, sleeves, waistband, legs and hems; one top and one pair of pants only. Preserve the same repeat scale, palette and personalization on both pieces.',
        '05 — SET DETAIL. One close photograph of the matching top and pants placed adjacent on the surface. Show a real top detail (collar/placket/pocket only when confirmed) beside the pants waistband or print. Retain enough context to identify both pieces of the same set. Keep exact motif/face identity and print scale; do not invent fibers, construction, a size chart or a second product.'
    ]
    return [common + '\n' + shot for shot in shots]


LISTING_INSTRUCTIONS = (
    '\nPAJAMA SET FACTS: This is ONE listing/sales unit including BOTH a pajama top and matching pants. '
    'Title and copy must describe a pajama set, never a top-only or pants-only product or two separately priced listings. '
    'Only the confirmed style and construction are offered. Do not import sweatshirt fabric, ribbed cuffs, XL/5XL model sizes, unisex/oversized fit or size-up advice from the old template. '
    'No verified set size chart, fabric composition, price or customer face has been supplied by default. Do not invent one or claim a size chart appears in photos. '
    'If actual confirmed measurements are provided, identify top and pants measurements separately under the same set option. '
    'Personalization and separate top/pants sizing options exist only if explicitly confirmed in the structured brief; keep their approval gate.\n'
)
