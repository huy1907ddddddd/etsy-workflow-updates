"""No real Google writes: retry, folder, UTF-16, KPI and cutoff checks use isolated fixtures."""
import copy
import hashlib
import json
import re
import sqlite3
import tempfile
import unittest
import urllib.parse
import zipfile
from pathlib import Path
from unittest.mock import patch
import google_delivery as g


class FakeGoogle:
    def __init__(self):
        self.files = {}; self.created = 0; self.calls = []; self.header = []; self.rows = []
        self.doc = {'revisionId': 'r1', 'tabs': [{'tabProperties': {'tabId': name}, 'documentTab': {'body': {'content': [{'endIndex': 2, 'paragraph': {'elements': [{'textRun': {'content': '\n'}}]}}]}, 'namedRanges': {}}} for name in ('embroidered', 'printed')]}
        self.unknown = None

    def request(self, method, url, body=None, data=None, headers=None):
        self.calls.append((method, url, copy.deepcopy(body)))
        parsed = urllib.parse.urlparse(url); query = urllib.parse.parse_qs(parsed.query)
        if parsed.path.endswith('/generateIds'):
            self.created += 1; return {'ids': ['id' + str(self.created)]}, {}
        if parsed.path == '/drive/v3/files' and method == 'GET':
            q = query['q'][0]; parent = re.search("'([^']+)' in parents", q)[1]; name = re.search("name='([^']*)'", q)[1]
            return {'files': [f for f in self.files.values() if f.get('name') == name and parent in f.get('parents', []) and f.get('mimeType') == 'application/vnd.google-apps.folder']}, {}
        if parsed.path == '/drive/v3/files' and method == 'POST':
            self.files[body['id']] = dict(body); return dict(body), {}
        if parsed.path.startswith('/drive/v3/files/'):
            found = self.files.get(parsed.path.rsplit('/', 1)[1])
            if found is None: raise ValueError('google_http_404')
            return dict(found), {}
        if parsed.path.startswith('/upload/drive/') and method == 'POST':
            self.upload = dict(body); return {}, {'Location': 'https://www.googleapis.com/resumable/fixture'}
        if parsed.path == '/resumable/fixture':
            self.files[self.upload['id']] = {**self.upload, 'md5Checksum': hashlib.md5(data).hexdigest(), 'webViewLink': 'https://drive.google.com/file/d/' + self.upload['id'] + '/view'}
            if self.unknown == 'drive': self.unknown = None; raise ValueError('google_connection_failed')
            return {}, {}
        if parsed.hostname == 'docs.googleapis.com':
            if method == 'GET': return copy.deepcopy(self.doc), {}
            insert = body['requests'][0]['insertText']; named = body['requests'][1]['createNamedRange']
            tab = next(t['documentTab'] for t in self.doc['tabs'] if t['tabProperties']['tabId'] == insert['location']['tabId'])
            text = g.tab_text(tab)[:-1] + insert['text'] + '\n'
            self.last_range = named['range']; self.last_write = body['writeControl']
            tab['body']['content'] = [{'endIndex': 1 + len(text.encode('utf-16-le')) // 2, 'paragraph': {'elements': [{'textRun': {'content': text}}]}}]
            tab['namedRanges'][named['name']] = {'namedRanges': [{'ranges': [named['range']]}]}
            self.doc['revisionId'] = 'r2'
            if self.unknown == 'docs': self.unknown = None; raise ValueError('google_connection_failed')
            return {}, {}
        if parsed.hostname == 'sheets.googleapis.com':
            if '/values/' not in parsed.path:
                return {'sheets': [{'properties': {'title': 'KPI', 'gridProperties': {'rowCount': 1000}}}]}, {}
            target = urllib.parse.unquote(parsed.path).split('/values/', 1)[1]
            if 'A1:W1' in target:
                if method == 'GET': return {'values': [self.header]} if self.header else {}, {}
                self.header = copy.deepcopy(body['values'][0]); return {}, {}
            if method == 'POST':
                self.rows.extend(body['values'])
                if self.unknown == 'sheets': self.unknown = None; raise ValueError('google_connection_failed')
                return {}, {}
            if method == 'PUT':
                match = re.search(r'!B(\d+):W\d+', target)
                assert match, target
                self.rows[int(match[1])-2][1:] = copy.deepcopy(body['values'][0])
                if self.unknown == 'sheets': self.unknown = None; raise ValueError('google_connection_failed')
                return {}, {}
            return {'values': copy.deepcopy(self.rows)}, {}
        raise AssertionError((method, url))


class GoogleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='google-delivery-fixture-'); self.root = Path(self.tmp.name)
        self.api = FakeGoogle(); self.events = []; self.artifacts = {}
        self.config = {'enabled': True, 'start_after': '2026-10-20T00:00:00+00:00', 'document_id': 'doc', 'spreadsheet_id': 'sheet', 'sheet_name': 'KPI', 'folder_id': 'root', 'document_tabs': {'apparel_2d': 'printed'}}
        self.env = {'ROOT': self.root, 'STORE': self.root / 'store', 'read': lambda f: json.loads(f.read_text(encoding='utf-8')), 'sha': lambda f: hashlib.sha256(f.read_bytes()).hexdigest(), 'scoped': lambda f: Path(f), 'now': lambda: '2026-10-20T01:00:00+00:00',
                    'artifact': lambda c, j, k: {'payload': self.artifacts[(j['code'], k)]} if (j['code'], k) in self.artifacts else None,
                    'put': lambda c, j, k, p: self.artifacts.__setitem__((j['code'], k), p), 'event': lambda c, j, k, p: self.events.append(k)}
        g.write(self.root / 'config/google-delivery.json', self.config)
        self.code = 'UST_261020_01_TQH'; self.source = self.root / (self.code + '_01_thumbnail.jpg'); self.source.write_bytes(b'original isolated fixture image bytes')
        self.package = {'public_listing_code': self.code, 'review_fingerprint': 'a'*64, 'destination': str(Path('C:/Huy/Đã xử lý/Áo 2D/UST') / self.code), 'files': [{'name': self.source.name, 'path': str(self.source), 'sha256': self.env['sha'](self.source)}]}
        self.content = {'title': 'Capybara 😴 sweater', 'description': 'Line one\nLine two', 'tags': ['capybara', 'cozy']}

    def tearDown(self): self.tmp.cleanup()

    def test_set_and_pants_keep_distinct_delivery_categories_with_one_zip_each(self):
        for category in ['Bộ pijama', 'Quần ngủ', 'Áo pijama']:
            package = dict(self.package, destination=str(Path('C:/Huy/Đã xử lý') / category / 'UST' / self.code))
            _, parts = g.drive_destination(self.api, package, self.config, self.env)
            self.assertEqual(parts, [category, 'UST', self.code + '.zip'])

    def test_zip_matches_locked_files_and_rejects_changed_sources_and_paths(self):
        file = g.zip_package({'code': self.code, 'revision': 1}, self.package, self.env)
        before = file.read_bytes()
        with zipfile.ZipFile(file) as z:
            self.assertEqual(z.namelist(), [self.source.name]); self.assertEqual(z.read(self.source.name), self.source.read_bytes())
        self.assertEqual(g.zip_package({'code': self.code, 'revision': 1}, self.package, self.env).read_bytes(), before)
        bad = copy.deepcopy(self.package); bad['files'][0]['name'] = '../escape.jpg'
        with self.assertRaises(ValueError): g.zip_package({'code': self.code, 'revision': 1}, bad, self.env)
        self.source.write_bytes(b'changed')
        with self.assertRaises(ValueError): g.zip_package({'code': self.code, 'revision': 1}, self.package, self.env)

    def test_drive_matches_local_tree_reuses_folders_and_recovers_unknown_upload(self):
        folder, parts = g.drive_destination(self.api, self.package, self.config, self.env)
        self.assertEqual(parts, ['Áo 2D', 'UST', self.code + '.zip'])
        self.assertEqual(g.drive_destination(self.api, self.package, self.config, self.env)[0], folder)
        file = g.zip_package({'code': self.code, 'revision': 1}, self.package, self.env); receipt = file.with_suffix('.upload.json')
        self.api.unknown = 'drive'
        with self.assertRaises(ValueError): g.drive_upload(self.api, file, folder, receipt)
        proof = g.drive_upload(self.api, file, folder, receipt)
        self.assertTrue(proof['verified_after_readback']); self.assertEqual(len(self.api.files), 3)
        self.assertEqual(sum(m == 'PUT' for m, _, _ in self.api.calls), 1)
        with self.assertRaises(ValueError): g.drive_upload(self.api, file, 'wrong-parent', receipt)
        bad = dict(self.package, destination='C:/Huy/Đã xử lý/Áo 2D/OTHER/' + self.code)
        with self.assertRaises(ValueError): g.drive_destination(self.api, bad, self.config, self.env)

    def test_docs_correct_tab_unicode_revision_guard_and_unknown_commit_deduplicate(self):
        self.api.unknown = 'docs'
        args = (self.api, self.config, 'printed', self.code, self.content, 'https://example.test/zip', 1)
        with self.assertRaises(ValueError): g.document_upsert(*args)
        proof = g.document_upsert(*args)
        self.assertEqual(self.api.last_write, {'requiredRevisionId': 'r1'})
        printed = self.api.doc['tabs'][1]['documentTab']; text = g.tab_text(printed)
        self.assertIn(self.content['title'], text); self.assertEqual(self.api.last_range['endIndex'] - self.api.last_range['startIndex'], len(text[:-1].encode('utf-16-le')) // 2)
        self.assertEqual(g.tab_text(self.api.doc['tabs'][0]['documentTab']), '\n')
        self.assertEqual(sum(m == 'POST' and 'docs.googleapis' in u for m, u, _ in self.api.calls), 1)
        self.assertTrue(proof['verified_after_readback'])
        with self.assertRaisesRegex(ValueError, 'readback'): g.document_upsert(self.api, self.config, 'printed', self.code, dict(self.content, title='changed'), 'https://example.test/zip', 1)

    def test_sheet_groups_each_day_keeps_one_code_per_cell_and_unknown_commits_deduplicate(self):
        self.api.unknown = 'sheets'
        args=(self.api,self.config,'2026-10-22',self.code)
        with self.assertRaises(ValueError): g.sheet_upsert(*args)
        self.assertTrue(g.sheet_upsert(*args)['verified_after_readback'])
        self.assertEqual(self.api.header,['Ngày KPI','Số listing',*['Listing %02d'%n for n in range(1,22)]])
        self.assertEqual(self.api.rows,[['2026-10-22',1,self.code,*['']*20]])
        second='UST_261020_02_TQH';self.api.unknown='sheets'
        with self.assertRaises(ValueError):g.sheet_upsert(self.api,self.config,'2026-10-22',second)
        self.assertTrue(g.sheet_upsert(self.api,self.config,'2026-10-22',second)['verified_after_readback'])
        self.assertEqual(self.api.rows,[['2026-10-22',2,self.code,second,*['']*19]])
        g.sheet_upsert(self.api,self.config,'2026-10-23','UST_261020_03_TQH')
        self.assertEqual(len(self.api.rows),2)
        self.assertEqual(sum(m=='POST' for m,u,_ in self.api.calls if 'sheets.googleapis' in u),2)
        self.assertTrue(all('valueInputOption=RAW' in u for m, u, _ in self.api.calls if m in ('PUT', 'POST')))
        with self.assertRaisesRegex(ValueError,'conflict'):g.sheet_upsert(self.api,self.config,'2026-10-23',self.code)
        self.api.header[0] = 'user changed'
        with self.assertRaisesRegex(ValueError, 'headers'):g.sheet_upsert(*args)

    def test_sheet_preserves_existing_dates_and_refuses_duplicates_invalid_counts_or_overflow(self):
        self.api.header=list(g.HEADERS);self.api.rows=[['22/10/2026',1,self.code]]
        g.sheet_upsert(self.api,self.config,'2026-10-22','UST_261020_02_TQH')
        self.assertEqual(self.api.rows[0][0],'22/10/2026');self.assertEqual(self.api.rows[0][1],2)
        for rows in [[['2026-10-22',1,self.code],['2026-10-22',0]],
                     [['2026-10-22',2,self.code,self.code]], [['2026-10-22',3,self.code]],
                     [['2026-10-22',1,'=BAD()']]]:
            self.api.rows=rows;before=copy.deepcopy(rows)
            with self.assertRaises(ValueError):g.sheet_upsert(self.api,self.config,'2026-10-22','UST_261020_03_TQH')
            self.assertEqual(self.api.rows,before)
        self.api.rows=[['2026-10-22',21,*['UST_261020_%02d_TQH'%i for i in range(1,22)]]]
        before=copy.deepcopy(self.api.rows)
        with self.assertRaisesRegex(ValueError,'capacity'):g.sheet_upsert(self.api,self.config,'2026-10-22','UST_261020_22_TQH')
        self.assertEqual(self.api.rows,before)

    def database(self):
        c = sqlite3.connect(':memory:'); c.row_factory = sqlite3.Row
        c.executescript('CREATE TABLE jobs(code TEXT,revision INTEGER,state TEXT,created_at TEXT);CREATE TABLE production_batch_items(listing_code TEXT,batch_id TEXT);CREATE TABLE production_batches(batch_id TEXT,created_at TEXT,payload TEXT);CREATE TABLE kpi(code TEXT,revision INTEGER,fingerprint TEXT,target_date TEXT,completed_at TEXT);')
        for code, date in [('UST_261019_01_TQH', '2026-10-19T01:00:00+00:00'), (self.code, '2026-10-20T01:00:00+00:00'), ('UST_261020_02_PILOT', '2026-10-20T01:00:00+00:00')]:
            c.execute('INSERT INTO jobs VALUES(?,1,?,?)', (code, 'completed', date)); c.execute('INSERT INTO production_batch_items VALUES(?,?)', (code, code))
            c.execute('INSERT INTO production_batches VALUES(?,?,?)', (code, date, json.dumps({'kind': 'apparel_2d'}))); c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)', (code, 1, 'a'*64, '2026-10-20', date))
        self.artifacts[(self.code, 'package')] = self.package; self.artifacts[(self.code, 'text')] = self.content
        return c

    def test_sync_new_only_retries_without_duplicate_and_never_changes_canonical_kpi(self):
        c = self.database(); self.addCleanup(c.close); before = [tuple(r) for r in c.execute('SELECT * FROM kpi')]
        self.api.unknown = 'docs'
        result = g.sync(c, self.env, self.api); self.assertEqual(result['status'], 'pending')
        state = self.env['STORE'] / 'google-sync/status.json'; retry = g.sync(c, self.env, self.api)
        self.assertEqual(result, retry)
        status = json.loads(state.read_text()); status['retry_after'] = 0; g.write(state, status)
        result = g.sync(c, self.env, self.api); self.assertEqual(result['status'], 'synced'); self.assertEqual(result['pending'], 0)
        self.assertEqual(self.api.rows[0][:3], ['2026-10-20',1,self.code]); self.assertEqual(len(self.api.rows), 1)
        self.assertEqual([tuple(r) for r in c.execute('SELECT * FROM kpi')], before)
        self.assertTrue(self.artifacts[(self.code, 'google_delivery')]['verified_after_readback'])
        self.assertEqual(self.events, ['google_delivery_verified']); self.assertEqual(g.sync(c, self.env, self.api)['status'], 'idle')

    def test_stale_kpi_blocks_all_google_writes_before_export(self):
        c = self.database(); self.addCleanup(c.close)
        c.execute('UPDATE kpi SET revision=2 WHERE code=?', (self.code,))
        result = g.sync(c, self.env, self.api)
        self.assertEqual(result['code'], 'google_canonical_kpi_missing'); self.assertEqual(self.api.calls, [])


if __name__ == '__main__': unittest.main(verbosity=2)
