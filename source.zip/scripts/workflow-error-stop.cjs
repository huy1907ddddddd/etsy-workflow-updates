'use strict';
const fs=require('node:fs'),path=require('node:path');
const {atomic}=require('./flow-worker/native-n8n.cjs');

async function stopOnError(native,file,input){
  let hold=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null;
  if(!hold){
    if(!input.batch_id)return null;
    hold={...input,created_at:new Date().toISOString(),stop_pending:true};
    atomic(file,hold);
  }
  if(!hold.stop_pending)return hold;
  const snapshot=await native.execute({action:'batch_status',batch_id:hold.batch_id});
  const batch=snapshot.ok===true?snapshot.batches?.find(x=>x.batch_id===hold.batch_id):null;
  if(!batch||hold.batch_fingerprint&&batch.fingerprint!==hold.batch_fingerprint)throw Error('error_stop_binding_changed');
  hold.batch_fingerprint=batch.fingerprint;atomic(file,hold);
  if(['active','ready','preparing','prepared'].includes(batch.status)){
    const result=await native.execute({action:'batch_stop',batch_id:batch.batch_id,batch_fingerprint:batch.fingerprint,authority:'direct_user',reference:'Workflow3 user 21/10/2026: stop on workflow errors, preserve checkpoints, notify phone and wait for explicit user resume. Error: '+hold.code});
    if(result.status!=='batch_stopped')throw Error('error_stop_not_confirmed');
  }
  hold.stop_pending=false;hold.stopped_at=new Date().toISOString();atomic(file,hold);
  return hold;
}
module.exports={stopOnError};
