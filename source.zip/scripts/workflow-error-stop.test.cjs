'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {stopOnError}=require('./workflow-error-stop.cjs');
test('first error stops only its bound batch and persisted hold never resumes or resends stop',async t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'workflow-error-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const file=path.join(dir,'hold.json'),calls=[];
  const native={execute:async cmd=>{calls.push(cmd);if(cmd.action==='batch_status')return {ok:true,batches:[{batch_id:'A',fingerprint:'a'.repeat(64),status:'active'},{batch_id:'B',fingerprint:'b'.repeat(64),status:'active'}]};assert.equal(cmd.action,'batch_stop');assert.equal(cmd.batch_id,'A');return {status:'batch_stopped'};}};
  const result=await stopOnError(native,file,{batch_id:'A',code:'flow_quota_required'});
  assert.equal(result.stop_pending,false);assert.equal(calls.length,2);
  await stopOnError(native,file,{batch_id:'B',code:'other'});assert.equal(calls.length,2);
  assert.equal(JSON.parse(fs.readFileSync(file)).batch_id,'A');
});
test('failed stop persists a gate and changed fingerprint cannot stop a replacement batch',async t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'workflow-error-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const file=path.join(dir,'hold.json');let changed=false,stops=0;
  const native={execute:async cmd=>{if(cmd.action==='batch_status')return {ok:true,batches:[{batch_id:'A',fingerprint:(changed?'b':'a').repeat(64),status:'active'}]};stops++;throw Error('offline');}};
  await assert.rejects(stopOnError(native,file,{batch_id:'A',code:'failed'}),/offline/);
  assert.equal(JSON.parse(fs.readFileSync(file)).stop_pending,true);changed=true;
  await assert.rejects(stopOnError(native,file,{}),/binding_changed/);assert.equal(stops,1);
});
