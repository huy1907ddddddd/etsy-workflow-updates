'use strict';
const fs=require('node:fs'),path=require('node:path');
function choice(root){const file=path.join(root,'config/review-transport.json');return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')):{};}
function configFile(root,fallback){const provider=choice(root).provider;return ['telegram','web'].includes(provider)?path.join(root,'config',provider+'-review.private.json'):fallback;}
module.exports={choice,configFile};
