"""Google delivery from canonical completed packages, called only inside native n8n."""
import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
import urllib.error
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from kpi_sync_orchestration import COLUMNS as HEADERS



def write(file, data):
    file.parent.mkdir(parents=True, exist_ok=True)
    temporary = file.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(file)


class Google:
    def __init__(self, token_file):
        if not token_file.is_file():
            raise ValueError('google_login_required')
        self.token = json.loads(token_file.read_text(encoding='utf-8-sig'))
        body = urllib.parse.urlencode({k: self.token[k] for k in ('client_id', 'client_secret', 'refresh_token')} | {'grant_type': 'refresh_token'}).encode()
        try:
            with urllib.request.urlopen(urllib.request.Request('https://oauth2.googleapis.com/token', data=body), timeout=20) as r:
                self.access = json.load(r)['access_token']
        except (urllib.error.URLError, KeyError):
            raise ValueError('google_login_required') from None

    def request(self, method, url, body=None, data=None, headers=None):
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != 'https' or parsed.hostname not in ('www.googleapis.com', 'docs.googleapis.com', 'sheets.googleapis.com') or parsed.username or parsed.password:
            raise ValueError('google_endpoint_invalid')
        h = {'Authorization': 'Bearer ' + self.access, **(headers or {})}
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode(); h['Content-Type'] = 'application/json'
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
                return (json.loads(raw) if raw else {}), dict(r.headers)
        except urllib.error.HTTPError as error:
            raise ValueError('google_http_' + str(error.code)) from None
        except urllib.error.URLError:
            raise ValueError('google_connection_failed') from None


def zip_package(j, package, e):
    directory = e['STORE'] / 'google-sync' / 'packages' / j['code'] / ('v%03d' % j['revision'])
    directory.mkdir(parents=True, exist_ok=True)
    file = directory / (package['public_listing_code'] + '.zip')
    incoming = package['files']
    if len({a['name'] for a in incoming}) != len(incoming):
        raise ValueError('google_duplicate_package_name')
    for asset in incoming:
        if Path(asset['name']).name != asset['name'] or '/' in asset['name'] or '\\' in asset['name'] or e['sha'](e['scoped'](asset['path'])) != asset['sha256']:
            raise ValueError('google_package_source_changed')
    temporary = file.with_suffix('.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for asset in incoming:
            info = zipfile.ZipInfo(asset['name']); info.compress_type = zipfile.ZIP_DEFLATED
            data = e['scoped'](asset['path']).read_bytes()
            if hashlib.sha256(data).hexdigest() != asset['sha256']:
                raise ValueError('google_package_source_changed')
            archive.writestr(info, data)
    temporary.replace(file)
    return file


def drive_folder(api, parent, name, receipts):
    """Reuse an existing folder, or reserve its id before any retryable create."""
    escaped = name.replace('\\', '\\\\').replace("'", "\\'")
    query = "'" + parent + "' in parents and trashed=false and mimeType='application/vnd.google-apps.folder' and name='" + escaped + "'"
    url = 'https://www.googleapis.com/drive/v3/files'
    found, _ = api.request('GET', url + '?' + urllib.parse.urlencode({'q': query, 'fields': 'files(id,name,parents),nextPageToken', 'pageSize': 100, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'}))
    folders = found.get('files', [])
    if len(folders) > 1 or found.get('nextPageToken'):
        raise ValueError('google_duplicate_destination_folder')
    if folders:
        return folders[0]['id']
    receipt_file = receipts / (hashlib.sha256((parent + '\n' + name).encode()).hexdigest() + '.json')
    receipt = json.loads(receipt_file.read_text(encoding='utf-8')) if receipt_file.exists() else {}
    if not receipt.get('id'):
        data, _ = api.request('GET', url + '/generateIds?count=1&space=drive&type=files')
        receipt = {'id': data['ids'][0]}
        write(receipt_file, receipt)
    target = url + '/' + receipt['id'] + '?fields=id,name,parents,mimeType,trashed&supportsAllDrives=true'
    try:
        folder, _ = api.request('GET', target)
    except ValueError as error:
        if str(error) != 'google_http_404':
            raise
        api.request('POST', url + '?supportsAllDrives=true', {'id': receipt['id'], 'name': name, 'parents': [parent], 'mimeType': 'application/vnd.google-apps.folder'})
        folder, _ = api.request('GET', target)
    if folder.get('name') != name or parent not in folder.get('parents', []) or folder.get('mimeType') != 'application/vnd.google-apps.folder' or folder.get('trashed'):
        raise ValueError('google_folder_readback_failed')
    return folder['id']


def drive_destination(api, package, config, e):
    code = package['public_listing_code']
    destination = Path(package['destination'])
    category, topic = destination.parts[-3:-1]
    if (destination.name != code or topic != code.split('_')[0]
            or category not in ('Áo 2D', 'Áo thêu', 'Áo pijama', 'Bộ pijama', 'Quần ngủ')
            or destination.parent.parent.parent.name != 'Đã xử lý'):
        raise ValueError('google_output_layout_changed')
    receipts = e['STORE'] / 'google-sync/folders'
    product = drive_folder(api, config['folder_id'], category, receipts)
    folder = drive_folder(api, product, topic, receipts)
    return folder, [category, topic, code + '.zip']


def drive_upload(api, file, folder, receipt_file):
    checksum = hashlib.md5(file.read_bytes()).hexdigest()
    receipt = json.loads(receipt_file.read_text(encoding='utf-8')) if receipt_file.exists() else {}
    if not receipt.get('file_id'):
        data, _ = api.request('GET', 'https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files')
        receipt = {'file_id': data['ids'][0], 'folder': folder, 'md5': checksum}
        write(receipt_file, receipt)
    if receipt.get('folder') != folder or receipt.get('md5') != checksum:
        raise ValueError('google_upload_binding_changed')
    target = 'https://www.googleapis.com/drive/v3/files/' + receipt['file_id'] + '?fields=id,name,parents,md5Checksum,webViewLink,trashed&supportsAllDrives=true'
    try:
        found, _ = api.request('GET', target)
    except ValueError as error:
        if str(error) != 'google_http_404':
            raise
        metadata = {'id': receipt['file_id'], 'name': file.name, 'parents': [folder], 'mimeType': 'application/zip'}
        _, headers = api.request('POST', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true', metadata,
                                 headers={'X-Upload-Content-Type': 'application/zip', 'X-Upload-Content-Length': str(file.stat().st_size)})
        location = next((v for k, v in headers.items() if k.lower() == 'location'), None)
        if not location:
            raise ValueError('google_upload_session_missing')
        api.request('PUT', location, data=file.read_bytes(), headers={'Content-Type': 'application/zip'})
        found, _ = api.request('GET', target)
    if found.get('md5Checksum') != checksum or folder not in found.get('parents', []) or found.get('name') != file.name or found.get('trashed'):
        raise ValueError('google_upload_readback_failed')
    return {'id': found['id'], 'url': found['webViewLink'], 'md5': checksum, 'verified_after_readback': True}


def tabs(document):
    for tab in document.get('tabs', []):
        yield tab['documentTab'], tab['tabProperties']['tabId']
        yield from tabs({'tabs': tab.get('childTabs', [])})


def tab_text(tab):
    parts = []
    def walk(elements):
        for element in elements:
            for piece in element.get('paragraph', {}).get('elements', []):
                if 'textRun' in piece:
                    parts.append(piece['textRun']['content'])
            for row in element.get('table', {}).get('tableRows', []):
                for cell in row['tableCells']:
                    walk(cell.get('content', []))
    walk(tab.get('body', {}).get('content', []))
    return ''.join(parts)


def document_upsert(api, config, tab_id, code, content, zip_url, revision):
    url = 'https://docs.googleapis.com/v1/documents/' + config['document_id']
    block = f"Mã: {code}\nTitle\n{content['title']}\nMô tả\n{content['description']}\nTags\n{', '.join(content['tags'])}\nZIP: {zip_url}\n\n"
    marker = 'Workflow3_' + hashlib.sha256((code + ':' + str(revision)).encode()).hexdigest()[:30]
    def inspect():
        document, _ = api.request('GET', url + '?includeTabsContent=true')
        tab = next((t for t, tid in tabs(document) if tid == tab_id), None)
        if tab is None:
            raise ValueError('google_document_tab_missing')
        return document, tab, tab.get('namedRanges', {})
    document, tab, named = inspect()
    if marker not in named:
        if 'Mã: ' + code + '\n' in tab_text(tab):
            raise ValueError('google_document_existing_code_conflict')
        end = tab['body']['content'][-1]['endIndex'] - 1
        length = len(block.encode('utf-16-le')) // 2
        api.request('POST', url + ':batchUpdate', {'writeControl': {'requiredRevisionId': document['revisionId']}, 'requests': [
            {'insertText': {'location': {'index': end, 'tabId': tab_id}, 'text': block}},
            {'createNamedRange': {'name': marker, 'range': {'tabId': tab_id, 'startIndex': end, 'endIndex': end + length}}},
            {'updateParagraphStyle': {'range': {'tabId': tab_id, 'startIndex': end, 'endIndex': end + len(('Mã: ' + code).encode('utf-16-le')) // 2},
                                      'paragraphStyle': {'namedStyleType': 'HEADING_2'}, 'fields': 'namedStyleType'}}]})
        document, tab, named = inspect()
    if marker not in named or block not in tab_text(tab):
        raise ValueError('google_document_readback_failed')
    return {'url': 'https://docs.google.com/document/d/' + config['document_id'] + '/edit?tab=' + tab_id,
            'tab_id': tab_id, 'named_range': marker, 'verified_after_readback': True}


def sheet_upsert(api, config, target_date, code):
    root = 'https://sheets.googleapis.com/v4/spreadsheets/' + config['spreadsheet_id']
    name = "'" + config['sheet_name'].replace("'", "''") + "'"
    base = root + '/values/'
    header_range = urllib.parse.quote(name + '!A1:W1', safe='')
    header, _ = api.request('GET', base + header_range)
    if not header.get('values'):
        api.request('PUT', base + header_range + '?valueInputOption=RAW', {'values': [HEADERS]})
    elif header['values'][0] != HEADERS:
        raise ValueError('google_sheet_headers_changed')
    def all_rows():
        info, _ = api.request('GET', root + '?fields=sheets(properties(title,gridProperties(rowCount)))')
        sheet = next((s['properties'] for s in info['sheets'] if s['properties']['title'] == config['sheet_name']), None)
        if not sheet:
            raise ValueError('google_sheet_tab_missing')
        result = []
        for start in range(2, sheet['gridProperties']['rowCount'] + 1, 1000):
            data, _ = api.request('GET', base + urllib.parse.quote(name + f'!A{start}:W{min(start + 999, sheet["gridProperties"]["rowCount"])}', safe='') + '?valueRenderOption=FORMULA')
            result.extend((start + offset, row) for offset, row in enumerate(data.get('values', [])) if any(v != '' for v in row))
        return result
    def day(value):
        if isinstance(value, (int, float)) and 30000 < value < 100000:
            return (datetime(1899, 12, 30) + timedelta(days=value)).strftime('%Y-%m-%d')
        for pattern in ('%Y-%m-%d', '%d/%m/%Y'):
            try:
                return datetime.strptime(str(value), pattern).strftime('%Y-%m-%d')
            except ValueError:
                pass
        raise ValueError('google_sheet_date_invalid')
    if day(target_date) != target_date or not re.fullmatch(r'[A-Z]{2,5}_\d{6}_\d{2}(?:_TQH)?', code):
        raise ValueError('google_sheet_kpi_invalid')
    def entries():
        found = {}; seen = set()
        for index, row in all_rows():
            date = day(row[0]); codes = [v for v in row[2:] if v != '']
            if date in found or len(codes) > 21 or any(not isinstance(v, str) or not re.fullmatch(r'[A-Z]{2,5}_\d{6}_\d{2}(?:_TQH)?', v) or v in seen for v in codes) or len(set(codes)) != len(codes):
                raise ValueError('google_sheet_existing_code_conflict')
            if len(row) < 2 or str(row[1]) != str(len(codes)):
                raise ValueError('google_sheet_count_conflict')
            seen.update(codes); found[date] = (index, codes)
        if any(code in codes for date, (_, codes) in found.items() if date != target_date):
            raise ValueError('google_sheet_existing_code_conflict')
        return found
    rows = entries()
    if target_date in rows:
        index, codes = rows[target_date]
        codes = codes if code in codes else codes + [code]
        if len(codes) > 21:
            raise ValueError('google_sheet_daily_capacity_exceeded')
        if code not in rows[target_date][1]:
            values = [len(codes), *codes, *[''] * (21 - len(codes))]
            api.request('PUT', base + urllib.parse.quote(name + f'!B{index}:W{index}', safe='') + '?valueInputOption=RAW', {'values': [values]})
    else:
        codes = [code]
        api.request('POST', base + urllib.parse.quote(name + '!A:W', safe='') + ':append?valueInputOption=RAW&insertDataOption=INSERT_ROWS', {'values': [[target_date, 1, code, *[''] * 20]]})
    observed = entries().get(target_date)
    if not observed or observed[1] != codes:
        raise ValueError('google_sheet_readback_failed')
    return {'url': 'https://docs.google.com/spreadsheets/d/' + config['spreadsheet_id'] + '/edit', 'layout': 'one_listing_per_cell_v1',
            'target_date': target_date, 'row_index': observed[0], 'verified_after_readback': True}


def sync(c, e, client=None):
    file = e['ROOT'] / 'config/google-delivery.json'
    if not file.is_file():
        return {'status': 'not_configured'}
    config = e['read'](file)
    if not config.get('enabled'):
        return {'status': 'setup_required'}
    state_file = e['STORE'] / 'google-sync/status.json'
    previous = e['read'](state_file) if state_file.is_file() else {}
    if previous.get('retry_after', 0) > time.time():
        return previous
    pending = []
    for row in c.execute("SELECT j.*,b.created_at AS batch_created_at,b.payload AS batch_payload FROM jobs j JOIN production_batch_items i ON i.listing_code=j.code JOIN production_batches b ON b.batch_id=i.batch_id WHERE j.state='completed' ORDER BY j.created_at"):
        j = dict(row)
        if j['code'].endswith('_PILOT') or datetime.fromisoformat(j['batch_created_at']) < datetime.fromisoformat(config['start_after']):
            continue
        artifact = e['artifact'](c, j, 'google_delivery')
        if artifact and artifact['payload'].get('verified_after_readback') is True:
            continue
        pending.append(j)
    state = {'status': 'idle', 'pending': len(pending), 'updated_at': e['now']()}
    if not pending:
        write(state_file, state)
        return state
    j = pending[0]
    try:
        package = e['artifact'](c, j, 'package')['payload']
        content = e['artifact'](c, j, 'text')['payload']
        kpi = c.execute('SELECT * FROM kpi WHERE code=? AND revision=?', (j['code'], j['revision'])).fetchone()
        if not kpi or kpi['fingerprint'] != package['review_fingerprint']:
            raise ValueError('google_canonical_kpi_missing')
        api = client or Google(e['ROOT'] / 'config/google-oauth.private.json')
        kind = json.loads(j['batch_payload'])['kind']
        tab_id = config['document_tabs'][kind]
        file = zip_package(j, package, e)
        folder, relative_path = drive_destination(api, package, config, e)
        drive = drive_upload(api, file, folder, file.with_suffix('.upload.json'))
        drive['relative_path'] = relative_path
        doc = document_upsert(api, config, tab_id, package['public_listing_code'], content, drive['url'], j['revision'])
        sheet = sheet_upsert(api, config, kpi['target_date'], package['public_listing_code'])
        proof = {'verified_after_readback': True, 'drive': drive, 'docs': doc, 'sheets': sheet, 'zip': {'path': str(file), 'sha256': e['sha'](file)}, 'synced_at': e['now']()}
        e['put'](c, j, 'google_delivery', proof)
        e['event'](c, j, 'google_delivery_verified', proof)
        state.update(status='synced', listing_code=j['code'], pending=len(pending) - 1)
    except (ValueError, KeyError, OSError) as error:
        code = str(error)
        if not re.fullmatch(r'[a-z_0-9]{1,90}', code):
            code = 'google_sync_failed_check_config'
        state.update(status='pending', listing_code=j['code'], code=code, retry_after=time.time() + 60)
    write(state_file, state)
    return state
