const path=require('node:path');
const {spawn}=require('node:child_process');
const python='C:/Users/ADMIN/AppData/Local/Programs/Python/Python313/python.exe';
function runProduction({input,res,reply,release}){
  const child=spawn(python,['-X','utf8',path.join(__dirname,'production-engine.py')],
    {cwd:path.resolve(__dirname,'..'),windowsHide:true,stdio:['pipe','pipe','ignore']});
  let output='',done=false;
  const timer=setTimeout(()=>{child.kill();finish(504,{ok:false,error:'Production task timed out; inspect preserved artifacts before retry'});},180000);
  function finish(status,value){if(done)return;done=true;clearTimeout(timer);release();reply(res,status,value);}
  child.stdout.setEncoding('utf8');
  child.stdout.on('data',v=>{output+=v;if(Buffer.byteLength(output)>4000000){child.kill();finish(502,{ok:false,error:'Production output exceeded limit'});}});
  child.on('error',()=>finish(503,{ok:false,error:'Production worker unavailable'}));
  child.on('close',exit=>{if(done)return;try{const value=JSON.parse(output);finish(exit===0&&value.ok===true?200:422,value);}catch{finish(502,{ok:false,error:'Invalid production worker output'});}});
  child.stdin.on('error',()=>{});
  child.stdin.end(JSON.stringify(input));
}
module.exports={runProduction};
