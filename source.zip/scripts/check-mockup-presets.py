"""Isolated prompt-set regression checks; no AI, live batch or Google writes."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path
from PIL import Image

spec=importlib.util.spec_from_file_location('wf3',Path(__file__).with_name('check-workflow3.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,profiles,batch,flow=fixture.engine,fixture.profiles,fixture.batch,fixture.flow
import mockup_prompt_sets


class MockupPresetTests(fixture.Workflow3Tests):
    def preset(self,kind='apparel_2d'):
        names=profiles.GARMENT_SIX if kind=='embroidery_prompts' else profiles.PRINT
        return {'schema_version':1,'kind':kind,'name':'Noel fixture','source':'\n'.join(
            '===== '+name+' =====\nComplete custom photo prompt; Christmas tree and red ornaments BEHIND the garment. KEEP original camera and window daylight.' for name in names)}

    def test_printed_set_reaches_manifest_sample_rest_and_keeps_plain_flatlay(self):
        cmd=self.printed();cmd['mockup_prompt_set']=self.preset();start=self.start(cmd)
        b=batch.batch(self.c,start['batch_id']);manifest=batch.manifest(b)
        self.assertEqual(manifest['mockup_prompt_set']['clean_flatlay'],'04_flatlay.jpg')
        first=self.cycle()['tasks'][0];hero=first['payload']['images'][0]['prompt']
        self.assertIn('Christmas tree and red ornaments',hero);self.assertIn('Standing male front hero',hero)
        self.assertIn('indirect window daylight, neutral white balance',hero);self.assertIn('An otter bakery corner.',hero)
        self.execute(self.candidate(first));review=self.cycle()['reviews'][0]
        flow.apply_decision(self.c,self.decision(review),self.env)
        rest=self.cycle()['tasks'][0];images=rest['payload']['images']
        flat=next(i for i in images if i['name']=='04_flatlay.jpg')
        self.assertIn('CLEAN FLATLAY OVERRIDE',flat['prompt']);self.assertNotIn('Christmas tree and red ornaments',flat['prompt'])
        self.assertTrue(all(rest['payload']['references']['approved_sample']['sha256'] in [r['sha256'] for r in image.get('references',list(rest['payload']['references'].values()))] for image in images))
        second=batch.plan_images(self.c,b,batch.item(self.c,b['batch_id'],'0002'),True,self.env)
        self.assertIn('An otter garden.',second['images'][0]['prompt']);self.assertNotIn('An otter bakery corner.',second['images'][0]['prompt'])
        self.execute(self.candidate(rest))
        self.c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
        finished=self.cycle();code=finished['production_jobs'][0]['listing_code']
        saved_plan=json.loads(engine.job(self.c,code)['plan'])
        self.assertEqual(saved_plan['mockup_prompt_set'],manifest['mockup_prompt_set'])
        cmd['mockup_prompt_set']['source']='changed later';self.assertIn('Christmas tree',batch.manifest(batch.batch(self.c,b['batch_id']))['mockup_prompt_set']['source'])

    def test_embroidery_keeps_garment_colors_regions_layout_and_clean_flatlay(self):
        import embroidery_layout
        file=engine.STORE/'source.png';Image.new('RGB',(64,64),'green').save(file)
        ref={'path':str(file),'sha256':engine.sha(file)}
        plan={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,
              'regions':{'left_chest':ref,'left_sleeve':ref,'right_sleeve':ref},'layout_profile':embroidery_layout.load(self.env),'approved_sample':ref}
        def images(p):return profiles.image_plan({'code':'FIXTURE','revision':1,'plan':json.dumps(p)},self.env)['images']
        old=images(plan);new=images({**plan,'mockup_prompt_set':self.preset('embroidery_prompts')})
        self.assertEqual([(x['name'],x['wardrobe'],x['visible_regions'],x['references']) for x in old],[(x['name'],x['wardrobe'],x['visible_regions'],x['references']) for x in new])
        self.assertTrue(all('GARMENT ONLY:' in x['prompt'] and 'neutral white balance' in x['prompt'] for x in new))
        self.assertIn('Christmas tree',new[0]['prompt']);self.assertNotIn('Christmas tree',new[-1]['prompt'])
        self.assertIn('CLEAN FLATLAY OVERRIDE',new[-1]['prompt']);self.assertIn('GARMENT-RELATIVE POSITION LOCK',new[-1]['prompt'])

    def test_pajama_set_and_pants_keep_their_own_product_and_idea(self):
        import pajama_set
        for kind in ('pajama_set','sleep_pants'):
            plan={'profile_version':3,'product_kind':kind,'regions':{},'idea_prompt':'Distinct '+kind+' design','mockup_prompt_set':self.preset(kind)}
            if kind=='pajama_set':plan.update(garment='pajama_set',product_bundle=pajama_set.CONTRACT)
            result=profiles.image_plan({'code':'FIXTURE','revision':1,'plan':json.dumps(plan)},self.env)
            self.assertIn('Distinct '+kind+' design',result['images'][0]['prompt'])
            if kind=='pajama_set':self.assertIn('both the confirmed top and matching full-length pants',result['images'][0]['prompt'])
            else:self.assertNotIn('ONE PAJAMA SET',result['images'][0]['prompt'])

    def test_incomplete_mismatched_or_reordered_set_is_rejected_before_batch_write(self):
        preset=self.preset()
        bad=[{**preset,'kind':'sleep_pants'},{**preset,'source':'only append a tree'},
             {**preset,'source':preset['source'].replace('01_thumbnail.jpg','02_female_angle.jpg')}]
        for value in bad:
            cmd=self.printed();cmd['mockup_prompt_set']=value
            with self.assertRaises(ValueError):self.execute(cmd)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batches').fetchone()[0],0)

    def test_new_option_never_modifies_default_or_legacy_prompt_payload(self):
        old_path=engine.ROOT/'workspace/maintenance/versions/20261030-mockup-presets1/before/scripts/production_profiles.py'
        spec=importlib.util.spec_from_file_location('old_profiles',old_path);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        for kind in profiles.PRINT_KINDS:
            plan={'profile_version':3,'product_kind':kind,'regions':{},'idea_prompt':'Original design'}
            if kind=='pajama_set':plan.update(garment='pajama_set',product_bundle=__import__('pajama_set').CONTRACT)
            j={'code':'FIXTURE','revision':1,'plan':json.dumps(plan)}
            self.assertEqual(profiles.image_plan(j,self.env),old.image_plan(j,self.env))


if __name__=='__main__':
    suite=unittest.TestSuite(MockupPresetTests(n) for n in MockupPresetTests.__dict__ if n.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
