"""Exercise new SKU allocation and source isolation without live jobs, AI or KPI."""
import copy
import importlib.util
import json
import sqlite3
import tempfile
from pathlib import Path

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('production-engine.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'passed':True})
def fails(fn):
    try:fn()
    except ValueError:return True
    return False

original_jobs=m.JOBS; original_now=m.now
with tempfile.TemporaryDirectory(prefix='intake-test-',dir=m.STORE) as temp:
    temp=Path(temp);m.JOBS=temp/'jobs';m.JOBS.mkdir()
    m.now=lambda:'2026-10-13T04:00:00+00:00'
    c=m.connect(temp/'test.sqlite')
    brief={'brief_id':'test-01','topic_code':'HLW','product_type':'physical_apparel','product_id':'isolated-fixture',
        'garment':'crewneck','color':'cream','available_styles':['crewneck sweatshirt'],
        'motifs':{'center_chest':'test blue flower','left_sleeve':'test green leaf','right_sleeve':'test green leaf'},
        'back_artwork':False,'personalization':{'enabled':False},'sources':[]}
    response=m.execute(c,{'action':'receive_brief','brief':brief})
    command={'action':'reserve_listing','brief_id':brief['brief_id'],'brief_fingerprint':response['brief_fingerprint'],
        'authority':'direct_user','reference':'isolated test approval only'}
    check('Incoming research brief never approves itself',response['status']=='received_not_approved' and c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0]==0)
    check('New SKU cannot be assigned before workflow acceptance',fails(lambda:m.execute(c,command)))
    c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':'2026-10-13T00:00:00+00:00'})))
    check('Attached approval is not trusted as authority',fails(lambda:m.execute(c,{**command,'authority':'research_document'})))
    allocations=[]
    for i in range(1,31):
        b={**brief,'brief_id':'test-%02d'%i}
        received=m.execute(c,{'action':'receive_brief','brief':b})
        allocations.append(m.execute(c,{**command,'brief_id':b['brief_id'],'brief_fingerprint':received['brief_fingerprint']}))
    check('New codes use the fixed first KPI date as a provisional date',all(x['target_date']=='2026-10-15' and x['listing_code'].startswith('HLW_261015_') for x in allocations))
    check('Unfinished reservations do not consume the 21 completed-listing slots',all(x.get('kpi_date_provisional') is True for x in allocations))
    check('Repeated reservation is idempotent',m.execute(c,command)['listing_code']==allocations[0]['listing_code'] and c.execute('SELECT COUNT(*) FROM reservations').fetchone()[0]==30)
    check('Reservations do not count unfinished listings',c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0]==0)
    check('Received brief cannot be silently replaced',fails(lambda:m.execute(c,{'action':'receive_brief','brief':{**brief,'color':'black'}})))
    live=sqlite3.connect('file:'+str(m.DB).replace('\\','/')+'?mode=ro',uri=True)
    plan=json.loads(live.execute("SELECT plan FROM jobs WHERE code='HLW_261010_01'").fetchone()[0]);live.close()
    plan={**plan,'product_id':brief['product_id']}
    fit=m.execute(c,{'action':'resolve_plan','brief_id':brief['brief_id'],'artwork':{k:{'path':v['path'],'sha256':v['sha256'],'bounds_px':[0,0,20,40]} for k,v in plan['regions'].items()}})
    check('Sizes fit once at largest uniform scale with preserved aspect ratio',fit['plan']['regions']['center_chest']['width_cm']==13 and fit['plan']['regions']['center_chest']['height_cm']==26 and fit['plan']['regions']['left_sleeve']['width_cm']==7 and fit['plan']['regions']['left_sleeve']['height_cm']==14)
    check('Automatic size resolution never grants approval',fit['status']=='resolved_sizes_awaiting_review' and all(x['size_approval_reference'] is None for x in fit['plan']['regions'].values()))
    queued=m.execute(c,{'action':'prepare_listing','brief_id':brief['brief_id'],'plan':plan})
    source=m.read(m.JOBS/(queued['listing_code']+'.json'))
    check('New packet uses received motifs and no pilot keyword evidence',source['packet']['confirmed_product_brief']['motifs']==brief['motifs'] and source['packet']['keyword_evidence']==[] and 'source_listing' not in source['packet']['confirmed_product_brief'])
    check('Intake queues without auto-approving locked art',queued['status']=='queued' and c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0]==0)
    check('Preparing same listing twice is idempotent',m.execute(c,{'action':'prepare_listing','brief_id':brief['brief_id'],'plan':plan})['status']=='already_queued')
    bad=copy.deepcopy(plan);bad['back_artwork']=True
    check('Unexpected back region cannot enter production',fails(lambda:m.execute(c,{'action':'prepare_listing','brief_id':brief['brief_id'],'plan':bad})))
    m.now=lambda:'2026-10-14T04:00:00+00:00'
    expired=m.execute(c,{'action':'advance','listing_code':queued['listing_code']})
    check('Delayed completion preserves the code and still requires artwork approval',expired['status']=='awaiting_brief_approval')
    c.execute('SAVEPOINT delayed_allocation')
    late=m.allocate_kpi(c,m.job(c,queued['listing_code']),'fixture',m.now())
    check('Delayed completion uses the current KPI row instead of expiring the code',late['target_date']=='2026-10-15')
    c.execute('ROLLBACK TO delayed_allocation');c.execute('RELEASE delayed_allocation')
    check('Re-date cannot use approval from an attachment',fails(lambda:m.execute(c,{'action':'redate_listing','listing_code':queued['listing_code'],'authority':'attachment','reference':'test'})))
    redated=m.execute(c,{'action':'redate_listing','listing_code':queued['listing_code'],'authority':'direct_user','reference':'isolated schedule approval'})
    check('Explicit replacement preserves old job history without advancing the KPI calendar',redated['target_date']=='2026-10-15' and redated['listing_code'].startswith('HLW_261015_') and m.job(c,queued['listing_code'])['state']=='superseded')
    check('Re-date never carries text evidence or final approval to a new source',m.artifact(c,m.job(c,redated['listing_code']),'text') is None and not c.execute("SELECT 1 FROM approvals WHERE code=? AND stage='final'",(redated['listing_code'],)).fetchone())
    m.execute(c,{'action':'cancel_listing','listing_code':redated['listing_code'],'authority':'direct_user','reference':'isolated cancellation'})
    check('Cancelling a draft releases its capacity without deleting history',m.job(c,redated['listing_code'])['state']=='cancelled' and c.execute('SELECT status FROM reservations WHERE code=?',(redated['listing_code'],)).fetchone()[0]=='released')
    c.close()
m.JOBS=original_jobs;m.now=original_now
report={'ok':True,'checks':checks,'isolated_database':True,'real_listing_created':False,'real_kpi_written':False,'ai_called':False}
m.write(m.STORE/'brief-intake-test-report.json',report)
print(json.dumps({'ok':True,'checks':len(checks),'report':str(m.STORE/'brief-intake-test-report.json')}))
