"""Explicit batch selection, finite night plans and representative preparation via n8n."""
import json
from pathlib import Path
import uuid
import production_profiles as profiles


def get(c, key, default=None):
    row = c.execute('SELECT value FROM config WHERE key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else default


def put(c, key, value):
    c.execute('INSERT OR REPLACE INTO config VALUES(?,?)', (key, json.dumps(value, ensure_ascii=False)))


def prep(c, bid):
    return get(c, 'batch_preparation:' + bid, False)


def release_error_holds(root, bid, c=None, completed=False):
    for worker in ('flow-worker','batch-worker'):
        file=Path(root)/'workspace'/worker/'runtime/workflow-error-hold.json'
        if not file.exists():
            continue
        hold=json.loads(file.read_text(encoding='utf-8-sig'))
        if completed:
            # A failed idle poll can leave a hold after the last listing completed.
            old=c.execute('SELECT status,fingerprint FROM production_batches WHERE batch_id=?',(bid,)).fetchone() if c is not None else None
            unfinished=c.execute("SELECT 1 FROM production_batch_items WHERE batch_id=? AND state!='completed' LIMIT 1",(bid,)).fetchone() if c is not None else True
            if (old and old['status']=='completed' and not unfinished and hold.get('batch_id')==bid
                    and hold.get('batch_fingerprint')==old['fingerprint'] and hold.get('stop_pending') is False
                    and hold.get('code')=='n8n_native_failed_check_private_log' and hold.get('task_id') is None):
                file.rename(file.with_name('workflow-error-released-'+uuid.uuid4().hex+'.json'))
            continue
        retired=False
        cancelled_upload=hold.get('code')=='flow_upload_ui_failed'
        if c is not None and (hold.get('code')=='task_no_longer_pending' or cancelled_upload) and hold.get('stop_pending') is False:
            old=c.execute('SELECT status,fingerprint FROM production_batches WHERE batch_id=?',(hold.get('batch_id'),)).fetchone()
            if old and old['status']=='closed_partial' and old['fingerprint']==hold.get('batch_fingerprint'):
                unfinished=c.execute("SELECT 1 FROM production_batch_items WHERE batch_id=? AND state NOT IN ('completed','cancelled') LIMIT 1",(hold['batch_id'],)).fetchone()
                # A cancelled upload task must not hold the next explicitly selected batch.
                task=c.execute("SELECT 1 FROM production_batch_tasks WHERE id=? AND batch_id=? AND status=?",(hold.get('task_id'),hold['batch_id'],'cancelled' if cancelled_upload else 'superseded')).fetchone()
                design=None if cancelled_upload else c.execute("SELECT 1 FROM design_tasks t JOIN production_batch_items i ON i.brief_id=t.brief_id WHERE t.id=? AND i.batch_id=? AND t.status='superseded'",(hold.get('task_id'),hold['batch_id'])).fetchone()
                retired=not unfinished and bool(task or design)
        if hold.get('batch_id')==bid or retired:
            file.rename(file.with_name('workflow-error-released-'+uuid.uuid4().hex+'.json'))


def binding(c, b):
    p = c.execute('SELECT sample_fingerprint FROM production_batch_policies WHERE batch_id=? AND batch_fingerprint=?', (b['batch_id'], b['fingerprint'])).fetchone()
    return {'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'], 'sample_fingerprint': p[0] if p else None,
            'corrections': get(c, 'batch_corrections:' + b['batch_id'], [])}


def representative_ready(c, b, e):
    import production_batch as batch
    p = batch.policy(c, b)
    first = c.execute('SELECT * FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1', (b['batch_id'],)).fetchone()
    asset = json.loads(first['images']).get(profiles.names(batch.manifest(b))[0]) if first else None
    if not p or not asset:
        return False
    fp = e['digest']({'batch_fingerprint': b['fingerprint'], 'revision': first['revision'], 'sample': asset})
    if p['sample_fingerprint'] != fp:
        return False
    from flow_lark_orchestration import check_hashes
    check_hashes(asset, e)
    return True


def stop_plan(c, bid):
    import flow_worker_pool
    if flow_worker_pool.stop(c,bid):
        return
    run = get(c, 'batch_run_plan')
    if run and run['status'] in ('preparing', 'running') and any(x['batch_id'] == bid for x in run['entries']):
        run['resume_status'] = run['status']
        run['status'] = 'stopped'; put(c, 'batch_run_plan', run)
        for entry in run['entries']:
            put(c, 'batch_preparation:' + entry['batch_id'], False)
            c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=? AND status='active'", (entry['batch_id'],))


def finished(c, b):
    if b['status'] == 'completed':
        return True
    # Discarded work stays terminal; malformed closures must still stop the group.
    return (b['status'] == 'closed_partial'
            and bool(c.execute('SELECT 1 FROM production_batch_items WHERE batch_id=? LIMIT 1', (b['batch_id'],)).fetchone())
            and not c.execute("SELECT 1 FROM production_batch_items WHERE batch_id=? AND state NOT IN ('completed','cancelled') LIMIT 1", (b['batch_id'],)).fetchone()
            and not c.execute("SELECT 1 FROM production_batch_tasks WHERE batch_id=? AND status='pending' LIMIT 1", (b['batch_id'],)).fetchone())


def group_reviews(c, e):
    import production_batch as batch
    import flow_lark_orchestration as flow
    run = get(c, 'batch_run_plan')
    if not run or run['status'] != 'preparing':
        return []
    reviews = []
    for entry in run['entries']:
        b = batch.batch(c, entry['batch_id'])
        if finished(c, b):
            continue
        first = dict(c.execute('SELECT * FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1', (b['batch_id'],)).fetchone())
        packet = flow.review_packet(c, {'brief_id': first['brief_id']}, e) if first['state'] == 'designing' else batch.sample_review(c, b, first, e)
        if packet:
            packet['summary'] += '\nNhóm nhiều mẻ: duyệt riêng mẻ này. Các mẻ đã duyệt đứng chờ; chỉ chạy lần lượt khi mọi mẻ trong nhóm đều được duyệt.'
            reviews.append(packet)
    return reviews


def resume_selected_group(c, bid, e, reference):
    import production_batch as batch
    run = get(c, 'batch_run_plan')
    if not run or run.get('mode') != 'selected_group' or run['status'] != 'stopped' or not any(x['batch_id'] == bid for x in run['entries']):
        return None
    batches = [batch.batch(c, entry['batch_id']) for entry in run['entries']]
    for b, entry in zip(batches, run['entries']):
        current = binding(c, b)
        # During preparation, independent human approvals may arrive before every sample is ready.
        if entry['sample_fingerprint'] is None and run.get('resume_status', 'preparing') == 'preparing':
            current = dict(current, sample_fingerprint=None)
        if current != entry or (b['status'] not in ('stopped', 'prepared', 'preparing', 'confirmed') and not finished(c, b)):
            raise ValueError('Selected group source or approval changed; review the group before resuming')
    if c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone():
        raise ValueError('Stop the active batch before resuming the selected group')
    ready = [finished(c, b) or representative_ready(c, b, e) for b in batches]
    run.update(status='running' if all(ready) else 'preparing', reference=reference)
    for b, approved in zip(batches, ready):
        if finished(c, b):
            continue
        put(c, 'batch_preparation:' + b['batch_id'], False if approved else {'batch_fingerprint': b['fingerprint'], 'reference': reference})
        c.execute('UPDATE production_batches SET status=?,reference=? WHERE batch_id=?', ('prepared' if approved else 'preparing', reference, b['batch_id']))
    put(c, 'batch_run_plan', run)
    chosen = choose(c, e)
    return {'resumed_group': True, 'batch_ids': [x['batch_id'] for x in run['entries']], 'group_status': run['status'], 'worker_batch_id': chosen['batch_id'] if chosen else bid}


def activate(c, b, e, reference):
    import production_batch as batch
    other = c.execute("SELECT batch_id FROM production_batches WHERE status='active' AND batch_id<>?", (b['batch_id'],)).fetchone()
    if other:
        raise ValueError('Stop the active batch before choosing another')
    c.execute("UPDATE production_batches SET status='active',reference=? WHERE batch_id=?", (reference, b['batch_id']))
    # A saved human preparation/run-plan grant authorizes only this selected batch scope.
    from chatgpt_image_orchestration import selection
    choice = selection(e)
    if choice.get('provider') == 'flow' and choice.get('batch_id') != b['batch_id']:
        updated = dict(choice, batch_id=b['batch_id'], batch_scope_reference=reference, batch_scope_updated_at=e['now']())
        import flow_worker_pool
        e['write'](flow_worker_pool.selection_file(e), updated)
    return batch.batch(c, b['batch_id'])


def choose(c, e):
    import flow_worker_pool
    if flow_worker_pool.enabled(c):
        return flow_worker_pool.choose(c,e)
    import production_batch as batch
    active = c.execute("SELECT batch_id FROM production_batches WHERE status='active' LIMIT 1").fetchone()
    if active:
        return batch.batch(c, active[0])
    run = get(c, 'batch_run_plan')
    if run and run['status'] == 'preparing':
        batches = [batch.batch(c, x['batch_id']) for x in run['entries']]
        if any(b['fingerprint'] != x['batch_fingerprint'] or (b['status'] in ('stopped','cancelled','closed_partial') and not finished(c, b)) for b, x in zip(batches, run['entries'])):
            stop_plan(c, run['entries'][0]['batch_id'])
            return None
        ready = [finished(c, b) or representative_ready(c, b, e) for b in batches]
        for b, approved in zip(batches, ready):
            if approved and not finished(c, b):
                c.execute("UPDATE production_batches SET status='prepared' WHERE batch_id=?", (b['batch_id'],))
                put(c, 'batch_preparation:' + b['batch_id'], False)
        if all(ready):
            run.update(status='running', entries=[binding(c, b) for b in batches], index=0)
            put(c, 'batch_run_plan', run)
        else:
            for b, approved in zip(batches, ready):
                if approved:
                    continue
                first = c.execute('SELECT brief_id,state FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1', (b['batch_id'],)).fetchone()
                design = c.execute('SELECT state FROM design_jobs WHERE brief_id=?', (first['brief_id'],)).fetchone()
                if first['state'] in ('awaiting_sample_approval','failed') or (design and (design[0].endswith('_approval') or design[0] == 'needs_design_revision')):
                    continue
                return activate(c, b, e, run['reference'])
            return None
    if run and run['status'] == 'running':
        while run['index'] < len(run['entries']):
            entry = run['entries'][run['index']]
            b = batch.batch(c, entry['batch_id'])
            if binding(c, b) != entry or (b['status'] not in ('prepared', 'confirmed') and not finished(c, b)):
                run['status'] = 'blocked'; put(c, 'batch_run_plan', run)
                return None
            if finished(c, b):
                run['index'] += 1; put(c, 'batch_run_plan', run)
                continue
            return activate(c, b, e, run['reference'])
        run['status'] = 'completed'; put(c, 'batch_run_plan', run)
    if run and run.get('mode') == 'selected_group':
        return None
    for row in c.execute("SELECT batch_id FROM production_batches WHERE status IN ('preparing','confirmed') ORDER BY queue_order").fetchall():
        grant = prep(c, row[0])
        if grant:
            b = batch.batch(c, row[0])
            if grant['batch_fingerprint'] != b['fingerprint']:
                raise ValueError('Preparation source changed')
            first=c.execute('SELECT brief_id,state FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1',(b['batch_id'],)).fetchone()
            design=c.execute('SELECT state FROM design_jobs WHERE brief_id=?',(first['brief_id'],)).fetchone()
            if first['state']=='awaiting_sample_approval' or (design and design[0].endswith('_approval')):
                continue
            return activate(c, b, e, grant['reference'])
    return None


def preparation_checkpoint(c, b, i, e):
    grant = prep(c, b['batch_id'])
    if not grant:
        return
    import production_batch as batch
    if batch.policy(c, b):
        c.execute("UPDATE production_batches SET status='prepared' WHERE batch_id=?", (b['batch_id'],))
        put(c, 'batch_preparation:' + b['batch_id'], False)
    else:
        pending = c.execute("SELECT 1 FROM production_batch_tasks WHERE batch_id=? AND status='pending'", (b['batch_id'],)).fetchone()
        design = c.execute('SELECT state FROM design_jobs WHERE brief_id=?', (i['brief_id'],)).fetchone()
        waiting = i['state'] == 'awaiting_sample_approval' or (design and design[0].endswith('_approval'))
        if waiting and not pending:
            c.execute("UPDATE production_batches SET status='preparing' WHERE batch_id=?", (b['batch_id'],))


def execute(c, cmd, e):
    import production_batch as batch
    action = cmd['action']
    if action == 'batch_run_selected':
        ids = cmd.get('batch_ids')
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
            raise ValueError('Choose distinct batches in the run order')
        import flow_worker_pool
        if flow_worker_pool.enabled(c):
            batches=[batch.batch(c,bid) for bid in ids]
            if any(b['status'] not in ('confirmed','active','stopped','preparing','prepared') for b in batches):
                raise ValueError('Confirm each selected batch before entering the pool')
            for b in batches:
                flow_worker_pool.resume(c,b,e,cmd['reference'])
            return {'ok':True,'status':'batch_selected_group_started','batch_ids':ids,'group_status':'parallel','maximum_workers':3}
        run = get(c, 'batch_run_plan')
        if run and run['status'] in ('preparing','running'):
            if run.get('mode') == 'selected_group' and ids == [x['batch_id'] for x in run['entries']]:
                return {'ok': True, 'status': 'batch_selected_group_started', 'batch_ids': ids, 'group_status': run['status']}
            raise ValueError('Stop the current selected group before changing its batches or order')
        if c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone():
            raise ValueError('Stop the active batch before choosing a group')
        batches = [batch.batch(c, bid) for bid in ids]
        if any(b['status'] not in ('submitted','confirmed','stopped','preparing','prepared') for b in batches):
            raise ValueError('A selected batch is unavailable')
        for b in batches:
            ready = representative_ready(c, b, e)
            put(c, 'batch_preparation:' + b['batch_id'], False if ready else {'batch_fingerprint': b['fingerprint'], 'reference': cmd['reference']})
            c.execute('UPDATE production_batches SET status=?,reference=? WHERE batch_id=?', ('prepared' if ready else 'preparing', cmd['reference'], b['batch_id']))
        put(c, 'batch_run_plan', {'status': 'preparing', 'mode': 'selected_group', 'entries': [binding(c, b) for b in batches], 'index': 0, 'reference': cmd['reference']})
        return {'ok': True, 'status': 'batch_selected_group_started', 'batch_ids': ids, 'group_status': 'preparing'}
    if action == 'batch_prepare_reviews':
        ids = cmd.get('batch_ids')
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
            raise ValueError('Choose distinct batches')
        if c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone():
            raise ValueError('Stop the active batch before preparing other samples')
        batches = [batch.batch(c, bid) for bid in ids]
        for b in batches:
            if b['status'] not in ('submitted', 'confirmed', 'stopped', 'preparing', 'prepared'):
                raise ValueError('Batch is not available for preparation')
        for b in batches:
            put(c, 'batch_preparation:' + b['batch_id'], {'batch_fingerprint': b['fingerprint'], 'reference': cmd['reference']})
            c.execute("UPDATE production_batches SET status='preparing',reference=? WHERE batch_id=?", (cmd['reference'], b['batch_id']))
        return {'ok': True, 'status': 'batch_preparation_selected', 'batch_ids': ids, 'representatives_only': True}
    if action == 'batch_review_bundle':
        import flow_lark_orchestration as flow
        ids = cmd.get('batch_ids', [])
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
            raise ValueError('Choose distinct batches for grouped review')
        packets = []; ready_ids=[]; waiting=[]
        for bid in ids:
            b = batch.batch(c, bid)
            first = dict(c.execute('SELECT * FROM production_batch_items WHERE batch_id=? ORDER BY position LIMIT 1', (bid,)).fetchone())
            packet = flow.review_packet(c, {'brief_id': first['brief_id']}, e) if first['state'] == 'designing' else batch.sample_review(c, b, first, e)
            if packet:
                packets.append(packet);ready_ids.append(bid)
            else:
                waiting.append({'batch_id': bid, 'status': b['status'], 'item_state': first['state']})
        if not packets:
            return {'ok': True, 'status': 'batch_reviews_not_ready', 'batch_ids': ids,
                    'waiting_batches': waiting, 'images': [],
                    'next_action': 'batch_prepare_reviews' if all(b['status'] in ('submitted','confirmed','stopped') for b in waiting) else 'batch_status'}
        stage=min((p['stage'] for p in packets),key=lambda s:('2d','embroidery','sample_mockup').index(s))
        ready=[(bid,p) for bid,p in zip(ready_ids,packets) if p['stage']==stage]
        ids=[bid for bid,p in ready];packets=[p for bid,p in ready]
        key = e['digest'](packets)
        put(c, 'batch_review_bundle:' + key, {'packets': packets, 'batch_ids': ids})
        images=[];seen=set()
        for bid,p in zip(ids,packets):
            for a in p['images']:
                identity=(bid,a['sha256'])
                if identity not in seen:
                    images.append(dict(a,label=bid+' · '+a.get('label',a.get('name',''))));seen.add(identity)
        return {'ok': True, 'status': 'batch_review_bundle', 'bundle_id': key, 'stage': packets[0]['stage'], 'batch_ids': ids,
                'images': images,
                'review_fingerprints': [p['fingerprint'] for p in packets]}
    if action == 'batch_approve_bundle':
        import flow_lark_orchestration as flow
        if not cmd.get('event_id') or not cmd.get('message_id'):
            raise ValueError('Actual human review event and message required')
        bundle = get(c, 'batch_review_bundle:' + str(cmd.get('bundle_id')))
        if not bundle:
            raise ValueError('Review the current bundle images first')
        for p in bundle['packets']:
            live = flow.review_packet(c, p['entity'], e)
            if not live or any(live[k] != p[k] for k in ('review_id', 'entity', 'revision', 'stage', 'fingerprint')):
                raise ValueError('A bundled review changed; request the current bundle')
        results = []
        for p in bundle['packets']:
            body = {k: p[k] for k in ('review_id', 'entity', 'revision', 'stage', 'fingerprint')}
            body.update(event_id=cmd['event_id'], message_id=cmd['message_id'], reference=cmd['reference'], decision='approve', authority='direct_user')
            results.append(flow.apply_decision(c, body, e))
        return {'ok': True, 'status': 'batch_bundle_approved', 'batch_ids': bundle['batch_ids'], 'results': results}
    if action == 'batch_run_plan':
        ids = cmd.get('batch_ids')
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
            raise ValueError('Choose distinct batches in the exact run order')
        if c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone():
            raise ValueError('Stop the active batch first')
        entries = []
        for bid in ids:
            b = batch.batch(c, bid); entry = binding(c, b)
            if b['status'] != 'prepared' or not entry['sample_fingerprint']:
                raise ValueError('Every night-plan batch must have approved representative images')
            entries.append(entry)
        put(c, 'batch_run_plan', {'status': 'running', 'entries': entries, 'index': 0, 'reference': cmd['reference']})
        return {'ok': True, 'status': 'batch_run_plan_selected', 'batch_ids': ids}
    if action == 'batch_discard_remaining':
        b = batch.batch(c, cmd['batch_id'])
        if cmd.get('batch_fingerprint') != b['fingerprint'] or b['status'] != 'stopped':
            raise ValueError('Stop this exact batch before removing unfinished work')
        rows = c.execute("SELECT * FROM production_batch_items WHERE batch_id=? AND state NOT IN ('completed','cancelled')", (b['batch_id'],)).fetchall()
        # Retain completed work and all downloaded assets, including partial items; only cancel future execution.
        for row in rows:
            c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=? AND item_id=?", (b['batch_id'], row['item_id']))
            c.execute("UPDATE production_batch_tasks SET status='cancelled' WHERE batch_id=? AND item_id=? AND status='pending'", (b['batch_id'], row['item_id']))
            c.execute("UPDATE design_tasks SET status='superseded' WHERE brief_id=? AND status='pending'", (row['brief_id'],))
        c.execute("UPDATE production_batches SET status='closed_partial' WHERE batch_id=?", (b['batch_id'],))
        put(c, 'batch_preparation:' + b['batch_id'], False)
        return {'ok': True, 'status': 'batch_remaining_cancelled', 'batch_id': b['batch_id'], 'cancelled_items': len(rows), 'existing_files_docs_kpi_preserved': True}
    raise ValueError('Unknown batch control')
