"""Meaningful state/KPI checks in a temporary isolated database, not live KPI."""
import importlib.util
import json
import tempfile
from pathlib import Path
from datetime import datetime, timezone

spec=importlib.util.spec_from_file_location('production',Path(__file__).with_name('production-engine.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def test(name,fn):
    fn();checks.append({'name':name,'passed':True})
def expect_failure(fn):
    try:fn()
    except (ValueError,KeyError):return
    raise AssertionError('Invalid operation was accepted')

def product_path_scope():
    import production_profiles as profiles
    for kind in ('embroidery_prompts', *profiles.PRINT_KINDS):
        category = profiles.category({'product_kind': kind})
        for state in ('Chưa xử lý', 'Đã xử lý'):
            root = Path('C:/Huy') / state / category
            image = root / 'PJM/PJM_261029_01_TQH/01_thumbnail.jpg'
            assert m.scoped(image) == image.resolve()
            expect_failure(lambda: m.scoped(root))
            expect_failure(lambda: m.scoped(root / '../Unknown/01_thumbnail.jpg'))

test('Every current product category has bounded input/output artifact paths', product_path_scope)

with tempfile.TemporaryDirectory(prefix='etsy-production-check-') as d:
    c=m.connect(Path(d)/'test.sqlite')
    j={'code':'HLW_261010_01','revision':1,'state':'queued','source_hash':'a'*64,'plan':'{}','created_at':m.now()}
    c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)',tuple(j.values()));c.commit()
    test('Invalid SKU/path traversal rejected',lambda:expect_failure(lambda:m.code('../../escape')))
    test('External asset path rejected',lambda:expect_failure(lambda:m.scoped('C:/Windows/win.ini')))
    test('KPI inactive until acceptance',lambda: (__import__('builtins').exec("assert m.allocate_kpi(c,j,'x',m.now())['counted'] is False",globals(),locals())))
    test('Cannot activate without final acceptance',lambda:expect_failure(lambda:m.execute(c,{'action':'activate_kpi','reference':'not acceptance'})))
    test('Pending browser task deduplicated',lambda: (__import__('builtins').exec("assert m.task(c,j,'flow_images',{'sample':1})['id']==m.task(c,j,'flow_images',{'sample':1})['id']",globals(),locals())))
    def task_identity():
        fresh=m.task(c,j,'lark_review',{'contract':'fixture'})
        reused=m.task(c,j,'lark_review',{'contract':'fixture'})
        assert fresh['id']==reused['id']
        assert fresh['code']==reused['code']==j['code']
        assert fresh['revision']==reused['revision']==j['revision']
        assert fresh['fingerprint']==reused['fingerprint']==m.digest({'contract':'fixture'})
    test('New and replayed delivery tasks carry the same listing/revision binding',task_identity)
    test('Final approval cannot be created without outputs',lambda:expect_failure(lambda:m.execute(c,{'action':'approve','listing_code':j['code'],'revision':1,'authority':'direct_user','reference':'test only','stage':'final','fingerprint':'x'})))
    test('Wrong revision approval rejected',lambda:expect_failure(lambda:m.execute(c,{'action':'approve','listing_code':j['code'],'revision':2,'authority':'direct_user','reference':'test only','stage':'brief','fingerprint':m.digest({})})))
    test('Task cannot be marked delivered without proof',lambda:expect_failure(lambda:m.execute(c,{'action':'task_verified','task_id':m.task(c,j,'lark_review',{})['id'],'proof':{}})))
    c.execute("INSERT INTO config VALUES('kpi_activation',?)",(json.dumps({'activated_at':'2026-10-13T00:00:00+00:00'}),))
    completed='2026-10-13T09:00:00+00:00'
    allocations=[]
    for n in range(1,31):
        trial={**j,'code':'HLW_261013_%02d'%n}
        allocations.append(m.allocate_kpi(c,trial,'f'+str(n),completed))
    test('First 21 fill the configured starting KPI day',lambda: (__import__('builtins').exec("assert all(x['target_date']=='2026-10-15' for x in allocations[:21])",globals(),locals())))
    test('Nine surplus assigned to following day',lambda: (__import__('builtins').exec("assert all(x['target_date']=='2026-10-16' for x in allocations[21:])",globals(),locals())))
    test('Retry cannot duplicate KPI',lambda: (__import__('builtins').exec("assert m.allocate_kpi(c,{**j,'code':'HLW_261013_01'},'f1',completed)['status']=='already_recorded'; assert c.execute('SELECT COUNT(*) FROM kpi').fetchone()[0]==30",globals(),locals())))
    test('Historical pilot excluded',lambda: (__import__('builtins').exec("assert m.allocate_kpi(c,j,'x','2026-10-12T09:00:00+00:00')['counted'] is False",globals(),locals())))
    test('Later completion still fills the current KPI day',lambda: (__import__('builtins').exec("assert m.allocate_kpi(c,{**j,'code':'HLW_261014_01'},'f','2026-10-15T09:00:00+00:00')['target_date']=='2026-10-16'",globals(),locals())))
    test('UTC midnight does not move a partially filled KPI day',lambda: (__import__('builtins').exec("assert m.allocate_kpi(c,{**j,'code':'HLW_261014_02'},'f','2026-10-15T20:00:00+00:00')['target_date']=='2026-10-16'",globals(),locals())))
    test('Reject revokes current approvals and blocks advancement',lambda: (__import__('builtins').exec("m.execute(c,{'action':'approve','listing_code':j['code'],'revision':1,'authority':'direct_user','reference':'test only','stage':'brief','fingerprint':m.digest({})}); m.execute(c,{'action':'reject','listing_code':j['code'],'stage':'brief','reason':'test only'}); assert c.execute('SELECT COUNT(*) FROM approvals').fetchone()[0]==0; assert m.execute(c,{'action':'advance','listing_code':j['code']})['status']=='needs_revision'",globals(),locals())))
    real=__import__('sqlite3').connect(m.DB)
    columns=real.execute('SELECT * FROM jobs WHERE code=?',(j['code'],)).fetchone()
    c.execute('INSERT OR REPLACE INTO jobs VALUES(?,?,?,?,?,?)',columns)
    for table in ['artifacts','approvals']:
        rows=real.execute('SELECT * FROM '+table+' WHERE code=?',(j['code'],)).fetchall()
        if rows:
            c.executemany('INSERT OR REPLACE INTO '+table+' VALUES('+','.join('?'*len(rows[0]))+')',rows)
    real.close()
    # Exercise the pre-delivery gate in this isolated fixture, not the completed-job retry shortcut.
    c.execute("UPDATE jobs SET state='needs_text' WHERE code=?",(j['code'],))
    livejob=m.job(c,j['code'])
    source_text=m.read(m.ROOT/'workspace/keyword-mcp-HLW_261010_01-20261013/listing-draft-with-tags.json')
    raw=[]
    for p in (Path('C:/Users/ADMIN/.n8n-files/etsy-keywords/checkpoints')/j['code']).glob('*/[0-9][0-9].json'):
        r=m.read(p)
        if r['status']=='checked':raw.append({'keyword':r['keyword'],'requested_filter':'physical','checked_at_utc':r['checked_at_utc']})
    raw=list({x['keyword']:x for x in raw}.values())[:20]
    for x in raw:x.update(evidence_status='indexed_record',competition_level='low',listing_count=80,indexed_avg_listing_views=600,indexed_avg_listing_views_24h=2,provider_says_insufficient_data=False)
    fixture={**source_text,'tags':[x['keyword'] for x in raw[:13]],'provenance':{'input_sha256':livejob['source_hash']},
             'keyword_provenance':{'keyword_policy':'ai_first_20_to_13_v1','source_hash':livejob['source_hash']},'keyword_evidence':raw}
    test('Text without 20 records rejected',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':raw[:19]})))
    test('Legacy 50-record input rejected for new text',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':raw+[{'keyword':'legacy '+str(n),'requested_filter':'physical','checked_at_utc':m.now()} for n in range(30)]})))
    test('Missing view signal accepted',lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':[{**raw[0],'indexed_avg_listing_views':None}]+raw[1:]}))
    test('All no-match Ytrend checks accepted',lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':[{**x,'evidence_status':'no_matching_record','competition_level':None,'indexed_avg_listing_views':None,'indexed_avg_listing_views_24h':None,'provider_says_insufficient_data':True} for x in raw]}))
    test('Failed check rejected',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':[{**raw[0],'evidence_status':'failed'}]+raw[1:]})))
    test('New text cannot use the obsolete traffic gate policy',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'keyword_provenance':{**fixture['keyword_provenance'],'keyword_policy':'ytrend_first_20_to_13_v1'}})))
    test('Existing 20-record text is preserved',lambda:m.validate_text(livejob,{**fixture,'keyword_provenance':{**fixture['keyword_provenance'],'keyword_policy':'ytrend_first_20_to_13_v1'}},allow_legacy=True))
    test('New 15-record text rejected',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':raw[:15]})))
    test('Existing 15-record text is preserved during advance',lambda:m.validate_text(livejob,{**fixture,'keyword_evidence':raw[:15]},allow_legacy=True))
    test('Unchecked tag rejected',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'tags':['unverified test tag']+fixture['tags'][1:]})))
    test('Text from another source rejected',lambda:expect_failure(lambda:m.validate_text(livejob,{**fixture,'provenance':{'input_sha256':'bad'}})))
    m.put(c,livejob,'text',m.validate_text(livejob,fixture))
    original_store=m.STORE; m.STORE=Path(d)/'artifacts'
    result=m.advance(c,livejob)
    test('New text waits for final user approval',lambda: (__import__('builtins').exec("assert result['status']=='awaiting_final_approval'",globals(),locals())))
    test('No Lark delivery task created before final approval',lambda: (__import__('builtins').exec("assert c.execute(\"SELECT COUNT(*) FROM tasks WHERE kind='lark_review' AND payload LIKE '%review_fingerprint%'\").fetchone()[0]==0",globals(),locals())))
    test('Six prompts retain fixed inch sizes while labels appear only on dimension view',lambda: (__import__('builtins').exec("plan=m.image_plan(livejob); assert len(plan['images'])==6; assert set(plan['sizes_in'])=={'center_chest','left_sleeve','right_sleeve'}; assert all('PHYSICAL DIMENSIONS IN INCHES:' in x['prompt'] for x in plan['images']); assert 'Display only the supplied inch measurements.' in plan['images'][4]['prompt']; assert all('Do not add measurement labels.' in x['prompt'] for i,x in enumerate(plan['images']) if i!=4)",globals(),locals())))
    # Retry after an interrupted native run accepts identical assets but never replacements.
    sources=m.artifact(c,livejob,'images')['payload']
    processed=m.artifact(c,livejob,'processed')['payload']
    test('Identical original retry is idempotent',lambda: (__import__('builtins').exec("assert m.execute(c,{'action':'attach_images','listing_code':livejob['code'],'images':sources})['status']=='images_already_attached'",globals(),locals())))
    m.STORE=original_store
    # A newer completed listing can change the aggregate sheet while an older write is pending.
    # Reject that stale acknowledgement and supersede its browser task instead of overwriting newer rows.
    c.execute("UPDATE jobs SET state='awaiting_kpi_sync' WHERE code=?",(j['code'],))
    sheet='https://local-workspace.invalid/wiki/LOCAL_DESTINATION_REQUIRED'
    stale=m.task(c,livejob,'lark_kpi',{'url':sheet,'rows':[]})
    proof={'verified_after_reload':True,'url':sheet,'screenshot_path':str(m.ROOT/'workspace/production/proof/kpi-restored-empty.png'),'rows_fingerprint':m.digest([])}
    test('Stale aggregate KPI cannot be verified against newer ledger',lambda:expect_failure(lambda:m.execute(c,{'action':'task_verified','task_id':stale['id'],'proof':proof})))
    fresh=m.task(c,livejob,'lark_kpi',{'url':sheet,'rows':m.kpi_rows(c)})
    test('A new KPI snapshot supersedes the pending old snapshot',lambda: (__import__('builtins').exec("assert c.execute('SELECT status FROM tasks WHERE id=?',(stale['id'],)).fetchone()[0]=='superseded'",globals(),locals())))
    test('Superseded browser tasks cannot be acknowledged',lambda:expect_failure(lambda:m.execute(c,{'action':'task_verified','task_id':stale['id'],'proof':proof})))
    test('Browser queue exposes only the currently eligible stage',lambda: (__import__('builtins').exec("assert [x['id'] for x in m.execute(c,{'action':'browser_queue'})['tasks']]==[fresh['id']]",globals(),locals())))
    c.close()

report={'ok':True,'checks':checks,'check_count':len(checks),'isolated_database':True,
        'real_kpi_written':False,'real_ai_called':False,'browser_delivery_tested':False,
        'native_n8n_execution_tested':False,'limitations':'These checks verify ledger invariants, not a full production execution.'}
m.write(m.STORE/'offline-check-report.json',report)
print(json.dumps(report,ensure_ascii=True))
