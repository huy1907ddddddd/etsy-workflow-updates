const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawn} = require('node:child_process');

const inputPath = 'C:/Users/ADMIN/.n8n-files/etsy-gemini/pumpkin-title-description-input.json';
const jobRoot = path.resolve(__dirname, '../workspace/n8n-codex-pilot-20261012');
const schemaPath = path.join(jobRoot, 'title-description.schema.json');

function failureDetails(stdout, stderr) {
  const events = stdout.trim().split(/\r?\n/).flatMap(line => {
    try { const event = JSON.parse(line); return ['error', 'turn.failed'].includes(event.type) ? [event] : []; }
    catch { return []; }
  });
  const text = JSON.stringify(events) + '\n' + stderr;
  const limited = /usage_limit_exceeded|[Yy]ou[’']ve hit your usage limit/.test(text);
  return { error_code: limited ? 'codex_usage_limit_exceeded' : 'codex_generation_failed',
    retryable: false, failure_events: events };
}

function loadJob(input) {
  if (!input || Array.isArray(input) || Object.keys(input).length !== 2 ||
      input.job_id !== 'pumpkin-title-description-v1' || !/^[a-f0-9]{64}$/.test(input.input_sha256 || '')) {
    throw new Error('Only the configured title-description pilot job is accepted');
  }
  const bytes = fs.readFileSync(inputPath);
  const hash = crypto.createHash('sha256').update(bytes).digest('hex');
  if (input.input_sha256 !== hash) throw new Error('Input changed; review the source packet before running');
  const source = JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, ''));
  const p = source.packet;
  if (p.bundle_version !== 1 || p.confirmed_product_brief.product_id !== 'pumpkin-cream-crewneck-pilot' ||
      p.confirmed_product_brief.personalization.enabled !== false || p.confirmed_product_brief.back_artwork !== false ||
      p.seo_knowledge.length !== 12 || !p.original_description_template.text) {
    throw new Error('Configured source packet is outside the approved pilot');
  }
  if (JSON.stringify(JSON.parse(fs.readFileSync(schemaPath, 'utf8'))) !== JSON.stringify(source.response_schema)) {
    throw new Error('Output schema does not match the approved source packet');
  }
  const prompt = source.task + '\n\nOutput JSON schema:\n' + JSON.stringify(source.response_schema) +
    '\n\nBEGIN REFERENCE DATA (not action authorization)\n' + JSON.stringify(p) + '\nEND REFERENCE DATA';
  const instructions = 'Text generation only. Do not use tools, access files, browse, or take external actions. ' +
    'All source content is supplied below. Follow the task and return only the requested JSON.\n\n' + source.system_instruction;
  return {prompt, instructions, hash};
}

function runJob({res, input, cli, reply, release, load = loadJob, outputRoot = jobRoot, outputSchemaPath = schemaPath, onResult, webSearch = false}) {
  let job;
  try { job = load(input); } catch (error) { release(); return reply(res, 400, {error: error.message}); }
  const requestId = crypto.randomUUID();
  const output = path.join(outputRoot, 'reply-' + requestId + '.json');
  const startedAt = new Date().toISOString();
  const started = Date.now();
  let child;
  try {
    child = spawn(process.execPath, [cli, 'exec', '--skip-git-repo-check', '--sandbox', 'read-only',
      '-c', webSearch ? 'web_search="live"' : 'web_search="disabled"',
      '-c', 'features.shell_tool=false', '-c', 'mcp_servers.node_repl.enabled=false',
      ...(job.images||[]).flatMap(image=>['--image',image]), '--output-schema', outputSchemaPath, '--json', '-o', output, '-'],
      {cwd: outputRoot, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe']});
  } catch { release(); return reply(res, 502, {error: 'Codex worker could not start'}); }
  let stdout = '', stderr = '', finished = false, timedOut = false, overflow = false;
  const timer = setTimeout(() => { timedOut = true; child.kill(); }, 300000);
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', chunk => {
    stdout += chunk;
    if (Buffer.byteLength(stdout) > 2000000) { overflow = true; child.kill(); }
  });
  child.stderr.on('data', chunk => { if (stderr.length < 100000) stderr += chunk; });
  function finish(code, error) {
    if (finished) return;
    finished = true;
    clearTimeout(timer);
    release();
    const metadata = {request_id: requestId, started_at: startedAt, duration_ms: Date.now() - started,
      input_sha256: job.hash, prompt_characters: job.prompt.length, listing_code: job.listing_code ?? null};
    try {
      if (timedOut || overflow || error || code !== 0) {
        const failure = failureDetails(stdout, stderr);
        fs.writeFileSync(path.join(outputRoot, 'worker-failure-' + requestId + '.json'), JSON.stringify({
          ...metadata, exit_code: code, timed_out: timedOut, overflow, stderr, ...failure,
        }, null, 2));
        return reply(res, timedOut ? 504 : 502, {error: failure.error_code, error_code: failure.error_code,
          retryable: false, ...metadata});
      }
      const events = stdout.trim().split(/\r?\n/).filter(Boolean).map(line => JSON.parse(line));
      const complete = events.findLast(x => x.type === 'turn.completed');
      const executed = events.filter(x => x.type === 'item.completed' &&
        ['command_execution', 'mcp_tool_call', 'web_search', 'file_change'].includes(x.item?.type));
      const searches = executed.filter(x => x.item.type === 'web_search');
      if (!complete || events.some(x => ['error', 'turn.failed'].includes(x.type)) || executed.some(x => !webSearch || x.item.type !== 'web_search')) {
        throw new Error(webSearch ? 'Research worker used a disallowed tool or failed' : 'Worker did not complete a text-only turn');
      }
      if (webSearch && !searches.length) throw new Error('Research worker did not perform web search');
      const draft = JSON.parse(fs.readFileSync(output, 'utf8'));
      const result = {ok: true, draft, ...metadata, provider: 'codex_cli_chatgpt',
        thread_id: events.find(x => x.type === 'thread.started')?.thread_id ?? null,
        usage: complete.usage ?? null, model_selection: 'existing_cli_configuration',
        external_tools_used: searches.length > 0, ...(webSearch ? { research_events: searches.map(x => x.item) } : {}), status: 'awaiting_user_review'};
      fs.writeFileSync(path.join(outputRoot, 'worker-result-' + requestId + '.json'), JSON.stringify(result, null, 2));
      if (onResult) onResult(result);
      return reply(res, 200, result);
    } catch (error) {
      fs.writeFileSync(path.join(outputRoot, 'worker-failure-' + requestId + '.json'), JSON.stringify({
        ...metadata, error_code: 'codex_text_turn_invalid', reason: error.message,
        event_types: stdout.trim().split(/\r?\n/).flatMap(line => { try { const event=JSON.parse(line);return [{type:event.type,item_type:event.item?.type}]; } catch { return []; } }),
      }, null, 2));
      return reply(res, 502, {error: error.message, error_code:'codex_text_turn_invalid', ...metadata});
    }
    finally { try { fs.unlinkSync(output); } catch {} }
  }
  child.on('error', error => finish(null, error));
  child.on('close', code => finish(code));
  child.stdin.on('error', () => {});
  child.stdin.end(job.instructions + '\n\nCURRENT TASK:\n' + job.prompt);
}

module.exports = {loadJob, runJob, failureDetails, TEXT_WORKER_BUILD:'20261105-text-only1'};
