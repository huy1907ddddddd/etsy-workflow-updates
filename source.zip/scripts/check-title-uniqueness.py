"""Title guards in temporary databases; no production, Etsy or Google writes."""
import importlib.util
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import title_uniqueness as titles

spec = importlib.util.spec_from_file_location('engine', Path(__file__).with_name('production-engine.py'))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)


class TitleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='unique-title-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.c = engine.connect(self.root / 'production.sqlite')
        self.addCleanup(self.c.close)
        self.a = {'code': 'CAT_261030_01_TQH', 'revision': 1}
        self.b = {'code': 'CAT_261030_02_TQH', 'revision': 1}

    def existing(self, title='Christmas Cat Embroidered Sweatshirt', code=None):
        sku = code or self.a['code']
        self.c.execute('INSERT OR REPLACE INTO artifacts VALUES(?,?,?,?,?)', (sku, 1, 'text', 'proof', json.dumps({'title': title})))

    def check_title(self, title, code=None):
        return titles.ensure_unique(self.c, code or self.b['code'], title, self.root)

    def test_case_whitespace_and_unicode_width_do_not_make_another_title(self):
        self.existing()
        with self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
            self.check_title('  Ｃhristmas CAT\n embroidered   sweatshirt ')

    def test_punctuation_reordering_stopword_sku_or_number_only_change_is_blocked(self):
        self.existing()
        for title in ('Christmas Cat, Embroidered Sweatshirt!', 'Cat Christmas Sweatshirt Embroidered',
                      'The Christmas Cat Embroidered Sweatshirt', 'Christmas Cat Embroidered Sweatshirt 2027',
                      'Christmas Cat Embroidered Sweatshirt SKU CAT_261030_02_TQH'):
            with self.subTest(title=title), self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
                self.check_title(title)

    def test_specific_different_design_word_is_allowed(self):
        self.existing()
        self.check_title('Christmas Otter Embroidered Sweatshirt')

    def test_same_sku_can_reuse_its_title_including_legacy_suffix_alias(self):
        self.existing()
        self.check_title('CHRISTMAS Cat Embroidered Sweatshirt', 'CAT_261030_01')

    def test_same_sku_reuse_survives_preexisting_multi_sku_mapping(self):
        self.existing()
        self.existing(code=self.b['code'])
        self.check_title('Christmas Cat Embroidered Sweatshirt', self.a['code'])
        with self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
            self.check_title('Christmas Cat Embroidered Sweatshirt', 'CAT_261030_03_TQH')

    def test_warehouse_database_is_read_only_and_includes_active_catalog(self):
        database = self.root / 'warehouse.sqlite'
        with sqlite3.connect(database) as ext:
            ext.execute('CREATE TABLE documents(kind TEXT,data TEXT)')
            for kind, data in [('title_sku', {'title': 'Christmas Cat Shirt', 'skus': ['OLD']}),
                               ('catalog', {'title': 'Christmas Otter Shirt', 'sku': 'OTHER', 'active': True})]:
                ext.execute('INSERT INTO documents VALUES(?,?)', (kind, json.dumps(data)))
        ext.close()
        (self.root / 'config').mkdir()
        (self.root / 'config/title-uniqueness.json').write_text(json.dumps({'history_database': str(database)}))
        before = database.read_bytes()
        for title in ('Christmas Cat Shirt', 'Christmas Otter Shirt'):
            with self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
                self.check_title(title)
        self.assertEqual(database.read_bytes(), before)

    def test_missing_configured_history_blocks_instead_of_creating_empty_database(self):
        (self.root / 'config').mkdir()
        missing = self.root / 'missing.sqlite'
        (self.root / 'config/title-uniqueness.json').write_text(json.dumps({'history_database': str(missing)}))
        with self.assertRaisesRegex(ValueError, 'listing_title_history_unavailable'):
            self.check_title('Christmas Cat Shirt')
        self.assertFalse(missing.exists())

    def test_google_document_snapshot_is_checked(self):
        file = self.root / 'history.json'
        file.write_text(json.dumps({'pairs': [{'sku': 'OTHER', 'title': 'Christmas Cat Shirt'}]}))
        (self.root / 'config').mkdir()
        (self.root / 'config/title-uniqueness.json').write_text(json.dumps({'history_file': str(file)}))
        with self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
            self.check_title('Christmas Cat Shirt')

    def test_native_text_attachment_blocks_same_batch_duplicate_before_export(self):
        with patch.object(engine, 'ROOT', self.root):
            engine.put(self.c, self.a, 'text', {'title': 'Christmas Cat Shirt'})
            before = self.c.execute('SELECT COUNT(*) FROM artifacts').fetchone()[0]
            with self.assertRaisesRegex(ValueError, 'listing_title_conflict'):
                engine.put(self.c, self.b, 'text', {'title': 'Christmas Cat Shirt'})
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM artifacts').fetchone()[0], before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
