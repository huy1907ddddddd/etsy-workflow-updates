"""Six-image public listing folders; immutable receipts and history live in workspace."""
import json,shutil,uuid
import production_profiles as profiles
from pathlib import Path


def image_role(name,code):
    return name[len(code)+1:] if name.startswith(code+'_') else name


def directory_files(directory,e):
    result=[]
    for p in sorted(directory.rglob('*')):
        if p.is_symlink() or not p.resolve().is_relative_to(directory.resolve()):raise ValueError('Delivery folder cannot contain symlinks or external paths')
        if p.is_file():result.append({'name':p.relative_to(directory).as_posix(),'sha256':e['sha'](p)})
    return result


def public_images(e,code,category,kind,images,expected_names=None):
    known=set(profiles.LEGACY+profiles.PRINT+profiles.EMBROIDERY+profiles.GARMENT_SIX)
    mockups=[x for x in images if x['name'] in known];extra=[x for x in images if x['name'] not in known]
    layouts = [expected_names] if expected_names is not None else [profiles.LEGACY,profiles.PRINT,profiles.EMBROIDERY,profiles.GARMENT_SIX]
    if sorted(x['name'] for x in mockups) not in [sorted(x) for x in layouts]:raise ValueError('Mockups do not match a versioned product layout')
    if extra and (kind!='processed' or not 1<=len(extra)<=4 or len({x.get('region') for x in extra})!=len(extra)):raise ValueError('Invalid locked embroidery originals')
    base='Chưa xử lý' if kind=='originals' else 'Đã xử lý'
    dest=e['scoped'](Path('C:/Huy')/base/category/code.split('_')[0]/code)
    expected=[{'name':code+'_'+x['name'],'sha256':x['sha256'],'role':x['name']} for x in images]
    current=directory_files(dest,e) if dest.exists() else []
    if current==sorted([{'name':x['name'],'sha256':x['sha256']} for x in expected],key=lambda x:x['name']):
        return dest,[{**x,'path':str(dest/x['name'])} for x in expected],None
    fingerprint=e['digest'](expected)
    stage=e['STORE']/'delivery-staging'/code/(kind+'-'+fingerprint[:16])
    stage.mkdir(parents=True,exist_ok=True)
    for x,desired in zip(images,expected):
        source=e['scoped'](x['path']);target=stage/desired['name']
        if e['sha'](source)!=desired['sha256']:raise ValueError('Locked export source changed')
        if target.exists() and e['sha'](target)!=desired['sha256']:raise ValueError('Delivery staging collision')
        if not target.exists():shutil.copy2(source,target)
    archive=None
    if dest.exists():
        archive=e['scoped'](e['STORE']/'output-history'/code/(kind+'-'+e['digest'](current)[:16]))
        # Both resolved targets are checked before the recursive directory move.
        if dest.name!=code or not dest.is_relative_to(e['scoped'](Path('C:/Huy')/base/category/code.split('_')[0])) or not archive.is_relative_to(e['STORE'].resolve()):raise ValueError('Unsafe delivery history target')
        if archive.exists():raise ValueError('History destination occupied; preserve both and reconcile')
        redirects=e['STORE']/'output-path-redirects.json';mapping=e['read'](redirects) if redirects.exists() else {}
        # Only old version directories are redirected; the flat current folder stays current.
        for child in dest.iterdir():
            if child.is_dir():mapping[str(child.resolve())]=str(archive/child.name)
        e['write'](redirects,mapping)
        archive.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(dest),str(archive))
        e['write'](archive.with_suffix('.inventory.json'),{'source_directory':str(dest),'files':current,'archived_at':e['now']()})
    dest.parent.mkdir(parents=True,exist_ok=True);stage.rename(dest)
    actual=directory_files(dest,e)
    if actual!=sorted([{'name':x['name'],'sha256':x['sha256']} for x in expected],key=lambda x:x['name']):raise ValueError('Public delivery contains extra or changed files')
    return dest,[{**x,'path':str(dest/x['name'])} for x in expected],str(archive) if archive else None


def retire_legacy(e,code,public,category,kind):
    if public==code:return
    base='Chưa xử lý' if kind=='originals' else 'Đã xử lý'
    root=e['scoped'](Path('C:/Huy')/base/category/code.split('_')[0]).resolve()
    old=e['scoped'](Path('C:/Huy')/base/category/code.split('_')[0]/code).resolve()
    if old.parent!=root:
        if old.is_relative_to((e['STORE']/'output-history').resolve()):return
        raise ValueError('Legacy output is outside its public root')
    if not old.exists():return
    old=old.resolve();inventory=directory_files(old,e)
    archive=(e['STORE']/'output-history'/code/('renamed-'+kind+'-'+e['digest'](inventory)[:16])).resolve()
    if old.parent!=root or old.name!=code or not archive.is_relative_to(e['STORE'].resolve()) or archive.exists():raise ValueError('Unsafe legacy output archive target')
    archive.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(old),str(archive))
    file=e['STORE']/'output-path-redirects.json';mapping=e['read'](file) if file.exists() else {}
    mapping[str(old)]=str(archive);e['write'](file,mapping)
    e['write'](archive.with_suffix('.inventory.json'),{'source_directory':str(old),'files':inventory,'archived_at':e['now']()})


def embroidery_originals(plan,e):
    if plan.get('rendering_mode')=='apparel_2d':return []
    if profiles.current(plan):
        result=[]
        for region,asset in plan['regions'].items():
            if region=='right_sleeve':continue
            file=e['scoped'](asset['path'])
            if e['sha'](file)!=asset['sha256']:raise ValueError('Locked embroidery original changed')
            result.append({'name':'%02d_embroidery_%s%s'%(11+len(result),region,file.suffix.lower()),'path':str(file),'sha256':asset['sha256'],'region':region})
        return result
    regions=plan['regions'];chests=[k for k in regions if 'chest' in k or k=='back']
    if len(chests)!=1 or not all(k in regions for k in ('left_sleeve','right_sleeve')):raise ValueError('One chest and shared sleeve embroidery required')
    if regions['left_sleeve']['sha256']!=regions['right_sleeve']['sha256']:raise ValueError('Both sleeves must use the same locked embroidery original')
    result=[]
    for number,role,key in [(7,'chest',chests[0]),(8,'sleeve','left_sleeve')]:
        source=regions[key];file=e['scoped'](source['path'])
        if e['sha'](file)!=source['sha256']:raise ValueError('Locked embroidery original changed')
        result.append({'name':'%02d_embroidery_%s%s'%(number,role,file.suffix.lower()),'path':str(file),'sha256':source['sha256'],'region':role})
    return result


def export_originals(j,a,e,public=None):
    plan=json.loads(j['plan']);category=profiles.category(plan)
    public=public or j['code']
    dest,files,archive=public_images(e,public,category,'originals',a['payload'],profiles.names(json.loads(j['plan'])))
    retire_legacy(e,j['code'],public,category,'originals')
    receipt={'source_fingerprint':a['fingerprint'],'files':files,'archive':archive,'originals_preserved':True}
    e['write'](e['STORE']/'delivery-receipts'/j['code']/('originals-'+a['fingerprint'][:16]+'.json'),receipt)
    return dest,[{**x,'path':next(f['path'] for f in files if f['role']==x['name']),'original_workspace_path':x['path']} for x in a['payload']]


def package(c,j,p,text,fp,artifact_kind,delivery_variant,e):
    e['verify_assets'](p['payload']['images'],True,expected_names=profiles.names(json.loads(j['plan'])))
    plan=json.loads(j['plan']);category=profiles.category(plan)
    public=e['public_code'](c,j['code'])
    images=[{**x,'name':x.get('role',image_role(x['name'],j['code']))} for x in p['payload']['images']]
    if public.endswith('_TQH'):images+=embroidery_originals(plan,e)
    prior=e['artifact'](c,j,'package');ledger=c.execute('SELECT completed_at,fingerprint FROM kpi WHERE code=?',(j['code'],)).fetchone()
    if ledger and ledger['fingerprint']!=fp:raise ValueError('Flat export cannot change a counted review')
    completed=ledger['completed_at'] if ledger else prior['payload']['completed_at'] if prior else e['now']()
    dest,files,archive=public_images(e,public,category,'processed',images,profiles.names(plan))
    retire_legacy(e,j['code'],public,category,'processed')
    private=e['STORE']/'listing-content'/j['code']/('v%03d-'%j['revision']+p['fingerprint'][:16])
    content={'listing_code':public,'title':text['payload']['title'],'description':text['payload']['description'],'tags':text['payload']['tags']}
    e['write'](private/'listing.json',content)
    (private/'listing.md').write_text('# '+public+'\n\n## Title\n\n'+content['title']+'\n\n## Mô tả\n\n'+content['description']+'\n\n## Tags\n\n'+', '.join(content['tags'])+'\n',encoding='utf-8')
    result={'listing_code':j['code'],'revision':j['revision'],'review_fingerprint':fp,'files':files,'destination':str(dest),
      'public_listing_code':public,'completed_at':completed,'contains_2d':False,'etsy_published':False,'layout':'product_profiles_v3' if profiles.current(plan) else 'mockups_and_embroidery_v2' if len(files)==8 else 'six_images_only_v1','content_directory':str(private),
      'processing_fingerprint':p['fingerprint'],'embroidery_sources':plan.get('regions',{})}
    if plan.get('skipped_mockups'):result['skipped_mockups']=plan['skipped_mockups']
    if delivery_variant:result['processing_correction']={'fingerprint':p['fingerprint'],'scope':'corner_logo_only','visual_qa':'pending_user_review'}
    receipt=e['STORE']/'delivery-receipts'/j['code']/('package-'+e['digest'](result)[:16]+'.json');e['write'](receipt,result)
    if archive:e['event'](c,j,'superseded_output_archived',{'archive':archive,'destination':str(dest),'file_count':6})
    e['put'](c,j,artifact_kind,result)
    return result


def compact(c,j,e):
    expected=profiles.names(json.loads(j['plan']))
    old=e['artifact'](c,j,'package')
    if not old:raise ValueError('Delivered package required')
    images=[]
    for x in old['payload']['files']:
        role=x.get('role',image_role(x['name'],j['code']))
        if role in expected:
            source=e['scoped'](x['path'])
            if not source.is_file():
                corrected=e['artifact'](c,j,'processed_logo_corrected')
                candidates=corrected['payload']['images'] if corrected else []
                locked=next((a for a in candidates if a['name']==role and a['sha256']==x['sha256']),None)
                if not locked:raise ValueError('Missing delivery has no matching locked processed original')
                source=e['scoped'](locked['path'])
            images.append({**x,'name':role,'path':str(source)})
    if len(images)!=len(expected):raise ValueError('Current package does not match its product photo count')
    e['verify_assets'](images,True,expected_names=expected)
    private=e['STORE']/'processed'/j['code']/('migration-'+e['digest'](images)[:16]);private.mkdir(parents=True,exist_ok=True)
    staged=[]
    for image in images:
        target=private/image['name']
        if not target.exists():shutil.copy2(e['scoped'](image['path']),target)
        if e['sha'](target)!=image['sha256']:raise ValueError('Migration image changed')
        staged.append({**image,'path':str(target)})
    public=e['public_code'](c,j['code'])
    # Rebuild a missing legacy reference from locked bytes, never from a new generation.
    legacy=Path('C:/Huy/Đã xử lý')/('Áo 2D' if json.loads(j['plan']).get('rendering_mode')=='apparel_2d' else 'Áo thêu')/j['code'].split('_')[0]/j['code']
    if public!=j['code'] and not e['scoped'](legacy).exists():
        archive=e['scoped'](e['STORE']/'output-history'/j['code']/('recovered-delivery-'+e['digest']([x['sha256'] for x in staged])[:16]));archive.mkdir(parents=True,exist_ok=True)
        inventory=[]
        for image in staged:
            target=archive/(j['code']+'_'+image['name'])
            if not target.exists():shutil.copy2(image['path'],target)
            if e['sha'](target)!=image['sha256']:raise ValueError('Recovered legacy reference hash changed')
            inventory.append({'name':target.name,'sha256':image['sha256']})
        redirects=e['STORE']/'output-path-redirects.json';mapping=e['read'](redirects) if redirects.exists() else {};mapping[str(legacy.resolve())]=str(archive);e['write'](redirects,mapping)
        e['write'](archive.with_suffix('.inventory.json'),{'source_directory':str(legacy),'files':inventory,'restored_from_locked_sources':True})
    raw,_=export_originals(j,e['artifact'](c,j,'images'),e,e['public_code'](c,j['code']))
    payload={'images':staged,'sources_preserved':True,'source_directory':str(raw),'destination_directory':str(private),'migration_only':True}
    processed={'payload':payload,'fingerprint':e['digest'](payload)}
    result=package(c,j,processed,e['artifact'](c,j,'text'),old['payload']['review_fingerprint'],'package','',e)
    e['event'](c,j,'public_listing_folder_compacted',{'prior_package':old['payload'],'destination':result['destination'],'reference':'User 15/10/2026: one listing folder contains only its own final images'})
    return {'ok':True,'status':'six_image_folder_ready','listing_code':result['public_listing_code'],'destination':result['destination'],'source_directory':str(raw),'image_count':len(result['files']),'kpi_unchanged':True,'generation_called':False}
