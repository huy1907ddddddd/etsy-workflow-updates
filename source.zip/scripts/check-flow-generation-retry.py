"""Isolated retry authorization checks: no real Flow/n8n/journal mutations."""
import hashlib
import json
import sqlite3
import tempfile
from pathlib import Path
from types import SimpleNamespace
import flow_lark_orchestration as flow

with tempfile.TemporaryDirectory() as directory:
    root=Path(directory)
    c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
    c.execute('CREATE TABLE config(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
    task={'id':'fixture-task','revision':3,'fingerprint':'a'*64,'payload':{'images':[{'region':'left_sleeve'}]}}
    file=root/'workspace/flow-worker/runtime'/('task-'+hashlib.sha256(task['id'].encode()).hexdigest()+'.json')
    file.parent.mkdir(parents=True)
    journal={'revision':3,'fingerprint':task['fingerprint'],'images':{'left_sleeve':{'status':'generation_started','generation_id':'failed-generation'},'center_chest':{'status':'acquired','asset':{'sha256':'locked'}}}}
    file.write_text(json.dumps(journal))
    def authority(cmd):
        if cmd.get('authority')!='direct_user' or not cmd.get('reference'):raise ValueError('Human authorization required')
    e={'ROOT':root,'design_module':lambda:SimpleNamespace(authority=authority),'execute':lambda c,cmd:{'tasks':[task]},'now':lambda:'fixture-time','digest':lambda x:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()}
    cmd={'authority':'direct_user','reference':'Actual fixture user retry','generation_retry':{'task_id':task['id'],'task_fingerprint':task['fingerprint'],'revision':3,'image_key':'left_sleeve','generation_id':'failed-generation','reason':'Failed tile disappeared'}}
    before=file.read_bytes()
    first=flow.authorize_generation_retry(c,cmd,e)
    assert first==flow.authorize_generation_retry(c,cmd,e)
    assert c.execute('SELECT COUNT(*) FROM config').fetchone()[0]==1
    assert file.read_bytes()==before
    for changed in [{**cmd,'authority':'attached_document'},{**cmd,'generation_retry':{**cmd['generation_retry'],'generation_id':'stale'}},{**cmd,'generation_retry':{**cmd['generation_retry'],'task_fingerprint':'wrong'}},{**cmd,'generation_retry':{**cmd['generation_retry'],'image_key':'center_chest'}}]:
        try:flow.authorize_generation_retry(c,changed,e)
        except ValueError:pass
        else:raise AssertionError('Invalid retry authorized')
    print('Retry authorization, immutable journal, replay and stale/acquired guards passed')
