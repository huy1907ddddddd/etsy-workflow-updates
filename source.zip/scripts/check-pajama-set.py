"""Isolated set/legacy checks. Fixture approvals never approve production images."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('wf3_fixture', Path(__file__).with_name('check-workflow3.py'))
fixture = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture)
engine, profiles, batch = fixture.engine, fixture.profiles, fixture.batch
import pajama_set


class PajamaSetTests(fixture.Workflow3Tests):
    def test_one_set_contract_reaches_manifest_task_approval_and_listing_source(self):
        cmd = self.printed('pajama_set'); cmd['items'] = cmd['items'][:1]
        start = self.start(cmd)
        manifest = batch.manifest(batch.batch(self.c, start['batch_id']))
        brief = manifest['items'][0]['brief']
        self.assertEqual(manifest['product_bundle'], pajama_set.CONTRACT)
        self.assertEqual(brief['garment'], 'pajama_set')
        self.assertEqual(brief['available_styles'], [pajama_set.STYLE])
        first = self.cycle()['tasks'][0]
        self.assertEqual(first['payload']['product_bundle'], pajama_set.CONTRACT)
        self.assertEqual(first['payload']['references'], {})
        self.assertNotIn('reference_image', manifest)
        self.assertTrue(all(not i.get('references') for i in first['payload']['images']))
        hero = first['payload']['images'][0]['prompt']
        self.assertIn('below both pant hems', hero)
        self.assertNotIn('approximately mid-thigh', hero)
        self.execute(self.candidate(first)); review = self.cycle()['reviews'][0]
        self.assertEqual(self.c.execute('select count(*) from production_batch_policies').fetchone()[0], 0)
        fixture.flow.apply_decision(self.c, self.decision(review), self.env)
        rest = self.cycle()['tasks'][0]
        self.assertEqual(len(rest['payload']['images']), 4)
        sample_sha = rest['payload']['references']['approved_sample']['sha256']
        self.assertTrue(all(sample_sha in [r['sha256'] for r in image.get('references', list(rest['payload']['references'].values()))] for image in rest['payload']['images']))
        self.assertTrue(all('APPROVED SAME-LISTING MASTER' in image['prompt'] for image in rest['payload']['images']))
        self.execute(self.candidate(rest))
        self.c.execute('INSERT OR REPLACE INTO config VALUES(?,?)', ('kpi_activation', json.dumps({'activated_at': engine.now()})))
        state = self.cycle(); self.assertEqual(len(state['production_jobs']), 1)
        code = state['production_jobs'][0]['listing_code']; packet = engine.read(engine.JOBS/(code+'.json'))
        facts = packet['packet']['confirmed_product_brief']
        self.assertEqual(facts['product_bundle'], pajama_set.CONTRACT)
        self.assertEqual(facts['mockup_garment'], pajama_set.STYLE)
        self.assertIsNone(facts['garment_size_chart'])
        self.assertIn('ONE listing/sales unit including BOTH', packet['system_instruction'])
        self.assertNotIn('Keep the confirmed garment fabric, fit, XL flatlay/5XL model sizes', packet['system_instruction'])
        self.assertEqual(self.c.execute('select count(*) from reservations').fetchone()[0], 1)
        self.assertEqual(profiles.category(json.loads(engine.job(self.c, code)['plan'])), 'Bộ pijama')

    def test_incomplete_set_is_rejected_and_pants_remain_a_separate_product(self):
        cmd = self.printed('pajama_set'); result = profiles.normalize(cmd, self.env, batch.normalize)
        brief = result['items'][0]['brief']
        for broken in ({}, {**pajama_set.CONTRACT, 'components': ['top']}, {**pajama_set.CONTRACT, 'listing_units': 2}):
            with self.assertRaises(ValueError): profiles.validate_brief({**brief, 'product_bundle': broken})
        pants = profiles.normalize(self.printed('sleep_pants'), self.env, batch.normalize)
        self.assertNotIn('product_bundle', pants)
        self.assertEqual(pants['items'][0]['brief']['available_styles'], ['sleep pants'])
        self.assertEqual(profiles.category({'product_kind': 'sleep_pants'}), 'Quần ngủ')

    def test_old_product_plans_remain_identical(self):
        old_path = engine.ROOT/'workspace/maintenance/versions/20261026-pajama-set1/before/scripts/production_profiles.py'
        spec = importlib.util.spec_from_file_location('profiles_before_set', old_path)
        old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
        for kind in ('apparel_2d', 'pajama_top', 'sleep_pants'):
            p = {'profile_version': 3, 'product_kind': kind, 'idea_prompt': 'A confirmed old design', 'regions': {}}
            j = {'code': 'FIXTURE', 'revision': 1, 'plan': json.dumps(p)}
            self.assertEqual(profiles.image_plan(j, self.env), old.image_plan(j, self.env))
            self.assertEqual(profiles.category(p), old.category(p))


if __name__ == '__main__':
    suite = unittest.TestSuite(PajamaSetTests(n) for n in PajamaSetTests.__dict__ if n.startswith('test_'))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
