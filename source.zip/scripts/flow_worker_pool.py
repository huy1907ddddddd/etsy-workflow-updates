"""Native three-lane batch ownership. Disabled installations retain legacy behavior."""
import contextvars
import json
from contextlib import contextmanager
from pathlib import Path

KEY = 'flow_worker_pool'
_context = contextvars.ContextVar('flow_worker_lane', default=None)
_depth = contextvars.ContextVar('flow_worker_depth', default=0)


def get(c):
    row = c.execute('SELECT value FROM config WHERE key=?', (KEY,)).fetchone()
    return json.loads(row[0]) if row else None


def enabled(c):
    return bool((get(c) or {}).get('enabled'))


def save(c, value):
    c.execute('INSERT OR REPLACE INTO config VALUES(?,?)', (KEY, json.dumps(value)))


def publish(e,pool):
    e['write'](e['ROOT']/'workspace/flow-worker/runtime/pool-state.private.json',
               {k:v for k,v in pool.items() if k!='provider_template'})


def runtime(e, lane=None):
    lane = lane or _context.get()
    number = lane['id'] if lane else 1
    if number not in (1,2,3):
        raise ValueError('Unknown Flow worker lane')
    return e['ROOT'] / 'workspace/flow-worker' / ('runtime' if number == 1 else f'lanes/chrome-{number}/runtime')


def selection_file(e):
    return runtime(e) / 'image-provider.json'


def lane_for_batch(c, bid):
    return next((x for x in (get(c) or {}).get('lanes',[]) if x.get('batch_id') == bid), None)


@contextmanager
def command_scope(c, cmd, e):
    if _depth.get():
        if 'worker_lane' in cmd and (not _context.get() or cmd['worker_lane'] != _context.get()['id']):
            raise ValueError('Nested Flow lane changed')
        yield
        return
    depth = _depth.set(1)
    token = _context.set(None)
    try:
        if 'worker_lane' not in cmd and enabled(c):
            import production_batch as batch
            bid = cmd.get('batch_id')
            if not bid and (cmd.get('brief_id') or cmd.get('listing_code')):
                linked = batch.linked(c,brief_id=cmd.get('brief_id'),code=cmd.get('listing_code'))[0]
                bid = linked['batch_id'] if linked else None
            owner = lane_for_batch(c,bid) if bid else None
            if owner:
                _context.set(dict(owner))
        if 'worker_lane' in cmd:
            pool = get(c)
            number = cmd['worker_lane']
            if type(number) is not int or number not in (1,2,3) or not pool or not pool.get('enabled'):
                raise ValueError('Flow worker pool is not enabled')
            lane = next(x for x in pool['lanes'] if x['id'] == number)
            expected = cmd.get('worker_lane_batch_id')
            if expected is not None and expected != lane.get('batch_id'):
                raise ValueError('Flow worker lane lease changed')
            bid = lane.get('batch_id')
            if cmd.get('batch_id') and cmd['batch_id'] != bid:
                raise ValueError('Command belongs to another Flow lane')
            if cmd.get('brief_id') or cmd.get('listing_code'):
                import production_batch as batch
                linked = batch.linked(c,brief_id=cmd.get('brief_id'),code=cmd.get('listing_code'))[0]
                if not linked or linked['batch_id'] != bid:
                    raise ValueError('Job belongs to another Flow lane')
            if cmd.get('task_id'):
                from chatgpt_image_orchestration import source_task
                task = source_task(c, cmd['task_id'])
                import production_batch as batch
                linked = batch.linked(c,brief_id=task.get('brief_id'),code=task.get('code'))[0] if not task.get('batch_id') else None
                if (task.get('batch_id') or (linked or {}).get('batch_id')) != bid:
                    raise ValueError('Task belongs to another Flow lane')
            _context.set(dict(lane))
        yield
    finally:
        _context.reset(token)
        _depth.reset(depth)


def write_choice(e, pool, lane):
    file = runtime(e,lane) / 'image-provider.json'
    choice = dict(pool['provider_template'])
    # Legacy template grants stay batch-bound; only an explicit pool grant applies to future leases.
    choice.pop('unusual_activity_policy',None)
    if pool.get('unusual_activity_policy'):
        choice['unusual_activity_policy']=dict(pool['unusual_activity_policy'])
    account = dict(choice['account_policy'],preferred_email=lane['email'],pool_fixed_account=True)
    if lane['id'] != 1:
        account['accounts']=[dict(a,home_url='https://flow.google.com/') if a['email']==lane['email'] else dict(a) for a in account['accounts']]
    account.pop('on_unusual_activity',None)
    choice.update(provider='flow',mode='flow',batch_id=lane.get('batch_id'),account_policy=account,
                  worker_lane=lane['id'],reference=pool['reference'])
    e['write'](file,choice)


def schedule(c,e):
    import production_batch as batch
    pool = get(c)
    if not pool or not pool.get('enabled'):
        return None
    occupied = set()
    for lane in pool['lanes']:
        lane['disabled'] = (runtime(e,lane) / 'worker.disabled.json').exists()
        if lane['disabled']:
            lane['ready'] = False
        bid = lane.get('batch_id')
        if bid:
            b = batch.batch(c,bid)
            if b['fingerprint'] != lane['batch_fingerprint']:
                lane['blocked'] = 'batch_binding_changed'
            elif batch.controls.finished(c,b):
                lane.update(batch_id=None,batch_fingerprint=None,blocked=None)
                write_choice(e,pool,lane)
            elif b['status'] == 'stopped':
                lane['blocked'] = lane.get('blocked') or 'batch_stopped'
            elif c.execute("SELECT 1 FROM production_batch_items WHERE batch_id=? AND state='failed'",(bid,)).fetchone():
                lane['blocked'] = 'batch_item_failed'
        if lane.get('batch_id'):
            occupied.add(lane['batch_id'])
    for lane in pool['lanes']:
        if lane.get('disabled') or not lane.get('ready') or lane.get('batch_id'):
            continue
        for entry in pool['queue']:
            if entry['batch_id'] in occupied or entry.get('assigned'):
                continue
            b = batch.batch(c,entry['batch_id'])
            if b['fingerprint'] != entry['batch_fingerprint']:
                entry['blocked'] = 'batch_binding_changed'
                continue
            if b['status'] not in ('confirmed','prepared','preparing'):
                continue
            lane.update(batch_id=b['batch_id'],batch_fingerprint=b['fingerprint'],blocked=None)
            entry['assigned'] = lane['id']
            occupied.add(b['batch_id'])
            c.execute("UPDATE production_batches SET status='active',reference=? WHERE batch_id=?",(pool['reference'],b['batch_id']))
            write_choice(e,pool,lane)
            break
    save(c,pool)
    publish(e,pool)
    return pool


def choose(c,e):
    import production_batch as batch
    pool = schedule(c,e)
    if not pool:
        return None
    current = _context.get()
    if current:
        lane = next(x for x in pool['lanes'] if x['id'] == current['id'])
    else:
        eligible = [x for x in pool['lanes'] if not x.get('disabled') and x.get('ready') and x.get('batch_id') and not x.get('blocked')]
        if not eligible:
            return None
        lane = eligible[pool.get('cursor',0) % len(eligible)]
        pool['cursor'] = pool.get('cursor',0) + 1
        save(c,pool)
    _context.set(dict(lane))
    if lane.get('disabled') or not lane.get('ready') or not lane.get('batch_id') or lane.get('blocked'):
        return None
    b = batch.batch(c,lane['batch_id'])
    return b if b['status'] == 'active' else None


def in_scope(bid):
    lane = _context.get()
    return not lane or bid == lane.get('batch_id')


def stop(c,bid):
    pool = get(c)
    if not pool or not pool.get('enabled'):
        return False
    lane = next((x for x in pool['lanes'] if x.get('batch_id') == bid),None)
    if lane:
        lane['blocked'] = 'batch_stopped'
        save(c,pool)
    return True


def resume(c,b,e,reference):
    pool = get(c)
    if not pool or not pool.get('enabled'):
        return None
    lane = next((x for x in pool['lanes'] if x.get('batch_id') == b['batch_id']),None)
    if not lane:
        entry=next((x for x in pool['queue'] if x['batch_id']==b['batch_id']),None)
        if entry and entry['batch_fingerprint']!=b['fingerprint']:
            raise ValueError('Queued batch source changed')
        if entry and entry.get('assigned'):
            raise ValueError('Queued batch lease must be reconciled')
        if not entry:
            pool['queue'].append({'batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],'assigned':None})
        c.execute("UPDATE production_batches SET status='confirmed',reference=? WHERE batch_id=?",(reference,b['batch_id']))
        save(c,pool)
        schedule(c,e)
        return {'ok':True,'status':'batch_queued','batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint']}
    if lane['batch_fingerprint'] != b['fingerprint']:
        raise ValueError('Batch is not bound to a Flow lane')
    if c.execute("SELECT 1 FROM production_batch_items WHERE batch_id=? AND state='failed'",(b['batch_id'],)).fetchone():
        raise ValueError('Repair and retry the failed item before resuming its batch')
    lane['blocked'] = None
    c.execute("UPDATE production_batches SET status='active',reference=? WHERE batch_id=?",(reference,b['batch_id']))
    save(c,pool)
    publish(e,pool)
    write_choice(e,pool,lane)
    # Error holds are archived only for an explicitly resumed exact batch.
    for file in [runtime(e,lane)/'workflow-error-hold.json',e['ROOT']/'workspace/batch-worker/runtime/workflow-error-hold.json']:
        if file.exists() and e['read'](file).get('batch_id') == b['batch_id']:
            import uuid
            file.rename(file.with_name('workflow-error-released-'+uuid.uuid4().hex+'.json'))
    return {'ok':True,'status':'batch_queued','batch_id':b['batch_id'],'worker_batch_id':b['batch_id'],'worker_lane':lane['id'],'batch_fingerprint':b['fingerprint']}


def execute(c,cmd,e):
    import production_batch as batch
    action = cmd['action']
    if action == 'batch_pool_status':
        return {'ok':True,'pool':get(c)}
    e['design_module']().authority(cmd)
    if action == 'batch_pool_configure':
        if enabled(c):
            raise ValueError('Stop the pool before changing its ownership')
        accounts = cmd.get('accounts')
        ids = cmd.get('batch_ids')
        template = e['read'](e['ROOT']/'workspace/flow-worker/runtime/image-provider.json')
        allowed = {a['email'] for a in template.get('account_policy',{}).get('accounts',[])}
        if not isinstance(accounts,list) or len(accounts)!=3 or len(set(accounts))!=3 or any(x not in allowed for x in accounts):
            raise ValueError('Choose exactly three distinct authorized Flow accounts')
        if not isinstance(ids,list) or not ids or len(set(ids))!=len(ids):
            raise ValueError('Choose distinct confirmed batches for the pool')
        batches = [batch.batch(c,bid) for bid in ids]
        adopt=cmd.get('checkpoint_batch_id')
        if adopt and adopt not in ids:
            raise ValueError('Checkpoint batch must be in the chosen queue')
        if any(b['status'] not in ('confirmed','prepared','preparing') and not (b['batch_id']==adopt and b['status']=='stopped') for b in batches):
            raise ValueError('Only confirmed batches may enter the pool; repair and resume stopped work explicitly')
        if c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone():
            raise ValueError('Pause the existing active batch before enabling the pool')
        pool = {'enabled':True,'reference':cmd['reference'],'provider_template':template,'cursor':0,
                'lanes':[{'id':n,'email':email,'ready':False,'batch_id':None,'batch_fingerprint':None,'blocked':None}for n,email in enumerate(accounts,1)],
                'queue':[{'batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],'assigned':None}for b in batches]}
        if adopt:
            b=next(b for b in batches if b['batch_id']==adopt)
            pool['lanes'][0].update(batch_id=adopt,batch_fingerprint=b['fingerprint'],blocked='batch_stopped')
            next(x for x in pool['queue'] if x['batch_id']==adopt)['assigned']=1
        save(c,pool)
        for lane in pool['lanes']:
            write_choice(e,pool,lane)
        publish(e,pool)
        return {'ok':True,'status':'flow_pool_configured','pool':pool}
    pool = get(c)
    if not pool or not pool.get('enabled'):
        raise ValueError('Flow pool is not enabled')
    if action == 'batch_pool_ready':
        lane = _context.get()
        if not lane:
            raise ValueError('Current lane required')
        if (runtime(e,lane) / 'worker.disabled.json').exists():
            raise ValueError('Flow worker lane is disabled')
        file = e['scoped'](cmd['evidence_path'])
        if not file.is_relative_to(runtime(e,lane).resolve()) or e['sha'](file)!=cmd.get('evidence_sha256'):
            raise ValueError('Account readiness proof changed')
        proof = e['read'](file)
        from datetime import datetime
        age = (datetime.fromisoformat(e['now']())-datetime.fromisoformat(proof['checked_at'].replace('Z','+00:00'))).total_seconds()
        if proof.get('verified_email')!=lane['email'] or proof.get('worker_lane')!=lane['id'] or not 0<=age<=180:
            raise ValueError('Fresh matching Flow account evidence required')
        next(x for x in pool['lanes'] if x['id']==lane['id'])['ready'] = True
        save(c,pool)
        publish(e,pool)
        return {'ok':True,'status':'flow_lane_ready','worker_lane':lane['id']}
    if action == 'batch_pool_poll':
        if 'handover' in cmd:
            return handover(c,cmd,e,pool)
        if 'unusual_activity_policy' in cmd:
            policy=cmd['unusual_activity_policy']
            if (cmd.get('refresh_choices') is not True or not isinstance(policy,dict)
                    or policy.get('enabled') is not True or type(policy.get('cooldown_ms')) is not int
                    or policy['cooldown_ms']!=600000 or policy.get('retry_after_cooldown') is not True
                    or policy.get('retry_unlimited') is not True):
                raise ValueError('Pool unusual retries require explicit unlimited new Generate after each full ten-minute cooldown and refreshed choices')
            pool['unusual_activity_policy']={k:policy[k] for k in ('enabled','cooldown_ms','retry_after_cooldown','retry_unlimited')}
            pool['unusual_activity_policy']['reference']=cmd['reference']
            save(c,pool)
        pool=schedule(c,e)
        if cmd.get('refresh_choices') is True:
            for lane in pool['lanes']:write_choice(e,pool,lane)
        return {'ok':True,'pool':pool}
    raise ValueError('Unknown Flow pool action')


def handover(c,cmd,e,pool):
    """Move an explicitly selected batch between quiescent lanes, retaining originals."""
    import shutil
    import uuid
    from datetime import datetime
    import production_batch as batch
    from chatgpt_image_orchestration import source_task
    from flow_lark_orchestration import check_hashes
    request=cmd['handover']
    source=next((l for l in pool['lanes'] if l['id']==request.get('source_lane')),None)
    target=next((l for l in pool['lanes'] if l['id']==request.get('target_lane')),None)
    if not source or not target or source==target or source.get('batch_id')!=request.get('batch_id'):
        raise ValueError('Exact source and distinct target lane required')
    b=batch.batch(c,source['batch_id'])
    if b['fingerprint']!=request.get('batch_fingerprint') or source['batch_fingerprint']!=b['fingerprint']:
        raise ValueError('Handover batch fingerprint changed')
    status=e['read'](runtime(e,{'id':1})/'pool-status.json')
    age=(datetime.fromisoformat(e['now']())-datetime.fromisoformat(status['updated_at'].replace('Z','+00:00'))).total_seconds()
    if not 0<=age<=30:
        raise ValueError('Fresh stopped-worker evidence required')
    for lane in (source,target):
        record=next((w for w in status['workers'] if w['worker_lane']==lane['id']),{})
        if record.get('pid') is not None or record.get('process_status')!='disabled' or not (runtime(e,lane)/'worker.disabled.json').exists():
            raise ValueError('Both lanes must be quiescent before handover')
    if e['read'](runtime(e,target)/'worker.disabled.json').get('reason')!='batch1_handover_maintenance':
        raise ValueError('Target must be paused for explicit handover maintenance')
    previous=target.get('batch_id')
    if previous!=request.get('previous_batch_id'):
        raise ValueError('Target lane lease changed')
    if previous and (batch.batch(c,previous)['status']!='stopped' or target['batch_fingerprint']!=request.get('previous_batch_fingerprint')):
        raise ValueError('Park the exact previous target batch before handover')
    journals=[]
    for file in runtime(e,source).glob('task-*.json'):
        journal=e['read'](file)
        task=source_task(c,journal['task_id'])
        linked=batch.linked(c,brief_id=task.get('brief_id'),code=task.get('code'))[0] if not task.get('batch_id') else None
        if (task.get('batch_id') or (linked or {}).get('batch_id'))!=b['batch_id']:
            continue
        if journal['fingerprint']!=task['fingerprint'] or journal['revision']!=task['revision']:
            raise ValueError('Source checkpoint identity changed')
        check_hashes(journal,e)
        for key,image in journal.get('images',{}).items():
            if image.get('status')=='generation_started':
                permits=[json.loads(r[0]) for r in c.execute("SELECT value FROM config WHERE key LIKE 'flow_generation_retry:%'")]
                if not any(p.get('task_id')==task['id'] and p.get('task_fingerprint')==task['fingerprint'] and p.get('revision')==task['revision'] and p.get('image_key')==key and p.get('generation_id')==image.get('generation_id') for p in permits):
                    raise ValueError('Reconcile every unresolved generation before handover')
        destination=runtime(e,target)/file.name
        if destination.exists() and e['sha'](destination)!=e['sha'](file):
            raise ValueError('Target checkpoint conflict')
        journals.append((file,destination))
    expected={x['name']:x['sha256'] for x in request.get('journals',[])}
    if {file.name:e['sha'](file) for file,_ in journals}!=expected:
        raise ValueError('Exact source journal manifest required')
    evidence=e['scoped'](request['evidence_path'])
    if e['sha'](evidence)!=request.get('evidence_sha256'):
        raise ValueError('Handover inspection evidence changed')
    for file,destination in journals:
        destination.parent.mkdir(parents=True,exist_ok=True)
        if not destination.exists():shutil.copyfile(file,destination)
    for lane in (source,target):
        for name in ('workflow-error-hold.json','pause.request.json'):
            file=runtime(e,lane)/name
            if file.exists() and e['read'](file).get('batch_id') in (b['batch_id'],previous):
                file.rename(file.with_name(name+'.handover-'+uuid.uuid4().hex))
    for entry in pool['queue']:
        if entry['batch_id']==previous:entry['assigned']=None
        if entry['batch_id']==b['batch_id']:entry['assigned']=target['id']
    source.update(batch_id=None,batch_fingerprint=None,ready=False,blocked=None,disabled=True)
    target.update(batch_id=b['batch_id'],batch_fingerprint=b['fingerprint'],ready=False,blocked=None)
    receipt={'batch_id':b['batch_id'],'from_lane':source['id'],'to_lane':target['id'],'parked_batch_id':previous,
             'reference':cmd['reference'],'at':e['now'](),'journals':expected,'evidence_sha256':request['evidence_sha256']}
    pool.setdefault('handovers',[]).append(receipt)
    c.execute("UPDATE production_batches SET status='confirmed',reference=? WHERE batch_id=?",(cmd['reference'],b['batch_id']))
    save(c,pool)
    for lane in (source,target):write_choice(e,pool,lane)
    publish(e,pool)
    return {'ok':True,'status':'flow_batch_handed_over','handover':receipt}
