'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { Supervisor } = require('./supervisor.cjs');
const { claimProcessLock } = require('./native-n8n.cjs');
function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-supervisor-test-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const stateDir = path.join(root, 'workspace/flow-worker/runtime'); fs.mkdirSync(stateDir, { recursive: true });
  const larkConfigFile = path.join(root, 'lark.private.json'), botState = path.join(root, 'bot-state.private.json');
  fs.writeFileSync(larkConfigFile, JSON.stringify({ stateFile: botState, localToken: 'test-only-never-real' }));
  const config = { workflowRoot: root, stateDir, logDir: path.join(root, 'private-logs'), larkConfigFile, workerConfigFile: path.join(root, 'worker.private.json') };
  const calls = [], notices = [], live = new Set(); let time = 1760000000000, botReady = true, n8nReady = true;
  const supervisor = new Supervisor(config, {
    now: () => time, alive: pid => live.has(pid), probe: async kind => kind === 'bot' ? botReady : n8nReady,
    notify: async (code, status) => { notices.push({ code, status }); },
    spawn: (exe, args, options) => {
      const child = new EventEmitter(); child.pid = 70000 + calls.length;
      child.kill = () => { throw Error('Supervisor must never kill a process'); };
      calls.push({ exe, args, options, child }); return child;
    }
  });
  return { root, config, supervisor, calls, notices, botState, live, advance: ms => time += ms,
    bot: ready => { botReady = ready; }, n8n: ready => { n8nReady = ready; } };
}
test('reuse live Lark without spawning duplicate, graceful stop owns only worker', async t => {
  const f = fixture(t); fs.writeFileSync(f.botState + '.lock', '58500'); f.live.add(58500);
  await f.supervisor.tick();
  assert.equal(f.calls.length, 3); assert.match(f.calls[0].args[0], /flow-worker[\\/]runtime\.cjs$/); assert.match(f.calls[1].args[0], /kpi-worker[\\/]runtime\.cjs$/); assert.match(f.calls[2].args[0], /batch-worker[\\/]runtime\.cjs$/);
  assert.equal(f.supervisor.records.bot.reused, true);
  assert.equal((await f.supervisor.stop()).status, 'stopping');
  assert.ok(fs.existsSync(path.join(f.config.stateDir, 'stop.request')));
  assert.equal(fs.existsSync(f.botState + '.stop.request'), false);
  f.calls.forEach(call => call.child.emit('exit', 0));
  assert.equal((await f.supervisor.tick()).status, 'stopped'); assert.equal(f.live.has(58500), true);
});

test('selected Telegram starts its own service and preserves the separate Lark state',async t=>{
  const f=fixture(t);fs.mkdirSync(path.join(f.root,'config'));
  const state=path.join(f.root,'telegram-state.json');fs.writeFileSync(path.join(f.root,'config/telegram-review.private.json'),JSON.stringify({stateFile:state}));
  fs.writeFileSync(path.join(f.root,'config/review-transport.json'),JSON.stringify({provider:'telegram',delivery_backend:'local_v1'}));
  f.bot(false);await f.supervisor.tick();assert.match(f.calls[0].args[0],/telegram-review[\\/]service\.cjs$/);
  assert.equal(f.calls[0].options.env.TELEGRAM_REVIEW_CONFIG,path.join(f.root,'config/telegram-review.private.json'));
  await f.supervisor.stop();assert.equal(fs.existsSync(state+'.stop.request'),true);assert.equal(fs.existsSync(f.botState+'.stop.request'),false);
});
test('owned bot launches first, worker waits health + n8n, both stop via files', async t => {
  const f = fixture(t); f.bot(false);
  await f.supervisor.tick(); assert.equal(f.calls.length, 1); assert.match(f.calls[0].args[0], /service\.cjs$/);
  f.bot(true); f.n8n(false); await f.supervisor.tick(); assert.equal(f.calls.length, 1);
  f.n8n(true); await f.supervisor.tick(); assert.equal(f.calls.length, 4);
  await f.supervisor.stop(); assert.ok(fs.existsSync(f.botState + '.stop.request'));
  assert.ok(fs.existsSync(path.join(f.config.stateDir, 'stop.request')));
  f.calls.forEach(call => call.child.emit('exit', 0));
  assert.equal((await f.supervisor.stop()).status, 'stopped');
});
test('unhealthy live external bot and externally locked worker are never duplicated or stopped', async t => {
  const f = fixture(t); f.bot(false);
  fs.writeFileSync(f.botState + '.lock', '58500'); f.live.add(58500);
  fs.writeFileSync(path.join(f.config.stateDir, 'worker.lock'), JSON.stringify({ pid: 60000, identity: 'flow-worker' })); f.live.add(60000);
  fs.mkdirSync(f.supervisor.config.kpiStateDir, { recursive: true });
  fs.writeFileSync(path.join(f.supervisor.config.kpiStateDir, 'worker.lock'), JSON.stringify({ pid: 60001, identity: 'kpi-worker' })); f.live.add(60001);
  await f.supervisor.tick(); assert.equal(f.calls.length, 0);
  assert.equal(f.supervisor.records.bot.status, 'unhealthy_external');
  assert.equal((await f.supervisor.stop()).status, 'stopped');
  assert.equal(fs.existsSync(f.botState + '.stop.request'), false);
  assert.equal(fs.existsSync(path.join(f.config.stateDir, 'stop.request')), false);
});
test('owned worker crash backoff and restart limit preserve journals and locks', async t => {
  const f = fixture(t); const journal = path.join(f.config.stateDir, 'task-test.json'); fs.writeFileSync(journal, '{"generation_started":true}');
  await f.supervisor.tick();
  for (let i = 0; i < 7; i++) {
    const child = f.supervisor.records.worker.child; assert.ok(child); child.emit('exit', 1);
    const count = f.calls.length;
    await f.supervisor.tick(); assert.equal(f.calls.length, count);
    f.advance(60001); await f.supervisor.tick();
    if (i < 6) assert.equal(f.calls.length, count + 1);
  }
  assert.equal(f.supervisor.records.worker.status, 'restart_limit');
  assert.equal((await f.supervisor.tick()).status, 'supervisor_restart_limit');
  assert.equal(fs.readFileSync(journal, 'utf8'), '{"generation_started":true}');
});
test('long stable run resets consecutive crash count and unavailable notice deduplicates', async t => {
  const f = fixture(t); f.n8n(false);
  await f.supervisor.tick(); await f.supervisor.tick(); assert.equal(f.notices.length, 1);
  f.n8n(true); await f.supervisor.tick(); assert.equal(f.notices.at(-1).status, 'recovered');
  f.supervisor.records.worker.crashes = 5; f.advance(61000); f.supervisor.records.worker.child.emit('exit', 1);
  assert.equal(f.supervisor.records.worker.crashes, 1);
});
test('stop-request file wins over restart and double supervisor lock refuses duplicate', async t => {
  const f = fixture(t);
  const unlock = claimProcessLock(path.join(f.config.stateDir, 'supervisor.lock'), 'flow-supervisor');
  assert.throws(() => claimProcessLock(path.join(f.config.stateDir, 'supervisor.lock'), 'flow-supervisor'), /already_running/); unlock();
  fs.writeFileSync(path.join(f.config.stateDir, 'supervisor.stop.request'), 'test-stop');
  assert.equal((await f.supervisor.tick()).status, 'stopped'); assert.equal(f.calls.length, 0);
});
test('private process logs never receive credentials in command arguments', async t => {
  const f = fixture(t); await f.supervisor.tick();
  assert.equal(f.calls[0].options.windowsHide, true);
  assert.equal(f.calls[0].args.length, 1); assert.match(f.calls[0].args[0], /runtime\.cjs$/);
  assert.equal(f.calls[0].options.env.FLOW_WORKER_CONFIG, f.config.workerConfigFile);
  assert.equal(f.calls[1].options.env.KPI_WORKER_CONFIG, f.supervisor.config.kpiConfigFile);
  assert.equal(JSON.stringify(f.calls[0].args).includes('test-only-never-real'), false);
  assert.equal(f.calls[0].options.stdio[0], 'ignore');
});
test('web review launches the selected private service and owns its stop file', async t => {
  const f=fixture(t);fs.mkdirSync(path.join(f.config.workflowRoot,'config'),{recursive:true});
  const webFile=path.join(f.config.workflowRoot,'config/web-review.private.json');
  fs.writeFileSync(webFile,JSON.stringify({stateFile:f.botState}));
  fs.writeFileSync(path.join(f.config.workflowRoot,'config/review-transport.json'),JSON.stringify({provider:'web'}));
  f.bot(false);await f.supervisor.tick();const bot=f.calls.find(c=>/web-review[\\/]service.cjs$/.test(c.args[0]));assert.ok(bot);assert.equal(bot.options.env.WEB_REVIEW_CONFIG,webFile);
});
test('KPI crash backs off independently, never interrupts running Flow or live reused bot', async t => {
  const f = fixture(t); await f.supervisor.tick(); const flow = f.supervisor.records.worker.child;
  f.supervisor.records.kpi.child.emit('exit', 1); assert.equal((await f.supervisor.tick()).status, 'kpi_worker_restart_pending');
  f.advance(2001); await f.supervisor.tick(); assert.equal(f.calls.length, 4); assert.equal(f.supervisor.records.worker.child, flow);
  await f.supervisor.stop(); assert.ok(fs.existsSync(path.join(f.supervisor.config.kpiStateDir, 'stop.request'))); assert.ok(fs.existsSync(path.join(f.config.stateDir, 'stop.request')));
  assert.equal(fs.existsSync(f.botState + '.stop.request'), false);
});
