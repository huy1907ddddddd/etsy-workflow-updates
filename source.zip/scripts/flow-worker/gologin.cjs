'use strict';
const fs=require('node:fs'),path=require('node:path');
const {atomic}=require('./native-n8n.cjs');
const fail=code=>{throw Object.assign(Error(code),{code});};
function settings(config){
 const g=config.gologin;
 if(!g||!/^[a-f0-9]{24}$/.test(g.profileId||'')||g.apiUrl!=='http://127.0.0.1:36912'||!config.stateDir)fail('flow_gologin_config_invalid');
 return {...g,file:path.join(config.stateDir,'gologin-connection.private.json')};
}
function endpoint(value){
 let u;try{u=new URL(value);}catch{fail('flow_gologin_endpoint_invalid');}
 if(u.protocol!=='ws:'||u.hostname!=='127.0.0.1'||!/^\/devtools\/browser\/[a-f0-9-]+$/.test(u.pathname)||Number(u.port)<1024||u.username||u.password||u.search||u.hash)fail('flow_gologin_endpoint_invalid');
 return u.href;
}
async function start(config,fetcher=fetch){
 const g=settings(config);
 let response;try{response=await fetcher(g.apiUrl+'/browser/start-profile',{method:'POST',redirect:'error',headers:{'content-type':'application/json'},body:JSON.stringify({profileId:g.profileId,sync:true}),signal:AbortSignal.timeout(60000)});}catch{fail('flow_gologin_local_api_unavailable');}
 if(!response.ok)fail('flow_gologin_profile_start_failed');
 const result=await response.json();
 if(result.status!=='success')fail('flow_gologin_profile_start_failed');
 const record={profile_id:g.profileId,api_url:g.apiUrl,ws_url:endpoint(result.wsUrl),created_at:new Date().toISOString()};
 atomic(g.file,record);return record;
}
async function connect(config,playwright,fetcher=fetch){
 const g=settings(config);let saved;
 if(fs.existsSync(g.file)){
  saved=JSON.parse(fs.readFileSync(g.file,'utf8'));
  if(saved.profile_id!==g.profileId||saved.api_url!==g.apiUrl)fail('flow_gologin_binding_changed');
  endpoint(saved.ws_url);
  try{return await playwright.chromium.connectOverCDP(saved.ws_url,{timeout:10000});}catch{/* A stopped managed profile can be started through the same local API. */}
 }
 const record=await start(config,fetcher);
 return playwright.chromium.connectOverCDP(record.ws_url,{timeout:20000});
}
module.exports={settings,endpoint,connect};
