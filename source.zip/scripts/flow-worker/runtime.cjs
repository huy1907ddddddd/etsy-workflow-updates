'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { NativeN8n, atomic, claimProcessLock } = require('./native-n8n.cjs');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
const keyOf = item => item.region || item.name;
const jsonHash = value => hash(JSON.stringify(value));
const WORKFLOW_ROOT = 'C:/Huy/etsy-workflow';
function defaults(root = WORKFLOW_ROOT) {
  return {
    workflowRoot: root, projectUrl: '', model: 'Nano Banana Pro', channel: 'chrome', headless: false,
    profileDir: root + '/workspace/flow-worker/browser-profile', stateDir: root + '/workspace/flow-worker/runtime',
    logDir: root + '/logs/flow-worker', mainWorkflowId: 'DpZkxoKm7B6jrFQi', cycleWorkflowId: 'EtsyFlowImageCycleV1',
    commandFile: 'C:/Users/ADMIN/.n8n-files/etsy-codex/production-command.json',
    n8nCli: path.join(process.env.APPDATA || '', 'npm/node_modules/n8n/bin/n8n'), brokerPort: 5689,
    pollIntervalMs: 30000, nativeTimeoutMs: 240000, generationTimeoutMs: 240000,
    actionTimeoutMs: 30000, downloadTimeoutMs: 60000, maxSnapshotAgeMs: 30000,
    larkConfigFile: root + '/config/lark-review.private.json', larkBaseUrl: 'http://127.0.0.1:8790',
  };
}
function validateConfig(config) {
  if (config.model !== 'Nano Banana Pro') throw new Error('model_must_be_nano_banana_pro');
  if (config.projectUrl && !/^https:\/\/flow\.google\.com\/[^\s]*$/.test(config.projectUrl)) throw new Error('flow_project_url_setup_required');
  const base = path.resolve(config.workflowRoot, 'workspace/flow-worker');
  for (const key of ['profileDir', 'stateDir']) {
    const rel = path.relative(base, path.resolve(config[key]));
    if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) throw new Error('dedicated_worker_directory_required');
  }
  for (const key of ['pollIntervalMs', 'nativeTimeoutMs', 'generationTimeoutMs', 'actionTimeoutMs', 'downloadTimeoutMs', 'maxSnapshotAgeMs']) {
    if (!Number.isInteger(config[key]) || config[key] < 1000) throw new Error('invalid_timeout_' + key);
  }
  if (!Number.isInteger(config.brokerPort) || config.brokerPort < 1024 || config.brokerPort > 65535) throw new Error('invalid_broker_port');
  if (config.mainWorkflowId !== 'DpZkxoKm7B6jrFQi' || config.cycleWorkflowId !== 'EtsyFlowImageCycleV1') throw new Error('native_workflow_identity_changed');
  if (config.larkBaseUrl !== 'http://127.0.0.1:8790') throw new Error('lark_endpoint_must_be_local');
  if (!fs.existsSync(config.n8nCli)) throw new Error('n8n_cli_missing');
  if(config.workerLane!==undefined){
    if(![1,2,3].includes(config.workerLane))throw Error('invalid_flow_worker_lane');
    const expected=path.join(config.workflowRoot,'workspace/flow-worker',config.workerLane===1?'runtime':`lanes/chrome-${config.workerLane}/runtime`);
    if(path.resolve(config.stateDir)!==path.resolve(expected))throw Error('flow_lane_runtime_changed');
  }
  return config;
}
class FlowRuntime {
  constructor(config, deps = {}) {
    this.config = config;
    this.native = deps.native || new NativeN8n(config);
    this.adapter = deps.adapter;
    this.now = deps.now || Date.now;
    this.fetch = deps.fetch || fetch;
    this.notify = deps.notify || ((status) => this.notifyLark(status));
    this.reviewState = deps.reviewState || ((reviewId,packet) => this.getReviewState(reviewId,packet));
    this.stopping = false;
    this.browserStarted = false;
    fs.mkdirSync(config.stateDir, { recursive: true });
    this.noticeFile = path.join(config.stateDir, 'notice.json');
    this.noticeState = fs.existsSync(this.noticeFile) ? read(this.noticeFile) : { last_sent_key: null, last_blocked: false, pending: null };
  }
  status(value) { const status = { ...value, ...(this.config.workerLane?{worker_lane:this.config.workerLane}:{}), build: '20261026-pajama-set1', pid: process.pid, updated_at: new Date(this.now()).toISOString() }; atomic(path.join(this.config.stateDir, 'status.json'), status); return status; }
  async block(code, task_id = null) {
    if (code === 'native_execution_busy') return this.status({ status: 'waiting_native_execution', code, task_id });
    const priorFile=path.join(this.config.stateDir,'status.json');
    task_id ||= fs.existsSync(priorFile)?read(priorFile).task_id||null:null;
    const providerFile=path.join(this.config.stateDir,'image-provider.json');
    let batch_id=fs.existsSync(providerFile)?read(providerFile).batch_id:null;
    const file=path.join(this.config.stateDir,'workflow-error-hold.json');
    let hold,stop_pending=false;
    try{hold=await require('../workflow-error-stop.cjs').stopOnError(this.native,file,{batch_id,code,task_id});}
    catch{stop_pending=true;}
    batch_id=hold?.batch_id||batch_id;
    const state = this.status({ status: 'blocked', code, task_id, ...(batch_id?{batch_id,automatic_retry:false,stop_pending,requires_user_resume:true}:{}) });
    const notice = code + ':' + (task_id || '');
    this.noticeState.last_blocked = true;
    if (notice !== this.noticeState.last_sent_key) {
      this.noticeState.pending = { ...state, notice_key: notice };
      atomic(this.noticeFile, this.noticeState);
      try {
        await this.notify(state);
        this.noticeState.last_sent_key = notice; this.noticeState.pending = null; atomic(this.noticeFile, this.noticeState);
      } catch { this.status({ ...state, notification_pending: true }); }
    } else atomic(this.noticeFile, this.noticeState);
    return state;
  }
  async recoverNotice() {
    if (!this.noticeState.last_blocked) return;
    if (this.noticeState.last_sent_key === 'native_execution_busy:') {
      this.noticeState = { last_sent_key: null, last_blocked: false, pending: null };
      atomic(this.noticeFile, this.noticeState); return;
    }
    const notice = { status: 'recovered', code: 'flow_worker_recovered', task_id: null };
    this.noticeState.pending = notice; atomic(this.noticeFile, this.noticeState);
    try {
      await this.notify(notice);
      this.noticeState = { last_sent_key: 'ready:flow_worker_recovered', last_blocked: false, pending: null };
      atomic(this.noticeFile, this.noticeState);
    } catch { /* Pending recovery notification will retry after the next healthy cycle. */ }
  }
  async notifyLark(status) {
    const config = read(this.config.larkConfigFile);
    const messages = {
      flow_worker_recovered: 'Worker Flow đã hoạt động lại.',
      flow_unusual_activity_required: 'Google Flow báo “We noticed some unusual activity”. Đã giữ checkpoint; chờ bạn xử lý cảnh báo và bấm Tiếp tục mẻ, không tự tạo lại.',
      flow_unusual_activity_cooldown: 'Google Flow báo unusual activity. Worker giữ ô Failed và bằng chứng, chờ đủ 10 phút rồi Generate mới theo quyền đã lưu; nếu lỗi lặp lại thì dừng. Checkpoint được giữ.',
      flow_quota_required: 'Flow báo đã đạt hạn mức sử dụng hoặc thiếu credits. Giữ checkpoint; chờ hạn mức được gỡ và bạn bấm Tiếp tục mẻ.',
      flow_accounts_exhausted: 'Các tài khoản Flow được phép dùng đều đã báo hết hạn mức. Mẻ đã dừng và giữ checkpoint; cần kiểm tra hạn mức trước khi tiếp tục.',
      flow_model_retry_exhausted: 'Nano Banana 2.1 cũng báo hết hạn mức. Mẻ đã dừng và giữ checkpoint; không tự tạo thêm ảnh.',
      flow_account_identity_mismatch: 'Email đang hoạt động trong Flow không khớp tài khoản đã gắn. Mẻ đã dừng và giữ checkpoint; cần kiểm tra đăng nhập.',
      flow_generation_failed: 'Flow hiển thị generation Failed nhưng chưa có đủ bằng chứng để tự thử lại. Checkpoint được giữ; cần kiểm tra nguyên nhân trên Flow.',
      flow_policy_review_required: 'Flow chặn nội dung theo chính sách. Workflow đã dừng và giữ checkpoint; cần kiểm tra cảnh báo trên Flow, không tự thử lại.',
      flow_generation_retry_exhausted: 'Flow vẫn Failed sau 2 lần thử lại cách nhau 1 phút. Workflow đã dừng và giữ checkpoint; cần kiểm tra lỗi trên Flow.',
      flow_generation_failure_cooldown: 'Flow đang chờ 1 phút trước khi thử lại lỗi Failed tạm thời; các ảnh đã tải được giữ nguyên.',
      flow_generate_disabled: 'Nút Generate của Flow chưa sẵn sàng. Checkpoint được giữ; trạng thái dừng cần được kiểm tra trước khi tiếp tục.',
      flow_generate_not_ready: 'Giao diện Flow chưa cho phép bấm Generate. Checkpoint được giữ; trạng thái dừng cần được kiểm tra trước khi tiếp tục.',
      flow_generation_reconcile_required: 'Worker chưa đối chiếu được ảnh của lượt Generate đang chờ. Mẻ và checkpoint vẫn được giữ; worker chỉ tìm lại kết quả cũ, không tự tạo ảnh trùng.',
    };
    const response = await fetch(this.config.larkBaseUrl + '/worker-status', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': config.localToken },
      body: JSON.stringify({ status: status.status, code: status.code, task_id: status.task_id, message: (status.requires_user_resume?'Workflow đã dừng'+(status.batch_id?' mẻ '+status.batch_id:'')+'. ':'')+(messages[status.code] || 'Flow worker cần xử lý: ' + status.code)+(status.requires_user_resume?' Không tự tiếp tục; sửa lỗi rồi bấm Tiếp tục mẻ.':'') }), signal: AbortSignal.timeout(5000), redirect: 'error' });
    if (!response.ok) throw new Error('worker_notification_pending');
  }
  async larkReadiness() {
    let config;
    try { config = read(this.config.larkConfigFile); } catch { return { ready: false, code: 'lark_config_missing' }; }
    if (['appId', 'appSecret', 'chatId', 'humanOpenId', 'localToken', 'n8nToken'].some(k => typeof config[k] !== 'string' || !config[k].trim())) return { ready: false, code: 'lark_setup_pending' };
    try {
      const response = await fetch(this.config.larkBaseUrl + '/health', { signal: AbortSignal.timeout(5000) });
      const health = await response.json();
      if (!response.ok || health.ok !== true || health.websocket_state !== 'connected') return { ready: false, code: 'lark_connection_pending' };
    } catch { return { ready: false, code: 'lark_service_unavailable' }; }
    return { ready: true };
  }
  async getReviewState(reviewId,packet) {
    const config = read(this.config.larkConfigFile);
    const response = await this.fetch(this.config.larkBaseUrl + '/reviews/' + encodeURIComponent(reviewId), { headers: { 'x-review-token': config.localToken }, signal: AbortSignal.timeout(5000), redirect: 'error' });
    // Pooled cycles use Main, which does not publish the cycle workflow's review cards.
    if(response.status===404&&this.config.workerLane&&packet?.review_id===reviewId){
      const sent=await this.fetch(this.config.larkBaseUrl+'/reviews',{method:'POST',headers:{'content-type':'application/json','x-review-token':config.localToken},body:JSON.stringify(packet),signal:AbortSignal.timeout(5000),redirect:'error'});
      if(!sent.ok)throw Error('lark_review_delivery_unavailable');
      const receipt=await sent.json();if(receipt.ok!==true||receipt.review_id!==reviewId)throw Error('lark_review_identity_invalid');
      return this.getReviewState(reviewId);
    }
    if (!response.ok) throw new Error('lark_review_state_unavailable');
    const result = await response.json();
    if (result.ok !== true || result.review?.review_id !== reviewId) throw new Error('lark_review_identity_invalid');
    return result.review;
  }
  async renewExpiredReviews(snapshot) {
    let refreshed = false;
    for (const packet of snapshot.reviews || []) {
      const review = await this.reviewState(packet.review_id,packet);
      if (Number.isFinite(review.expires_at) && review.expires_at <= this.now() && !['accepted', 'superseded'].includes(review.status)) {
        await this.native.execute({ action: 'lark_review_refresh', ...packet.entity, review_id: packet.review_id });
        refreshed = true;
      }
    }
    return refreshed ? this.native.cycle() : snapshot;
  }
  asset(asset, outputRoot = null) {
    if (!asset || !/^[a-f0-9]{64}$/.test(asset.sha256 || '')) throw new Error('asset_sha256_missing');
    const file = fs.realpathSync(asset.path);
    const rel = path.relative(fs.realpathSync(this.config.workflowRoot), file);
    if (!rel || rel.startsWith('..') || path.isAbsolute(rel) || !fs.statSync(file).isFile()) throw new Error('asset_outside_workflow_root');
    if (outputRoot) {
      const outRel = path.relative(fs.realpathSync(outputRoot), file);
      if (!outRel || outRel.startsWith('..') || path.isAbsolute(outRel)) throw new Error('asset_outside_task_output');
    }
    if (hash(fs.readFileSync(file)) !== asset.sha256) throw new Error('asset_hash_changed');
    return { path: file, sha256: asset.sha256 };
  }
  reference(asset, task) {
    try { return this.asset(asset); }
    catch (error) {
      if (error.message !== 'asset_outside_workflow_root' || !['flow_images', 'flow_batch_images'].includes(task.kind)) throw error;
      const allowed = read(path.join(this.config.workflowRoot, 'workspace/chat-handoff/20261014-prompt-authoring/embroidered-apparel-10-photo-plan-v001.json')).references || [];
      const file = fs.realpathSync(asset.path);
      if (!allowed.some(ref => ['fold_framing_zoom_only', 'sweatshirt_palette', 'hoodie_quarterzip_palette'].includes(ref.role)
          && ref.role === asset.role && ref.sha256 === asset.sha256 && fs.realpathSync(ref.path) === file)) throw error;
      if (hash(fs.readFileSync(file)) !== asset.sha256) throw new Error('asset_hash_changed');
      return { path: file, sha256: asset.sha256 };
    }
  }
  task(snapshot, id) {
    const stamp = Date.parse(snapshot?.observed_at);
    if (snapshot?.ok !== true || !Array.isArray(snapshot.tasks) || !Number.isFinite(stamp) || stamp > this.now() + 1000 || this.now() - stamp > this.config.maxSnapshotAgeMs) throw new Error('native_snapshot_stale');
    const task = snapshot.tasks.find(t => t.id === id);
    if (!task || task.status !== 'pending' || !['flow_design_2d', 'flow_design_embroidery', 'flow_images', 'flow_batch_images'].includes(task.kind)) throw new Error('task_no_longer_pending');
    const p = task.payload;
    if (!p || p.revision !== task.revision || !Number.isInteger(task.revision) || task.revision < 1 || !/^[a-f0-9]{64}$/.test(task.fingerprint || '') || p.provider !== 'Flow Nano Banana Pro') throw new Error('task_identity_invalid');
    const rule = read(path.join(this.config.workflowRoot, 'config/artwork-flow-prompts.json')).mandatory_outline_rule;
    if (!Array.isArray(p.images) || !p.images.length || p.images.some(i => !i.prompt?.trimEnd().endsWith(rule))) throw new Error('mandatory_outline_rule_missing');
    if (new Set(p.images.map(keyOf)).size !== p.images.length || (task.kind === 'flow_images' && p.images.length !== 6)) throw new Error('task_images_invalid');
    if (task.kind.startsWith('flow_design_') && (p.brief_id !== task.brief_id || p.stage !== task.kind.replace('flow_design_', ''))) throw new Error('task_brief_identity_invalid');
    if (task.kind === 'flow_images' && p.listing_code !== task.code) throw new Error('task_listing_identity_invalid');
    if (task.kind === 'flow_batch_images') {
      // Older embroidery mockup tasks omit the ratio; FlowBrowser still enforces and verifies 1:1.
      if (![task.batch_id, task.item_id].every(id => /^[A-Za-z0-9_-]{1,100}$/.test(id || '')) || p.batch_id !== task.batch_id || p.item_id !== task.item_id || p.stage !== task.stage
        || p.executor !== 'independent_flow_worker' || (p.aspect_ratio !== undefined && p.aspect_ratio !== '1:1')) throw new Error('task_batch_identity_invalid');
      if (p.product_kind === 'pajama_set' && (!p.product_bundle || Object.keys(p.product_bundle).length!==3 || p.product_bundle.sales_unit!=='set' || p.product_bundle.listing_units!==1 || JSON.stringify(p.product_bundle.components)!==JSON.stringify(['top','pants']))) throw Error('task_pajama_set_invalid');
      let names = ['01_thumbnail.jpg', '02_model_front.jpg', '03_model_angle.jpg', '04_embroidery_closeup.jpg', '05_embroidery_dimensions.jpg', '06_flatlay.jpg'];
      if (p.profile_version === 3) {
        if (['apparel_2d', 'pajama_top','pajama_set', 'sleep_pants'].includes(p.product_kind)) names = ['01_thumbnail.jpg', '02_female_angle.jpg', '03_female_seated.jpg', '04_flatlay.jpg', '05_print_closeup.jpg'];
        else if (p.product_kind === 'embroidery_prompts') names = ['01_thumbnail.jpg', '02_hoodie_folded.jpg', '03_quarterzip_folded.jpg', '04_male_front.jpg', '05_female_angle.jpg', '06_female_seated.jpg', '07_embroidery_closeup.jpg', '08_maximum_dimensions.jpg', '09_gift_packaging.jpg', '10_flatlay.jpg'];
        else throw new Error('task_batch_images_invalid');
        if(p.mockup_set!==undefined){
          if(p.product_kind!=='embroidery_prompts'||!['embroidery_6_v1','embroidery_6_flatlay_v1','embroidery_10_v1'].includes(p.mockup_set))throw Error('task_mockup_set_invalid');
          if(p.mockup_set==='embroidery_6_v1')names=names.filter((_name,index)=>[0,1,3,4,6,9].includes(index));
          if(p.mockup_set==='embroidery_6_flatlay_v1')names=['01_thumbnail.jpg','02_hoodie_folded.jpg','04_sweatshirt_flatlay.jpg','05_hoodie_flatlay.jpg','07_embroidery_closeup.jpg','10_flatlay.jpg'];
        }
      }
      const retained = p.retained_images || [];
      if (!Array.isArray(retained) || new Set(retained.map(i => i.name)).size !== retained.length || retained.some(i => !names.includes(i.name))) throw new Error('task_batch_retained_images_invalid');
      retained.forEach(i => this.asset(i));
      const expectedNames = p.stage === 'sample_mockup' ? names.slice(0, 1) : p.stage === 'mockups' && retained.length ? names.filter(name => !retained.some(i => i.name === name)) : p.stage === 'mockups' && p.images.length === names.length - 1 ? names.slice(1) : p.stage === 'mockups' && p.images.length === names.length ? names : [];
      if (!expectedNames.length || JSON.stringify(p.images.map(keyOf).sort()) !== JSON.stringify(expectedNames.slice().sort())) throw new Error('task_batch_images_invalid');
      if (typeof p.output_directory !== 'string' || !p.output_directory.trim()) throw new Error('task_batch_output_missing');
      const relative = path.relative(path.resolve(this.config.workflowRoot, 'workspace/production'), path.resolve(p.output_directory));
      if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('task_batch_output_outside_production');
      let ancestor = path.resolve(p.output_directory);
      while (!fs.existsSync(ancestor)) ancestor = path.dirname(ancestor);
      const actualRelative = path.relative(fs.realpathSync(this.config.workflowRoot), fs.realpathSync(ancestor));
      if (actualRelative.startsWith('..') || path.isAbsolute(actualRelative)) throw new Error('task_batch_output_outside_production');
    }
    for (const image of p.images) {
      if (image.output_aspect_ratio === '7:26') {
        if (!task.kind.startsWith('flow_design_') || !image.region?.endsWith('sleeve') || image.aspect_ratio !== '9:16') throw Error('portrait_sleeve_task_invalid');
      } else if (['9:16', '16:9'].includes(image.aspect_ratio) && image.output_aspect_ratio === image.aspect_ratio) {
        if (!task.kind.startsWith('flow_design_') || !image.region?.endsWith('sleeve')) throw Error('native_sleeve_task_invalid');
      } else if (image.aspect_ratio && image.aspect_ratio !== '1:1') throw Error('task_image_aspect_invalid');
      const refs = this.references(task, image);
      refs.forEach(ref => this.reference(ref, task));
      if (task.kind === 'flow_design_embroidery' && !refs.some(r => r.role === 'exact_locked_2d')) throw new Error('locked_2d_reference_missing');
    }
    const quality = read(path.join(this.config.workflowRoot, 'config/artwork-approved-quality-standard.json'));
    for (const reference of quality.assets || []) this.asset(reference);
    if (['flow_images', 'flow_batch_images'].includes(task.kind)) read(path.join(this.config.workflowRoot, 'config/mockup-wardrobe-standard.json'));
    return task;
  }
  references(task, item) { return item.references || Object.values(task.payload.references || {}); }
  file(id) { return path.join(this.config.stateDir, 'task-' + hash(id) + '.json'); }
  load(task) {
    const file = this.file(task.id);
    const state = fs.existsSync(file) ? read(file) : { task_id: task.id, revision: task.revision, fingerprint: task.fingerprint, payload_hash: jsonHash(task.payload), images: {}, events: [], status: 'claimed' };
    if (state.revision !== task.revision || state.fingerprint !== task.fingerprint || state.payload_hash !== jsonHash(task.payload)) throw new Error('checkpoint_task_identity_changed');
    const projectKey=task.flow_project_key||task.batch_id||'listing-'+(task.code||task.brief_id);
    if(state.project_key&&state.project_key!==projectKey)throw Error('checkpoint_project_identity_changed');
    state.project_key=projectKey;
    for (const image of Object.values(state.images)) if (image.asset) { this.asset(image.asset); this.validateProof(image.proof); }
    return state;
  }
  save(state) { atomic(this.file(state.task_id), state); }
  reconcileSkipped(task,state) {
    for(const receipt of task.skipped_images||[]) {
      const key=receipt.image_key,image=state.images[key];
      if(task.kind!=='flow_batch_images'||task.stage!=='mockups'||receipt.task_id!==task.id||receipt.task_fingerprint!==task.fingerprint||receipt.revision!==task.revision||!task.payload.images.some(i=>keyOf(i)===key)||!receipt.reference||receipt.reason!=='flow_generation_might_violate'||!image||image.asset||image.generation_id!==receipt.generation_id)throw Error('mockup_skip_binding_changed');
      if(image.status==='skipped')continue;
      if(image.status!=='generation_started')throw Error('mockup_skip_binding_changed');
      state.events.push({event:'mockup_skipped',image_key:key,prior_generation:image,receipt,at:new Date(this.now()).toISOString()});
      state.images[key]={...image,status:'skipped',skip_receipt:receipt};
      if(state.generation_failure_cooldown?.image_key===key)delete state.generation_failure_cooldown;
      this.save(state);
    }
    for(const [key,image] of Object.entries(state.images))if(image.status==='skipped'&&!(task.skipped_images||[]).some(r=>r.image_key===key&&r.generation_id===image.generation_id))throw Error('mockup_skip_receipt_missing');
  }
  async skipMockup(task,state,imageKey) {
    const evidence=await this.adapter.generationFailureEvidence(path.join(this.config.stateDir,'skip-'+hash(task.id)+'-'+this.now()+'.png'));
    this.asset({path:evidence.screenshot_path,sha256:evidence.screenshot_sha256});
    const image=state.images[imageKey];
    if(image?.status!=='generation_started'||image.asset||!image.generation_id)throw Error('mockup_skip_binding_changed');
    const result=await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:'Workflow3 user22/10/2026: might-violate mockup is skipped, design/embroidery keeps bounded retries. Preserve valid outputs and human representative gate.',
      mockup_skip:{task_id:task.id,task_fingerprint:task.fingerprint,revision:task.revision,image_key:imageKey,generation_id:image.generation_id,evidence}});
    const live=result.tasks?.find(t=>t.id===task.id);
    if(!live?.skipped_images?.some(r=>r.image_key===imageKey&&r.generation_id===image.generation_id))throw Error('mockup_skip_not_confirmed');
    this.reconcileSkipped(live,state);
    state.failed_tiles_baseline=await this.adapter.acknowledgeFailedTiles();this.save(state);
  }
  cooldownStatus(task,state) {
    atomic(path.join(this.config.stateDir,'unusual-activity-cooldown.json'),{task_id:task.id,...state.unusual_activity_cooldown});
    return this.status({status:'cooldown',code:'flow_unusual_activity_cooldown',task_id:task.id,image_key:state.unusual_activity_cooldown.image_key,
      resume_at:state.unusual_activity_cooldown.not_before,remaining_seconds:Math.max(0,Math.ceil((Date.parse(state.unusual_activity_cooldown.not_before)-this.now())/1000)),next_action:state.unusual_activity_cooldown.retry_after_cooldown?'new_generation':state.unusual_activity_cooldown.wait_only?'check_warning':'new_generation'});
  }
  armUnusualRetry(task,state,policy) {
    const waiting=state.unusual_activity_cooldown;
    if(policy.retry_after_cooldown!==true||waiting.retry_policy_reference===policy.reference)return;
    const image=state.images[waiting.image_key];
    if((waiting.not_before!==undefined&&!Number.isFinite(Date.parse(waiting.not_before)))||image?.status!=='generation_started'||image.asset
      ||!waiting.generation_id||image.generation_id!==waiting.generation_id)throw Error('unusual_activity_cooldown_checkpoint_invalid');
    if(!waiting.wait_only&&(!waiting.failed_tiles?.length||waiting.failed_tiles.some(t=>!t.includes('We noticed some unusual activity.'))))throw Error('unusual_activity_cooldown_checkpoint_invalid');
    this.asset({path:waiting.screenshot_path,sha256:waiting.screenshot_sha256});
    waiting.wait_only=true;waiting.retry_after_cooldown=true;waiting.retry_policy_reference=policy.reference;
    waiting.not_before=new Date(Math.max(Date.parse(waiting.not_before)||0,this.now()+policy.cooldown_ms)).toISOString();
    state.events.push({event:'unusual_activity_retry_wait_started',...waiting,at:new Date(this.now()).toISOString()});this.save(state);
  }
  async beginUnusualCooldown(task,state,imageKey,policy,passive=false) {
    if(passive&&state.unusual_activity_cooldown&&!state.unusual_activity_cooldown.wait_only)return this.block('flow_unusual_activity_required',task.id);
    if(!state.unusual_activity_cooldown) {
      if(passive&&policy.retry_unlimited!==true&&state.events.some(e=>['unusual_warning_cleared','unusual_activity_retry_authorized'].includes(e.event)&&e.image_key===imageKey))return this.block('flow_unusual_activity_required',task.id);
      const screenshot=path.join(this.config.stateDir,'unusual-'+hash(task.id)+'-'+this.now()+'.png');
      const evidence=await this.adapter.unusualActivityEvidence(screenshot);
      this.asset({path:evidence.screenshot_path,sha256:evidence.screenshot_sha256});
      state.unusual_activity_cooldown={image_key:imageKey,generation_id:state.images[imageKey]?.generation_id||null,
        observed_at:new Date(this.now()).toISOString(),not_before:new Date(this.now()+policy.cooldown_ms).toISOString(),...evidence,...(passive?{wait_only:true}:{})};
      delete state.generation_failure_cooldown;
      state.events.push({event:'unusual_activity_cooldown_started',...state.unusual_activity_cooldown});this.save(state);
      if(!passive)await this.block('flow_unusual_activity_cooldown',task.id);
    }
    if(passive)this.armUnusualRetry(task,state,policy);
    if(passive&&!state.unusual_activity_cooldown.notification_sent&&!(policy.retry_unlimited===true&&state.events.some(e=>e.event==='unusual_activity_retry_authorized'&&e.image_key===imageKey))) {
      try {
        await this.notify({status:'blocked',code:'flow_unusual_activity_cooldown',task_id:task.id});
        state.unusual_activity_cooldown.notification_sent=true;this.save(state);
      } catch { /* Retry this one notice on the next cooldown tick. */ }
    }
    return this.cooldownStatus(task,state);
  }
  failureCooldownStatus(task,state) {
    const waiting=state.generation_failure_cooldown;
    return this.status({status:'cooldown',code:'flow_generation_failure_cooldown',task_id:task.id,image_key:waiting.image_key,
      resume_at:waiting.not_before,remaining_seconds:Math.max(0,Math.ceil((Date.parse(waiting.not_before)-this.now())/1000)),next_action:'new_generation',automatic_retry:true,silent:true});
  }
  async beginFailureCooldown(task,state,imageKey,policy) {
    const image=state.images[imageKey];
    if(image?.status!=='generation_started'||image.asset||!image.generation_id)throw Error('flow_generation_reconcile_required');
    if(!state.generation_failure_cooldown) {
      const evidence=await this.adapter.generationFailureEvidence(path.join(this.config.stateDir,'failed-'+hash(task.id)+'-'+this.now()+'.png'));
      this.asset({path:evidence.screenshot_path,sha256:evidence.screenshot_sha256});
      if(state.events.filter(e=>e.event==='generation_failure_cooldown_completed'&&e.image_key===imageKey).length>=2)return this.block('flow_generation_retry_exhausted',task.id);
      state.generation_failure_cooldown={image_key:imageKey,generation_id:image.generation_id,
        observed_at:new Date(this.now()).toISOString(),not_before:new Date(this.now()+policy.cooldown_ms).toISOString(),...evidence};
      state.events.push({event:'generation_failure_cooldown_started',...state.generation_failure_cooldown});this.save(state);
    }
    return this.failureCooldownStatus(task,state);
  }
  async completeAccountSwitch(task,state,policy) {
    const pending=state.account_switch_pending,image=state.images[pending?.image_key];
    if(!policy?.enabled||pending.policy_reference!==policy.reference||image?.status!=='generation_started'||image.asset||image.generation_id!==pending.generation_id||!policy.accounts.some(a=>a.email===pending.target_email))throw Error('flow_account_switch_binding_invalid');
    if(pending.failure_code&&!['flow_unusual_activity_required','flow_quota_required'].includes(pending.failure_code))throw Error('flow_account_switch_binding_invalid');
    const unusual=pending.failure_code==='flow_unusual_activity_required',waiting=state.unusual_activity_cooldown;
    if(unusual&&(policy.on_unusual_activity!=='switch_account'||!waiting||waiting.image_key!==pending.image_key||waiting.generation_id!==pending.generation_id||!waiting.failed_tiles?.length||waiting.failed_tiles.some(t=>!t.includes('We noticed some unusual activity.'))))throw Error('flow_account_switch_binding_invalid');
    if(unusual)this.asset({path:waiting.screenshot_path,sha256:waiting.screenshot_sha256});
    if(this.stopping)throw Error('worker_stopping');
    const live=this.task(await this.native.cycle(),task.id);
    if(live.fingerprint!==task.fingerprint||jsonHash(live.payload)!==state.payload_hash||live.flow_project_key!==task.flow_project_key)throw Error('task_changed_before_account_switch');
    await this.adapter.switchAccount(pending.target_email);
    await this.adapter.ensureProject(task.flow_project_key||task.batch_id||'listing-'+(task.code||task.brief_id));
    // The native permit alone may replace the failed generation; acquired images remain untouched.
    const current=this.task(await this.native.cycle(),task.id);
    if(this.stopping||current.fingerprint!==task.fingerprint||jsonHash(current.payload)!==state.payload_hash||current.flow_project_key!==task.flow_project_key)throw Error('task_changed_before_account_switch');
    await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:policy.reference,
      generation_retry:{task_id:task.id,task_fingerprint:task.fingerprint,revision:task.revision,image_key:pending.image_key,generation_id:pending.generation_id,reason:unusual?'User explicitly authorizes immediate signed-in Flow account handover after the saved unusual failure, without the former ten-minute wait; preserve prompt, references and acquired images. Do not claim the source warning cleared.':'User-authorized signed-in Flow account handover after a confirmed quota failure; preserve prompt, references and acquired images.'}});
    state.events.push({event:unusual?'unusual_account_handover':'quota_account_handover',image_key:pending.image_key,generation_id:pending.generation_id,target_account_sha256:hash(pending.target_email),...(unusual?{unusual_activity_cooldown:{...waiting}}:{}),at:new Date(this.now()).toISOString()});
    if(unusual){
      atomic(path.join(this.config.stateDir,'unusual-activity-cooldown.json'),{task_id:task.id,...waiting,consumed_at:new Date(this.now()).toISOString(),next_action:'authorized_account_handover'});
      delete state.unusual_activity_cooldown;state.failed_tiles_baseline=[];
    }
    delete state.account_switch_pending;this.save(state);
    return this.status({status:'preparing_flow',task_id:task.id,image_key:pending.image_key,code:'flow_account_handover_ready'});
  }
  async retryOnOtherAccount(task,state,imageKey,policy) {
    const image=state.images[imageKey];
    if(!policy?.enabled||!policy.reference||!image||image.status!=='generation_started'||image.asset||typeof this.adapter.quotaTarget!=='function')throw Object.assign(Error('flow_quota_required'),{code:'flow_quota_required'});
    const target=this.adapter.quotaTarget();
    if(!target)return this.block('flow_accounts_exhausted',task.id);
    state.account_switch_pending={image_key:imageKey,generation_id:image.generation_id,target_email:target,policy_reference:policy.reference};this.save(state);
    return this.completeAccountSwitch(task,state,policy);
  }
  async switchAfterUnusualFailure(task,state,policy,imageKey=state.unusual_activity_cooldown?.image_key) {
    const image=state.images[imageKey],item=task.payload.images.find(i=>keyOf(i)===imageKey);
    if(!policy?.enabled||policy.on_unusual_activity!=='switch_account'||!policy.reference||image?.status!=='generation_started'||image.asset||!image.generation_id||image.recovery?.prompt_sha256!==hash(item?.prompt||''))throw Error('flow_account_switch_binding_invalid');
    if(!state.unusual_activity_cooldown){
      const evidence=await this.adapter.unusualActivityEvidence(path.join(this.config.stateDir,'unusual-account-'+hash(task.id)+'-'+this.now()+'.png'));
      state.unusual_activity_cooldown={image_key:imageKey,generation_id:image.generation_id,observed_at:new Date(this.now()).toISOString(),...evidence};
      state.events.push({event:'unusual_account_failure_saved',...state.unusual_activity_cooldown});this.save(state);
    }
    const waiting=state.unusual_activity_cooldown;
    if(waiting.image_key!==imageKey||image.generation_id!==waiting.generation_id||!waiting.failed_tiles?.length||waiting.failed_tiles.some(t=>!t.includes('We noticed some unusual activity.')))throw Error('flow_account_switch_binding_invalid');
    this.asset({path:waiting.screenshot_path,sha256:waiting.screenshot_sha256});
    if(state.account_switch_pending)return this.completeAccountSwitch(task,state,policy);
    const ready=await this.adapter.readiness();
    if(!ready.ready&&ready.code!=='flow_unusual_activity_required')return this.block(ready.code||'flow_login_required',task.id);
    const target=this.adapter.unusualTarget(image.recovery.project_url);
    if(!target)return this.block('flow_accounts_exhausted',task.id);
    state.account_switch_pending={image_key:waiting.image_key,generation_id:waiting.generation_id,target_email:target,policy_reference:policy.reference,failure_code:'flow_unusual_activity_required'};
    this.save(state);return this.completeAccountSwitch(task,state,policy);
  }
  async retryOnOtherModel(task,state,imageKey,policy) {
    const image=state.images[imageKey];
    if(!policy?.enabled||policy.model!=='Nano Banana 2.1'||!policy.reference||image?.status!=='generation_started'||image.asset||!image.generation_id)throw Error('flow_model_switch_binding_invalid');
    if(state.model_switch_pending?.generation_id!==image.generation_id&&this.adapter.config.model==='Nano Banana 2.1')throw Error('flow_model_retry_exhausted');
    if(this.stopping)throw Error('worker_stopping');
    const current=this.task(await this.native.cycle(),task.id);
    if(current.fingerprint!==task.fingerprint||jsonHash(current.payload)!==state.payload_hash||current.flow_project_key!==task.flow_project_key)throw Error('task_changed_before_model_switch');
    state.model_switch_pending={image_key:imageKey,generation_id:image.generation_id,policy_reference:policy.reference};this.save(state);
    const item=task.payload.images.find(item=>keyOf(item)===imageKey);
    const evidence=await this.adapter.resumeAfterQuotaFailure(item,image);
    this.asset({path:evidence.screenshot_path,sha256:evidence.screenshot_sha256});
    await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:policy.reference,
      generation_retry:{task_id:task.id,task_fingerprint:task.fingerprint,revision:task.revision,image_key:imageKey,generation_id:image.generation_id,
        reason:'Confirmed usage limit: owner authorizes one new Generate on Nano Banana 2.1 with unchanged prompt/references and acquired images.'}});
    atomic(path.join(this.config.stateDir,'flow-model.json'),{model:policy.model,policy_reference:policy.reference});
    this.adapter.config.model=policy.model;state.failed_tiles_baseline=evidence.baseline;
    state.events.push({event:'quota_model_fallback',image_key:imageKey,generation_id:image.generation_id,model:policy.model,reference:policy.reference,...evidence,at:new Date(this.now()).toISOString()});
    delete state.model_switch_pending;this.save(state);
    return this.status({status:'preparing_flow',code:'flow_model_fallback_ready',task_id:task.id,image_key:imageKey,model:policy.model});
  }
  async tick({ readinessOnly = false } = {}) {
    if(this.config.workerLane&&fs.existsSync(path.join(this.config.stateDir,'manual-login.request'))){
      if(this.browserStarted||this.adapter.page){await this.adapter.close();this.browserStarted=false;}
      return this.status({status:'paused_for_login',code:'flow_manual_login_in_progress'});
    }
    if(this.config.workerLane&&!this.poolReady){
      const choice=read(path.join(this.config.stateDir,'image-provider.json'));
      this.adapter.config.accountPolicy=choice.account_policy;
      this.status({status:'connecting_account',account_email:choice.account_policy.preferred_email});
      try{
        await this.adapter.start();
        await this.adapter.verifyAccount(choice.account_policy.preferred_email);
        this.browserStarted=true;
      }catch(error){return this.status({status:'login_required',code:error.code||'flow_account_identity_required',account_email:choice.account_policy.preferred_email});}
      const file=path.join(this.config.stateDir,'account-readiness.private.json');
      atomic(file,{worker_lane:this.config.workerLane,verified_email:choice.account_policy.preferred_email,checked_at:new Date(this.now()).toISOString()});
      await this.native.execute({action:'batch_pool_ready',authority:'direct_user',reference:choice.reference,evidence_path:file,evidence_sha256:hash(fs.readFileSync(file))});
      this.poolReady=true;
    }
    const errorHold=path.join(this.config.stateDir,'workflow-error-hold.json');
    if(fs.existsSync(errorHold)){const hold=read(errorHold);return this.block(hold.code,hold.task_id);}
    const pauseFile=path.join(this.config.stateDir,'pause.request.json');
    if(fs.existsSync(pauseFile)) {
      const pause=read(pauseFile);
      if(this.browserStarted){await this.adapter.close();this.browserStarted=false;}
      return this.status({status:'paused',code:'image_worker_paused_by_user',reference:pause.reference});
    }
    const lark = await this.larkReadiness();
    if (!lark.ready) return this.block(lark.code);
    let snapshot = await this.native.cycle();
    this.adapter.config||={};this.adapter.config.accountPolicy=snapshot.account_policy;
    this.modelPolicy=snapshot.model_fallback_policy;this.adapter.config.modelPolicy=this.modelPolicy;
    const modelFile=path.join(this.config.stateDir,'flow-model.json');
    const savedModel=fs.existsSync(modelFile)?read(modelFile):null;
    this.adapter.config.model=this.modelPolicy?.enabled&&savedModel?.policy_reference===this.modelPolicy.reference?savedModel.model:this.config.model;
    if (!readinessOnly) snapshot = await this.renewExpiredReviews(snapshot);
    // Resend the same native command after an unknown attachment result, never regenerate.
    for (const name of fs.readdirSync(this.config.stateDir).filter(n => /^task-[a-f0-9]{64}\.json$/.test(n))) {
      const state = read(path.join(this.config.stateDir, name));
      if(state.status==='submitted'&&state.result?.status==='design_canvas_rejected'){state.status='design_canvas_rejected';this.save(state);}
      if (['submit_pending','design_canvas_rejected'].includes(state.status)) {
        const identity = snapshot.task_states?.find(task => task.id === state.task_id);
        if (identity && (identity.status === 'superseded' || identity.current_revision !== state.revision || identity.revision !== state.revision || identity.fingerprint !== state.fingerprint)) {
          state.status = 'superseded';
          state.events.push({ event: 'native_task_superseded', at: new Date(this.now()).toISOString(), current_revision: identity.current_revision });
          this.save(state);
          continue;
        }
        if(state.status==='design_canvas_rejected' && identity?.status==='assets_attached') {
          for (const image of Object.values(state.images)) { this.asset(image.asset); this.validateProof(image.proof); }
          state.events.push({event:'native_canvas_attachment_reconciled',at:new Date(this.now()).toISOString(),prior_result:state.result});
          state.status='submitted';state.result={ok:true,status:'native_assets_attached',task_id:state.task_id};this.save(state);continue;
        }
        if(state.status==='design_canvas_rejected')return this.block('flow_sleeve_canvas_invalid',state.task_id);
        for (const image of Object.values(state.images)) { this.asset(image.asset); this.validateProof(image.proof); }
        const result = await this.native.execute(state.command);
        if(result.status==='design_canvas_rejected'){state.status='design_canvas_rejected';state.result=result;this.save(state);return this.block('flow_sleeve_canvas_invalid',state.task_id);}
        state.status = 'submitted'; state.result = result; this.save(state);
        await this.native.cycle();
        await this.recoverNotice(); return this.status({ status: 'awaiting_human_review', task_id: state.task_id });
      }
    }
    if (!snapshot.tasks.length && !readinessOnly) { await this.recoverNotice(); return this.status({ status: 'idle', pending_reviews: snapshot.reviews?.length || 0 }); }
    const policy=snapshot.unusual_activity_policy;
    const providerFile=path.join(this.config.stateDir,'image-provider.json');
    const selectedBatch=fs.existsSync(providerFile)&&!!read(providerFile).batch_id;
    const passiveUnusual=selectedBatch&&!readinessOnly&&policy?.enabled===true&&policy.cooldown_ms===600000&&typeof policy.reference==='string'&&policy.reference.trim();
    const automaticCooldown=!selectedBatch&&!readinessOnly&&policy?.enabled===true&&policy.cooldown_ms===600000&&typeof policy.reference==='string'&&policy.reference.trim();
    const failurePolicy=snapshot.generation_failure_policy;
    const automaticFailure=!readinessOnly&&failurePolicy?.enabled===true&&failurePolicy.cooldown_ms===60000&&typeof failurePolicy.reference==='string'&&failurePolicy.reference.trim();
    if(passiveUnusual&&snapshot.tasks.length) {
      const target=this.task(snapshot,snapshot.tasks[0].id),journal=this.load(target),waiting=journal.unusual_activity_cooldown;
      if(waiting&&snapshot.account_policy?.on_unusual_activity!=='switch_account')this.armUnusualRetry(target,journal,policy);
      if(waiting?.wait_only) {
        if(snapshot.account_policy?.on_unusual_activity==='switch_account'){
          if(!this.browserStarted){await this.adapter.start();this.browserStarted=true;}
          return this.switchAfterUnusualFailure(target,journal,snapshot.account_policy);
        }
        this.armUnusualRetry(target,journal,policy);
        if(!Number.isFinite(Date.parse(waiting.not_before)))throw Error('unusual_activity_cooldown_checkpoint_invalid');
        if(this.now()<Date.parse(waiting.not_before))return this.beginUnusualCooldown(target,journal,waiting.image_key,policy,true);
        const image=journal.images[waiting.image_key];
        if(waiting.generation_id&&(image?.status!=='generation_started'||image.asset||image.generation_id!==waiting.generation_id))throw Error('unusual_activity_cooldown_checkpoint_invalid');
        const returnPermit=(snapshot.generation_retries||[]).find(p=>p.return_account_sha256&&p.task_id===target.id&&p.task_fingerprint===target.fingerprint&&p.revision===target.revision&&p.image_key===waiting.image_key&&p.generation_id===waiting.generation_id&&!journal.events.some(e=>e.event==='generation_retry_authorized'&&e.permit_id===p.permit_id));
        if(returnPermit&&(!Number.isFinite(Date.parse(returnPermit.not_before))||this.now()<Date.parse(returnPermit.not_before)))return this.cooldownStatus(target,{unusual_activity_cooldown:{...waiting,not_before:returnPermit.not_before}});
        this.asset({path:waiting.screenshot_path,sha256:waiting.screenshot_sha256});
        if(!this.browserStarted){await this.adapter.start();this.browserStarted=true;}
        const baseline=journal.failed_tiles_baseline||Object.values(journal.images).find(i=>i.status==='generation_started')?.recovery?.failure_baseline;
        if(baseline)this.adapter.failureBaseline=baseline;
        if(waiting.retry_after_cooldown&&policy.retry_after_cooldown===true) {
          const item=target.payload.images.find(i=>keyOf(i)===waiting.image_key);
          if(returnPermit){
            const prior=journal.events.find(e=>e.event==='generation_retry_authorized'&&e.image_key===waiting.image_key&&e.prior_generation?.generation_id===returnPermit.return_generation_id)?.prior_generation;
            const evidence=journal.events.find(e=>e.event==='unusual_account_handover'&&e.image_key===waiting.image_key&&e.generation_id===returnPermit.return_generation_id)?.unusual_activity_cooldown;
            if(returnPermit.cooldown_ms!==600000||!returnPermit.reference||!prior||!evidence)throw Error('flow_unusual_retry_binding_invalid');
            this.asset({path:evidence.screenshot_path,sha256:evidence.screenshot_sha256});
            journal.failed_tiles_baseline=await this.adapter.resumeUnusualOnPreviousAccount(item,prior,evidence,returnPermit.return_account_sha256,target.flow_project_key||target.batch_id);
          }else journal.failed_tiles_baseline=await this.adapter.resumeAfterUnusualFailure(item,image,waiting);
          this.save(journal);
        }
        const ready=await this.adapter.readiness();if(!ready.ready)return this.block(ready.code||'flow_login_required',target.id);
        if(typeof this.adapter.generationFailure!=='function')return this.block('flow_unusual_activity_check_unavailable',target.id);
        const failure=await this.adapter.generationFailure();if(failure)return this.block(failure,target.id);
        if(waiting.generation_id&&!returnPermit)await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:policy.reference,
          generation_retry:{task_id:target.id,task_fingerprint:target.fingerprint,revision:target.revision,image_key:waiting.image_key,generation_id:waiting.generation_id,reason:waiting.retry_after_cooldown?'User-authorized ten-minute wait completed; retain the saved Failed tile as history and issue one new Generate with the same prompt/references, never Retry. No claim that an account restriction cleared.':'Ten-minute wait completed and the provider warning is no longer present; continue the same checkpoint without changing session/network or suppressing warnings.'}});
        journal.events.push({event:waiting.retry_after_cooldown?'unusual_activity_retry_authorized':'unusual_warning_cleared',...waiting,at:new Date(this.now()).toISOString()});
        atomic(path.join(this.config.stateDir,'unusual-activity-cooldown.json'),{task_id:target.id,...waiting,consumed_at:new Date(this.now()).toISOString()});
        delete journal.unusual_activity_cooldown;this.save(journal);
        snapshot=await this.native.cycle();
      }
    }
    const accountCooldownFile=path.join(this.config.stateDir,'unusual-activity-cooldown.json');
    let accountCooldown;
    if(automaticCooldown&&fs.existsSync(accountCooldownFile)) {
      accountCooldown=read(accountCooldownFile);
      if(!Number.isFinite(Date.parse(accountCooldown.not_before)))throw Error('unusual_activity_cooldown_checkpoint_invalid');
      if(this.now()<Date.parse(accountCooldown.not_before))return this.cooldownStatus({id:accountCooldown.task_id},{unusual_activity_cooldown:accountCooldown});
    }
    let cooldownTask,cooldownState;
    if((automaticCooldown||automaticFailure)&&snapshot.tasks.length) {
      cooldownTask=this.task(snapshot,snapshot.tasks[0].id);cooldownState=this.load(cooldownTask);
      this.reconcileSkipped(cooldownTask,cooldownState);
      if(!cooldownState.unusual_activity_cooldown&&accountCooldown&&accountCooldown.task_id!==cooldownTask.id&&!accountCooldown.consumed_at
        &&!Object.values(cooldownState.images).some(image=>image.status==='generation_started')) {
        cooldownState.unusual_activity_cooldown={image_key:keyOf(cooldownTask.payload.images[0]),observed_at:accountCooldown.observed_at,
          not_before:accountCooldown.not_before,source_task_id:accountCooldown.task_id};
        cooldownState.events.push({event:'account_cooldown_carried_to_new_task',...cooldownState.unusual_activity_cooldown});this.save(cooldownState);
      }
      if(automaticCooldown&&!cooldownState.unusual_activity_cooldown) {
        const timedPermit=(snapshot.generation_retries||[]).find(p=>p.task_id===cooldownTask.id&&p.task_fingerprint===cooldownTask.fingerprint&&p.revision===cooldownTask.revision&&p.not_before&&
          cooldownState.images[p.image_key]?.status==='generation_started'&&cooldownState.images[p.image_key]?.generation_id===p.generation_id&&
          !cooldownState.events.some(e=>e.event==='generation_retry_authorized'&&e.permit_id===p.permit_id));
        if(timedPermit) {
          cooldownState.unusual_activity_cooldown={image_key:timedPermit.image_key,generation_id:timedPermit.generation_id,observed_at:timedPermit.authorized_at,
            not_before:timedPermit.not_before,permit_id:timedPermit.permit_id};
          cooldownState.events.push({event:'user_authorized_cooldown_started',...cooldownState.unusual_activity_cooldown});this.save(cooldownState);
        }
      }
      const waiting=automaticCooldown?cooldownState.unusual_activity_cooldown:null;
      if(waiting&&!Number.isFinite(Date.parse(waiting.not_before)))throw Error('unusual_activity_cooldown_checkpoint_invalid');
      if(waiting&&this.now()<Date.parse(waiting.not_before))return this.cooldownStatus(cooldownTask,cooldownState);
      const failed=cooldownState.generation_failure_cooldown;
      if(automaticFailure&&failed&&!waiting) {
        if(!Number.isFinite(Date.parse(failed.not_before)))throw Error('generation_failure_cooldown_checkpoint_invalid');
        if(this.now()<Date.parse(failed.not_before))return this.failureCooldownStatus(cooldownTask,cooldownState);
      }
    }
    if (!this.browserStarted) { await this.adapter.start(); this.browserStarted = true; }
    if(!readinessOnly&&snapshot.tasks.length){
      const target=this.task(snapshot,snapshot.tasks[0].id),journal=this.load(target);
      if(journal.model_switch_pending)return this.retryOnOtherModel(target,journal,journal.model_switch_pending.image_key,snapshot.model_fallback_policy);
      if(journal.account_switch_pending)return this.completeAccountSwitch(target,journal,snapshot.account_policy);
    }
    if(selectedBatch&&snapshot.tasks.length){
      const journal=this.load(this.task(snapshot,snapshot.tasks[0].id));
      const priorBaseline=journal.failed_tiles_baseline||Object.values(journal.images).find(i=>i.status==='generation_started')?.recovery?.failure_baseline;
      if(priorBaseline)this.adapter.failureBaseline=priorBaseline;
    }
    if(cooldownState) {
      const priorBaseline=cooldownState.failed_tiles_baseline||Object.values(cooldownState.images).find(i=>i.status==='generation_started')?.recovery?.failure_baseline;
      if(priorBaseline)this.adapter.failureBaseline=priorBaseline;
      const waiting=automaticCooldown?cooldownState.unusual_activity_cooldown:null;
      if(waiting) {
        if(!waiting.browser_restarted_at) {
          this.status({status:'recovering_browser',task_id:cooldownTask.id,image_key:waiting.image_key,code:'flow_unusual_activity_browser_restart'});
          await this.adapter.restartBrowser();
          waiting.browser_restarted_at=new Date(this.now()).toISOString();
          cooldownState.events.push({event:'unusual_activity_browser_restarted',image_key:waiting.image_key,generation_id:waiting.generation_id,at:waiting.browser_restarted_at});
          this.save(cooldownState);
        }
        const recovered=await this.adapter.readiness();
        if(!recovered.ready&&recovered.code!=='flow_unusual_activity_required')return this.block(recovered.code||'flow_login_required',cooldownTask.id);
        const baseline=await this.adapter.acknowledgeFailedTiles();
        if(waiting.generation_id&&!waiting.permit_id)await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:policy.reference,
          generation_retry:{task_id:cooldownTask.id,task_fingerprint:cooldownTask.fingerprint,revision:cooldownTask.revision,image_key:waiting.image_key,
            generation_id:waiting.generation_id,reason:'New Generate after the user-authorized ten-minute unusual-activity cooldown; never click Retry.'}});
        cooldownState.failed_tiles_baseline=baseline;
        cooldownState.events.push({event:'unusual_activity_cooldown_completed',...waiting,at:new Date(this.now()).toISOString()});
        atomic(accountCooldownFile,{task_id:cooldownTask.id,...waiting,consumed_at:new Date(this.now()).toISOString()});
        delete cooldownState.unusual_activity_cooldown;this.save(cooldownState);
      }
    }
    if(!readinessOnly&&snapshot.tasks.length&&typeof this.adapter.ensureProject==='function'){
      const selected=this.task(snapshot,snapshot.tasks[0].id),journal=this.load(selected);
      if(!Object.values(journal.images).some(image=>image.status==='generation_started'))await this.adapter.ensureProject(selected.flow_project_key||selected.batch_id||'listing-'+(selected.code||selected.brief_id));
    }
    let ready = await this.adapter.readiness();
    if (ready.code === 'flow_browser_closed' && typeof this.adapter.recoverBrowser === 'function' && !this.stopping) ready = await this.adapter.recoverBrowser();
    if(!ready.ready&&ready.code==='flow_unusual_activity_required'&&passiveUnusual&&snapshot.tasks.length) {
      const target=this.task(snapshot,snapshot.tasks[0].id),journal=this.load(target);
      const item=target.payload.images.find(i=>journal.images[keyOf(i)]?.status!=='acquired');
      if(item&&snapshot.account_policy?.on_unusual_activity==='switch_account')return this.switchAfterUnusualFailure(target,journal,snapshot.account_policy,keyOf(item));
      if(item)return this.beginUnusualCooldown(target,journal,keyOf(item),policy,true);
    }
    if(!ready.ready&&ready.code==='flow_unusual_activity_required'&&automaticCooldown&&cooldownTask) {
      const item=cooldownTask.payload.images.find(i=>cooldownState.images[keyOf(i)]?.status!=='acquired');
      if(item)return this.beginUnusualCooldown(cooldownTask,cooldownState,keyOf(item),policy);
    }
    if (!ready.ready) return this.block(ready.code || 'flow_login_required');
    if (readinessOnly) { await this.recoverNotice(); return this.status({ status: 'ready', ready: true, tasks: snapshot.tasks.length, generation_performed: false }); }
    if(automaticFailure&&cooldownState?.generation_failure_cooldown) {
      const waiting=cooldownState.generation_failure_cooldown,image=cooldownState.images[waiting.image_key];
      if(image?.status!=='generation_started'||image.asset||image.generation_id!==waiting.generation_id)throw Error('generation_failure_cooldown_checkpoint_invalid');
      this.asset({path:waiting.screenshot_path,sha256:waiting.screenshot_sha256});
      if(typeof this.adapter.generationFailure==='function') {
        const failure=await this.adapter.generationFailure();
        if(failure==='flow_generation_might_violate'&&cooldownTask.kind==='flow_batch_images'&&cooldownTask.stage==='mockups'){
          await this.skipMockup(cooldownTask,cooldownState,waiting.image_key);
          return this.status({status:'preparing_flow',task_id:cooldownTask.id,code:'mockup_skipped'});
        }
        if(failure&&!['flow_generation_failed','flow_generation_might_violate'].includes(failure))return this.block(failure,cooldownTask.id);
      }
      cooldownState.failed_tiles_baseline=await this.adapter.acknowledgeFailedTiles();
      await this.native.execute({action:'flow_cycle',authority:'direct_user',reference:failurePolicy.reference,
        generation_retry:{task_id:cooldownTask.id,task_fingerprint:cooldownTask.fingerprint,revision:cooldownTask.revision,
          image_key:waiting.image_key,generation_id:waiting.generation_id,reason:'Confirmed generation Failed; new Generate after the user-authorized one-minute cooldown.'}});
      cooldownState.events.push({event:'generation_failure_cooldown_completed',...waiting,at:new Date(this.now()).toISOString()});
      delete cooldownState.generation_failure_cooldown;this.save(cooldownState);
    }
    snapshot = await this.native.cycle();
    if (!snapshot.tasks.length) return this.status({ status: 'idle', pending_reviews: snapshot.reviews?.length || 0 });
    const task = this.task(snapshot, snapshot.tasks[0].id);
    const state = this.load(task);
    this.reconcileSkipped(task,state);
    for (const permit of snapshot.generation_retries || []) {
      if(permit.not_before&&(!Number.isFinite(Date.parse(permit.not_before))||this.now()<Date.parse(permit.not_before)))continue;
      if (permit.task_id !== task.id || permit.task_fingerprint !== task.fingerprint || permit.revision !== task.revision || state.events.some(e => e.event === 'generation_retry_authorized' && e.permit_id === permit.permit_id)) continue;
      const image = state.images[permit.image_key];
      if (!image || image.status !== 'generation_started' || image.asset || image.generation_id !== permit.generation_id || !permit.reference || !/^[a-f0-9]{64}$/.test(permit.permit_id)) continue;
      state.events.push({ event: 'generation_retry_authorized', permit_id: permit.permit_id, image_key: permit.image_key, prior_generation: image, reference: permit.reference, at: new Date(this.now()).toISOString() });
      state.images[permit.image_key] = { status: 'ready', retry_permit_id: permit.permit_id };
      this.save(state);
    }
    const outputDir = task.payload.output_directory || path.join(this.config.workflowRoot, 'workspace/production/artifacts', task.code, 'v' + String(task.revision).padStart(3, '0'), 'flow-originals', task.id);
    fs.mkdirSync(outputDir, { recursive: true });
    const expected = task.payload.images.filter(i => (!task.missing_regions || task.missing_regions.includes(i.region))&&state.images[keyOf(i)]?.status!=='skipped');
    if (!expected.length) return this.status({ status: 'idle', task_id: task.id });
    for (const item of expected) {
      if (this.stopping) return this.status({ status: 'stopping', task_id: task.id });
      const imageKey = keyOf(item);
      if (state.images[imageKey]?.status === 'acquired') continue;
      const live = this.task(await this.native.cycle(), task.id);
      if (live.fingerprint !== task.fingerprint || jsonHash(live.payload) !== state.payload_hash || live.flow_project_key!==task.flow_project_key) throw new Error('task_changed_before_generation');
      if (task.kind.startsWith('flow_design_')) {
        const same = task.payload.images.find(other => keyOf(other) !== imageKey && state.images[keyOf(other)]?.status === 'acquired'
          && other.prompt === item.prompt && other.aspect_ratio === item.aspect_ratio && other.output_aspect_ratio === item.output_aspect_ratio
          && JSON.stringify(this.references(task, other).map(r => r.sha256).sort()) === JSON.stringify(this.references(task, item).map(r => r.sha256).sort()));
        if (same) {
          state.images[imageKey] = { ...state.images[keyOf(same)], reused_from: keyOf(same) };
          state.events.push({ event: 'identical_design_reused', image_key: imageKey, reused_from: keyOf(same), at: new Date(this.now()).toISOString() });
          this.save(state); continue;
        }
      }
      const checkpoint = async record => {
        state.events.push({ ...record, image_key: imageKey, at: new Date(this.now()).toISOString() });
        if (record.event === 'generation_started') state.images[imageKey] = { ...(state.images[imageKey] || {}), ...record, status: 'generation_started' };
        if (record.event === 'acquired' && record.asset && record.proof) {
          const asset = this.asset(record.asset, outputDir);
          const proof = this.validateProof(record.proof);
          state.images[imageKey] = { ...state.images[imageKey], ...(record.generation_id?{generation_id:record.generation_id}:{}), status: 'acquired', asset, proof };
        }
        this.save(state);
      };
      this.status({ status: state.images[imageKey]?.status === 'generation_started' ? 'waiting_generation' : 'preparing_flow', task_id: task.id, image_key: imageKey });
      let result;
      try { result = await this.adapter.generate(item, this.references(task, item), outputDir, {
        projectKey: task.flow_project_key || task.batch_id || 'listing-'+(task.code||task.brief_id),
        resume: state.images[imageKey] || null,
        retryRecovery: state.images[imageKey]?.retry_permit_id ? (()=>{
          const prior=state.events.find(e=>e.event==='generation_retry_authorized'&&e.permit_id===state.images[imageKey].retry_permit_id&&e.image_key===imageKey)?.prior_generation;
          return prior?.recovery?{...prior,recovery:{...prior.recovery,failure_baseline:state.failed_tiles_baseline||prior.recovery.failure_baseline}}:undefined;
        })() : undefined,
        beforeGenerate: async metadata => {
          if (state.images[imageKey]?.status === 'generation_started') throw new Error('generation_already_started_reconcile_required');
          const current = this.task(await this.native.cycle(), task.id);
          if (current.fingerprint !== task.fingerprint || jsonHash(current.payload) !== state.payload_hash || current.flow_project_key!==task.flow_project_key) throw new Error('task_changed_before_click');
          await checkpoint({ ...metadata, event: 'generation_started' });
          this.status({ status: 'waiting_generation', task_id: task.id, image_key: imageKey });
        }, checkpoint,
      }); } catch(error) {
        if (['flow_generate_disabled','flow_generate_not_ready'].includes(error.code||error.message)
            && (!state.images[imageKey] || ['ready','generation_failed'].includes(state.images[imageKey].status))) {
          await this.recoverNotice();
          return this.status({status:'preparing_flow',code:error.code||error.message,task_id:task.id,image_key:imageKey,
            automatic_retry:true,requires_user_resume:false,next_action:'check_generate',
            next_check_at:new Date(this.now()+this.config.pollIntervalMs).toISOString()});
        }
        if((error.code||error.message)==='flow_quota_required'&&snapshot.model_fallback_policy?.enabled){
          if(this.adapter.config.model!=='Nano Banana 2.1')return this.retryOnOtherModel(task,state,imageKey,snapshot.model_fallback_policy);
          return this.block('flow_model_retry_exhausted',task.id);
        }
        if((error.code||error.message)==='flow_quota_required'&&snapshot.account_policy?.enabled)return this.retryOnOtherAccount(task,state,imageKey,snapshot.account_policy);
        if((error.code||error.message)==='flow_unusual_activity_required'&&passiveUnusual&&snapshot.account_policy?.on_unusual_activity==='switch_account')return this.switchAfterUnusualFailure(task,state,snapshot.account_policy,imageKey);
        if((error.code||error.message)==='flow_unusual_activity_required'&&passiveUnusual)return this.beginUnusualCooldown(task,state,imageKey,policy,true);
        if((error.code||error.message)==='flow_unusual_activity_required'&&automaticCooldown)return this.beginUnusualCooldown(task,state,imageKey,policy);
        if((error.code||error.message)==='flow_generation_might_violate'&&task.kind==='flow_batch_images'&&task.stage==='mockups'){
          await this.skipMockup(task,state,imageKey);continue;
        }
        if(['flow_generation_failed','flow_generation_might_violate'].includes(error.code||error.message)&&automaticFailure) {
          try{return await this.beginFailureCooldown(task,state,imageKey,failurePolicy);}
          catch(e){
            if((e.code||e.message)==='flow_unusual_activity_required'&&passiveUnusual&&snapshot.account_policy?.on_unusual_activity==='switch_account')return this.switchAfterUnusualFailure(task,state,snapshot.account_policy,imageKey);
            if((e.code||e.message)==='flow_unusual_activity_required'&&passiveUnusual)return this.beginUnusualCooldown(task,state,imageKey,policy,true);
            if((e.code||e.message)==='flow_unusual_activity_required'&&automaticCooldown)return this.beginUnusualCooldown(task,state,imageKey,policy);throw e;
          }
        }
        throw error;
      }
      if (!state.images[imageKey] || !['generation_started', 'acquired'].includes(state.images[imageKey].status)) throw new Error('generation_checkpoint_missing');
      const asset = this.asset(result.asset, outputDir);
      const proof = this.validateProof(result.proof);
      state.images[imageKey] = { ...state.images[imageKey], status: 'acquired', asset, proof };
      state.events.push({ event: 'acquired', image_key: imageKey, asset, at: new Date(this.now()).toISOString() });
      this.save(state);
    }
    const current = this.task(await this.native.cycle(), task.id);
    if (current.fingerprint !== task.fingerprint) throw new Error('task_changed_before_submit');
    const delivered=expected.filter(i=>state.images[keyOf(i)]?.status!=='skipped');
    if(!delivered.length)throw Error('mockup_valid_image_required');
    const assets = delivered.map(i => ({ image_key: keyOf(i), ...this.asset(state.images[keyOf(i)].asset, outputDir) }));
    if (['flow_images', 'flow_batch_images'].includes(task.kind) && new Set(assets.map(a => a.sha256)).size !== delivered.length) throw new Error('mockup_originals_must_be_distinct');
    const firstProof = state.images[keyOf(delivered[0])].proof;
    state.command = { action: 'flow_auto_submit', task_id: task.id, revision: task.revision, task_fingerprint: task.fingerprint, assets,
      proof: { model: firstProof.model, ...(firstProof.model_policy_reference?{model_policy_reference:firstProof.model_policy_reference}:{}), url: firstProof.url, screenshot_path: firstProof.screenshot_path, screenshot_sha256: firstProof.screenshot_sha256, executor: 'independent_flow_worker', acquisition: 'flow_download',
        prompt_provenance: delivered.map(i => ({ image_key: keyOf(i), prompt_sha256: hash(i.prompt), reference_sha256: this.references(task, i).map(r => r.sha256).sort() })),
        images: delivered.map(i => ({ image_key: keyOf(i), ...state.images[keyOf(i)].proof })) } };
    if (task.kind === 'flow_batch_images') Object.assign(state.command, { batch_id: task.batch_id, item_id: task.item_id });
    state.status = 'submit_pending'; this.save(state);
    state.result = await this.native.execute(state.command);
    if(state.result.status==='design_canvas_rejected'){state.status='design_canvas_rejected';this.save(state);return this.block('flow_sleeve_canvas_invalid',task.id);}
    state.status = 'submitted'; this.save(state);
    await this.native.cycle();
    await this.recoverNotice();
    return this.status({ status: 'awaiting_human_review', task_id: task.id });
  }
  validateProof(proof) {
    const modelAllowed=proof?.model==='Nano Banana Pro'||(proof?.model==='Nano Banana 2.1'&&this.modelPolicy?.enabled&&proof.model_policy_reference===this.modelPolicy.reference);
    if (!modelAllowed || !/^https:\/\/flow\.google\.com\//.test(proof.url || '') || proof.visually_verified === true || (proof.acquisition?.method || proof.acquisition) !== 'flow_download') throw new Error('real_flow_download_proof_required');
    const screenshot = this.asset({ path: proof.screenshot_path, sha256: hash(fs.readFileSync(proof.screenshot_path)) });
    if (proof.screenshot_sha256 && proof.screenshot_sha256 !== screenshot.sha256) throw new Error('proof_screenshot_changed');
    return { ...proof, screenshot_sha256: screenshot.sha256 };
  }
  async run({ once = false, readinessOnly = false } = {}) {
    const release = claimProcessLock(path.join(this.config.stateDir, 'worker.lock'));
    const stopFile = path.join(this.config.stateDir, 'stop.request');
    const watch = fs.watch(this.config.stateDir, () => { if (fs.existsSync(stopFile)) this.stop().catch(() => {}); });
    try {
      this.status({ status: 'starting' });
      while (!this.stopping) {
        if (fs.existsSync(path.join(this.config.stateDir, 'stop.request'))) break;
        try { await this.tick({ readinessOnly }); }
        catch (error) {
          if(this.stopping)break;
          const raw = error.code || error.message || 'worker_failed';
          const code = /^[a-z0-9_-]{1,100}$/i.test(raw) ? raw : 'flow_action_failed';
          if (code === 'flow_action_failed') {
            fs.mkdirSync(this.config.logDir, { recursive: true });
            atomic(path.join(this.config.logDir, 'last-action-error.private.json'), { message: error.message, at: new Date(this.now()).toISOString() });
          }
          await this.block(code);
        }
        if (once || readinessOnly) break;
        await new Promise(resolve => { this.wake = resolve; this.timer = setTimeout(resolve, this.config.pollIntervalMs); });
        clearTimeout(this.timer); this.wake = null;
      }
    } finally {
      watch.close();
      try { await this.adapter.close(); } finally {
        this.native.stop?.(); release();
        const statusFile = path.join(this.config.stateDir, 'status.json');
        const current = fs.existsSync(statusFile) ? read(statusFile) : { status: 'not_started' };
        if (!once && !readinessOnly) this.status({ ...current, status: 'stopped', previous_status: current.status });
      }
    }
  }
  async stop() { this.stopping = true; clearTimeout(this.timer); this.wake?.(); await this.adapter.close(); this.native.stop?.(); }
}
async function main() {
  const file = process.env.FLOW_WORKER_CONFIG || path.join(WORKFLOW_ROOT, 'config/flow-worker.private.json');
  const config = validateConfig({ ...defaults(), ...read(file) });
  const providerFile = path.join(config.stateDir, 'image-provider.json');
  if (fs.existsSync(providerFile) && read(providerFile).provider === 'chatgpt') return require('../chatgpt-worker/runtime.cjs').main(config);
  config.mandatoryOutlineRule = read(path.join(config.workflowRoot, 'config/artwork-flow-prompts.json')).mandatory_outline_rule;
  const { FlowBrowser } = require('./flow-browser.cjs');
  const worker = new FlowRuntime(config, { adapter: new FlowBrowser(config) });
  process.once('SIGINT', () => worker.stop()); process.once('SIGTERM', () => worker.stop());
  await worker.run({ once: process.argv.includes('--once'), readinessOnly: process.argv.includes('--check') });
  if (process.argv.includes('--once') || process.argv.includes('--check')) console.log(JSON.stringify(read(path.join(config.stateDir, 'status.json'))));
}
module.exports = { FlowRuntime, defaults, validateConfig, hash };
if (require.main === module) main().catch(error => { console.error(JSON.stringify({ ok: false, code: error.code || error.message || 'worker_start_failed' })); process.exitCode = 1; });
