'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {EventEmitter}=require('node:events');
const {PoolSupervisor}=require('./pool.cjs');

function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'three-flow-lanes-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const lanes=[1,2,3].map(id=>{const configFile=path.join(root,'lane'+id+'.json');fs.writeFileSync(configFile,JSON.stringify({workerLane:id,profileDir:path.join(root,'profile'+id),stateDir:path.join(root,'state'+id),logDir:path.join(root,'logs'+id)}));return{id,email:`account${id}@example.com`,configFile};});
  const started=[];let time=100;
  const pool=new PoolSupervisor({workflowRoot:root,stateDir:root,lanes},{now:()=>time,spawn:(_exe,args,options)=>{const child=new EventEmitter();child.pid=100+started.length;started.push({child,args,options});return child;}});
  return{root,lanes,started,pool,time:n=>time=n};
}
test('starts exactly three isolated persistent workers, never a fourth on another tick',t=>{
  const f=fixture(t);f.pool.tick();f.pool.tick();assert.equal(f.started.length,3);
  assert.equal(new Set(f.started.map(x=>x.options.env.FLOW_WORKER_CONFIG)).size,3);
  assert.ok(f.started.every(x=>x.options.windowsHide===true));
  assert.equal(f.pool.status().workers.length,3);
});
test('one process crash restarts only that lane and preserves its existing state files',t=>{
  const f=fixture(t);f.pool.tick();const config=JSON.parse(fs.readFileSync(f.lanes[1].configFile));fs.mkdirSync(config.stateDir,{recursive:true});const journal=path.join(config.stateDir,'checkpoint.json');fs.writeFileSync(journal,'keep-exact');
  f.started[1].child.emit('exit',1);f.time(10000);f.pool.tick();assert.equal(f.started.length,4);assert.equal(f.started[3].options.env.FLOW_WORKER_CONFIG,f.lanes[1].configFile);assert.equal(fs.readFileSync(journal,'utf8'),'keep-exact');
});
test('graceful pool stop writes only each owned lane stop request and does not kill unrelated processes',async t=>{
  const f=fixture(t);f.pool.tick();await f.pool.stop();for(const lane of f.lanes){const config=JSON.parse(fs.readFileSync(lane.configFile));assert.ok(fs.existsSync(path.join(config.stateDir,'stop.request')));}f.pool.tick();assert.equal(f.started.length,3);
});
test('duplicate profile or account configuration is rejected before launching Chrome',t=>{
  const f=fixture(t),c=JSON.parse(fs.readFileSync(f.lanes[1].configFile));c.profileDir=JSON.parse(fs.readFileSync(f.lanes[0].configFile)).profileDir;fs.writeFileSync(f.lanes[1].configFile,JSON.stringify(c));assert.throws(()=>new PoolSupervisor({workflowRoot:f.root,stateDir:f.root,lanes:f.lanes}),/isolated/);
});

test('disabled login lanes have no worker process and stay disabled across ticks',t=>{
 const f=fixture(t);
 for(const lane of f.lanes.slice(1)){const c=JSON.parse(fs.readFileSync(lane.configFile));fs.mkdirSync(c.stateDir,{recursive:true});fs.writeFileSync(path.join(c.stateDir,'worker.disabled.json'),'{}');}
 f.pool.tick();f.pool.tick();assert.equal(f.started.length,1);
 const status=f.pool.status();assert.ok(status.workers.slice(1).every(x=>x.status==='disabled'&&x.pid===null));
});

test('temporary Windows sharing denial cannot stop worker management or leave status stale',t=>{
 const f=fixture(t);let writes=0;
 f.pool.write=(_file,value)=>{if(writes++===0)throw Object.assign(Error('sharing denial'),{code:'EPERM'});assert.equal(value.maximum_workers,3);};
 assert.equal(f.pool.tick().status_write_pending,true);assert.equal(f.started.length,3);
 assert.equal(f.pool.tick().status_write_pending,undefined);assert.equal(f.started.length,3);assert.equal(writes,2);
});

test('fatal pool loop error gracefully releases owned workers before unlocking and exiting',async t=>{
 const f=fixture(t);f.pool.tick();f.pool.tick=()=>{throw Error('fixture-fatal');};
 const running=f.pool.run();
 setImmediate(()=>{for(const lane of f.lanes){const c=JSON.parse(fs.readFileSync(lane.configFile));assert.ok(fs.existsSync(path.join(c.stateDir,'stop.request')));}for(const child of f.started)child.child.emit('exit',0);});
 await assert.rejects(running,/fixture-fatal/);assert.equal(fs.existsSync(path.join(f.root,'pool-supervisor.lock')),false);assert.ok(f.pool.records.every(r=>!r.child));
});
