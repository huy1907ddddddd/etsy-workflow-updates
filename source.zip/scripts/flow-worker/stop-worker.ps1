$ErrorActionPreference = 'Stop'
$flowConfig = Get-Content -LiteralPath 'C:\Huy\etsy-workflow\config\flow-worker.private.json' -Raw | ConvertFrom-Json
$flowState = [IO.Path]::GetFullPath($flowConfig.stateDir)
$flowExpectedRoot = [IO.Path]::GetFullPath('C:\Huy\etsy-workflow\workspace\flow-worker') + [IO.Path]::DirectorySeparatorChar
if (!$flowState.StartsWith($flowExpectedRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Worker state directory outside expected root.' }
New-Item -ItemType Directory -Path $flowState -Force | Out-Null
[IO.File]::WriteAllText((Join-Path $flowState 'stop.request'),[DateTimeOffset]::UtcNow.ToString('o'))
Write-Output 'Stop requested. Worker closes only its owned browser and CLI process; checkpoints are preserved.'
