'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { FlowRuntime, defaults, validateConfig, hash } = require('./runtime.cjs');

function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-runtime-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, 'config'));
  fs.writeFileSync(path.join(root, 'config/artwork-flow-prompts.json'), JSON.stringify({ mandatory_outline_rule: 'NO OUTLINE' }));
  fs.writeFileSync(path.join(root, 'config/artwork-approved-quality-standard.json'), JSON.stringify({ assets: [] }));
  fs.writeFileSync(path.join(root, 'config/mockup-wardrobe-standard.json'), '{}');
  const config = { ...defaults(root), n8nCli: __filename, projectUrl: 'https://flow.google.com/project/test-only', maxSnapshotAgeMs: 30000 };
  const output = path.join(root, 'workspace/production/designs/TEST/v001/2d'); fs.mkdirSync(output, { recursive: true });
  const ref = path.join(root, 'reference.png'); fs.writeFileSync(ref, 'reference-test-only');
  const task = { id: 'task-test-only', revision: 1, fingerprint: 'a'.repeat(64), status: 'pending', kind: 'flow_design_2d', brief_id: 'TEST',
    payload: { provider: 'Flow Nano Banana Pro', revision: 1, brief_id: 'TEST', stage: '2d', output_directory: output,
      images: [{ region: 'chest', name: 'chest.png', prompt: 'TEST\nNO OUTLINE', references: [{ path: ref, sha256: hash('reference-test-only') }] }] } };
  let currentTasks = [task]; const calls = { generate: 0, execute: [], cycle: 0, before: 0, notify: [], start: 0, closed: 0, restarted: 0 };
  const native = {
    cycle: async () => { calls.cycle++; return { ok: true, observed_at: new Date().toISOString(), tasks: currentTasks, reviews: [] }; },
    execute: async command => { calls.execute.push(command); currentTasks = []; return { ok: true, quality_verified: false }; }, stop: () => {} };
  const result = () => {
    const file = path.join(output, 'generated.png'); fs.writeFileSync(file, 'fake-test-only-image');
    const screenshot = path.join(output, 'proof.png'); fs.writeFileSync(screenshot, 'fake-test-only-screen');
    return { asset: { path: file, sha256: hash('fake-test-only-image') }, proof: { model: 'Nano Banana Pro', url: 'https://flow.google.com/project/test-only', screenshot_path: screenshot, acquisition: { method: 'flow_download' } } };
  };
  const adapter = { start: async () => { calls.start++; }, restartBrowser: async () => { calls.restarted++; }, readiness: async () => ({ ready: true }), close: async () => { calls.closed++; },
    generate: async (_item, _refs, _dir, hooks) => {
      calls.generate++; if (!hooks.resume) { await hooks.beforeGenerate({ generation_id: 'generation-test', recovery: { baseline: ['old-image'], project_url: config.projectUrl } }); calls.before++; }
      return result();
    } };
  const runtime = new FlowRuntime(config, { native, adapter, notify: async status => calls.notify.push(status) });
  runtime.larkReadiness = async () => ({ ready: true });
  return { root, config, task, runtime, native, adapter, calls, result, setTasks: tasks => { currentTasks = tasks; } };
}

test('pooled Chrome verifies its own account before readiness and waits for login without generating',async t=>{
  const f=fixture(t);f.config.workerLane=1;
  fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({account_policy:{preferred_email:'own@example.com'},reference:'Fixture human requests fixed lane'}));
  const login=path.join(f.config.stateDir,'manual-login.request');fs.writeFileSync(login,'Fixture user pauses worker to sign in');
  assert.equal((await f.runtime.tick()).status,'paused_for_login');assert.equal(f.calls.start,0);assert.equal(f.calls.generate,0);fs.unlinkSync(login);
  f.adapter.config={};f.adapter.verifyAccount=async()=>{throw Object.assign(Error('login'),{code:'flow_login_required'});};
  assert.equal((await f.runtime.tick()).status,'login_required');assert.equal(f.calls.generate,0);assert.equal(f.calls.execute.length,0);
  f.adapter.verifyAccount=async email=>assert.equal(email,'own@example.com');f.setTasks([]);
  assert.equal((await f.runtime.tick()).status,'idle');assert.equal(f.calls.execute[0].action,'batch_pool_ready');assert.equal(f.calls.generate,0);
  const proof=JSON.parse(fs.readFileSync(f.calls.execute[0].evidence_path));assert.equal(proof.worker_lane,1);assert.equal(proof.verified_email,'own@example.com');
});

test('pooled Main cycle publishes a missing native review once and reads it back without approval',async t=>{
 const f=fixture(t),file=path.join(f.root,'config/review-fixture.json');fs.writeFileSync(file,JSON.stringify({localToken:'fixture-only'}));f.config.larkConfigFile=file;f.config.workerLane=1;
 const packet={review_id:'native-review-fixture',entity:{brief_id:'TEST'},fingerprint:'a'.repeat(64)},calls=[];let exists=false;
 f.runtime.fetch=async(url,options={})=>{calls.push({url,options});if(options.method==='POST'){assert.deepEqual(JSON.parse(options.body),packet);exists=true;return new Response(JSON.stringify({ok:true,review_id:packet.review_id,status:'sending'}),{status:202});}return new Response(JSON.stringify(exists?{ok:true,review:{review_id:packet.review_id,status:'pending',expires_at:Date.now()+60000}}:{ok:false,code:'review_not_found'}),{status:exists?200:404});};
 await f.runtime.renewExpiredReviews({reviews:[packet]});await f.runtime.renewExpiredReviews({reviews:[packet]});
 assert.equal(calls.filter(x=>x.options.method==='POST').length,1);assert.equal(f.calls.execute.length,0);assert.equal(f.calls.generate,0);
});

test('missing review publication never retries unauthorized access or publishes a mismatched packet',async t=>{
 const f=fixture(t),file=path.join(f.root,'config/review-fixture.json');fs.writeFileSync(file,JSON.stringify({localToken:'fixture-only'}));f.config.larkConfigFile=file;f.config.workerLane=1;
 let posts=0,status=401;f.runtime.fetch=async(_url,options={})=>{if(options.method==='POST')posts++;return new Response('{}',{status});};
 await assert.rejects(f.runtime.getReviewState('wanted',{review_id:'wanted'}),/lark_review_state_unavailable/);status=404;
 await assert.rejects(f.runtime.getReviewState('wanted',{review_id:'different'}),/lark_review_state_unavailable/);assert.equal(posts,0);
});
test('independent runtime downloads then submits native candidate without visual approval', async t => {
  const f = fixture(t); const status = await f.runtime.tick();
  assert.equal(status.build, '20261026-pajama-set1');
  assert.equal(status.status, 'awaiting_human_review'); assert.equal(f.calls.generate, 1); assert.equal(f.calls.before, 1);
  const command = f.calls.execute[0]; assert.equal(command.action, 'flow_auto_submit');
  assert.equal(command.proof.executor, 'independent_flow_worker'); assert.equal(command.proof.visually_verified, undefined);
  assert.equal(command.proof.prompt_provenance[0].prompt_sha256, hash(f.task.payload.images[0].prompt));
  assert.equal(f.runtime.load(f.task).status, 'submitted');
});

test('pre-click Generate readiness waits for the next tick without stopping a batch or replacing acquired work',async t=>{
  const f=fixture(t),state=f.runtime.load(f.task),acquired={status:'acquired',...f.result()};
  state.images.retained=acquired;f.runtime.save(state);
  const generate=f.adapter.generate;let failures=2;
  f.adapter.generate=async(...args)=>{if(failures--)throw Object.assign(Error('temporarily disabled'),{code:failures?'flow_generate_disabled':'flow_generate_not_ready'});return generate(...args);};
  for(const code of ['flow_generate_disabled','flow_generate_not_ready']){
    const status=await f.runtime.tick();assert.equal(status.status,'preparing_flow');assert.equal(status.code,code);
    assert.equal(status.automatic_retry,true);assert.equal(status.requires_user_resume,false);assert.equal(status.next_action,'check_generate');
    assert(Number.isFinite(Date.parse(status.next_check_at)));assert.equal(f.calls.before,0);assert.equal(f.calls.execute.length,0);
    assert.equal(fs.existsSync(path.join(f.config.stateDir,'workflow-error-hold.json')),false);
    assert.deepEqual(f.runtime.load(f.task).images.retained,acquired);
  }
  assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(f.calls.before,1);
  assert.deepEqual(f.runtime.load(f.task).images.retained,acquired);
});

test('Generate readiness never retries after a durable generation marker or disguises provider/login blocks',async t=>{
  const f=fixture(t);
  f.adapter.generate=async(_item,_refs,_out,hooks)=>{await hooks.beforeGenerate({generation_id:'uncertain-existing',recovery:{baseline:[]}});throw Object.assign(Error('disabled after marker'),{code:'flow_generate_disabled'});};
  await assert.rejects(f.runtime.tick(),{code:'flow_generate_disabled'});
  assert.equal(f.runtime.load(f.task).images.chest.generation_id,'uncertain-existing');
  assert.equal(f.runtime.load(f.task).images.chest.status,'generation_started');
  for(const code of ['flow_login_required','flow_policy_review_required','flow_quota_required']){
    f.adapter.generate=async()=>{throw Object.assign(Error(code),{code});};
    await assert.rejects(f.runtime.tick(),{code});
  }
});

test('quota handover keeps the failed generation until exact native permit; restart resumes transition without Generate',async t=>{
 const f=fixture(t),s=f.runtime.load(f.task),policy={enabled:true,reference:'Fixture user authorizes signed-in accounts',accounts:[{email:'first@example.com'},{email:'second@example.com'}]};
 s.images.chest={status:'generation_started',generation_id:'quota-old'};f.runtime.save(s);
 f.adapter.quotaTarget=()=> 'second@example.com';let switched=0,failOnce=true;
 f.adapter.switchAccount=async email=>{assert.equal(email,'second@example.com');switched++;};f.adapter.ensureProject=async()=>{};
 f.native.execute=async cmd=>{if(failOnce){failOnce=false;throw Error('native_execution_busy');}f.calls.execute.push(cmd);return {ok:true};};
 await assert.rejects(f.runtime.retryOnOtherAccount(f.task,s,'chest',policy),/native_execution_busy/);
 assert.equal(f.runtime.load(f.task).images.chest.generation_id,'quota-old');assert.equal(f.calls.generate,0);
 const cycle=f.native.cycle;f.native.cycle=async()=>({...await cycle(),account_policy:policy});
 const state=await f.runtime.tick();assert.equal(state.code,'flow_account_handover_ready');assert.equal(switched,2);
 assert.equal(f.calls.execute[0].generation_retry.generation_id,'quota-old');assert.equal(f.calls.execute[0].reference,policy.reference);
 assert.equal(f.runtime.load(f.task).account_switch_pending,undefined);assert.equal(f.calls.generate,0);
 s.images.chest.asset={path:'already-acquired'};
 await assert.rejects(f.runtime.retryOnOtherAccount(f.task,s,'chest',policy),{code:'flow_quota_required'});
});

test('quota rotation stops after both accounts are exhausted, and never authorizes an unbound retry',async t=>{
 const f=fixture(t),s=f.runtime.load(f.task),policy={enabled:true,reference:'Fixture user',accounts:[]};s.images.chest={status:'generation_started',generation_id:'quota-last'};
 f.adapter.quotaTarget=()=>null;let blocked;f.runtime.block=async code=>(blocked=code);
 await f.runtime.retryOnOtherAccount(f.task,s,'chest',policy);assert.equal(blocked,'flow_accounts_exhausted');assert.equal(f.calls.execute.length,0);
 s.account_switch_pending={image_key:'chest',generation_id:'stale',policy_reference:policy.reference,target_email:'first@example.com'};
 await assert.rejects(f.runtime.completeAccountSwitch(f.task,s,policy),/binding_invalid/);assert.equal(f.calls.generate,0);
});

test('unusual account handover skips the old ten-minute deadline, preserves evidence and acquired work, and requires the exact native permit',async t=>{
 const f=fixture(t);let now=Date.now(),targets=0,switched=0,failOnce=true;
 f.runtime.now=()=>now;
 const policy={enabled:true,reference:'Fixture user authorizes immediate unusual account switch',on_unusual_activity:'switch_account',accounts:[{email:'first@example.com'},{email:'second@example.com'},{email:'third@example.com'}]};
 const unusual={enabled:true,cooldown_ms:600000,retry_after_cooldown:true,reference:'Earlier wait policy'};
 fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({batch_id:'fixture-batch'}));
 const s=f.runtime.load(f.task),file=path.join(f.root,'unusual.png');fs.writeFileSync(file,'saved-evidence');
 s.images.chest={status:'generation_started',generation_id:'unusual-old',recovery:{project_url:f.config.projectUrl,prompt_sha256:hash(f.task.payload.images[0].prompt)}};
 s.images.already_done={status:'acquired',...f.result(),generation_id:'done'};
 const acquired=JSON.stringify(s.images.already_done);
 s.unusual_activity_cooldown={image_key:'chest',generation_id:'unusual-old',wait_only:true,retry_after_cooldown:true,retry_policy_reference:unusual.reference,
  not_before:new Date(now+600000).toISOString(),failed_tiles:['Failed We noticed some unusual activity.'],screenshot_path:file,screenshot_sha256:hash('saved-evidence')};
 f.runtime.save(s);
 f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task],reviews:[],account_policy:policy,unusual_activity_policy:unusual});
 f.adapter.unusualTarget=url=>{assert.equal(url,f.config.projectUrl);targets++;return 'third@example.com';};
 f.adapter.switchAccount=async email=>{assert.equal(email,'third@example.com');switched++;};f.adapter.ensureProject=async()=>{};
 f.native.execute=async cmd=>{if(failOnce){failOnce=false;throw Error('native_execution_busy');}f.calls.execute.push(cmd);return {ok:true};};
 await assert.rejects(f.runtime.tick(),/native_execution_busy/);
 assert.equal(f.runtime.load(f.task).images.chest.generation_id,'unusual-old');assert.ok(f.runtime.load(f.task).unusual_activity_cooldown);assert.equal(f.calls.generate,0);
 const result=await f.runtime.tick();assert.equal(result.code,'flow_account_handover_ready');assert.equal(targets,1);assert.equal(switched,2);
 const after=f.runtime.load(f.task);assert.equal(JSON.stringify(after.images.already_done),acquired);assert.equal(after.images.chest.generation_id,'unusual-old');
 assert.equal(after.unusual_activity_cooldown,undefined);assert.equal(after.account_switch_pending,undefined);assert.equal(f.calls.generate,0);
 assert.equal(f.calls.execute[0].generation_retry.generation_id,'unusual-old');assert.equal(f.calls.execute[0].reference,policy.reference);
 assert.equal(after.events.filter(e=>e.event==='unusual_account_handover').length,1);assert.equal(after.events.some(e=>e.event==='unusual_warning_cleared'),false);
});

test('unusual account handover stops on login, exhausted accounts, changed evidence or stale binding without Generate',async t=>{
 const f=fixture(t),s=f.runtime.load(f.task),policy={enabled:true,on_unusual_activity:'switch_account',reference:'Fixture authority',accounts:[{email:'second@example.com'}]};
 const file=path.join(f.root,'unusual.png');fs.writeFileSync(file,'evidence');
 s.images.chest={status:'generation_started',generation_id:'saved',recovery:{project_url:f.config.projectUrl,prompt_sha256:hash(f.task.payload.images[0].prompt)}};
 s.unusual_activity_cooldown={image_key:'chest',generation_id:'saved',not_before:new Date(Date.now()-1).toISOString(),failed_tiles:['Failed We noticed some unusual activity.'],screenshot_path:file,screenshot_sha256:hash('evidence')};
 let blocked;f.runtime.block=async code=>{blocked=code;return {code};};f.adapter.unusualTarget=()=>null;
 f.adapter.readiness=async()=>({ready:false,code:'flow_captcha_required'});
 await f.runtime.switchAfterUnusualFailure(f.task,s,policy);assert.equal(blocked,'flow_captcha_required');assert.equal(f.calls.execute.length,0);
 f.adapter.readiness=async()=>({ready:true});await f.runtime.switchAfterUnusualFailure(f.task,s,policy);assert.equal(blocked,'flow_accounts_exhausted');
 s.unusual_activity_cooldown.generation_id='stale';await assert.rejects(f.runtime.switchAfterUnusualFailure(f.task,s,policy),/binding_invalid/);
 s.unusual_activity_cooldown.generation_id='saved';fs.writeFileSync(file,'changed');await assert.rejects(f.runtime.switchAfterUnusualFailure(f.task,s,policy),/asset_hash_changed/);
 assert.equal(f.calls.generate,0);assert.equal(f.calls.execute.length,0);
});

test('a newly confirmed unusual failure saves evidence and switches accounts immediately without a cooldown tick',async t=>{
 const f=fixture(t),policy={enabled:true,on_unusual_activity:'switch_account',reference:'Fixture immediate handover',accounts:[{email:'first@example.com'},{email:'second@example.com'},{email:'third@example.com'}]};
 fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({batch_id:'fixture-batch'}));
 f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task],reviews:[],account_policy:policy,unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:'Old policy'}});
 f.native.execute=async command=>{f.calls.execute.push(command);return {ok:true};};
 let switched=0;
 f.adapter.generate=async(_item,_refs,_dir,hooks)=>{f.calls.generate++;await hooks.beforeGenerate({generation_id:'new-unusual',recovery:{project_url:f.config.projectUrl,prompt_sha256:hash(f.task.payload.images[0].prompt)}});throw Object.assign(Error('unusual'),{code:'flow_unusual_activity_required'});};
 f.adapter.unusualActivityEvidence=async file=>{fs.writeFileSync(file,'actual-failure-evidence');return {failed_tiles:['Failed We noticed some unusual activity.'],screenshot_path:file,screenshot_sha256:hash('actual-failure-evidence')};};
 f.adapter.unusualTarget=()=> 'third@example.com';f.adapter.switchAccount=async()=>{switched++;};f.adapter.ensureProject=async()=>{};
 const result=await f.runtime.tick();assert.equal(result.code,'flow_account_handover_ready');assert.equal(switched,1);assert.equal(f.calls.generate,1);
 const state=f.runtime.load(f.task);assert.equal(state.images.chest.generation_id,'new-unusual');assert.equal(state.unusual_activity_cooldown,undefined);
 assert.equal(state.events.some(e=>e.event==='unusual_account_failure_saved'),true);assert.equal(state.events.some(e=>e.event==='unusual_warning_cleared'),false);
 assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);assert.equal(f.calls.notify.length,0);
});

test('a quota failure in tick hands over once then consumes native permit and preserves acquired image',async t=>{
 const f=fixture(t),policy={enabled:true,reference:'Fixture account authority',accounts:[{email:'first@example.com'},{email:'second@example.com'}]};
 f.task.payload.images.push({...f.task.payload.images[0],region:'back',name:'back.png',prompt:'Different view\nNO OUTLINE'});
 const s=f.runtime.load(f.task),acquired={...f.result(),status:'acquired',generation_id:'already-done'};s.images.chest=acquired;s.images.back={status:'generation_started',generation_id:'quota-old'};f.runtime.save(s);
 const preserved=JSON.stringify(f.runtime.load(f.task).images.chest),permits=[];let failed=false,switched=0,submitted=false;
 f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:submitted?[]:[f.task],reviews:[],account_policy:policy,generation_retries:permits});
 f.native.execute=async cmd=>{f.calls.execute.push(cmd);if(cmd.generation_retry)permits.push({...cmd.generation_retry,permit_id:hash('fixture-permit'),reference:cmd.reference});else if(cmd.action==='flow_auto_submit')submitted=true;return {ok:true};};
 f.adapter.quotaTarget=()=> 'second@example.com';f.adapter.switchAccount=async()=>{switched++;};f.adapter.ensureProject=async()=>{};
 f.adapter.generate=async(_item,_refs,_dir,hooks)=>{f.calls.generate++;if(!failed){failed=true;throw Object.assign(Error('quota'),{code:'flow_quota_required'});}assert.equal(hooks.resume.status,'ready');await hooks.beforeGenerate({generation_id:'new-on-second-account'});return f.result();};
 assert.equal((await f.runtime.tick()).code,'flow_account_handover_ready');assert.equal(switched,1);assert.equal(permits.length,1);
 assert.equal(f.runtime.load(f.task).images.back.generation_id,'quota-old');assert.equal((await f.runtime.tick()).status,'awaiting_human_review');
 assert.equal(JSON.stringify(f.runtime.load(f.task).images.chest),preserved);assert.equal(switched,1);assert.equal(f.calls.generate,2);
 assert.equal(f.runtime.load(f.task).events.filter(e=>e.event==='generation_retry_authorized').length,1);
});

test('shared native lock contention waits quietly and does not conceal a real blocker', async t => {
  const f = fixture(t);
  f.runtime.noticeState = { last_sent_key: 'native_execution_busy:', last_blocked: true, pending: null };
  assert.equal((await f.runtime.block('native_execution_busy')).status, 'waiting_native_execution');
  await f.runtime.recoverNotice(); assert.equal(f.calls.notify.length, 0);
  await f.runtime.block('login_required');
  const saved = JSON.stringify(f.runtime.noticeState);
  await f.runtime.block('native_execution_busy');
  assert.equal(JSON.stringify(f.runtime.noticeState), saved);
  await f.runtime.recoverNotice();
  assert.deepEqual(f.calls.notify.map(n => n.code), ['login_required', 'flow_worker_recovered']);
});

test('quota switches to authorized 2.1 once, persists across restart and keeps acquired images and model proof',async t=>{
 const f=fixture(t),policy={enabled:true,model:'Nano Banana 2.1',reference:'Fixture user authorizes model fallback'};
 f.task.payload.images.push({...f.task.payload.images[0],region:'back',name:'back.png',prompt:'Different view\nNO OUTLINE'});
 const s=f.runtime.load(f.task);s.images.chest={...f.result(),status:'acquired',generation_id:'done-pro'};
 s.images.back={status:'generation_started',generation_id:'quota-pro'};f.runtime.save(s);
 const original=JSON.stringify(s.images.chest),permits=[];let submitted=false,failed=false;
 f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:submitted?[]:[f.task],reviews:[],generation_retries:permits,model_fallback_policy:policy});
 f.native.execute=async cmd=>{f.calls.execute.push(cmd);if(cmd.generation_retry)permits.push({...cmd.generation_retry,permit_id:hash('model-fixture-permit'),reference:cmd.reference});else submitted=true;return {ok:true};};
 f.adapter.resumeAfterQuotaFailure=async()=>({baseline:['quota tile'],screenshot_path:f.result().proof.screenshot_path,screenshot_sha256:hash('fake-test-only-screen')});
 f.adapter.generate=async(_item,_refs,_dir,hooks)=>{f.calls.generate++;if(!failed){failed=true;throw Object.assign(Error('quota'),{code:'flow_quota_required'});}assert.equal(f.adapter.config.model,'Nano Banana 2.1');assert.equal(hooks.resume.status,'ready');await hooks.beforeGenerate({generation_id:'new-2-1'});const r=f.result();r.proof.model='Nano Banana 2.1';r.proof.model_policy_reference=policy.reference;return r;};
 assert.equal((await f.runtime.tick()).code,'flow_model_fallback_ready');assert.equal(permits.length,1);
 assert.equal(f.runtime.load(f.task).images.back.generation_id,'quota-pro');assert.equal(f.calls.generate,1);
 f.adapter.config.model='Nano Banana Pro';
 assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(f.adapter.config.model,'Nano Banana 2.1');
 assert.equal(JSON.stringify(f.runtime.load(f.task).images.chest),original);
 assert.equal(f.calls.execute.at(-1).proof.images[0].model,'Nano Banana Pro');
 assert.equal(f.calls.execute.at(-1).proof.images[1].model,'Nano Banana 2.1');
 assert.equal(f.calls.execute.at(-1).proof.images[1].model_policy_reference,policy.reference);
});

test('2.1 quota stops without account cycling or another permit',async t=>{
 const f=fixture(t),policy={enabled:true,model:'Nano Banana 2.1',reference:'Fixture fallback'};
 fs.writeFileSync(path.join(f.config.stateDir,'flow-model.json'),JSON.stringify({model:policy.model,policy_reference:policy.reference}));
 const s=f.runtime.load(f.task);s.images.chest={status:'generation_started',generation_id:'quota-2-1'};f.runtime.save(s);
 const cycle=f.native.cycle;f.native.cycle=async()=>({...await cycle(),model_fallback_policy:policy,account_policy:{enabled:true}});
 f.adapter.generate=async()=>{throw Object.assign(Error('quota'),{code:'flow_quota_required'});};
 f.adapter.quotaTarget=()=>{throw Error('must not switch accounts');};f.runtime.block=async code=>({code});
 assert.equal((await f.runtime.tick()).code,'flow_model_retry_exhausted');assert.equal(f.calls.execute.length,0);
 assert.equal(f.runtime.load(f.task).images.chest.generation_id,'quota-2-1');
});

test('intentional worker reload preserves pending generation without turning browser closure into a batch error',async t=>{
 const f=fixture(t);let blocked=0;f.runtime.block=async()=>{blocked++;};
 f.adapter.generate=async(_item,_refs,_dir,hooks)=>{await hooks.beforeGenerate({generation_id:'preserved-on-reload'});await f.runtime.stop();throw Error('Target page, context or browser has been closed');};
 await f.runtime.run({once:true});assert.equal(blocked,0);assert.equal(f.calls.execute.length,0);
 assert.equal(f.runtime.load(f.task).images.chest.generation_id,'preserved-on-reload');
 assert.equal(f.runtime.load(f.task).images.chest.status,'generation_started');
});

test('explicit image worker pause preserves journals without browser, generation or native calls',async t=>{
  const f=fixture(t),s=f.runtime.load(f.task);s.images.chest={status:'generation_started',generation_id:'old-pending'};f.runtime.save(s);
  const before=fs.readFileSync(f.runtime.file(f.task.id),'utf8');f.runtime.browserStarted=true;
  fs.writeFileSync(path.join(f.config.stateDir,'pause.request.json'),JSON.stringify({reference:'Fixture user pauses images to focus on listing and KPI'}));
  assert.equal((await f.runtime.tick()).status,'paused');assert.equal(f.calls.closed,1);assert.equal(f.calls.start,0);
  assert.equal(f.calls.generate,0);assert.equal(f.calls.cycle,0);assert.equal(f.calls.execute.length,0);
  assert.equal(fs.readFileSync(f.runtime.file(f.task.id),'utf8'),before);
});

const batchNames = ['01_thumbnail.jpg', '02_model_front.jpg', '03_model_angle.jpg', '04_embroidery_closeup.jpg', '05_embroidery_dimensions.jpg', '06_flatlay.jpg'];
function batchTask(f, stage = 'sample_mockup', names = batchNames.slice(0, 1)) {
  f.task.kind = 'flow_batch_images'; f.task.batch_id = 'batch-test'; f.task.item_id = 'item-test'; f.task.stage = stage;
  delete f.task.brief_id; delete f.task.payload.brief_id;
  Object.assign(f.task.payload, { batch_id: f.task.batch_id, item_id: f.task.item_id, stage, executor: 'independent_flow_worker', aspect_ratio: '1:1' });
  const source = f.task.payload.images[0];
  f.task.payload.images = names.map(name => { const image = { ...source, name }; delete image.region; return image; });
}

test('batch sample mockup preserves entity and prompt/reference provenance through native submit', async t => {
  const f = fixture(t); batchTask(f);
  assert.equal((await f.runtime.tick()).status, 'awaiting_human_review');
  const command = f.calls.execute[0];
  assert.equal(command.batch_id, 'batch-test'); assert.equal(command.item_id, 'item-test');
  assert.equal(command.assets[0].image_key, '01_thumbnail.jpg');
  assert.equal(command.proof.visually_verified, undefined);
  assert.equal(command.proof.prompt_provenance[0].reference_sha256[0], f.task.payload.images[0].references[0].sha256);
});

test('batch task rejects mismatched identity, invalid stages/counts, and output outside production', async t => {
  const f = fixture(t); batchTask(f);
  const snapshot = () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task] });
  f.task.payload.item_id = 'other-item'; assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_identity_invalid/);
  f.task.payload.item_id = f.task.item_id; f.task.payload.aspect_ratio = '16:9'; assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_identity_invalid/);
  f.task.payload.aspect_ratio = null; assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_identity_invalid/);
  f.task.payload.aspect_ratio = '1:1'; f.task.payload.images[0].name = 'other'; assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_images_invalid/);
  f.task.payload.images[0].name = '01_thumbnail.jpg'; f.task.payload.output_directory = path.join(f.root, 'outside-production'); assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_output_outside_production/);
});

const printNames = ['01_thumbnail.jpg', '02_female_angle.jpg', '03_female_seated.jpg', '04_flatlay.jpg', '05_print_closeup.jpg'];
const embroideryNames = ['01_thumbnail.jpg', '02_hoodie_folded.jpg', '03_quarterzip_folded.jpg', '04_male_front.jpg', '05_female_angle.jpg', '06_female_seated.jpg', '07_embroidery_closeup.jpg', '08_maximum_dimensions.jpg', '09_gift_packaging.jpg', '10_flatlay.jpg'];
test('profile 3 validates each product layout, retained originals and replacement coverage', t => {
  for (const kind of ['apparel_2d', 'pajama_top','pajama_set', 'sleep_pants', 'embroidery_prompts']) {
    const names = kind === 'embroidery_prompts' ? embroideryNames : printNames;
    for (const requested of [names.slice(0, 1), names, names.slice(1), names.slice(2)]) {
      const f = fixture(t), stage = requested.length === 1 ? 'sample_mockup' : 'mockups';
      batchTask(f, stage, requested);
      Object.assign(f.task.payload, { profile_version: 3, product_kind: kind });
      if(kind==='pajama_set')f.task.payload.product_bundle={sales_unit:'set',listing_units:1,components:['top','pants']};
      const ref = f.task.payload.images[0].references[0];
      if (requested.length < names.length && stage === 'mockups') f.task.payload.retained_images = names.filter(name => !requested.includes(name)).map(name => ({ name, ...ref }));
      const snapshot = () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task] });
      const before = JSON.stringify(f.task.payload);
      assert.equal(f.runtime.task(snapshot(), f.task.id), f.task);
      assert.equal(JSON.stringify(f.task.payload), before);
      if (f.task.payload.retained_images) {
        f.task.payload.retained_images[0].sha256 = '0'.repeat(64);
        assert.throws(() => f.runtime.task(snapshot(), f.task.id), /asset_hash_changed/);
        f.task.payload.retained_images[0].sha256 = ref.sha256;
        f.task.payload.retained_images.pop();
        f.task.payload.images.pop();
        assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_images_invalid/);
      }
      f.task.payload.images[0].name = 'wrong-layout.jpg';
      assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_images_invalid/);
    }
  }
  const f = fixture(t); batchTask(f, 'mockups', batchNames);
  Object.assign(f.task.payload, { profile_version: 3, product_kind: 'apparel_2d' });
  const snapshot = () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task] });
  assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_images_invalid/);
  f.task.payload.product_kind = 'unknown';
  assert.throws(() => f.runtime.task(snapshot(), f.task.id), /task_batch_images_invalid/);
});

test('profile 3 keeps the approved sample and submits only four remaining print views', async t => {
  const f = fixture(t); batchTask(f, 'mockups', printNames.slice(1));
  Object.assign(f.task.payload, { profile_version: 3, product_kind: 'apparel_2d' });
  const ref = f.task.payload.images[0].references[0];
  f.task.payload.retained_images = [{ name: printNames[0], ...ref }];
  const before = JSON.stringify(f.task.payload), generate = f.adapter.generate;
  f.adapter.generate = async (...args) => {
    const result = await generate(...args), bytes = 'new-print-view-' + args[0].name;
    result.asset.path = path.join(f.task.payload.output_directory, args[0].name);
    fs.writeFileSync(result.asset.path, bytes); result.asset.sha256 = hash(bytes); return result;
  };
  assert.equal((await f.runtime.tick()).status, 'awaiting_human_review');
  assert.equal(f.calls.generate, 4);
  assert.deepEqual(f.calls.execute[0].assets.map(a => a.image_key), printNames.slice(1));
  assert.equal(JSON.stringify(f.task.payload), before);
  assert.equal(hash(fs.readFileSync(ref.path)), ref.sha256);
});

test('batch camera correction generates only the complement of hashed retained originals', async t => {
  const f=fixture(t);batchTask(f,'mockups',[batchNames[2],batchNames[3],batchNames[5]]);
  const reference=f.task.payload.images[0].references[0];
  f.task.payload.retained_images=[batchNames[0],batchNames[1],batchNames[4]].map(name=>({name,...reference}));
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  f.task.payload.retained_images[0].sha256='0'.repeat(64);
  assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/asset_hash_changed/);
  f.task.payload.retained_images[0].sha256=reference.sha256;
  const saved=f.task.payload.retained_images.pop();
  assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/task_batch_images_invalid/);
  f.task.payload.retained_images.push(saved);
  const generate=f.adapter.generate;
  f.adapter.generate=async(...args)=>{
    const result=await generate(...args),bytes='replacement-original-'+args[0].name;
    result.asset.path=path.join(f.task.payload.output_directory,args[0].name+'.png');
    fs.writeFileSync(result.asset.path,bytes);result.asset.sha256=hash(bytes);return result;
  };
  assert.equal((await f.runtime.tick()).status,'awaiting_human_review');
  assert.equal(f.calls.generate,3);
  assert.deepEqual(f.calls.execute[0].assets.map(a=>a.image_key),[batchNames[2],batchNames[3],batchNames[5]]);
});

test('existing embroidery batch task without ratio resumes with its original payload and checkpoint', async t => {
  const f = fixture(t); batchTask(f);
  delete f.task.payload.aspect_ratio;
  const payload = JSON.stringify(f.task.payload);
  const state = f.runtime.load(f.task);
  state.images['01_thumbnail.jpg'] = { status: 'generation_started', generation_id: 'existing-generation' };
  f.runtime.save(state);
  const generate = f.adapter.generate;
  f.adapter.generate = async (...args) => {
    assert.equal(args[3].resume.generation_id, 'existing-generation');
    return generate(...args);
  };
  assert.equal((await f.runtime.tick()).status, 'awaiting_human_review');
  assert.equal(f.calls.before, 0);
  assert.equal(JSON.stringify(f.task.payload), payload);
  assert.equal(f.calls.execute[0].task_id, f.task.id);
  assert.equal(f.calls.execute[0].task_fingerprint, f.task.fingerprint);
});

test('batch remaining five and complete six mockups are distinct originals even when prompts match', async t => {
  for (const names of [batchNames.slice(1), batchNames]) {
    const f = fixture(t); batchTask(f, 'mockups', names);
    const generate = f.adapter.generate;
    f.adapter.generate = async (...args) => {
      const result = await generate(...args);
      result.asset.path = path.join(f.task.payload.output_directory, args[0].name + '.original.png');
      const bytes = 'unique-test-only-image-' + args[0].name;
      fs.writeFileSync(result.asset.path, bytes); result.asset.sha256 = hash(bytes); return result;
    };
    await f.runtime.tick();
    assert.equal(f.calls.generate, names.length);
    assert.deepEqual(f.calls.execute[0].assets.map(asset => asset.image_key), names);
    assert.equal(new Set(f.calls.execute[0].assets.map(asset => asset.sha256)).size, names.length);
  }
});

test('batch rejects wrong mockup roles and duplicated original bytes before native attachment', async t => {
  const f = fixture(t); batchTask(f, 'mockups', batchNames.slice(1));
  f.task.payload.images[4].name = 'unknown.jpg';
  const snapshot = { ok: true, observed_at: new Date().toISOString(), tasks: [f.task] };
  assert.throws(() => f.runtime.task(snapshot, f.task.id), /task_batch_images_invalid/);
  f.task.payload.images[4].name = batchNames[5];
  await assert.rejects(f.runtime.tick(), /mockup_originals_must_be_distinct/);
  assert.equal(f.calls.generate, 5); assert.equal(f.calls.execute.length, 0);
});
test('identical sleeve prompts and locked reference hashes use exactly the same file', async t => {
  const f = fixture(t);
  f.task.payload.images[0].region = 'left_sleeve';
  f.task.payload.images.push({ ...f.task.payload.images[0], region: 'right_sleeve', name: 'right_sleeve.png' });
  await f.runtime.tick();
  assert.equal(f.calls.generate, 1);
  const [left, right] = f.calls.execute[0].assets;
  assert.equal(left.path, right.path); assert.equal(left.sha256, right.sha256);
  assert.equal(f.runtime.load(f.task).images.right_sleeve.reused_from, 'left_sleeve');
});
test('portrait normalization is reserved for sleeve design tasks and shared sleeves reuse it',async t=>{
  const f=fixture(t),image=f.task.payload.images[0];
  Object.assign(image,{region:'left_sleeve',aspect_ratio:'9:16',output_aspect_ratio:'7:26'});
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  image.region='left_chest';assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/portrait_sleeve_task_invalid/);
  image.region='left_sleeve';f.task.payload.images.push({...image,region:'right_sleeve',name:'right_sleeve.png'});
  await f.runtime.tick();assert.equal(f.calls.generate,1);
  assert.equal(f.calls.execute[0].assets[0].path,f.calls.execute[0].assets[1].path);
});
test('status distinguishes prompt preparation from a durable generation in progress', async t => {
  const f = fixture(t); const observed = [];
  const original = f.adapter.generate;
  f.adapter.generate = async (...args) => {
    observed.push(JSON.parse(fs.readFileSync(path.join(f.config.stateDir, 'status.json'), 'utf8')).status);
    const before = args[3].beforeGenerate;
    args[3].beforeGenerate = async metadata => { await before(metadata); observed.push(JSON.parse(fs.readFileSync(path.join(f.config.stateDir, 'status.json'), 'utf8')).status); };
    return original(...args);
  };
  await f.runtime.tick();
  assert.deepEqual(observed, ['preparing_flow', 'waiting_generation']);
});
test('changed screenshot in a submit checkpoint blocks native retry', async t => {
  const f = fixture(t); f.native.execute = async () => { throw new Error('unknown_submit'); };
  await assert.rejects(() => f.runtime.tick(), /unknown_submit/);
  const state = f.runtime.load(f.task); fs.writeFileSync(state.images.chest.proof.screenshot_path, 'changed-screen');
  await assert.rejects(() => f.runtime.tick(), /screenshot_changed/);
});
test('pairing/setup pending never opens Chrome or generates', async t => {
  const f = fixture(t); f.runtime.larkReadiness = async () => ({ ready: false, code: 'lark_setup_pending' });
  const status = await f.runtime.tick(); await f.runtime.tick();
  assert.equal(status.code, 'lark_setup_pending'); assert.equal(f.calls.start, 0); assert.equal(f.calls.generate, 0); assert.equal(f.calls.notify.length, 1);
});
test('login, CAPTCHA, quota block with status and one notification', async t => {
  const f = fixture(t);
  for (const code of ['flow_login_required', 'flow_captcha_required', 'flow_quota_required']) {
    f.adapter.readiness = async () => ({ ready: false, code });
    assert.equal((await f.runtime.tick()).code, code);
  }
  assert.equal(f.calls.generate, 0); assert.equal(f.calls.execute.length, 0); assert.equal(f.calls.notify.length, 3);
});
test('readiness dry-run never invokes generation or attachment', async t => {
  const f = fixture(t); assert.equal((await f.runtime.tick({ readinessOnly: true })).generation_performed, false);
  assert.equal(f.calls.generate, 0); assert.equal(f.calls.execute.length, 0);
});

test('selected batch stops on its first quota error, persists across restart and never retries until native release',async t=>{
  const f=fixture(t),file=path.join(f.config.stateDir,'image-provider.json');
  fs.writeFileSync(file,JSON.stringify({provider:'flow',batch_id:'batch-A'}));
  f.native.execute=async cmd=>{f.calls.execute.push(cmd);return cmd.action==='batch_status'?{ok:true,batches:[{batch_id:'batch-A',fingerprint:'a'.repeat(64),status:'active'}]}:{status:'batch_stopped'};};
  f.adapter.readiness=async()=>({ready:false,code:'flow_quota_required'});
  assert.equal((await f.runtime.tick()).requires_user_resume,true);
  assert.equal(f.calls.execute.filter(x=>x.action==='batch_stop').length,1);
  f.adapter.readiness=async()=>({ready:true});
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,notify:async s=>f.calls.notify.push(s)});
  restart.larkReadiness=async()=>({ready:true});
  await restart.tick();await restart.tick();assert.equal(f.calls.generate,0);assert.equal(f.calls.notify.length,1);
  assert.equal(fs.existsSync(path.join(f.config.stateDir,'workflow-error-hold.json')),true);
});

test('selected batch never upgrades a historical unusual cooldown into permission to retry',async t=>{
  const f=fixture(t);fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'flow',batch_id:'batch-A'}));
  f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task],reviews:[],unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:'Historical policy'},generation_failure_policy:{enabled:true,cooldown_ms:60000,reference:'Historical policy'}});
  f.native.execute=async cmd=>cmd.action==='batch_status'?{ok:true,batches:[{batch_id:'batch-A',fingerprint:'a'.repeat(64),status:'active'}]}:{status:'batch_stopped'};
  f.adapter.readiness=async()=>({ready:false,code:'flow_unusual_activity_required'});
  const saved=f.runtime.load(f.task);saved.unusual_activity_cooldown={image_key:'chest',observed_at:new Date(0).toISOString(),not_before:new Date(1).toISOString()};f.runtime.save(saved);
  const result=await f.runtime.tick();assert.equal(result.code,'flow_unusual_activity_required');assert.equal(result.requires_user_resume,true);assert.equal(f.calls.generate,0);
  assert.equal(f.calls.restarted,0);
  assert.equal(fs.existsSync(path.join(f.config.stateDir,'unusual-activity-cooldown.json')),false);
});

test('quota discovered inside generic failure evidence cannot enter the one-minute retry cooldown',async t=>{
  const f=fixture(t);
  f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task],reviews:[],generation_failure_policy:{enabled:true,cooldown_ms:60000,reference:'Fixture retry policy'}});
  f.adapter.generate=async(_item,_refs,_dir,hooks)=>{f.calls.generate++;await hooks.beforeGenerate({generation_id:'quota-generation',recovery:{baseline:[]}});throw Object.assign(Error('Failed tile'),{code:'flow_generation_failed'});};
  f.adapter.generationFailureEvidence=async()=>{throw Object.assign(Error('Usage limit'),{code:'flow_quota_required'});};
  await assert.rejects(f.runtime.tick(),{code:'flow_quota_required'});
  const state=f.runtime.load(f.task);
  assert.equal(state.images.chest.status,'generation_started');
  assert.equal(state.generation_failure_cooldown,undefined);
  assert.equal(state.events.some(x=>x.event==='generation_failure_cooldown_started'),false);
  f.adapter.readiness=async()=>({ready:false,code:'flow_quota_required'});
  assert.equal((await f.runtime.tick()).code,'flow_quota_required');
  await f.runtime.tick();
  assert.equal(f.calls.generate,1);assert.equal(f.calls.execute.length,0);assert.equal(f.calls.notify.length,1);
});
test('crash unknown Generate resumes same durable recovery metadata without new click', async t => {
  const f = fixture(t); const original = f.adapter.generate;
  f.adapter.generate = async (_i, _r, _o, hooks) => { await hooks.beforeGenerate({ generation_id: 'already-started', recovery: { baseline: ['old-result'], project_url: f.config.projectUrl } }); throw new Error('unknown_click'); };
  await assert.rejects(() => f.runtime.tick(), /unknown_click/);
  const saved = f.runtime.load(f.task); assert.equal(saved.images.chest.status, 'generation_started');
  f.adapter.generate = async (i, r, o, hooks) => {
    assert.equal(hooks.resume.generation_id, 'already-started'); assert.deepEqual(hooks.resume.recovery.baseline, ['old-result']);
    await assert.rejects(() => hooks.beforeGenerate({ generation_id: 'duplicate' }), /reconcile/);
    return original(i, r, o, hooks);
  };
  await f.runtime.tick(); assert.equal(f.calls.before, 0); assert.equal(f.calls.execute.length, 1);
});
test('crash after download checkpoint reuses original without Generate', async t => {
  const f = fixture(t);
  f.adapter.generate = async (_i, _r, _o, hooks) => { await hooks.beforeGenerate({ generation_id: 'downloaded' }); await hooks.checkpoint({ event: 'acquired', ...f.result() }); throw new Error('crash_after_download'); };
  await assert.rejects(() => f.runtime.tick(), /crash_after_download/);
  assert.equal(f.runtime.load(f.task).images.chest.status, 'acquired');
  f.adapter.generate = async () => { throw new Error('must_not_generate'); };
  await f.runtime.tick(); assert.equal(f.calls.execute.length, 1);
});
test('n8n human retry permit replaces only its exact unresolved generation once', async t => {
  const f = fixture(t), state = f.runtime.load(f.task);
  state.images.chest = { status: 'generation_started', generation_id: 'old-failed', recovery: { baseline: [] } };
  f.runtime.save(state);
  const cycle = f.native.cycle.bind(f.native);
  f.native.cycle = async () => ({ ...await cycle(), generation_retries: [{ task_id: f.task.id, task_fingerprint: f.task.fingerprint, revision: f.task.revision, image_key: 'chest', generation_id: 'old-failed', permit_id: 'a'.repeat(64), reference: 'Actual fixture human requested retry' }] });
  const generate = f.adapter.generate;
  f.adapter.generate = async (i,r,o,hooks) => { assert.equal(hooks.resume.status,'ready'); await hooks.beforeGenerate({generation_id:'replacement-generation',recovery:{baseline:[]}}); return generate(i,r,o,hooks); };
  await f.runtime.tick();
  const saved=f.runtime.load(f.task);
  assert.equal(saved.images.chest.status,'acquired');
  assert.equal(saved.events.filter(e=>e.event==='generation_retry_authorized').length,1);
  assert.equal(saved.events.find(e=>e.event==='generation_retry_authorized').prior_generation.generation_id,'old-failed');
});
test('retry supplies its saved generation for completed-image recovery and checkpoints acquisition without a new click',async t=>{
 const f=fixture(t),state=f.runtime.load(f.task),permit='b'.repeat(64);
 const prior={status:'generation_started',generation_id:'late-completed',recovery:{baseline:[],project_url:f.config.projectUrl,failure_baseline:[]}};
 state.images.chest={status:'ready',retry_permit_id:permit};state.failed_tiles_baseline=['saved failure'];
 state.events.push({event:'generation_retry_authorized',permit_id:permit,image_key:'chest',prior_generation:prior});f.runtime.save(state);
 f.adapter.generate=async(_item,_refs,_dir,hooks)=>{
  assert.equal(hooks.retryRecovery.generation_id,'late-completed');assert.deepEqual(hooks.retryRecovery.recovery.failure_baseline,['saved failure']);
  const acquired={...f.result(),generation_id:'late-completed'};await hooks.checkpoint({event:'acquired',...acquired});return acquired;
 };
 await f.runtime.tick();const saved=f.runtime.load(f.task);
 assert.equal(saved.images.chest.status,'acquired');assert.equal(saved.images.chest.generation_id,'late-completed');
 assert.equal(saved.events.filter(e=>e.event==='generation_started').length,0);assert.equal(f.calls.before,0);
 assert.equal(f.calls.execute[0].action,'flow_auto_submit');
});

test('unknown attachment result resends exact native command and never regenerates', async t => {
  const f = fixture(t); const execute = f.native.execute;
  f.native.execute = async command => { f.calls.execute.push(command); f.setTasks([]); throw new Error('unknown_submit'); };
  await assert.rejects(() => f.runtime.tick(), /unknown_submit/);
  const saved = f.runtime.load(f.task); assert.equal(saved.status, 'submit_pending');
  f.native.execute = execute; await f.runtime.tick();
  assert.equal(f.calls.generate, 1); assert.deepEqual(f.calls.execute[0], f.calls.execute[1]);
});
test('rejected sleeve canvas stops repeated submission and preserves acquired files',async t=>{
  const f=fixture(t);f.native.execute=async command=>{f.calls.execute.push(command);return {ok:true,status:'design_canvas_rejected',rejected_images:[{image_key:'chest'}]};};
  let status=await f.runtime.tick();assert.equal(status.code,'flow_sleeve_canvas_invalid');
  const state=f.runtime.load(f.task);assert.equal(state.status,'design_canvas_rejected');assert.ok(fs.existsSync(state.images.chest.asset.path));
  status=await f.runtime.tick();assert.equal(status.code,'flow_sleeve_canvas_invalid');assert.equal(f.calls.execute.length,1);assert.equal(f.calls.generate,1);
});
test('rejection returned after an unknown submit leaves a stable blocked checkpoint',async t=>{
  const f=fixture(t);f.native.execute=async()=>{throw Error('unknown_submit');};
  await assert.rejects(()=>f.runtime.tick(),/unknown_submit/);
  f.native.execute=async()=>({ok:true,status:'design_canvas_rejected'});
  assert.equal((await f.runtime.tick()).code,'flow_sleeve_canvas_invalid');assert.equal(f.runtime.load(f.task).status,'design_canvas_rejected');
});
test('native portrait sleeve output is accepted only on a sleeve design task',async t=>{
  const f=fixture(t),image=f.task.payload.images[0];
  Object.assign(image,{region:'left_sleeve',aspect_ratio:'9:16',output_aspect_ratio:'9:16'});
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  image.region='center_chest';assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/native_sleeve_task_invalid/);
});

test('native recovery of rejected canvas releases checkpoint without Generate, resubmit or approval',async t=>{
  const f=fixture(t);f.native.execute=async command=>{f.calls.execute.push(command);return {ok:true,status:'design_canvas_rejected'};};
  await f.runtime.tick();const generated=f.calls.generate,submitted=f.calls.execute.length;
  f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:[],reviews:[],task_states:[{id:f.task.id,revision:1,current_revision:1,fingerprint:f.task.fingerprint,status:'assets_attached'}]});
  assert.equal((await f.runtime.tick()).status,'idle');assert.equal(f.runtime.load(f.task).status,'submitted');
  await f.runtime.tick();assert.equal(f.calls.generate,generated);assert.equal(f.calls.execute.length,submitted);
  assert.equal(f.runtime.load(f.task).events.at(-1).event,'native_canvas_attachment_reconciled');
});
test('landscape ratio is allowed only for sleeve design tasks with matching native output ratio',async t=>{
  const f=fixture(t);const image=f.task.payload.images[0];Object.assign(image,{region:'left_sleeve',aspect_ratio:'16:9',output_aspect_ratio:'16:9'});
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  assert.equal(f.runtime.task(snapshot(),f.task.id).id,f.task.id);
  image.region='center_chest';assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/native_sleeve_task_invalid/);
});

test('superseded unknown-submit journal is preserved and cannot block a new native revision', async t => {
  const f = fixture(t);
  const execute = f.native.execute;
  f.native.execute = async () => { throw Error('unknown_submit'); };
  await assert.rejects(() => f.runtime.tick(), /unknown_submit/);
  const oldTask = JSON.parse(JSON.stringify(f.task));
  f.task.id = 'task-new-revision'; f.task.revision = 2; f.task.payload.revision = 2; f.task.fingerprint = 'b'.repeat(64);
  f.native.cycle = async () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task], reviews: [],
    task_states: [{ id: oldTask.id, revision: 1, current_revision: 2, fingerprint: oldTask.fingerprint, status: 'superseded' }] });
  f.native.execute = execute;
  await f.runtime.tick();
  const oldState = JSON.parse(fs.readFileSync(f.runtime.file(oldTask.id), 'utf8'));
  assert.equal(oldState.status, 'superseded'); assert.equal(fs.existsSync(oldState.images.chest.asset.path), true);
  assert.equal(f.calls.execute.at(-1).task_id, 'task-new-revision');
});

test('completed task at the same revision still retries the exact unknown-submit command', async t => {
  const f = fixture(t), execute = f.native.execute;
  f.native.execute = async () => { throw Error('unknown_submit'); };
  await assert.rejects(() => f.runtime.tick(), /unknown_submit/);
  const command = f.runtime.load(f.task).command;
  f.native.cycle = async () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [], reviews: [],
    task_states: [{ id: f.task.id, revision: 1, current_revision: 1, fingerprint: f.task.fingerprint, status: 'completed' }] });
  f.native.execute = execute;
  await f.runtime.tick();
  assert.deepEqual(f.calls.execute[0], command); assert.equal(f.calls.generate, 1);
});
test('stale snapshot or reference hash blocks before any Generate', async t => {
  const f = fixture(t);
  f.native.cycle = async () => ({ ok: true, observed_at: new Date(0).toISOString(), tasks: [f.task] });
  await assert.rejects(() => f.runtime.tick(), /stale/); assert.equal(f.calls.generate, 0);
  f.native.cycle = async () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task] });
  fs.writeFileSync(f.task.payload.images[0].references[0].path, 'changed');
  await assert.rejects(() => f.runtime.tick(), /hash_changed/); assert.equal(f.calls.generate, 0);
});
test('mockup accepts only exact configured external fold and palette references; generated assets stay scoped', async t => {
  const f = fixture(t), external = fs.mkdtempSync(path.join(os.tmpdir(), 'approved-mockup-refs-'));
  t.after(() => fs.rmSync(external, { recursive: true, force: true }));
  const file = path.join(external, 'fold.png'), other = path.join(external, 'same-bytes.png');
  fs.writeFileSync(file, 'approved-fold'); fs.writeFileSync(other, 'approved-fold');
  const reference = { role: 'fold_framing_zoom_only', path: file, sha256: hash('approved-fold') };
  const plan = path.join(f.root, 'workspace/chat-handoff/20261014-prompt-authoring/embroidered-apparel-10-photo-plan-v001.json');
  fs.mkdirSync(path.dirname(plan), { recursive: true }); fs.writeFileSync(plan, JSON.stringify({ references: [reference] }));
  batchTask(f); f.task.payload.images[0].references.push(reference);
  const snapshot = () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [f.task] });
  assert.equal(f.runtime.task(snapshot(), f.task.id).id, f.task.id);
  assert.throws(() => f.runtime.asset(reference), /asset_outside_workflow_root/);
  assert.throws(() => f.runtime.asset(reference, f.task.payload.output_directory), /asset_outside_workflow_root/);
  assert.throws(() => f.runtime.reference({ ...reference, path: other }, f.task), /asset_outside_workflow_root/);
  assert.throws(() => f.runtime.reference({ ...reference, role: 'exact_locked_2d' }, f.task), /asset_outside_workflow_root/);
  assert.throws(() => f.runtime.reference(reference, { kind: 'flow_design_2d' }), /asset_outside_workflow_root/);
  assert.throws(() => f.runtime.reference({ ...reference, sha256: 'b'.repeat(64) }, f.task), /asset_outside_workflow_root/);
  fs.writeFileSync(file, 'changed-fold');
  assert.throws(() => f.runtime.task(snapshot(), f.task.id), /asset_hash_changed/);
  assert.equal(f.calls.generate, 0);
});
test('task replacement before click prevents Generate', async t => {
  const f = fixture(t); let count = 0;
  f.native.cycle = async () => ({ ok: true, observed_at: new Date().toISOString(), tasks: ++count === 1 ? [f.task] : [] });
  assert.equal((await f.runtime.tick()).status, 'idle'); assert.equal(f.calls.generate, 0);
});
test('fake visual QA and screenshot substitution fail closed', async t => {
  const f = fixture(t); const original = f.adapter.generate;
  f.adapter.generate = async (...args) => { const result = await original(...args); result.proof.visually_verified = true; return result; };
  await assert.rejects(() => f.runtime.tick(), /proof_required/);
  assert.equal(f.calls.execute.length, 0);
});
test('single-process lock rejects duplicate worker and cleanup closes only owned adapter', async t => {
  const f = fixture(t); const { claimProcessLock } = require('./native-n8n.cjs');
  const release = claimProcessLock(path.join(f.config.stateDir, 'worker.lock'));
  await assert.rejects(() => f.runtime.run({ once: true }), /already_running/); release();
  await f.runtime.run({ once: true, readinessOnly: true }); assert.equal(f.calls.closed, 1);
});
test('config requires dedicated worker profile and authorized model/native IDs', t => {
  const f = fixture(t); assert.equal(validateConfig(f.config), f.config);
  for (const [key, value] of [['profileDir', path.join(f.root, 'other-profile')], ['model', 'Other Model'], ['projectUrl', 'https://example.com'], ['mainWorkflowId', 'OtherID'], ['pollIntervalMs', 0]]) {
    assert.throws(() => validateConfig({ ...f.config, [key]: value }));
  }
});
test('expired Lark review is renewed once before any browser interaction', async t => {
  const f = fixture(t);
  let expired = true;
  const entity = { brief_id: 'TEST' };
  f.native.cycle = async () => ({ ok: true, observed_at: new Date().toISOString(), tasks: [], reviews: [{ review_id: expired ? 'old-review' : 'new-review', entity }] });
  f.native.execute = async command => { f.calls.execute.push(command); expired = false; return { ok: true }; };
  f.runtime.reviewState = async id => ({ review_id: id, expires_at: expired ? 0 : Date.now() + 60000, status: 'pending' });
  await f.runtime.tick(); await f.runtime.tick();
  assert.deepEqual(f.calls.execute, [{ action: 'lark_review_refresh', brief_id: 'TEST', review_id: 'old-review' }]);
  assert.equal(f.calls.start, 0); assert.equal(f.calls.generate, 0);
});
test('failed block notice retries same code after connection recovers and survives restart', async t => {
  const f = fixture(t); let offline = true; let attempts = 0;
  f.runtime.notify = async () => { attempts++; if (offline) throw new Error('offline'); };
  f.runtime.larkReadiness = async () => ({ ready: false, code: 'lark_service_unavailable' });
  await f.runtime.tick(); assert.equal(attempts, 1);
  const restarted = new FlowRuntime(f.config, { native: f.native, adapter: f.adapter, notify: f.runtime.notify });
  restarted.larkReadiness = f.runtime.larkReadiness; offline = false;
  await restarted.tick(); assert.equal(attempts, 2);
  await restarted.tick(); assert.equal(attempts, 2);
  restarted.larkReadiness = async () => ({ ready: true }); f.setTasks([]);
  await restarted.tick(); assert.equal(attempts, 3);
  await restarted.tick(); assert.equal(attempts, 3);
});
test('owned browser crash reopens profile and resumes pending generation without new click', async t => {
  const f = fixture(t); let crashed = false; let recovered = 0;
  f.adapter.readiness = async () => crashed ? { ready: false, code: 'flow_browser_closed' } : { ready: true };
  f.adapter.recoverBrowser = async () => { recovered++; crashed = false; return { ready: true }; };
  f.adapter.generate = async (_i, _r, _o, hooks) => {
    if (!hooks.resume) { await hooks.beforeGenerate({ generation_id: 'pending-before-crash', recovery: { baseline: [] } }); crashed = true; throw new Error('browser_crashed'); }
    assert.equal(hooks.resume.generation_id, 'pending-before-crash'); return f.result();
  };
  await assert.rejects(() => f.runtime.tick(), /browser_crashed/);
  await f.runtime.tick(); assert.equal(recovered, 1); assert.equal(f.calls.execute.length, 1);
});

test('unusual activity keeps the durable generation checkpoint across worker restart', async t => {
  const f = fixture(t); let clicks = 0;
  f.adapter.generate = async (_item, _refs, _directory, hooks) => {
    if (!hooks.resume) { await hooks.beforeGenerate({ generation_id: 'original-generation', recovery: { baseline: [] } }); clicks++; }
    const error = Error('Google rejected generation'); error.code = 'flow_unusual_activity_required'; throw error;
  };
  await f.runtime.run({ once: true });
  assert.equal(f.runtime.load(f.task).images.chest.status, 'generation_started');
  const restarted = new FlowRuntime(f.config, { native: f.native, adapter: f.adapter, notify: async status => f.calls.notify.push(status) });
  restarted.larkReadiness = async () => ({ ready: true });
  await restarted.run({ once: true });
  assert.equal(clicks, 1); assert.equal(f.calls.execute.length, 0);
  assert.equal(restarted.load(f.task).images.chest.generation_id, 'original-generation');
  assert.equal(f.calls.notify[0].code, 'flow_unusual_activity_required');
});
test('authorized unusual-activity cooldown survives restart and starts one new generation after ten minutes',async t=>{
  const f=fixture(t);let clock=Date.now(),warning=true,acknowledged=0,permits=[];
  const policy={enabled:true,cooldown_ms:600000,reference:'Actual fixture user requested ten-minute cooldown then new Generate'};
  f.runtime.now=()=>clock;
  const initial=f.runtime.load(f.task);initial.images.chest={status:'generation_started',generation_id:'old-failed',recovery:{baseline:[]}};
  initial.images.preserved={status:'acquired',...f.result()};f.runtime.save(initial);
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[f.task],reviews:[],unusual_activity_policy:policy,generation_retries:permits});
  f.adapter.readiness=async()=>warning?{ready:false,code:'flow_unusual_activity_required'}:{ready:true};
  f.adapter.unusualActivityEvidence=async file=>{fs.writeFileSync(file,'actual-fixture-warning');return {screenshot_path:file,screenshot_sha256:hash('actual-fixture-warning'),failed_tiles:['Failed unusual activity']};};
  f.adapter.acknowledgeFailedTiles=async()=>{acknowledged++;warning=false;return ['Failed unusual activity'];};
  f.native.execute=async cmd=>{f.calls.execute.push(cmd);if(cmd.generation_retry){assert.equal(f.runtime.load(f.task).images.chest.generation_id,'old-failed');permits=[{...cmd.generation_retry,reference:cmd.reference,permit_id:'b'.repeat(64)}];}return {ok:true};};
  f.adapter.generate=async(_item,_refs,_dir,hooks)=>{f.calls.generate++;assert.equal(hooks.resume.status,'ready');await hooks.beforeGenerate({generation_id:'new-generation',recovery:{baseline:[],failure_baseline:['Failed unusual activity']}});return f.result();};
  const first=await f.runtime.tick();assert.equal(first.status,'cooldown');assert.equal(first.remaining_seconds,600);assert.equal(f.calls.generate,0);
  clock+=599999;
  const restarted=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:()=>clock,notify:async()=>{}});restarted.larkReadiness=async()=>({ready:true});
  assert.equal((await restarted.tick()).status,'cooldown');assert.equal(f.calls.generate,0);assert.equal(acknowledged,0);assert.equal(f.calls.restarted,0);
  clock++;assert.equal((await restarted.tick()).status,'awaiting_human_review');assert.equal(f.calls.generate,1);assert.equal(acknowledged,1);assert.equal(f.calls.restarted,1);
  const state=restarted.load(f.task);assert.equal(state.images.preserved.asset.sha256,initial.images.preserved.asset.sha256);
  assert.equal(state.events.filter(e=>e.event==='generation_retry_authorized').length,1);
  assert.equal(state.events.find(e=>e.event==='generation_retry_authorized').prior_generation.generation_id,'old-failed');
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);
});
test('cooldown restart stops on login without replacing the pending generation or repeatedly restarting',async t=>{
  const f=fixture(t);let clock=Date.now();f.runtime.now=()=>clock;
  const state=f.runtime.load(f.task);state.images.chest={status:'generation_started',generation_id:'failed-original'};
  state.unusual_activity_cooldown={image_key:'chest',generation_id:'failed-original',not_before:new Date(clock).toISOString()};f.runtime.save(state);
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[f.task],reviews:[],unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:'User requests Chrome restart after cooldown'}});
  f.adapter.readiness=async()=>({ready:false,code:'flow_login_required'});
  assert.equal((await f.runtime.tick()).code,'flow_login_required');
  assert.equal((await f.runtime.tick()).code,'flow_login_required');
  assert.equal(f.calls.restarted,1);assert.equal(f.calls.generate,0);assert.equal(f.calls.execute.length,0);
  const saved=f.runtime.load(f.task);assert.equal(saved.images.chest.generation_id,'failed-original');assert.ok(saved.unusual_activity_cooldown.browser_restarted_at);
});

test('native timed replacement permit waits ten minutes even when the old Failed tile is gone',async t=>{
  const f=fixture(t);let clock=Date.now(),acknowledged=0;
  f.runtime.now=()=>clock;const state=f.runtime.load(f.task);state.images.chest={status:'generation_started',generation_id:'old-lost-tile',recovery:{baseline:[]}};f.runtime.save(state);
  const permit={task_id:f.task.id,task_fingerprint:f.task.fingerprint,revision:1,image_key:'chest',generation_id:'old-lost-tile',reference:'Direct fixture user requests fresh Generate',permit_id:'c'.repeat(64),authorized_at:new Date(clock).toISOString(),not_before:new Date(clock+600000).toISOString()};
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[f.task],reviews:[],unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:permit.reference},generation_retries:[permit]});
  f.adapter.acknowledgeFailedTiles=async()=>{acknowledged++;return [];};
  f.adapter.generate=async(_i,_r,_o,hooks)=>{f.calls.generate++;assert.equal(hooks.resume.status,'ready');await hooks.beforeGenerate({generation_id:'fresh',recovery:{baseline:[]}});return f.result();};
  assert.equal((await f.runtime.tick()).status,'cooldown');assert.equal(f.calls.generate,0);assert.equal(f.calls.execute.length,0);
  clock+=599999;assert.equal((await f.runtime.tick()).status,'cooldown');assert.equal(f.calls.generate,0);
  clock++;assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(f.calls.generate,1);assert.equal(acknowledged,1);
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);
});
test('changing tasks during account cooldown cannot start another Generate early',async t=>{
  const f=fixture(t);const clock=Date.now();f.runtime.now=()=>clock;
  f.runtime.cooldownStatus(f.task,{unusual_activity_cooldown:{image_key:'chest',not_before:new Date(clock+600000).toISOString()}});
  const other={...f.task,id:'next-task'};
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[other],reviews:[],unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:'Fixture user authorized cooldown'}});
  const result=await f.runtime.tick();assert.equal(result.status,'cooldown');assert.equal(result.task_id,f.task.id);assert.equal(f.calls.start,0);assert.equal(f.calls.generate,0);
});
test('expired account cooldown reopens Chrome and acknowledges old failure before a revised task starts',async t=>{
  const f=fixture(t);const clock=Date.now();f.runtime.now=()=>clock;
  f.runtime.cooldownStatus(f.task,{unusual_activity_cooldown:{image_key:'chest',observed_at:new Date(clock-600001).toISOString(),not_before:new Date(clock-1).toISOString()}});
  const revised={...f.task,id:'revised-task',revision:2,payload:{...f.task.payload,revision:2}};
  const policy={enabled:true,cooldown_ms:600000,reference:'Fixture user authorized cooldown and reopening Chrome'};
  let warning=true,acknowledged=0;
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[revised],reviews:[],unusual_activity_policy:policy});
  f.adapter.readiness=async()=>warning?{ready:false,code:'flow_unusual_activity_required'}:{ready:true};
  f.adapter.acknowledgeFailedTiles=async()=>{acknowledged++;warning=false;return ['Failed unusual activity'];};
  const generate=f.adapter.generate;
  f.adapter.generate=async(...args)=>{assert.equal(f.calls.restarted,1);assert.equal(acknowledged,1);return generate(...args);};
  assert.equal((await f.runtime.tick()).status,'awaiting_human_review');
  assert.equal(f.calls.generate,1);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);
  const receipt=JSON.parse(fs.readFileSync(path.join(f.config.stateDir,'unusual-activity-cooldown.json'),'utf8'));
  assert.equal(receipt.task_id,revised.id);assert.equal(Date.parse(receipt.consumed_at),clock);
  assert.equal(f.runtime.load(revised).events.filter(e=>e.event==='account_cooldown_carried_to_new_task').length,1);
});
test('another unusual-activity failure after a fresh Generate starts another full ten-minute cooldown',async t=>{
  const f=fixture(t);let clock=Date.now(),permits=[],attempts=0;
  f.runtime.now=()=>clock;
  const policy={enabled:true,cooldown_ms:600000,reference:'Actual fixture user authorizes new Generate after each ten-minute unusual-activity cooldown'};
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[f.task],reviews:[],unusual_activity_policy:policy,generation_retries:permits});
  f.native.execute=async cmd=>{assert.ok(cmd.generation_retry);permits.push({...cmd.generation_retry,reference:cmd.reference,permit_id:'d'.repeat(64)});return {ok:true};};
  f.adapter.unusualActivityEvidence=async file=>{fs.writeFileSync(file,'fixture-failure');return {screenshot_path:file,screenshot_sha256:hash('fixture-failure'),failed_tiles:['Failed unusual activity']};};
  f.adapter.acknowledgeFailedTiles=async()=>['Failed unusual activity'];
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'failed-'+attempts,recovery:{baseline:[]}});const error=Error('Flow rejected generation');error.code='flow_unusual_activity_required';throw error;};
  const first=await f.runtime.tick();assert.equal(first.status,'cooldown');assert.equal(first.remaining_seconds,600);assert.equal(attempts,1);
  clock+=600000;
  const second=await f.runtime.tick();assert.equal(second.status,'cooldown');assert.equal(second.remaining_seconds,600);assert.equal(attempts,2);
  assert.equal(Date.parse(second.resume_at)-Date.parse(first.resume_at),600000);
  clock+=599999;await f.runtime.tick();assert.equal(attempts,2);
});

test('Lark error notification explains unusual activity and preserved checkpoint', async t => {
  const f = fixture(t); let payload;
  fs.writeFileSync(f.config.larkConfigFile, JSON.stringify({ localToken: 'test-only' }));
  t.mock.method(global, 'fetch', async (_url, options) => { payload = JSON.parse(options.body); return { ok: true }; });
  await f.runtime.notifyLark({ status: 'blocked', code: 'flow_unusual_activity_required', task_id: f.task.id });
  assert.match(payload.message, /We noticed some unusual activity/);
  assert.match(payload.message, /checkpoint/);assert.match(payload.message, /không tự tạo lại/);assert.match(payload.message, /Tiếp tục mẻ/);
});

function failureRetryFixture(t, selectedBatch=false) {
  const f=fixture(t);let clock=Date.now(),permits=[];
  let stopped=false;
  if(selectedBatch)fs.writeFileSync(path.join(f.config.stateDir,'image-provider.json'),JSON.stringify({provider:'flow',batch_id:'batch-A'}));
  f.runtime.now=()=>clock;
  f.native.cycle=async()=>({ok:true,observed_at:new Date(clock).toISOString(),tasks:[f.task],reviews:[],generation_retries:permits,
    unusual_activity_policy:{enabled:true,cooldown_ms:600000,reference:'Fixture user retains ten-minute unusual activity cooldown'},
    generation_failure_policy:{enabled:true,cooldown_ms:60000,reference:'Fixture user requests one-minute confirmed Failed retry'}});
  f.native.execute=async cmd=>{f.calls.execute.push(cmd);if(cmd.action==='batch_status')return {ok:true,batches:[{batch_id:'batch-A',fingerprint:'a'.repeat(64),status:stopped?'stopped':'active'}]};if(cmd.action==='batch_stop'){stopped=true;return {ok:true,status:'batch_stopped'};}if(cmd.generation_retry)permits.push({...cmd.generation_retry,reference:cmd.reference,permit_id:hash(JSON.stringify(cmd.generation_retry))});return {ok:true};};
  const evidence=async file=>{fs.writeFileSync(file,'fixture-confirmed-failure');return {screenshot_path:file,screenshot_sha256:hash('fixture-confirmed-failure'),failed_tiles:['Failed Image could not be generated.']};};
  f.adapter.generationFailureEvidence=f.adapter.unusualActivityEvidence=evidence;
  f.adapter.acknowledgeFailedTiles=async()=>['Failed Image could not be generated.'];
  return {...f,advance:ms=>{clock+=ms;},now:()=>clock};
}

test('selected unusual activity notifies once and waits ten minutes across restart without stopping or retrying',async t=>{
  const f=failureRetryFixture(t,true);let attempts=0;
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'unusual-pending',recovery:{baseline:[]}});throw Object.assign(Error('Unusual activity'),{code:'flow_unusual_activity_required'});};
  const first=await f.runtime.tick();assert.equal(first.status,'cooldown');assert.equal(first.next_action,'check_warning');assert.equal(first.remaining_seconds,600);
  assert.equal(f.calls.notify.length,1);assert.equal(f.calls.execute.length,0);assert.equal(fs.existsSync(path.join(f.config.stateDir,'workflow-error-hold.json')),false);
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async s=>f.calls.notify.push(s)});restart.larkReadiness=async()=>({ready:true});
  f.advance(599999);assert.equal((await restart.tick()).status,'cooldown');assert.equal(attempts,1);assert.equal(f.calls.notify.length,1);assert.equal(f.calls.restarted,0);
  f.advance(1);f.adapter.generationFailure=async()=> 'flow_unusual_activity_required';
  assert.equal((await restart.tick()).code,'flow_unusual_activity_required');assert.equal(attempts,1);
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);assert.equal(f.calls.execute.filter(c=>c.action==='batch_stop').length,1);
});

test('cleared unusual warning permits one same-session retry after ten minutes without acknowledging failed tiles',async t=>{
  const f=failureRetryFixture(t,true);let attempts=0;
  f.adapter.acknowledgeFailedTiles=async()=>assert.fail('must not suppress unusual warnings');
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'unusual-'+attempts,recovery:{baseline:[]}});if(attempts===1)throw Object.assign(Error('Unusual activity'),{code:'flow_unusual_activity_required'});return f.result();};
  await f.runtime.tick();f.advance(600000);f.adapter.generationFailure=async()=>null;
  assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(attempts,2);assert.equal(f.calls.restarted,0);
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);assert.equal(f.calls.execute.filter(c=>c.action==='batch_stop').length,0);assert.equal(f.calls.notify.length,1);
  const state=f.runtime.load(f.task);assert.equal(state.unusual_activity_cooldown,undefined);assert.equal(state.events.filter(e=>e.event==='unusual_warning_cleared').length,1);
  assert.ok(JSON.parse(fs.readFileSync(path.join(f.config.stateDir,'unusual-activity-cooldown.json'),'utf8')).consumed_at);
});

test('repeated unusual warning or a policy block after ten minutes stops without another cooldown loop',async t=>{
  for(const after of ['recurring','flow_policy_review_required']){
    const f=failureRetryFixture(t,true);let attempts=0;
    f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'warning-'+attempts,recovery:{baseline:[]}});throw Object.assign(Error('Unusual activity'),{code:'flow_unusual_activity_required'});};
    await f.runtime.tick();f.advance(600000);f.adapter.generationFailure=async()=>after==='recurring'?null:after;
    const stopped=await f.runtime.tick();assert.equal(stopped.status,'blocked');assert.equal(stopped.code,after==='recurring'?'flow_unusual_activity_required':after);
    assert.equal(attempts,after==='recurring'?2:1);assert.equal(f.calls.execute.filter(c=>c.action==='batch_stop').length,1);assert.equal(f.calls.restarted,0);
  }
});

test('selected batch transient Failed waits silently and resumes after restart without batch stop or push',async t=>{
  const f=failureRetryFixture(t,true);let attempts=0;
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'quiet-'+attempts,recovery:{baseline:[]}});if(attempts===1)throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});return f.result();};
  const first=await f.runtime.tick();assert.equal(first.status,'cooldown');assert.equal(first.silent,true);assert.equal(first.automatic_retry,true);
  assert.equal(f.calls.notify.length,0);assert.equal(f.calls.execute.length,0);assert.equal(fs.existsSync(path.join(f.config.stateDir,'workflow-error-hold.json')),false);
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async s=>f.calls.notify.push(s)});restart.larkReadiness=async()=>({ready:true});
  f.advance(59999);assert.equal((await restart.tick()).status,'cooldown');assert.equal(attempts,1);
  f.advance(1);assert.equal((await restart.tick()).status,'awaiting_human_review');assert.equal(attempts,2);
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);assert.equal(f.calls.execute.filter(c=>c.action==='batch_stop').length,0);assert.equal(f.calls.notify.length,0);
});

test('selected batch stops and notifies only after two silent Failed retries, and the hold survives more ticks',async t=>{
  const f=failureRetryFixture(t,true);let attempts=0;
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'repeated-'+attempts,recovery:{baseline:[]}});throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});};
  assert.equal((await f.runtime.tick()).status,'cooldown');assert.equal(f.calls.notify.length,0);
  f.advance(60000);assert.equal((await f.runtime.tick()).status,'cooldown');assert.equal(f.calls.notify.length,0);
  f.advance(60000);const stopped=await f.runtime.tick();assert.equal(stopped.status,'blocked');assert.equal(stopped.code,'flow_generation_retry_exhausted');assert.equal(stopped.requires_user_resume,true);
  assert.equal(attempts,3);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,2);assert.equal(f.calls.execute.filter(c=>c.action==='batch_stop').length,1);assert.equal(f.calls.notify.length,1);
  await f.runtime.tick();assert.equal(attempts,3);assert.equal(f.calls.notify.length,1);
});

test('policy or quota appearing during a quiet cooldown stops before retry authorization or Generate',async t=>{
  for(const code of ['flow_policy_review_required','flow_quota_required']){
    const f=failureRetryFixture(t,true);let attempts=0;
    f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'guarded',recovery:{baseline:[]}});throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});};
    await f.runtime.tick();f.advance(60000);f.adapter.generationFailure=async()=>code;
    assert.equal((await f.runtime.tick()).code,code);assert.equal(attempts,1);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);assert.equal(f.calls.notify.length,1);
  }
});

test('confirmed Failed waits sixty seconds across restart, preserves acquired assets and retries once through native permit',async t=>{
  const f=failureRetryFixture(t),state=f.runtime.load(f.task);let attempts=0;
  state.images.preserved={status:'acquired',...f.result()};f.runtime.save(state);
  f.adapter.generate=async(_i,_r,_o,hooks)=>{
    attempts++;await hooks.beforeGenerate({generation_id:'generation-'+attempts,recovery:{baseline:[]}});
    if(attempts===1)throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});
    assert.equal(hooks.resume.status,'ready');return f.result();
  };
  const first=await f.runtime.tick();assert.equal(first.code,'flow_generation_failure_cooldown');assert.equal(first.remaining_seconds,60);
  assert.equal(f.calls.execute.length,0);assert.equal(attempts,1);
  f.advance(59999);
  const restarted=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async()=>{}});restarted.larkReadiness=async()=>({ready:true});
  assert.equal((await restarted.tick()).status,'cooldown');assert.equal(attempts,1);
  f.advance(1);assert.equal((await restarted.tick()).status,'awaiting_human_review');assert.equal(attempts,2);
  const saved=restarted.load(f.task);assert.equal(saved.images.preserved.asset.sha256,state.images.preserved.asset.sha256);
  assert.equal(saved.events.filter(e=>e.event==='generation_retry_authorized').length,1);
  assert.equal(saved.events.find(e=>e.event==='generation_retry_authorized').prior_generation.generation_id,'generation-1');
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);assert.equal(f.calls.restarted,0);
  await restarted.tick();assert.equal(attempts,2);
});

test('each new confirmed Failed starts another sixty seconds without resetting the old deadline while waiting',async t=>{
  const f=failureRetryFixture(t);let attempts=0;
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'failed-'+attempts,recovery:{baseline:[]}});throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});};
  const first=await f.runtime.tick();f.advance(30000);assert.equal((await f.runtime.tick()).resume_at,first.resume_at);
  f.advance(30000);const second=await f.runtime.tick();assert.equal(second.remaining_seconds,60);assert.equal(attempts,2);
  assert.equal(Date.parse(second.resume_at)-Date.parse(first.resume_at),60000);
  f.advance(59999);await f.runtime.tick();assert.equal(attempts,2);
});

test('unusual activity supersedes a one-minute Failed cooldown and still waits a full ten minutes',async t=>{
  const f=failureRetryFixture(t);
  f.adapter.generate=async(_i,_r,_o,hooks)=>{await hooks.beforeGenerate({generation_id:'failed',recovery:{baseline:[]}});throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});};
  await f.runtime.tick();f.advance(60000);
  f.adapter.readiness=async()=>({ready:false,code:'flow_unusual_activity_required'});
  const status=await f.runtime.tick();assert.equal(status.code,'flow_unusual_activity_cooldown');assert.equal(status.remaining_seconds,600);
  assert.equal(f.runtime.load(f.task).generation_failure_cooldown,undefined);assert.equal(f.calls.execute.length,0);
  f.advance(599999);assert.equal((await f.runtime.tick()).status,'cooldown');assert.equal(f.calls.execute.length,0);
});

test('one-minute Failed policy never replaces an uncertain generation or bypasses login',async t=>{
  const f=failureRetryFixture(t);
  f.adapter.generate=async(_i,_r,_o,hooks)=>{await hooks.beforeGenerate({generation_id:'unknown',recovery:{baseline:[]}});throw Object.assign(Error('unknown result'),{code:'flow_generation_reconcile_required'});};
  await assert.rejects(f.runtime.tick(),{code:'flow_generation_reconcile_required'});
  assert.equal(f.runtime.load(f.task).generation_failure_cooldown,undefined);assert.equal(f.calls.execute.length,0);
  f.adapter.generate=async()=>{throw Object.assign(Error('Failed'),{code:'flow_generation_failed'});};
  await f.runtime.tick();f.advance(60000);f.adapter.readiness=async()=>({ready:false,code:'flow_login_required'});
  assert.equal((await f.runtime.tick()).code,'flow_login_required');assert.equal(f.calls.execute.length,0);
  assert.equal(f.runtime.load(f.task).images.chest.generation_id,'unknown');
});

test('might-violate mockup is canonically skipped and the other views submit without retry, stop or push',async t=>{
  const f=fixture(t);batchTask(f,'mockups',batchNames);let active=true;const skipped=[];
  f.native.cycle=async()=>({ok:true,observed_at:new Date().toISOString(),tasks:active?[{...f.task,skipped_images:skipped}]:[],reviews:[]});
  f.adapter.generationFailureEvidence=async file=>{fs.writeFileSync(file,'fixture-skip-screen');return {screenshot_path:file,screenshot_sha256:hash('fixture-skip-screen'),failed_tiles:['Failed This generation might violate our policies.']};};
  f.adapter.acknowledgeFailedTiles=async()=>['Failed This generation might violate our policies.'];
  f.native.execute=async cmd=>{f.calls.execute.push(cmd);if(cmd.mockup_skip){skipped.push({...cmd.mockup_skip,reference:cmd.reference,reason:'flow_generation_might_violate'});return f.native.cycle();}active=false;return {ok:true};};
  f.adapter.generate=async(item,_r,dir,hooks)=>{f.calls.generate++;await hooks.beforeGenerate({generation_id:'g-'+item.name});if(item.name===batchNames[1])throw Object.assign(Error('might violate'),{code:'flow_generation_might_violate'});const r=f.result(),file=path.join(dir,item.name);fs.writeFileSync(file,item.name);return {...r,asset:{path:file,sha256:hash(item.name)}};};
  const result=await f.runtime.tick();assert.equal(result.status,'awaiting_human_review');assert.equal(f.calls.generate,6);
  assert.equal(f.calls.execute.filter(c=>c.mockup_skip).length,1);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);assert.equal(f.calls.notify.length,0);
  const submitted=f.calls.execute.find(c=>c.action==='flow_auto_submit');assert.deepEqual(submitted.assets.map(a=>a.image_key),batchNames.filter(n=>n!==batchNames[1]));
  assert.equal(f.runtime.load(f.task).images[batchNames[1]].status,'skipped');
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,notify:async s=>f.calls.notify.push(s)});restart.larkReadiness=async()=>({ready:true});
  await restart.tick();assert.equal(f.calls.generate,6);
});

test('design and embroidery might-violate failures retain the one-minute retry path',async t=>{
  for(const stage of ['2d','embroidery']){
    const f=failureRetryFixture(t,true);let attempts=0;
    f.task.kind='flow_design_'+stage;f.task.payload.stage=stage;
    if(stage==='embroidery')f.task.payload.images[0].references[0].role='exact_locked_2d';
    f.adapter.generate=async(_i,_r,_d,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'soft-'+attempts});if(attempts===1)throw Object.assign(Error('might violate'),{code:'flow_generation_might_violate'});return f.result();};
    f.adapter.generationFailure=async()=> 'flow_generation_might_violate';
    assert.equal((await f.runtime.tick()).status,'cooldown');f.advance(60000);
    assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(attempts,2);assert.equal(f.calls.execute.filter(c=>c.mockup_skip).length,0);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);
  }
});

test('local skipped state without the canonical receipt and changed skip bindings fail closed',async t=>{
  const f=fixture(t);batchTask(f,'mockups');const state=f.runtime.load(f.task);state.images[batchNames[0]]={status:'skipped',generation_id:'original'};
  assert.throws(()=>f.runtime.reconcileSkipped(f.task,state),/mockup_skip_receipt_missing/);
  f.task.skipped_images=[{task_id:f.task.id,task_fingerprint:'b'.repeat(64),revision:1,image_key:batchNames[0],generation_id:'original',reference:'fixture',reason:'flow_generation_might_violate'}];
  assert.throws(()=>f.runtime.reconcileSkipped(f.task,state),/mockup_skip_binding_changed/);
});

function waitGenerateFixture(t) {
  const f=failureRetryFixture(t,true),cycle=f.native.cycle;
  f.native.cycle=async()=>{const s=await cycle();s.unusual_activity_policy.retry_after_cooldown=true;return s;};
  f.adapter.resumeAfterUnusualFailure=async(_item,image,evidence)=>{
    assert.equal(image.status,'generation_started');assert.equal(evidence.generation_id,image.generation_id);
    f.calls.baselined=(f.calls.baselined||0)+1;return [...(image.recovery.failure_baseline||[]),...evidence.failed_tiles];
  };
  f.adapter.generationFailure=async()=>null;
  f.adapter.acknowledgeFailedTiles=async()=>assert.fail('do not acknowledge unrelated Failed tiles');
  return f;
}
test('unusual retains Failed and waits ten minutes across restart before one same-prompt new Generate',async t=>{
  const f=waitGenerateFixture(t);let attempts=0;
  assert.equal(f.adapter.deleteUnusualFailedTile,undefined);
  f.adapter.generate=async(item,refs,_out,hooks)=>{
    assert.deepEqual(item,f.task.payload.images[0]);assert.deepEqual(refs,item.references);
    attempts++;await hooks.beforeGenerate({generation_id:'wait-'+attempts,recovery:{baseline:[]}});
    if(attempts===1)throw Object.assign(Error('warning'),{code:'flow_unusual_activity_required'});return f.result();
  };
  const start=await f.runtime.tick();assert.equal(start.remaining_seconds,600);assert.equal(start.next_action,'new_generation');assert.equal(attempts,1);assert.equal(f.calls.baselined,undefined);
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async s=>f.calls.notify.push(s)});restart.larkReadiness=async()=>({ready:true});
  f.advance(599999);assert.equal((await restart.tick()).remaining_seconds,1);assert.equal(attempts,1);
  f.advance(1);assert.equal((await restart.tick()).status,'awaiting_human_review');assert.equal(attempts,2);assert.equal(f.calls.baselined,1);
  const journal=f.runtime.load(f.task);assert.equal(journal.events.filter(e=>e.event==='unusual_activity_retry_authorized').length,1);assert.equal(journal.events.filter(e=>e.event==='unusual_warning_cleared').length,0);
  assert.equal(f.calls.restarted,0);assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,1);
});
test('new wait-only policy on an expired held checkpoint waits ten new minutes without browser actions',async t=>{
  const f=waitGenerateFixture(t),state=f.runtime.load(f.task),file=path.join(f.config.stateDir,'old-warning.png');fs.writeFileSync(file,'old');
  state.images.chest={status:'generation_started',generation_id:'old-unusual',recovery:{baseline:[]}};
  state.unusual_activity_cooldown={wait_only:true,image_key:'chest',generation_id:'old-unusual',observed_at:new Date(f.now()-1000000).toISOString(),not_before:new Date(f.now()-400000).toISOString(),screenshot_path:file,screenshot_sha256:hash('old'),failed_tiles:['Failed unusual activity'],cleanup_started_at:new Date(f.now()-1000).toISOString()};f.runtime.save(state);
  const result=await f.runtime.tick();assert.equal(result.remaining_seconds,600);assert.equal(f.calls.generate,0);assert.equal(f.calls.start,0);
  const deadline=f.runtime.load(f.task).unusual_activity_cooldown.not_before;f.advance(1000);await f.runtime.tick();assert.equal(f.runtime.load(f.task).unusual_activity_cooldown.not_before,deadline);
  assert.equal(f.runtime.load(f.task).images.chest.generation_id,'old-unusual');
});
test('changing immediate unusual handover to wait migrates its saved failure and keeps a full ten minutes across restart',async t=>{
  const f=waitGenerateFixture(t),s=f.runtime.load(f.task),file=path.join(f.root,'immediate-warning.png');fs.writeFileSync(file,'evidence');
  f.adapter.generate=async(_i,_r,_o,hooks)=>{f.calls.generate++;await hooks.beforeGenerate({generation_id:'new-waited-generation',recovery:{baseline:[]}});return f.result();};
  s.images.chest={status:'generation_started',generation_id:'current-third',recovery:{baseline:[]}};
  s.images.done={status:'acquired',...f.result()};const done=JSON.stringify(s.images.done);
  s.unusual_activity_cooldown={image_key:'chest',generation_id:'current-third',failed_tiles:['Failed We noticed some unusual activity.'],screenshot_path:file,screenshot_sha256:hash('evidence')};f.runtime.save(s);
  let result=await f.runtime.tick();assert.equal(result.remaining_seconds,600);assert.equal(f.calls.start,0);assert.equal(f.calls.generate,0);
  const deadline=f.runtime.load(f.task).unusual_activity_cooldown.not_before;
  const restart=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async s=>f.calls.notify.push(s)});restart.larkReadiness=async()=>({ready:true});
  f.advance(599999);result=await restart.tick();assert.equal(result.remaining_seconds,1);assert.equal(f.calls.generate,0);assert.equal(f.runtime.load(f.task).unusual_activity_cooldown.not_before,deadline);
  f.advance(1);assert.equal((await restart.tick()).status,'awaiting_human_review');assert.equal(f.calls.generate,1);
  assert.equal(JSON.stringify(f.runtime.load(f.task).images.done),done);assert.equal(f.calls.execute.filter(c=>c.generation_retry)[0].generation_retry.generation_id,'current-third');
});
test('explicit previous-account permit waits, uses saved old-project evidence, and replaces only the current generation',async t=>{
  const f=waitGenerateFixture(t),s=f.runtime.load(f.task),file=path.join(f.root,'return-warning.png');fs.writeFileSync(file,'evidence');
  f.adapter.generate=async(_i,_r,_o,hooks)=>{f.calls.generate++;await hooks.beforeGenerate({generation_id:'new-old-account-generation',recovery:{baseline:[]}});return f.result();};
  const evidence={generation_id:'previous-account-failed',failed_tiles:['Failed We noticed some unusual activity.'],screenshot_path:file,screenshot_sha256:hash('evidence')};
  const prior={status:'generation_started',generation_id:evidence.generation_id,recovery:{project_url:'https://flow.google.com/u/1/project/old?hl=en'}};
  s.events.push({event:'generation_retry_authorized',image_key:'chest',prior_generation:prior},{event:'unusual_account_handover',image_key:'chest',generation_id:evidence.generation_id,unusual_activity_cooldown:evidence});
  s.images.chest={status:'generation_started',generation_id:'current-third',recovery:{baseline:[]}};
  s.unusual_activity_cooldown={image_key:'chest',generation_id:'current-third',...evidence,generation_id:'current-third'};f.runtime.save(s);
  const permit={task_id:f.task.id,task_fingerprint:f.task.fingerprint,revision:1,image_key:'chest',generation_id:'current-third',return_generation_id:evidence.generation_id,return_account_sha256:hash('old@example.com'),cooldown_ms:600000,not_before:new Date(f.now()+600000).toISOString(),reference:'User explicitly returns previous account once',permit_id:hash('return-permit')};
  const cycle=f.native.cycle;f.native.cycle=async()=>({...await cycle(),generation_retries:[permit]});let returned=0;
  f.adapter.resumeUnusualOnPreviousAccount=async(_item,image,proof,key)=>{returned++;assert.deepEqual(image,prior);assert.deepEqual(proof,evidence);assert.equal(key,permit.return_account_sha256);return evidence.failed_tiles;};
  f.adapter.resumeAfterUnusualFailure=async()=>assert.fail('current failed evidence belongs to a different account');
  assert.equal((await f.runtime.tick()).remaining_seconds,600);assert.equal(returned,0);assert.equal(f.calls.start,0);
  f.advance(599999);await f.runtime.tick();assert.equal(returned,0);assert.equal(f.calls.generate,0);
  f.advance(1);assert.equal((await f.runtime.tick()).status,'awaiting_human_review');assert.equal(returned,1);assert.equal(f.calls.generate,1);
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,0);
  const event=f.runtime.load(f.task).events.find(e=>e.event==='generation_retry_authorized'&&e.permit_id===permit.permit_id);assert.equal(event.prior_generation.generation_id,'current-third');
});
test('new unusual failure, quota, or login stops without another ten-minute loop',async t=>{
  for(const after of ['recurring','flow_quota_required','flow_login_required','flow_unusual_activity_required']) {
    const f=waitGenerateFixture(t);let attempts=0;
    f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'stop-'+attempts,recovery:{baseline:[]}});throw Object.assign(Error('warning'),{code:'flow_unusual_activity_required'});};
    await f.runtime.tick();f.advance(600000);
    if(after!=='recurring')f.adapter.readiness=async()=>({ready:false,code:after});
    const result=await f.runtime.tick();assert.equal(result.status,'blocked');assert.equal(result.code,after==='recurring'?'flow_unusual_activity_required':after);assert.equal(attempts,after==='recurring'?2:1);assert.equal(f.calls.restarted,0);
    assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,after==='recurring'?1:0);
  }
});
test('explicit unlimited unusual policy repeats every full ten minutes across restarts, with one notice and no extra Generate',async t=>{
  const f=waitGenerateFixture(t),cycle=f.native.cycle;let attempts=0;
  f.native.cycle=async()=>{const snapshot=await cycle();snapshot.unusual_activity_policy.retry_unlimited=true;return snapshot;};
  f.adapter.generate=async(_i,_r,_o,hooks)=>{attempts++;await hooks.beforeGenerate({generation_id:'unlimited-'+attempts,recovery:{baseline:[]}});throw Object.assign(Error('unusual'),{code:'flow_unusual_activity_required'});};
  let runtime=f.runtime;
  for(let round=0;round<4;round++){
    const status=await runtime.tick();assert.equal(status.status,'cooldown');assert.equal(status.remaining_seconds,600);assert.equal(attempts,round+1);
    const deadline=f.runtime.load(f.task).unusual_activity_cooldown.not_before;
    runtime=new FlowRuntime(f.config,{native:f.native,adapter:f.adapter,now:f.now,notify:async s=>f.calls.notify.push(s)});runtime.larkReadiness=async()=>({ready:true});
    f.advance(599999);assert.equal((await runtime.tick()).remaining_seconds,1);assert.equal(attempts,round+1);assert.equal(f.runtime.load(f.task).unusual_activity_cooldown.not_before,deadline);f.advance(1);
  }
  assert.equal(f.calls.execute.filter(c=>c.generation_retry).length,3);assert.equal(f.calls.notify.length,1);assert.equal(f.calls.restarted,0);
  f.adapter.readiness=async()=>({ready:false,code:'flow_quota_required'});assert.equal((await runtime.tick()).code,'flow_quota_required');assert.equal(attempts,4);
});
test('unusual wait does not replace a stale or acquired generation',async t=>{
  const f=waitGenerateFixture(t),state=f.runtime.load(f.task);state.images.chest={status:'acquired',generation_id:'done',asset:{}};
  state.unusual_activity_cooldown={wait_only:true,image_key:'chest',generation_id:'old',not_before:new Date(f.now()-1).toISOString()};
  assert.throws(()=>f.runtime.armUnusualRetry(f.task,state,{retry_after_cooldown:true,reference:'New user',cooldown_ms:600000}),/unusual_activity_cooldown_checkpoint_invalid/);
  assert.equal(f.calls.generate,0);
});

test('six-photo embroidery tasks keep their original numbers and historical ten-photo tasks remain valid',t=>{
  const f=fixture(t);f.task.kind='flow_batch_images';Object.assign(f.task,{batch_id:'batch-A',item_id:'item-A',stage:'mockups'});
  const source=f.task.payload.images[0];delete f.task.payload.brief_id;
  Object.assign(f.task.payload,{batch_id:'batch-A',item_id:'item-A',stage:'mockups',executor:'independent_flow_worker',product_kind:'embroidery_prompts',profile_version:3});
  const all=['01_thumbnail.jpg','02_hoodie_folded.jpg','03_quarterzip_folded.jpg','04_male_front.jpg','05_female_angle.jpg','06_female_seated.jpg','07_embroidery_closeup.jpg','08_maximum_dimensions.jpg','09_gift_packaging.jpg','10_flatlay.jpg'];
  f.task.payload.images=all.map(name=>({name,prompt:source.prompt,references:source.references}));
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  f.task.payload.mockup_set='embroidery_6_v1';f.task.payload.images=f.task.payload.images.filter((_x,i)=>[0,1,3,4,6,9].includes(i));
  assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  f.task.payload.images.push({name:'06_female_seated.jpg',prompt:source.prompt,references:source.references});assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/task_batch_images_invalid/);
  f.task.payload.mockup_set='unknown';assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/task_mockup_set_invalid/);
});

test('garment-only six-photo contract accepts full, remainder and sample tasks and rejects historical model names',t=>{
  const f=fixture(t),p=f.task.payload,source=p.images[0];
  Object.assign(f.task,{kind:'flow_batch_images',batch_id:'batch-A',item_id:'item-A',stage:'mockups'});delete p.brief_id;
  Object.assign(p,{batch_id:'batch-A',item_id:'item-A',stage:'mockups',executor:'independent_flow_worker',product_kind:'embroidery_prompts',profile_version:3,mockup_set:'embroidery_6_flatlay_v1'});
  const names=['01_thumbnail.jpg','02_hoodie_folded.jpg','04_sweatshirt_flatlay.jpg','05_hoodie_flatlay.jpg','07_embroidery_closeup.jpg','10_flatlay.jpg'];
  p.images=names.map(name=>({name,prompt:source.prompt,references:source.references}));
  const snapshot=()=>({ok:true,observed_at:new Date().toISOString(),tasks:[f.task]});
  assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  p.images[2].name='04_male_front.jpg';assert.throws(()=>f.runtime.task(snapshot(),f.task.id),/task_batch_images_invalid/);p.images[2].name=names[2];
  p.images=p.images.slice(1);assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
  f.task.stage=p.stage='sample_mockup';p.images=[{name:names[0],prompt:source.prompt,references:source.references}];assert.equal(f.runtime.task(snapshot(),f.task.id),f.task);
});

 test('text-only pajama sample reaches native submission with empty reference provenance',async t=>{const f=fixture(t);batchTask(f);Object.assign(f.task.payload,{profile_version:3,product_kind:'pajama_set',product_bundle:{sales_unit:'set',listing_units:1,components:['top','pants']},references:{}});f.task.payload.images[0].references=[];const original=f.adapter.generate;f.adapter.generate=async(item,refs,dir,hooks)=>{assert.deepEqual(refs,[]);return original(item,refs,dir,hooks);};assert.equal((await f.runtime.tick()).status,'awaiting_human_review');const cmd=f.calls.execute[0];assert.equal(cmd.action,'flow_auto_submit');assert.deepEqual(cmd.proof.prompt_provenance[0].reference_sha256,[]);assert.equal(cmd.proof.visually_verified,undefined);});
