'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { randomUUID } = require('node:crypto');
const { StringDecoder } = require('node:string_decoder');

function atomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temporary = file + '.' + randomUUID() + '.tmp';
  const fd = fs.openSync(temporary, 'wx', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(temporary, file);
}
function executionOutput(stdout) {
  for (let offset = stdout.indexOf('{'); offset !== -1; offset = stdout.indexOf('{', offset + 1)) {
    let data;
    try { data = JSON.parse(stdout.slice(offset).trim()); } catch { continue; }
    if (!data?.data?.resultData) continue;
    const result = data.data.resultData;
    if (result.error) throw new Error(result.error.description === 'codex_usage_limit_exceeded' ? 'codex_usage_limit_exceeded' : 'n8n_execution_failed');
    const run = result.runData?.[result.lastNodeExecuted];
    const items = run?.[run.length - 1]?.data?.main?.flat().filter(Boolean);
    if (!items?.length || items[0].json?.ok !== true) throw new Error('n8n_result_missing');
    return items[0].json;
  }
  throw new Error('n8n_execution_output_invalid');
}
function claimProcessLock(file, identity = 'flow-worker') {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const owner = { pid: process.pid, token: randomUUID(), identity, started_at: new Date().toISOString() };
  const temporary=file+'.'+owner.token+'.pending';
  try {
    const fd=fs.openSync(temporary,'wx',0o600);
    try{fs.writeFileSync(fd,JSON.stringify(owner));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    // Publish complete owner bytes without replacing an existing owner's lock.
    fs.linkSync(temporary,file);
  }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    let old; try { old = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (readError) { if (readError.code === 'ENOENT') return claimProcessLock(file, identity); throw new Error('process_lock_needs_review'); }
    try { process.kill(old.pid, 0); throw new Error('worker_already_running'); }
    catch (error) { if (error.code !== 'ESRCH') throw error; }
    fs.renameSync(file, file + '.abandoned-' + randomUUID());
    return claimProcessLock(file, identity);
  }
  finally { if(fs.existsSync(temporary))fs.unlinkSync(temporary); }
  return () => {
    if (!fs.existsSync(file)) return;
    const current = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (current.token === owner.token) fs.unlinkSync(file);
  };
}
async function waitProcessLock(file, timeoutMs, signal) {
  if (signal?.aborted) throw Object.assign(new Error('native_execution_stopped'), { code: 'native_execution_stopped' });
  try { return claimProcessLock(file, 'native-n8n'); }
  catch (error) { if (error.message !== 'worker_already_running') throw error; }
  return new Promise((resolve, reject) => {
    let watcher, timer, done = false;
    const finish = (error, release) => {
      if (done) { release?.(); return; }
      done = true; watcher?.close(); clearTimeout(timer); signal?.removeEventListener('abort', abort);
      if (error) reject(error); else resolve(release);
    };
    const attempt = final => {
      if (done) return;
      try { finish(null, claimProcessLock(file, 'native-n8n')); }
      catch (error) {
        if (error.message !== 'worker_already_running') finish(error);
        else if (final) finish(Object.assign(new Error('native_execution_busy'), { code: 'native_execution_busy' }));
      }
    };
    const abort = () => finish(Object.assign(new Error('native_execution_stopped'), { code: 'native_execution_stopped' }));
    watcher = fs.watch(path.dirname(file), (_event,name) => { if(!name||String(name)===path.basename(file))attempt(false); });
    watcher.on('error', finish);
    timer = setTimeout(() => attempt(true), timeoutMs);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort(); else attempt(false);
  });
}
class NativeN8n {
  constructor(config, dependencies = {}) {
    this.config = config;
    this.spawn = dependencies.spawn || spawn;
    this.child = null;
    this.lockAbort = new AbortController();
  }
  async execute(action, { timeoutMs = this.config.nativeTimeoutMs } = {}) {
    const unlock = await waitProcessLock(this.config.executionLockFile || path.join(this.config.workflowRoot, 'workspace/flow-worker/runtime/native-execution.lock'), this.config.nativeLockTimeoutMs || Math.min(this.config.nativeTimeoutMs || 240000, 30000), this.lockAbort.signal);
    try {
    if(this.config.workerLane){
      action ||= {action:'flow_cycle'};
      action={...action,worker_lane:this.config.workerLane};
      const choiceFile=path.join(this.config.stateDir,'image-provider.json');
      if(fs.existsSync(choiceFile)){
        const bid=JSON.parse(fs.readFileSync(choiceFile,'utf8')).batch_id;
        if(bid)action.worker_lane_batch_id=bid;
      }
    }
      if (action) atomic(this.config.commandFile, action);
      return await this.run(action ? this.config.mainWorkflowId : this.config.cycleWorkflowId, timeoutMs);
    } finally { unlock(); }
  }
  cycle() { return this.execute(null); }
  async run(workflowId, timeoutMs = this.config.nativeTimeoutMs) {
    fs.mkdirSync(this.config.logDir, { recursive: true });
    const prefix = path.join(this.config.logDir, Date.now() + '-' + randomUUID());
    const out = fs.openSync(prefix + '.stdout.private.log', 'wx', 0o600);
    const err = fs.openSync(prefix + '.stderr.private.log', 'wx', 0o600);
    const args = [this.config.n8nCli, 'execute', '--id=' + workflowId, '--rawOutput'];
    const env = { ...process.env, N8N_RUNNERS_BROKER_PORT: String(this.config.brokerPort), N8N_DIAGNOSTICS_ENABLED: 'false' };
    const child = this.spawn(process.execPath, args, { cwd: this.config.workflowRoot, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    this.child = child;
    let stdout = '', exceeded = false;
    const decoder = new StringDecoder('utf8');
    child.stdout.on('data', bytes => { fs.writeSync(out, bytes); if (stdout.length + bytes.length < 64 * 1024 * 1024) stdout += decoder.write(bytes); else exceeded = true; });
    child.stderr.on('data', bytes => fs.writeSync(err, bytes));
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; child.kill('SIGTERM'); }, timeoutMs);
    try {
      const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
      stdout += decoder.end();
      if (timedOut) throw new Error('native_execution_timeout');
      if (exceeded || code !== 0) {
        // n8n copies the HTTP worker error into description, even with trailing CLI diagnostics.
        const limited = /"(?:description|error_code)"\s*:\s*"codex_usage_limit_exceeded"/.test(stdout);
        const invalidText=/Worker did not complete a text-only turn|"error_code"\s*:\s*"codex_text_turn_invalid"/.test(stdout);
        throw new Error(limited ? 'codex_usage_limit_exceeded' : invalidText?'codex_text_turn_invalid':'n8n_native_failed_check_private_log');
      }
      return executionOutput(stdout);
    } finally { clearTimeout(timer); fs.closeSync(out); fs.closeSync(err); if (this.child === child) this.child = null; }
  }
  stop() { this.lockAbort.abort(); if (this.child) this.child.kill('SIGTERM'); }
}
module.exports = { NativeN8n, atomic, executionOutput, claimProcessLock, waitProcessLock };
