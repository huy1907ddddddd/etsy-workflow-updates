'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { createHash, randomUUID } = require('node:crypto');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const imageIdentity = source => { try {
  const url = new URL(source);
  const observedPath = (url.hostname === 'flow-content.google' && url.pathname.startsWith('/image/')) ||
    (url.hostname === 'flow.google.com' && /^\/asb\/[A-Za-z0-9_-]+(?:=[A-Za-z0-9-]+)?$/.test(url.pathname));
  return url.protocol === 'https:' && !url.username && !url.password && !url.port && observedPath ? url.origin + url.pathname : undefined;
} catch { return undefined; } };
function blocked(code, message = code) { const error = new Error(message); error.code = code; throw error; }
const official = value => { try { const url = new URL(value); return url.protocol === 'https:' && url.hostname === 'flow.google.com'; } catch { return false; } };
const diagnosticUrl = value => { try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.origin + url.pathname : url.protocol; } catch { return null; } };
const diagnosticText = value => String(value || '').replace(/https?:\/\/[^\s<>"']+/g, url => diagnosticUrl(url) || '[url]').slice(0, 2000);
const redactEmail = value => typeof value === 'string' ? value.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]') : value;
const semanticPrompt = value => value.replace(/\s+/g, ' ').trim();
// Selectors observed in the public Flow UI on 2026-10-13; unknown UI stops safely.
const observedSelectors = {
  prompt: 'div.ProseMirror[contenteditable="true"]',
  newProject: { role: 'button', nameRegex: '^(New project|Dự án mới)$' },
  accountButton: { role: 'button', nameRegex: '^(Google Account:|Tài khoản Google:)' },
  settingsButton: { role: 'button', name: 'Settings trigger' },
  agentMode: { role: 'button', name: 'Agent' },
  imageMode: { role: 'radio', name: 'Image' }, modelMenu: { role: 'button', name: 'Select model family' },
  modelOption: { role: 'menuitem', nameRegex: '^🍌 Nano Banana Pro$' },
  modelSelected: { role: 'button', nameRegex: 'Nano Banana Pro' },
  squareOption: { role: 'radio', name: '1:1' }, squareSelected: '[role="radio"][aria-checked="true"]:text-is("1:1")',
  outputOne: { role: 'radio', name: 'x1' },
  generate: { role: 'button', name: 'Start generation' },
  uploadButton: { role: 'button', name: 'Add ingredients to the prompt box' },
  uploadFile: { role: 'button', name: 'Upload media' },
  assetList: { role: 'listbox', name: 'Asset list' }, addToPrompt: { role: 'button', name: 'Add to prompt' },
  clearPrompt: { role: 'button', name: 'Clear prompt' }, referenceChip: 'flow-ingredient-chip',
  readyReferenceChip: 'flow-ingredient-chip button[aria-label="Ingredient"][aria-busy="false"]',
  resultTile: 'flow-image-tile', resultImage: 'img[data-media-id]', resultIdentityAttribute: 'data-media-id',
  recoveryGallery: '.cdk-virtual-scrollable.page-container',
  generationFailed: 'flow-image-tile:has(button[aria-label="Retry"])',
  generatedTileMarker: { role: 'button', name: 'Reuse prompt', includeHidden: true },
  openResult: 'img[data-media-id]', assetInfoButton: { role: 'button', name: 'Show asset info' },
  assetInfo: { role: 'complementary', name: 'Asset info' },
  exactResultPrompt: 'flow-expandable-prompt .prompt-text',
  resultMetadata: '.metadata .metadata-row',
  resultRatio: '.metadata .metadata-row span',
  resultIngredient: '.ingredients-list flow-ingredient-chip',
  promptIngredientImage: 'flow-ingredient-chip img[alt="Ingredient image"]',
  back: { role: 'button', name: 'Back button to go to previous page' },
  downloadMenu: { role: 'button', name: 'Download media' }, downloadOriginal: { role: 'menuitem', name: '1K Original size' }
};
class FlowBrowser {
  constructor(config, dependencies = {}) {
    this.config = config; this.dependencies = dependencies; this.page = dependencies.page; this.context = dependencies.context;
    this.selectors = { ...observedSelectors, ...config.selectors }; this.timeout = config.actionTimeoutMs || 30000;
    this.passiveEvents = []; this.observedPages = new WeakSet();
  }
  attachDiagnosticEvents() {
    const page = this.page; if (!page?.on || this.observedPages.has(page)) return;
    this.observedPages.add(page);
    const record = event => {
      const value = { ...event, at: new Date().toISOString() };
      this.passiveEvents.push(value); if (this.passiveEvents.length > 50) this.passiveEvents.shift();
      if (!this.config.logDir) return;
      try {
        fs.mkdirSync(this.config.logDir, { recursive: true }); const file = path.join(this.config.logDir, 'browser-events.private.jsonl');
        if (fs.existsSync(file) && fs.statSync(file).size > 2 * 1024 * 1024) fs.writeFileSync(file, '', { mode: 0o600 });
        fs.appendFileSync(file, JSON.stringify(value) + '\n', { mode: 0o600 });
      } catch { /* Diagnostics cannot interrupt the production checkpoint. */ }
    };
    page.on('pageerror', error => record({ event: 'pageerror', name: error.name, message: diagnosticText(error.message) }));
    page.on('console', message => { if (message.type() === 'error') record({ event: 'console_error', message: diagnosticText(message.text()), location: diagnosticUrl(message.location()?.url) }); });
    page.on('requestfailed', request => record({ event: 'requestfailed', url: diagnosticUrl(request.url()), resource_type: request.resourceType(), failure: diagnosticText(request.failure()?.errorText) }));
    page.on('response', response => { if(response.status()>=400)record({event:'http_error',url:diagnosticUrl(response.url()),status:response.status()}); });
  }
  locator(spec, scope = this.page) {
    if (!spec) blocked('flow_ui_selector_missing');
    if (typeof spec === 'string') return scope.locator(spec);
    if (spec.role) return scope.getByRole(spec.role, { name: spec.nameRegex ? new RegExp(spec.nameRegex, 'u') : spec.name, exact: spec.exact !== false, includeHidden: spec.includeHidden });
    if (spec.text) return scope.getByText(spec.text, { exact: spec.exact !== false });
    blocked('flow_ui_selector_invalid');
  }
  async visible(spec, scope = this.page) {
    if (!spec) return false;
    const target = this.locator(spec, scope); return await target.count() === 1 && await target.isVisible();
  }
  async unique(spec, scope = this.page) {
    const target = this.locator(spec, scope);
    if (await target.count() !== 1 || !await target.isVisible()) blocked('flow_ui_changed', 'Expected exactly one visible Flow control');
    return target;
  }
  async referenceIdentity(source, label) {
    const identity = imageIdentity(source);
    if (!identity || new URL(identity).hostname === 'flow-content.google') return identity;
    const url = new URL(this.page.url()), project = url.origin + url.pathname.split('/edit/')[0];
    if (this.referenceAliasProject !== project) { this.referenceAliasProject = project; this.referenceAliases = new Map(); }
    // A signed thumbnail URL is a presentation address; the public gallery carries the stable media ID.
    if (this.referenceAliases.has(identity)) return this.referenceAliases.get(identity);
    if (this.config.profileDir) {
      try {
        const assets = JSON.parse(fs.readFileSync(path.join(this.config.profileDir, 'flow-reference-assets.json'), 'utf8')).projects?.[project] || {};
        for (const asset of Object.values(assets)) {
          const canonical = imageIdentity(asset.identity);
          if (canonical && new URL(canonical).hostname === 'flow-content.google' && Array.isArray(asset.source_identities)) {
            for (const source of asset.source_identities) if (imageIdentity(source)) this.referenceAliases.set(imageIdentity(source), canonical);
          }
        }
      } catch { /* A missing legacy cache still requires observable identity evidence. */ }
      if (this.referenceAliases.has(identity)) return this.referenceAliases.get(identity);
    }
    const rows = await this.locator(this.selectors.resultTile).evaluateAll(elements => elements.map(element => {
      const image = element.querySelector('img[data-media-id]');
      return { source: image?.getAttribute('src'), media_id: image?.getAttribute('data-media-id'), labels: [...element.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')) };
    }));
    const filename = label?.replace(/ Image$/, '');
    const matches = rows.filter(row => /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(row.media_id || '') &&
      (imageIdentity(row.source) === identity || (filename && row.labels.includes(filename))));
    const ids = [...new Set(matches.map(row => row.media_id))];
    if (ids.length > 1) blocked('flow_reference_identity_ambiguous');
    if (!ids.length) return identity;
    const canonical = 'https://flow-content.google/image/' + ids[0];
    this.referenceAliases.set(identity, canonical);
    return canonical;
  }
  async launch() {
    if (this.page) return;
    const profile = path.resolve(this.config.profileDir || '');
    if (!this.config.profileDir || /(?:[\\/]Google[\\/]Chrome[\\/]User Data|[\\/]Microsoft[\\/]Edge[\\/]User Data)(?:[\\/]|$)/i.test(profile) || this.config.cdpUrl || this.config.storageState || this.config.args) blocked('flow_dedicated_profile_required');
    fs.mkdirSync(profile, { recursive: true });
    const playwright = this.dependencies.playwright || require('playwright');
    if(this.config.gologin){
      this.connectedBrowser=await require('./gologin.cjs').connect(this.config,playwright,this.dependencies.fetch||fetch);
      this.context=this.connectedBrowser.contexts()[0];
      if(!this.context)blocked('flow_gologin_context_missing');
      this.page=await this.context.newPage();
    }else{
      this.context = await playwright.chromium.launchPersistentContext(profile, { channel: this.config.channel || 'chrome', headless: this.config.headless === true, acceptDownloads: true, viewport: { width: 1440, height: 1000 },
        ...(this.config.enableExtensions === true ? { ignoreDefaultArgs: ['--disable-extensions'] } : {}) });
      this.page = this.context.pages()[0] || await this.context.newPage();
    }
    this.attachDiagnosticEvents();
    this.page.setDefaultTimeout(this.timeout);
  }
  async start() {
    if(this.page)return;
    await this.launch();
    this.projectStateFile = path.join(path.resolve(this.config.profileDir), 'flow-worker-project.json');
    const savedProject = fs.existsSync(this.projectStateFile) ? JSON.parse(fs.readFileSync(this.projectStateFile, 'utf8')).project_url : undefined;
    const account = this.config.accountPolicy ? this.accountState().active_email : null;
    const savedBinding=fs.existsSync(this.projectStateFile)?JSON.parse(fs.readFileSync(this.projectStateFile,'utf8')):{};
    const url = account ? savedBinding.account_key===hash(account)&&savedProject?savedProject:this.accountHome(account) : savedProject || this.config.projectUrl || 'https://flow.google.com/';
    if (!official(url)) blocked('flow_project_url_invalid');
    const target=this.uiUrl(url),priorEvents=new Set(this.passiveEvents);
    try{await this.page.goto(target, { waitUntil: 'domcontentloaded', timeout: this.timeout });}
    catch(error){
      if(this.config.enableExtensions!==true||!String(error.message).includes('net::ERR_HTTP_RESPONSE_CODE_FAILURE')||
        !this.passiveEvents.some(event=>!priorEvents.has(event)&&event.event==='http_error'&&event.status===407&&event.url===diagnosticUrl(target)))throw error;
      // A proxy extension can finish its existing authentication after the first navigation.
      await this.page.waitForTimeout(15000);
      await this.page.goto(target, { waitUntil: 'domcontentloaded', timeout: this.timeout });
    }
    if(account)await this.verifyAccount(account);
  }
  accountState() {
    const policy=this.config.accountPolicy;
    if(!policy?.enabled||!policy.reference||!Array.isArray(policy.accounts)||policy.accounts.length<2||policy.accounts.length>3)blocked('flow_account_policy_invalid');
    const file=path.join(this.config.stateDir,'flow-accounts.private.json');
    let state=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null;
    if(!state||state.policy_reference!==policy.reference){
      const unavailable=Object.fromEntries((policy.unavailable_accounts||[]).map(email=>[email,{reason:'previous_quota_evidence'}]));
      for(const [email,evidence]of Object.entries(state?.unavailable||{}))if(policy.accounts.some(a=>a.email===email))unavailable[email]=evidence;
      state={policy_reference:policy.reference,active_email:policy.preferred_email,unavailable};
      this.saveAccountState(state);
    }
    if(!policy.accounts.some(account=>account.email===state.active_email))blocked('flow_account_policy_invalid');
    return state;
  }
  saveAccountState(state) {
    const {atomic}=require('./native-n8n.cjs');atomic(path.join(this.config.stateDir,'flow-accounts.private.json'),state);
  }
  accountHome(email) {
    const home=this.config.accountPolicy.accounts.find(account=>account.email===email)?.home_url;
    if(!official(home)||!/^\/(?:u\/\d+\/)?$/.test(new URL(home).pathname)||new URL(home).search||new URL(home).hash)blocked('flow_account_policy_invalid');
    return home;
  }
  uiUrl(value) {
    if(!this.config.accountPolicy)return value;
    if(!official(value))blocked('flow_project_url_invalid');
    const url=new URL(value);url.searchParams.set('hl','en');return url.href;
  }
  async dismissChangelog() {
    if (!official(this.page?.url() || '') || typeof this.page?.getByRole !== 'function' || typeof this.page?.locator !== 'function') return false;
    const frame=this.page.locator('iframe[src^="https://www.gstatic.com/aitestkitchen/website/flow/changelogs/"]');
    if (await frame.count() !== 1 || !await frame.isVisible()) return false;
    const start=this.page.getByRole('button',{name:'Get started',exact:true});
    const history=this.page.getByRole('button',{name:'View all changelogs',exact:true});
    if (await start.count() !== 1 || !await start.isVisible() || await history.count() !== 1 || !await history.isVisible()) blocked('flow_changelog_ui_changed');
    await start.click();
    await frame.waitFor({state:'hidden',timeout:this.timeout});
    return true;
  }
  async dismissCookieNotice() {
    if (!official(this.page?.url() || '') || typeof this.page?.locator !== 'function') return false;
    const banner=this.page.locator('#glue-cookie-notification-bar-1');
    if (await banner.count() !== 1 || !await banner.isVisible()) return false;
    const decline=banner.getByRole('button',{name:'No thanks',exact:true});
    if (!(await banner.innerText()).includes('flow.google.com uses cookies') || await decline.count() !== 1 || !await decline.isVisible()) blocked('flow_cookie_notice_ui_changed');
    await decline.click();await banner.waitFor({state:'hidden',timeout:this.timeout});
    return true;
  }
  async verifyAccount(email) {
    if(!official(this.page.url()))blocked('flow_login_required');
    await this.dismissChangelog();
    const button=this.locator(this.selectors.accountButton);
    for(let attempt=0;attempt<2;attempt++){
      try{await button.waitFor({state:'visible',timeout:this.timeout});break;}
      catch{
        if(attempt===0&&(await this.dismissChangelog()||await this.revealAccountHeader()))continue;
        await this.captureDiagnostic({stage:'account.verify',error_code:'flow_account_identity_required'});
        blocked('flow_account_identity_required');
      }
    }
    if(await button.count()!==1)blocked('flow_account_identity_required');
    const label=await button.getAttribute('aria-label');
    const emails=String(label||'').match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[];
    if(emails.length!==1||emails[0].toLowerCase()!==email)blocked('flow_account_identity_mismatch');
    this.currentAccount=email;
    return email;
  }
  async revealAccountHeader() {
    if (!this.page?.mouse?.wheel || !this.selectors.recoveryGallery) return false;
    const gallery=this.locator(this.selectors.recoveryGallery);
    if (await gallery.count() !== 1 || !await gallery.isVisible()) return false;
    const top=await gallery.evaluate(element=>element.scrollTop);
    if (!Number.isFinite(top) || top<=0) return false;
    await gallery.hover();await this.page.mouse.wheel(0,-top);
    await this.page.waitForFunction(selector=>document.querySelector(selector)?.scrollTop===0,this.selectors.recoveryGallery,{timeout:this.timeout});
    return true;
  }
  quotaTarget() {
    const state=this.accountState();
    if(!this.currentAccount||state.active_email!==this.currentAccount)blocked('flow_account_identity_required');
    state.unavailable[this.currentAccount]={reason:'flow_quota_required',at:new Date().toISOString()};this.saveAccountState(state);
    if(this.config.accountPolicy.pool_fixed_account)return null;
    return this.config.accountPolicy.accounts.find(account=>!state.unavailable[account.email])?.email||null;
  }
  unusualTarget(projectUrl) {
    const policy=this.config.accountPolicy,state=this.accountState();
    if(policy.on_unusual_activity!=='switch_account'||!official(projectUrl)||state.active_email!==this.currentAccount)blocked('flow_account_switch_binding_invalid');
    const url=new URL(projectUrl),prefix=url.pathname.split('/project/')[0]+'/';
    const source=policy.accounts.filter(a=>new URL(a.home_url).pathname===prefix);
    if(!url.pathname.includes('/project/')||source.length!==1)blocked('flow_account_switch_binding_invalid');
    const email=source[0].email,previous=state.unavailable[email];
    state.unavailable[email]={...previous,previous_reason:previous?.previous_reason||previous?.reason,reason:'flow_unusual_activity_required',at:new Date().toISOString()};
    this.saveAccountState(state);
    return policy.accounts.find(a=>!state.unavailable[a.email])?.email||null;
  }
  async switchAccount(email) {
    const state=this.accountState();
    if(state.unavailable[email])blocked('flow_accounts_exhausted');
    await this.page.goto(this.uiUrl(this.accountHome(email)),{waitUntil:'domcontentloaded',timeout:this.timeout});
    this.failureBaseline=[];
    await this.verifyAccount(email);
    const ready=await this.readiness();if(!ready.ready)blocked(ready.code||'flow_login_required');
    state.active_email=email;this.saveAccountState(state);
  }
  async readiness() {
    if (!this.page) return { ready: false, code: 'flow_browser_not_started' };
    if (this.page.isClosed?.() || this.context?.browser?.()?.isConnected?.() === false) return { ready: false, code: 'flow_browser_closed' };
    if (/accounts\.google\./.test(this.page.url())) return { ready: false, code: 'flow_login_required' };
    for (const [code, selector] of [['flow_login_required', this.selectors.login], ['flow_captcha_required', this.selectors.captcha], ['flow_quota_required', this.selectors.quota]]) if (await this.visible(selector)) return { ready: false, code };
    if (!official(this.page.url())) return { ready: false, code: 'flow_project_url_invalid' };
    await this.dismissCookieNotice();
    await this.dismissChangelog();
    if (await this.generationFailure() === 'flow_unusual_activity_required') return { ready: false, code: 'flow_unusual_activity_required' };
    if (!await this.visible(this.selectors.prompt) && !await this.visible(this.selectors.newProject)) {
      // DOMContentLoaded can precede the visible Flow app; wait on observed controls, not a fixed delay.
      try {
        await this.page.waitForFunction(({ prompt, newProject }) => {
          const visible = element => element && element.getClientRects().length && getComputedStyle(element).visibility !== 'hidden';
          return [...document.querySelectorAll(prompt)].some(visible) || [...document.querySelectorAll('button,[role="button"]')]
            .some(element => visible(element) && (newProject.nameRegex ? new RegExp(newProject.nameRegex,'u').test(element.getAttribute('aria-label') || element.textContent.trim()) : (element.getAttribute('aria-label') || element.textContent.trim()) === newProject.name))
            || location.hostname === 'accounts.google.com';
        }, { prompt: this.selectors.prompt, newProject: this.selectors.newProject }, { timeout: this.timeout });
      } catch { /* Save diagnostics and retain the UI blocker if known controls never render. */ }
      if (this.page.isClosed?.()) return { ready: false, code: 'flow_browser_closed' };
      if (/accounts\.google\./.test(this.page.url())) return { ready: false, code: 'flow_login_required' };
      if (!official(this.page.url())) return { ready: false, code: 'flow_project_url_invalid' };
    }
    if (await this.visible(this.selectors.prompt)) return { ready: true };
    if (await this.visible(this.selectors.newProject)) return { ready: true, needs_project: true };
    await this.captureDiagnostic({ stage: 'readiness', error_code: 'flow_ui_changed' });
    return { ready: false, code: 'flow_ui_changed' };
  }
  async failedTileTexts() {
    // Only public failed gallery tiles; prompt text mentioning an error is not an error.
    const tiles = this.locator(this.selectors.generationFailed);
    const texts=[];
    for (let i = 0; i < await tiles.count(); i++) {
      const tile = tiles.nth(i);
      if (!await tile.isVisible()) continue;
      const text = await tile.innerText();
      if (!/(?:^|\n)\s*Failed\s*(?:\n|$)/u.test(text)) continue;
      texts.push(semanticPrompt(text));
    }
    return texts;
  }
  async acknowledgeFailedTiles() {
    this.failureBaseline=await this.failedTileTexts();
    return this.failureBaseline;
  }
  async unusualActivityEvidence(file) {
    const ignored=[...(this.failureBaseline||[])],fresh=[];
    for(const text of await this.failedTileTexts()){
      const index=ignored.indexOf(text);
      if(index!==-1){ignored.splice(index,1);continue;}
      fresh.push(text);
    }
    const other=await this.generationFailure(fresh.filter(text=>!text.includes('We noticed some unusual activity.')));
    if(other)blocked(other);
    const failed_tiles=fresh.filter(text=>text.includes('We noticed some unusual activity.'));
    if(!failed_tiles.length||!official(this.page.url()))blocked('flow_unusual_activity_evidence_missing');
    await this.page.screenshot({path:file});
    return {failed_tiles,screenshot_path:file,screenshot_sha256:hash(fs.readFileSync(file))};
  }
  async resumeAfterUnusualFailure(item, checkpoint, evidence) {
    const recovery=checkpoint?.recovery;
    if(!official(this.page.url())||!official(recovery?.project_url)||this.uiUrl(this.page.url())!==this.uiUrl(recovery.project_url)||recovery.prompt_sha256!==hash(item.prompt)
      ||checkpoint.status!=='generation_started'||!checkpoint.generation_id||checkpoint.asset
      ||evidence.generation_id!==checkpoint.generation_id||!evidence.failed_tiles?.length
      ||evidence.failed_tiles.some(text=>!text.includes('We noticed some unusual activity.')))blocked('flow_unusual_retry_binding_invalid');
    // Ignore only the saved failed generation; an additional identical tile is still a new failure.
    this.failureBaseline=[...(recovery.failure_baseline||[]),...evidence.failed_tiles];
    return this.failureBaseline;
  }
  async resumeUnusualOnPreviousAccount(item, checkpoint, evidence, accountHash, projectKey) {
    const policy=this.config.accountPolicy,email=policy?.preferred_email,url=checkpoint?.recovery?.project_url;
    if(!email||policy.on_unusual_activity==='switch_account'||hash(email)!==accountHash||this.accountState().active_email!==email
      ||!official(url)||new URL(url).pathname.split('/project/')[0]+'/'!==new URL(this.accountHome(email)).pathname)blocked('flow_unusual_retry_binding_invalid');
    const projects=JSON.parse(fs.readFileSync(path.join(path.resolve(this.config.profileDir),'flow-worker-projects.json'),'utf8'));
    const saved=projects.account_projects?.[accountHash]?.[projectKey];
    if(saved?.status!=='ready'||this.uiUrl(saved.project_url)!==this.uiUrl(url)||this.uiUrl(url)!==url)blocked('flow_unusual_retry_binding_invalid');
    await this.page.goto(url,{waitUntil:'domcontentloaded',timeout:this.timeout});
    await this.verifyAccount(email);
    const baseline=await this.resumeAfterUnusualFailure(item,checkpoint,evidence);
    await this.ensureProject(projectKey);
    return baseline;
  }
  async resumeAfterQuotaFailure(item, checkpoint) {
    const recovery=checkpoint?.recovery;
    if(checkpoint?.status!=='generation_started'||!checkpoint.generation_id||checkpoint.asset||!official(recovery?.project_url)||recovery.prompt_sha256!==hash(item?.prompt||''))blocked('flow_model_switch_binding_invalid');
    const url=this.uiUrl(recovery.project_url);
    if(this.page.url()!==url)await this.page.goto(url,{waitUntil:'domcontentloaded',timeout:this.timeout});
    if(this.config.accountPolicy)await this.verifyAccount(this.accountState().active_email);
    this.failureBaseline=recovery.failure_baseline||[];
    const ready=await this.readiness();if(!ready.ready)blocked(ready.code);
    const texts=await this.failedTileTexts();
    if(await this.generationFailure(texts)!=='flow_quota_required')blocked('flow_quota_evidence_required');
    // Keep multiplicity so a second identical quota tile is a new failure.
    this.failureBaseline=texts;
    const file=path.join(this.config.stateDir,'quota-model-'+checkpoint.generation_id+'.png');
    await this.page.screenshot({path:file});
    return {baseline:texts,screenshot_path:file,screenshot_sha256:hash(fs.readFileSync(file))};
  }
  async generationFailureEvidence(file) {
    const ignored=[...(this.failureBaseline||[])],failed_tiles=[];
    for(const text of await this.failedTileTexts()) {
      const index=ignored.indexOf(text);
      if(index!==-1){ignored.splice(index,1);continue;}
      if(text.includes('We noticed some unusual activity.'))blocked('flow_unusual_activity_required');
      if(/reached (?:your|the) usage limit|(?:insufficient|not enough) (?:ai )?credits|out of (?:ai )?credits/i.test(text))blocked('flow_quota_required');
      if(/policy violation|safety polic|content (?:was |has been )?blocked/i.test(text)||(!/this generation might violate our policies/i.test(text)&&/violat(?:e|es|ed) (?:our |the )?polic/i.test(text)))blocked('flow_policy_review_required');
      failed_tiles.push(text);
    }
    if(!failed_tiles.length||!official(this.page.url()))blocked('flow_generation_failure_evidence_missing');
    await this.page.screenshot({path:file});
    return {failed_tiles,screenshot_path:file,screenshot_sha256:hash(fs.readFileSync(file))};
  }
  async generationFailure(texts) {
    const ignored=[...(this.failureBaseline||[])];
    const failures=new Set();
    for(const text of texts||await this.failedTileTexts()) {
      const index=ignored.indexOf(text);
      if(index!==-1){ignored.splice(index,1);continue;}
      if(text.includes('We noticed some unusual activity.'))failures.add('flow_unusual_activity_required');
      else if(/policy violation|safety polic|content (?:was |has been )?blocked/i.test(text)||(!/this generation might violate our policies/i.test(text)&&/violat(?:e|es|ed) (?:our |the )?polic/i.test(text)))failures.add('flow_policy_review_required');
      else if(/reached (?:your|the) usage limit|(?:insufficient|not enough) (?:ai )?credits|out of (?:ai )?credits/i.test(text))failures.add('flow_quota_required');
      else if(/this generation might violate our policies/i.test(text))failures.add('flow_generation_might_violate');
      else failures.add('flow_generation_failed');
    }
    return ['flow_unusual_activity_required','flow_policy_review_required','flow_quota_required','flow_generation_might_violate','flow_generation_failed'].find(code=>failures.has(code))||null;
  }
  async captureDiagnostic(details = {}) {
    if (this.config.logDir && this.page && !this.page.isClosed?.() && official(this.page.url())) {
      try {
        fs.mkdirSync(this.config.logDir, { recursive: true });
        await this.page.screenshot({ path: path.join(this.config.logDir, 'last-blocked-flow.png'), fullPage: false });
        const text = await this.page.locator('body').innerText();
        const controls = await this.page.locator('button,a,input,textarea').evaluateAll(elements => elements.filter(e => e.getClientRects().length).map(e => ({ tag: e.tagName, role: e.getAttribute('role'), label: e.getAttribute('aria-label'), text: e.textContent?.trim() })));
        const iframeSources = await this.page.locator('iframe').evaluateAll(elements => elements.filter(e => e.getClientRects().length).map(e => e.getAttribute('src')));
        const prompts = await this.locator(this.selectors.prompt).evaluateAll(elements => elements.filter(e => e.getClientRects().length).map(e => ({ inner_text: e.innerText, text_content: e.textContent,
          children: [...e.children].map(child => ({ tag: child.tagName, inner_text: child.innerText, text_content: child.textContent })) })));
        const referenceChips = await this.locator(this.selectors.referenceChip).count();
        const scrollRegions = await this.page.locator('body').evaluate(body => [body, ...body.querySelectorAll('*')].filter(e => e.getClientRects().length && e.clientHeight > 100 && e.scrollHeight > e.clientHeight + 100 && /auto|scroll/.test(getComputedStyle(e).overflowY)).map(e => ({ tag: e.tagName, id: e.id, class: e.className, top: e.scrollTop, height: e.clientHeight, scroll_height: e.scrollHeight })));
        const gallery = await this.locator(this.selectors.resultTile).evaluateAll(elements => elements.slice(0, 25).map(e => ({ visible: !!e.getClientRects().length, image_id: e.querySelector('img[data-media-id]')?.getAttribute('data-media-id'), buttons: [...e.querySelectorAll('button')].map(b => ({ label: b.getAttribute('aria-label'), text: b.textContent?.trim() })) })));
        const safeControls = controls.map(control => ({ ...control, label: /^Google Account:/i.test(control.label || '') ? '[Google Account]' : redactEmail(control.label), text: redactEmail(control.text) }));
        const diagnostic = { ui_stage: this.uiStage, generation_id: this.currentGeneration, returned_verification: this.lastResultVerification,
          ...details, url: diagnosticUrl(this.page.url()), text: redactEmail(text), controls: safeControls,
          events: this.passiveEvents, upload_observations:this.uploadObservations, reference_identity_checks:this.referenceIdentityChecks, visible_iframes: iframeSources.map(diagnosticUrl), prompt_dom: prompts, reference_chip_count: referenceChips, gallery_tiles: gallery, gallery_tile_count: await this.locator(this.selectors.resultTile).count(), scroll_regions: scrollRegions };
        fs.writeFileSync(path.join(this.config.logDir, 'last-blocked-flow.private.json'), JSON.stringify(diagnostic, (_key, value) => redactEmail(value), 2), { mode: 0o600 });
      } catch { /* Keep the original blocker if diagnostics cannot be saved. */ }
    }
  }
  async ensureProject(projectKey) {
    if(projectKey){
      if(!/^[A-Za-z0-9_-]{1,160}$/.test(projectKey)||!this.config.profileDir)blocked('flow_project_batch_identity_required');
      const file=path.join(path.resolve(this.config.profileDir),'flow-worker-projects.json');
      const state=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{projects:{}};
      const save=()=>{fs.writeFileSync(file+'.tmp',JSON.stringify(state));fs.renameSync(file+'.tmp',file);};
      let projects=state.projects;
      let account=null;
      if(this.config.accountPolicy){
        account=this.accountState().active_email;await this.verifyAccount(account);
        state.account_projects||={};projects=state.account_projects[hash(account)]||={};
      }
      const saved=projects[projectKey];
      if(saved?.status==='ready'){
        if(!official(saved.project_url)||!new URL(saved.project_url).pathname.includes('/project/'))blocked('flow_project_batch_binding_invalid');
        const url=this.uiUrl(saved.project_url);
        if(this.page.url()!==url){await this.page.goto(url,{waitUntil:'domcontentloaded',timeout:this.timeout});this.failureBaseline=[];}
        const ready=await this.readiness();if(!ready.ready||ready.needs_project)blocked(ready.code||'flow_project_batch_missing');
        if(account)await this.verifyAccount(account);
        if(saved.project_url!==url){saved.project_url=url;save();}
        this.projectStateFile=path.join(path.resolve(this.config.profileDir),'flow-worker-project.json');
        fs.writeFileSync(this.projectStateFile,JSON.stringify({project_url:saved.project_url,project_key:projectKey,...(account?{account_key:hash(account)}:{})}));
        return;
      }
      if(saved?.status==='creating')blocked('flow_project_creation_reconcile_required');
      await this.page.goto(this.uiUrl(account?this.accountHome(account):'https://flow.google.com/'),{waitUntil:'domcontentloaded',timeout:this.timeout});
      if(account)await this.verifyAccount(account);
      const ready=await this.readiness();if(!ready.ready||!ready.needs_project)blocked(ready.code||'flow_new_project_control_required');
      projects[projectKey]={status:'creating',started_at:new Date().toISOString()};save();
      await (await this.unique(this.selectors.newProject)).click();
      await this.locator(this.selectors.prompt).waitFor({state:'visible',timeout:this.timeout});
      const url=this.uiUrl(this.page.url());
      if(!official(url)||!new URL(url).pathname.includes('/project/')||[state.projects,...Object.values(state.account_projects||{})].some(group=>Object.entries(group).some(([key,p])=>(group!==projects||key!==projectKey)&&p.project_url===url)))blocked('flow_project_batch_not_unique');
      if(this.page.url()!==url){await this.page.goto(url,{waitUntil:'domcontentloaded',timeout:this.timeout});const ready=await this.readiness();if(!ready.ready||ready.needs_project)blocked(ready.code||'flow_project_batch_missing');}
      if(account)await this.verifyAccount(account);
      projects[projectKey]={status:'ready',project_url:url,created_at:new Date().toISOString()};save();
      this.failureBaseline=[];
      this.projectStateFile=path.join(path.resolve(this.config.profileDir),'flow-worker-project.json');
      fs.writeFileSync(this.projectStateFile,JSON.stringify({project_url:url,project_key:projectKey,...(account?{account_key:hash(account)}:{})}));
      return;
    }
    const status = await this.readiness(); if (!status.ready) blocked(status.code);
    if (status.needs_project) {
      await (await this.unique(this.selectors.newProject)).click();
      await this.locator(this.selectors.prompt).waitFor({ state: 'visible', timeout: this.timeout });
      if (!official(this.page.url())) blocked('flow_project_url_invalid');
      if (this.projectStateFile) {
        fs.writeFileSync(this.projectStateFile + '.tmp', JSON.stringify({ project_url: this.page.url() }));
        fs.renameSync(this.projectStateFile + '.tmp', this.projectStateFile);
      }
    }
  }
  async dismissAssetPicker() {
    // Empty pickers can hide their listbox while the dialog/backdrop still covers Settings.
    const controls = [this.selectors.assetList, this.selectors.uploadFile].filter(Boolean);
    if (!(await Promise.all(controls.map(control => this.visible(control)))).some(Boolean)) return;
    await this.page.keyboard.press('Escape');
    for (const control of controls) await this.locator(control).waitFor({ state: 'hidden', timeout: this.timeout });
  }
  async configure(aspectRatio = '1:1') {
    if (!['1:1','9:16','16:9'].includes(aspectRatio)) blocked('flow_aspect_not_supported');
    try {
    await this.dismissCookieNotice();
    await this.dismissAssetPicker();
    const expectedModel=this.config.model||'Nano Banana Pro';
    if(expectedModel!=='Nano Banana Pro'&&(expectedModel!=='Nano Banana 2.1'||!this.config.modelPolicy?.enabled||this.config.modelPolicy.model!==expectedModel||!this.config.modelPolicy.reference))blocked('flow_model_not_authorized');
    if (!await this.visible(this.selectors.settingsButton) && !await this.visible(this.selectors.imageMode) && await this.visible(this.selectors.agentMode)) {
      const agent = await this.unique(this.selectors.agentMode);
      const pressed = await agent.getAttribute('aria-pressed');
      if (!['true','false'].includes(pressed)) blocked('flow_ui_changed');
      if (pressed === 'true') await agent.click();
      // Agent Settings is a different panel; wait for the verified direct-generation control.
      await this.locator(this.selectors.settingsButton).waitFor({ state: 'visible', timeout: this.timeout });
    }
    if (this.selectors.settingsButton && !await this.visible(this.selectors.imageMode)) await (await this.unique(this.selectors.settingsButton)).click();
    if (this.selectors.imageMode) {
      await this.locator(this.selectors.imageMode).waitFor({ state: 'visible', timeout: this.timeout });
      const image = await this.unique(this.selectors.imageMode);
      if (await image.getAttribute('aria-checked') !== 'true') await image.click();
    }
    await this.locator(this.selectors.modelMenu).waitFor({ state: 'visible', timeout: this.timeout });
    let model = await this.unique(this.selectors.modelMenu);
    if (!(await model.innerText()).includes(expectedModel)) {
      await (await this.unique(this.selectors.modelMenu)).click();
      await (await this.unique(expectedModel==='Nano Banana Pro'?this.selectors.modelOption:{role:'menuitem',nameRegex:'^(?:🍌\\s*)?Nano Banana 2\\.1$'})).click();
    }
    const ratioOption = aspectRatio === '1:1' ? this.selectors.squareOption : { role: 'radio', name: aspectRatio };
    const square = await this.unique(ratioOption);
    if (await square.getAttribute('aria-checked') !== 'true') {
      if (this.selectors.aspectMenu) await (await this.unique(this.selectors.aspectMenu)).click();
      await (await this.unique(ratioOption)).click();
    }
    // Flow updates the selected ratio after the click resolves.
    if (await square.getAttribute('aria-checked') !== 'true') {
      try { await square.and(this.page.locator('[aria-checked="true"]')).waitFor({ state: 'visible', timeout: this.timeout }); }
      catch { blocked('flow_model_or_aspect_unverified'); }
    }
    model = await this.unique(this.selectors.modelMenu);
    if (!(await model.innerText()).includes(expectedModel) || await square.getAttribute('aria-checked') !== 'true') blocked('flow_model_or_aspect_unverified');
    if (this.selectors.outputOne) {
      const one = await this.unique(this.selectors.outputOne);
      if (await one.getAttribute('aria-checked') !== 'true') await one.click();
      if (await one.getAttribute('aria-checked') !== 'true') {
        try { await one.and(this.page.locator('[aria-checked="true"]')).waitFor({ state: 'visible', timeout: this.timeout }); }
        catch { blocked('flow_output_count_unverified'); }
      }
      if (await one.getAttribute('aria-checked') !== 'true') blocked('flow_output_count_unverified');
    }
    if (this.selectors.settingsClose && await this.visible(this.selectors.settingsClose)) await (await this.unique(this.selectors.settingsClose)).click();
    else await this.page.keyboard.press('Escape');
    } catch (error) {
      if (!error.code) error.code = 'flow_configuration_ui_failed';
      await this.captureDiagnostic({ stage: 'configure', error_code: error.code, error_name: error.name });
      throw error;
    }
  }
  async selectReferenceOption(option, label, before) {
    for (let attempt = 0; attempt < 2; attempt++) {
      if (await this.locator(this.selectors.referenceChip).count() !== before) return;
      if (!await this.referenceOptionReady(option)) {
        option = await this.findCachedReference({ label });
        if (!option) blocked('flow_reference_selection_unavailable');
      }
      try { await option.click({ timeout: Math.min(this.timeout, 5000) }); return; }
      catch (error) {
        if (error.name !== 'TimeoutError' || !/element (?:is not stable|was detached from the DOM)|not attached to the DOM/.test(error.message)) throw error;
        // A timed-out click may already have selected/attached the asset; never toggle it again.
        if (await this.locator(this.selectors.referenceChip).count() !== before) return;
        if (await option.count() === 1 && await option.getAttribute('aria-selected') === 'true') return;
        if (attempt === 1) throw error;
        await this.page.keyboard.press('Escape');
        await this.locator(this.selectors.assetList).waitFor({ state: 'hidden', timeout: this.timeout });
        if (await this.locator(this.selectors.referenceChip).count() !== before) return;
        await (await this.unique(this.selectors.uploadButton)).click();
        await this.locator(this.selectors.assetList).waitFor({ state: 'visible', timeout: this.timeout });
        option = await this.findCachedReference({ label });
        if (!option) throw error;
      }
    }
  }
  async attachSelectedReference(before) {
    this.uiStage = 'upload.confirm_reference_selection';
    const chips = this.locator(this.selectors.referenceChip);
    const ready = this.locator(this.selectors.readyReferenceChip).nth(before);
    if (await chips.count() === before) {
      // Flow may auto-attach asynchronously and remove the picker/Add button in the same render.
      await Promise.race([
        ready.waitFor({ state: 'visible', timeout: this.timeout }),
        this.locator(this.selectors.addToPrompt).waitFor({ state: 'visible', timeout: this.timeout }),
      ]);
      if (await chips.count() === before) {
        try { await (await this.unique(this.selectors.addToPrompt)).click(); }
        catch (error) {
          // Reconcile a disappearing Add control using the ready chip, without another click/upload.
          try { await ready.waitFor({ state: 'visible', timeout: this.timeout }); }
          catch { throw error; }
        }
      }
    }
    await ready.waitFor({ state: 'visible', timeout: this.timeout });
    if (await chips.count() !== before + 1) blocked('flow_reference_upload_unconfirmed');
  }
  referenceTransfer(project, reference, method, details = {}) {
    const record={project,sha256:reference.sha256,method,...details,at:new Date().toISOString()};
    this.lastReferenceTransfers.push(record);
    if(this.config.stateDir){
      fs.mkdirSync(this.config.stateDir,{recursive:true});
      fs.appendFileSync(path.join(this.config.stateDir,'reference-transfers.jsonl'),JSON.stringify(record)+'\n',{mode:0o600});
    }
  }
  async referenceOptionReady(option) {
      // Virtualized options may disappear after the visibility check; take a non-waiting snapshot.
      const observation = await option.evaluateAll(async elements => {
        if (elements.length > 1) return { ambiguous: true };
        const element = elements[0];
        if (!element?.isConnected) return { ready: false };
      const box = element.getBoundingClientRect();
      let left = 0, top = 0, right = innerWidth, bottom = innerHeight;
      const scrollable = [];
      for (let parent = element.parentElement; parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent), rect = parent.getBoundingClientRect();
        if (/auto|scroll|hidden|clip/.test(style.overflowX)) { left = Math.max(left, rect.left); right = Math.min(right, rect.right); }
        if (/auto|scroll|hidden|clip/.test(style.overflowY)) { top = Math.max(top, rect.top); bottom = Math.min(bottom, rect.bottom); }
        if (/auto|scroll/.test(style.overflowY) && parent.scrollHeight > parent.clientHeight) scrollable.push(parent);
      }
      if (box.width === 0 || box.height === 0 || right <= left || bottom <= top) return { ready: false };
      // CSS-visible buffered items can lie outside the virtual picker's clipping viewport.
      if (box.top < top || box.bottom > bottom || box.left < left || box.right > right) {
        if (scrollable[0]) scrollable[0].scrollBy({ top: (box.top + box.bottom - top - bottom) / 2, behavior: 'instant' });
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        return { ready: false, adjusted: !!scrollable[0] };
      }
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      const after = element.getBoundingClientRect();
      return { ready: element.isConnected && ['left', 'top', 'right', 'bottom'].every(key => Math.abs(after[key] - box[key]) < 0.5) };
    });
      if (observation.ambiguous) blocked('flow_reference_cache_ambiguous');
      if (observation.adjusted) this.referenceViewportAdjustments = (this.referenceViewportAdjustments || 0) + 1;
    return observation.ready;
  }
  async findCachedReference(cached) {
    const option=this.page.getByRole('option',{name:cached.label,exact:true});
    const picker=this.locator(this.selectors.assetList);
    for(let page=0;page<40;page++) {
      const count=await option.count();
      if(count>1)blocked('flow_reference_cache_ambiguous');
      if(count===1&&await option.isVisible()) {
        if(await this.referenceOptionReady(option))return option;
        continue;
      }
      const moved=await picker.evaluate((element,action)=>{
        const candidates=[element,...element.querySelectorAll('*')];let parent=element.parentElement;
        for(let n=0;n<4&&parent&&parent!==document.body;n++,parent=parent.parentElement)candidates.push(parent);
        const view=candidates.find(e=>e.clientHeight>0&&e.scrollHeight>e.clientHeight+10&&/auto|scroll/.test(getComputedStyle(e).overflowY));
        if(!view)return {scrollable:false};
        const signature=[...element.querySelectorAll('[role="option"]')].map(e=>e.getAttribute('aria-label')||e.textContent).join('\n');
        const before=view.scrollTop;
        view.scrollTop=action==='top'?0:Math.min(view.scrollHeight-view.clientHeight,before+Math.max(1,view.clientHeight*0.8));
        return {scrollable:true,moved:view.scrollTop!==before,signature};
      },page===0?'top':'next');
      if(!moved.scrollable||(page>0&&!moved.moved))return null;
      if(moved.moved)try{
        await this.page.waitForFunction(signature=>{
          const list=document.querySelector('[role="listbox"][aria-label="Asset list"]');
          return list&&[...list.querySelectorAll('[role="option"]')].map(e=>e.getAttribute('aria-label')||e.textContent).join('\n')!==signature;
        },moved.signature,{timeout:Math.min(this.timeout,1500)});
      }catch(error){if(error.name!=='TimeoutError')throw error;}
    }
    blocked('flow_reference_cache_search_incomplete');
  }
  async observeUpload(chooser, phase, details) {
    if(typeof chooser.element!=='function')return;
    try {
      const input=await chooser.element().evaluate(element=>({connected:element.isConnected,tag:element.tagName,type:element.type,accept:element.accept,multiple:element.multiple,files:[...(element.files||[])].map(file=>({name:file.name,size:file.size,type:file.type})),markup:element.outerHTML.slice(0,1500)}));
      const record={phase,...details,input,at:new Date().toISOString()};(this.uploadObservations||=[]).push(record);
      if(this.config.stateDir)fs.appendFileSync(path.join(this.config.stateDir,'upload-observations.jsonl'),JSON.stringify(record)+'\n',{mode:0o600});
    } catch { /* Diagnostics cannot replace the original upload outcome. */ }
  }
  async upload(references, forceUploads = new Set()) {
    try {
    this.uploadObservations=[];this.referenceIdentityChecks=[];
    if (this.selectors.clearPrompt && await this.visible(this.selectors.clearPrompt)) {
      await (await this.unique(this.selectors.clearPrompt)).click();
      await this.page.waitForFunction(selector => document.querySelectorAll(selector).length === 0, this.selectors.referenceChip, { timeout: this.timeout });
    }
    else if (this.selectors.referenceRemove) {
      let count = 0;
      while (await this.locator(this.selectors.referenceRemove).count()) {
        if (++count > 12) blocked('flow_reference_cleanup_failed');
        await this.locator(this.selectors.referenceRemove).first().click();
      }
    }
    if (this.selectors.referenceChip && await this.locator(this.selectors.referenceChip).count()) blocked('flow_reference_cleanup_unavailable');
    const project = official(this.page.url()) ? new URL(this.page.url()).origin + new URL(this.page.url()).pathname : null;
    const cacheFile = this.config.profileDir ? path.join(path.resolve(this.config.profileDir), 'flow-reference-assets.json') : null;
    let cache = { version: 1, projects: {} };
    try { if (cacheFile && fs.existsSync(cacheFile)) { const saved = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); if (saved.version === 1 && saved.projects) cache = saved; } } catch { /* A missing cache only requires the original upload path. */ }
    const assets = project ? (cache.projects[project] ||= {}) : {};
    const saveCache = () => {
      if (!cacheFile || !project) return;
      fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
      fs.writeFileSync(cacheFile + '.tmp', JSON.stringify(cache), { mode: 0o600 }); fs.renameSync(cacheFile + '.tmp', cacheFile);
    };
    const attached = new Set(); this.lastReferenceTransfers = [];
    for (const reference of references) {
      this.referenceViewportAdjustments = 0;
      if (!reference.path || !/^[a-f0-9]{64}$/.test(reference.sha256 || '') || hash(fs.readFileSync(reference.path)) !== reference.sha256) blocked('flow_reference_hash_changed');
      const before = this.selectors.referenceChip ? await this.locator(this.selectors.referenceChip).count() : 0;
      const cached = assets[reference.sha256];
      // Reuse only an exact observed picker label AND verified ingredient identity in this project.
      // Old tasks with duplicate ingredients keep their original count/provenance contract.
      if (!forceUploads.has(reference.sha256) && cacheFile && cached && !attached.has(reference.sha256) && typeof cached.label === 'string' && imageIdentity(cached.identity)) {
        this.uiStage = 'upload.reuse_existing';
        await (await this.unique(this.selectors.uploadButton)).click();
        // Opening the picker is asynchronous; an immediate count incorrectly treats cached assets as missing.
        await this.locator(this.selectors.assetList).waitFor({ state: 'visible', timeout: this.timeout });
        const option = await this.findCachedReference(cached);
        if (option) {
          const thumbnail = option.locator('img.asset-thumbnail-image');
          await thumbnail.waitFor({ state: 'visible', timeout: this.timeout });
          const pickerIdentity = imageIdentity(await thumbnail.getAttribute('src'));
          let expectedIdentity = await this.referenceIdentity(pickerIdentity, cached.label);
          if (!expectedIdentity) blocked('flow_reference_reuse_unverified');
          if (new URL(cached.identity).hostname === 'flow-content.google') {
            if (new URL(expectedIdentity).hostname === 'flow.google.com') {
              // The exact unique upload label also binds a virtualized asset whose gallery tile is absent.
              expectedIdentity = cached.identity; this.referenceAliases.set(pickerIdentity, expectedIdentity);
            } else if (expectedIdentity !== cached.identity) blocked('flow_reference_reuse_unverified');
          }
          await this.selectReferenceOption(option, cached.label, before);
          await this.attachSelectedReference(before);
          let source;
          try { source=await this.locator(this.selectors.promptIngredientImage).nth(before).getAttribute('src'); }
          catch(error) {
            if(error.name!=='TimeoutError')throw error;
            this.referenceTransfer(project,reference,'cache_miss',{reason:'empty_cached_chip'});
            return this.upload(references,new Set([...forceUploads,reference.sha256]));
          }
          const identity = await this.referenceIdentity(source);
          if(!identity){
            this.referenceTransfer(project,reference,'cache_miss',{reason:'cached_identity_missing'});
            return this.upload(references,new Set([...forceUploads,reference.sha256]));
          }
          this.referenceIdentityChecks.push({sha256:reference.sha256,cached_identity:cached.identity,picker_identity:pickerIdentity,expected_identity:expectedIdentity,attached_identity:identity});
          if (await this.locator(this.selectors.referenceChip).count() !== before + 1 || identity !== expectedIdentity) blocked('flow_reference_reuse_unverified');
          assets[reference.sha256] = { ...cached, identity, source_identities:[...new Set([...(cached.source_identities || []),cached.identity,pickerIdentity,imageIdentity(source)].filter(Boolean))] }; saveCache();
          attached.add(reference.sha256);
          this.referenceTransfer(project,reference,'existing_project_asset',{identity,viewport_adjustments:this.referenceViewportAdjustments});
          continue;
        }
        await this.page.keyboard.press('Escape');
        this.referenceTransfer(project,reference,'cache_miss',{reason:'asset_not_found_in_picker'});
      }
      const chooserPromise = this.page.waitForEvent('filechooser', { timeout: this.timeout }).catch(error => ({ chooserError: error }));
      this.uiStage = 'upload.open_picker';
      await (await this.unique(this.selectors.uploadButton)).click();
      if (this.selectors.uploadFile) {
        await this.locator(this.selectors.uploadFile).waitFor({ state: 'visible', timeout: this.timeout });
        await (await this.unique(this.selectors.uploadFile)).click();
      }
      const chooser = await chooserPromise;
      if (chooser.chooserError) blocked('flow_upload_chooser_failed');
      const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-exact-reference-'));
      const uploadPath = path.join(staging, reference.sha256.slice(0, 16) + '-' + randomUUID() + path.extname(reference.path));
      fs.copyFileSync(reference.path, uploadPath);
      if (hash(fs.readFileSync(uploadPath)) !== reference.sha256) blocked('flow_reference_copy_changed');
      try {
      this.uiStage = 'upload.set_files';
      await this.observeUpload(chooser,'before_set_files',{sha256:reference.sha256,filename:path.basename(uploadPath)});
      await chooser.setFiles(uploadPath);
      await this.observeUpload(chooser,'after_set_files',{sha256:reference.sha256,filename:path.basename(uploadPath)});
      if (this.selectors.cropConfirm && await this.visible(this.selectors.cropConfirm)) await (await this.unique(this.selectors.cropConfirm)).click();
      if (this.selectors.assetList && this.selectors.addToPrompt) {
        this.uiStage = 'upload.wait_asset';
        await this.locator(this.selectors.assetList).waitFor({ state: 'visible', timeout: this.timeout });
        const option = this.page.getByRole('option', { name: path.basename(uploadPath) + ' Image', exact: true });
        await option.waitFor({ state: 'visible', timeout: this.timeout });
        if (await option.count() !== 1) blocked('flow_uploaded_asset_ambiguous');
        await this.selectReferenceOption(option, path.basename(uploadPath) + ' Image', before);
        this.uiStage = 'upload.add_to_prompt';
        await this.attachSelectedReference(before);
      }
      this.uiStage = 'upload.wait_reference_chip';
      if (!this.selectors.referenceChip) blocked('flow_reference_confirmation_unavailable');
      await this.locator(this.selectors.referenceChip).nth(before).waitFor({ state: 'visible', timeout: this.timeout });
      if (await this.locator(this.selectors.referenceChip).count() !== before + 1) blocked('flow_reference_upload_unconfirmed');
      await this.locator(this.selectors.readyReferenceChip).nth(before).waitFor({ state: 'visible', timeout: this.timeout });
      attached.add(reference.sha256);
      this.referenceTransfer(project,reference,'upload',{reason:forceUploads.has(reference.sha256)?'replace_bad_cached_asset':cached?'cache_miss':'first_seen_sha',viewport_adjustments:this.referenceViewportAdjustments});
      if (cacheFile && project) {
        const ingredient = this.locator(this.selectors.promptIngredientImage).nth(before);
        await ingredient.waitFor({ state: 'visible', timeout: this.timeout });
        const source = await ingredient.getAttribute('src');
        const identity = await this.referenceIdentity(source, path.basename(uploadPath) + ' Image');
        if (!identity) blocked('flow_reference_identity_unverified');
        assets[reference.sha256] = { label: path.basename(uploadPath) + ' Image', identity, source_identities:[imageIdentity(source)] };
        saveCache();
      }
      } finally { fs.rmSync(staging, { recursive: true, force: true }); }
    }
    } catch (error) {
      if (!error.code) error.code = 'flow_upload_ui_failed';
      await this.captureDiagnostic({ stage: 'upload', error_code: error.code, error_name: error.name, error_message: diagnosticText(error.message) });
      try {
        await this.dismissAssetPicker();
      } catch { /* Retain the original upload blocker. */ }
      throw error;
    }
  }
  async fillPrompt(value) {
    try {
      const prompt = await this.unique(this.selectors.prompt);
      await prompt.fill(value);
      // ProseMirror paragraphs are separate visible lines; textContent joins them without separators.
      if (semanticPrompt(await prompt.innerText()) !== semanticPrompt(value)) blocked('flow_prompt_fill_unverified');
    } catch (error) {
      if (!error.code) error.code = 'flow_prompt_ui_failed';
      await this.captureDiagnostic({ stage: 'prompt', error_code: error.code, expected_prompt_sha256: hash(value), error_name: error.name });
      throw error;
    }
  }
  async waitForGenerate(expectedPrompt) {
    const generate = await this.unique(this.selectors.generate);
    try { await generate.click({ trial: true, timeout: this.timeout }); }
    catch {
      const ready = await this.readiness();
      if (!ready.ready) blocked(ready.code);
      const failure = await this.generationFailure(); if (failure) blocked(failure);
      // Flow can reset its composer after fill; restore an empty prompt once before any click checkpoint.
      if (expectedPrompt && !semanticPrompt(await (await this.unique(this.selectors.prompt)).innerText())) {
        await this.fillPrompt(expectedPrompt);
        return this.waitForGenerate();
      }
      blocked(await generate.isEnabled() ? 'flow_generate_not_ready' : 'flow_generate_disabled');
    }
    return generate;
  }
  async results() {
    // Virtualized tiles can reorder between awaits; read candidates in one DOM snapshot.
    // Asset-info provenance and identity-based resultTile() still verify before acquisition.
    return this.locator(this.selectors.resultTile).evaluateAll((tiles, { selector, attribute }) => tiles.flatMap((tile, index) => {
      const style = tile.ownerDocument.defaultView.getComputedStyle(tile);
      const rect = tile.getBoundingClientRect();
      if (!tile.isConnected || !tile.getClientRects().length || rect.width <= 0 || rect.height <= 0 || style.visibility === 'hidden' || style.visibility === 'collapse') return [];
      const images = tile.querySelectorAll(selector);
      if (images.length !== 1 || !images[0].complete || images[0].naturalWidth <= 0) return [];
      const identity = images[0].getAttribute(attribute);
      return identity ? [{ identity, text: tile.innerText, index }] : [];
    }), { selector: this.selectors.resultImage, attribute: this.selectors.resultIdentityAttribute || 'src' });
  }
  async resultTile(result) {
    const attribute = this.selectors.resultIdentityAttribute || 'src';
    if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(attribute) || typeof this.selectors.resultImage !== 'string' || typeof result.identity !== 'string' || /[\r\n\x00]/.test(result.identity)) blocked('flow_result_identity_selector_invalid');
    const identity = result.identity.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    // Flow can reorder gallery tiles while new images finish loading.
    const tile = this.locator(this.selectors.resultTile).filter({ has: this.page.locator(this.selectors.resultImage + '[' + attribute + '="' + identity + '"]') });
    await tile.waitFor({ state: 'visible', timeout: this.timeout });
    if (await tile.count() !== 1) blocked('flow_result_identity_ambiguous');
    return tile;
  }
  async recover(recovery, prompt, { completedOnly = false } = {}) {
    this.uiStage = 'recover.validate';
    if (!recovery || !Array.isArray(recovery.baseline) || !official(recovery.project_url) || recovery.prompt_sha256 !== hash(prompt)) blocked('flow_generation_reconcile_required');
    if(recovery.failure_baseline)this.failureBaseline=recovery.failure_baseline;
    const projectUrl=this.uiUrl(recovery.project_url);
    if (this.page.url() !== projectUrl) await this.page.goto(projectUrl, { waitUntil: 'domcontentloaded', timeout: this.timeout });
    if(this.config.accountPolicy)await this.verifyAccount(this.accountState().active_email);
    const end = Date.now() + (this.config.generationTimeoutMs || 240000);
    const searchKey=hash(JSON.stringify([recovery.project_url,recovery.started_at,recovery.prompt_sha256,recovery.ingredient_identities,recovery.baseline]));
    if(this.recoverySearch?.key!==searchKey)this.recoverySearch={key:searchKey,rejected:new Set()};
    const inspected = this.recoverySearch.rejected, deferred=new Set(); let waitDiagnosticSaved = false;
    const historical=Date.now()-Date.parse(recovery.started_at)>(this.config.generationTimeoutMs||240000)&&recovery.reference_count>0&&recovery.ingredient_identities?.length===recovery.reference_count;
    if(historical&&!this.recoverySearch.oldestPositioned){await this.oldestRecoveryPage();this.recoverySearch.oldestPositioned=true;}
    while (Date.now() < end) {
      this.uiStage = 'recover.readiness';
      const readiness = await this.readiness(); if (!readiness.ready) blocked(readiness.code);
      this.uiStage = 'recover.results';
      const candidates = (await this.results()).filter(r => !recovery.baseline.includes(r.identity) && !inspected.has(r.identity)&&!deferred.has(r.identity));
      if(historical)candidates.reverse();
      if (this.config.logDir && Date.now() - Date.parse(recovery.started_at) > (this.config.generationTimeoutMs || 240000)) {
        await this.captureDiagnostic({ stage: 'historical_recovery_gallery', candidate_count: candidates.length, baseline_count: recovery.baseline.length });
        for (const suffix of ['private.json','png']) {
          const source=path.join(this.config.logDir,'last-blocked-flow.'+suffix);
          if(fs.existsSync(source))fs.copyFileSync(source,path.join(this.config.logDir,'historical-recovery-gallery.'+suffix));
        }
      }
      const matches = [];
      for (const candidate of candidates) {
        if(Date.now()>=end)break;
        const tile = await this.resultTile(candidate);
        this.uiStage = 'recover.open_result';
        await (await this.unique(this.selectors.openResult, tile)).click();
        let verified=false;
        try { verified=await this.verifyResultPrompt(prompt, recovery.reference_count, recovery.ingredient_identities, recovery.aspect_ratio || '1:1', recovery.model||'Nano Banana Pro'); }
        catch(error){if(error.code!=='flow_reference_thumbnail_unavailable')throw error;deferred.add(candidate.identity);}
        if (verified) matches.push({ ...candidate, model:recovery.model||'Nano Banana Pro', model_policy_reference:recovery.model_policy_reference, aspect_ratio: recovery.aspect_ratio || '1:1',
          prompt_sha256: recovery.prompt_sha256, reference_count: recovery.reference_count, ingredient_identities: recovery.ingredient_identities });
        else if(!deferred.has(candidate.identity))inspected.add(candidate.identity);
        this.uiStage = 'recover.back_to_project';
        await this.page.keyboard.press('Escape');
        const current = new URL(this.page.url()), expected = new URL(projectUrl);
        if (current.origin !== expected.origin || (current.pathname !== expected.pathname && !current.pathname.startsWith(expected.pathname + '/edit/'))) blocked('flow_generation_project_binding_changed');
        // Escape may already close the editor as well as Asset info.
        if (current.pathname !== expected.pathname) await (await this.unique(this.selectors.back)).click();
      }
      if (matches.length) {
        matches.sort((a, b) => a.identity.localeCompare(b.identity));
        return { ...matches[0], expected_prompt: prompt, equivalent_result_identities: matches.map(r => r.identity) };
      }
      const failure = await this.generationFailure();
      if (failure) blocked(failure, 'Flow displays a failed generation; no Generate or Retry will be repeated');
      if(historical&&Date.now()<end&&await this.nextRecoveryPage(-1))continue;
      if(completedOnly){
        if(deferred.size)blocked('flow_reference_thumbnail_unavailable');
        return null;
      }
      if (typeof this.selectors.resultTile !== 'string' || typeof this.selectors.resultImage !== 'string') blocked('flow_recovery_selector_invalid');
      this.uiStage = 'recover.wait_completed_result';
      if (!waitDiagnosticSaved) { await this.captureDiagnostic({ stage: 'waiting_completed_result', baseline_count: recovery.baseline.length, inspected_count: inspected.size }); waitDiagnosticSaved = true; }
      try {
        await this.page.waitForFunction(({ tileSelector, imageSelector, attribute, excluded, failureSelector, failureBaseline }) => {
          const ignored=[...failureBaseline];
          return [...document.querySelectorAll(failureSelector)].some(tile => {
            if(!tile.getClientRects().length||getComputedStyle(tile).visibility==='hidden'||!/(?:^|\n)\s*Failed\s*(?:\n|$)/u.test(tile.innerText))return false;
            const text=tile.innerText.replace(/\s+/g,' ').trim(),index=ignored.indexOf(text);
            if(index!==-1){ignored.splice(index,1);return false;}return true;
          }) || [...document.querySelectorAll(tileSelector)].some(tile => {
            const image = tile.querySelector(imageSelector);
            return image && image.getClientRects().length && image.complete && image.naturalWidth > 0 && !excluded.includes(image.getAttribute(attribute));
          });}, { tileSelector: this.selectors.resultTile, imageSelector: this.selectors.resultImage,
          attribute: this.selectors.resultIdentityAttribute || 'src', excluded: [...recovery.baseline, ...inspected, ...deferred],
          failureSelector: this.selectors.generationFailed, failureBaseline:this.failureBaseline||[] }, { timeout: Math.max(1, end - Date.now()) });
      } catch {
        const failure = await this.generationFailure();
        if (failure) blocked(failure, 'Flow displays a failed generation; no Generate or Retry will be repeated');
        blocked('flow_generation_reconcile_required', 'No correlated completed result found; Generate will not be repeated');
      }
    }
    blocked('flow_generation_reconcile_required', 'No unambiguous completed result found; Generate will not be repeated');
  }
  async oldestRecoveryPage() {
    const gallery=await this.unique(this.selectors.recoveryGallery);
    const before=await gallery.evaluate(e=>({top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight}));
    if(before.top+before.height>=before.total-1)return;
    await gallery.hover();await this.page.mouse.wheel(0,before.total);
    await this.page.waitForFunction(selector=>{const e=document.querySelector(selector);return e&&e.scrollTop+e.clientHeight>=e.scrollHeight-1;},this.selectors.recoveryGallery,{timeout:this.timeout});
  }
  async nextRecoveryPage(direction=1) {
    const gallery=await this.unique(this.selectors.recoveryGallery);
    const before=await gallery.evaluate(e=>({top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight}));
    if(direction>0?before.top+before.height>=before.total-1:before.top<=1)return false;
    await gallery.hover();
    await this.page.mouse.wheel(0,direction*Math.max(1,Math.floor(before.height*0.8)));
    try {
      await this.page.waitForFunction(({selector,top,direction})=>{const current=document.querySelector(selector)?.scrollTop;return direction>0?current>top:current<top;},{selector:this.selectors.recoveryGallery,top:before.top,direction},{timeout:this.timeout});
    } catch { blocked('flow_recovery_scroll_failed'); }
    return true;
  }
  async verifyResultPrompt(prompt, referenceCount, ingredientIdentities, aspectRatio = '1:1', expectedModel = 'Nano Banana Pro') {
    this.uiStage = 'recover.asset_info_button';
    await this.locator(this.selectors.assetInfoButton).waitFor({ state: 'visible', timeout: this.timeout });
    await (await this.unique(this.selectors.assetInfoButton)).click();
    this.uiStage = 'recover.asset_info_panel';
    await this.locator(this.selectors.assetInfo).waitFor({ state: 'visible', timeout: this.timeout });
    const panel = await this.unique(this.selectors.assetInfo);
    // Public asset info text, no hidden state or private endpoints.
    this.uiStage = 'recover.asset_info_metadata';
    await this.locator(this.selectors.resultMetadata, panel).first().waitFor({ state: 'visible', timeout: this.timeout });
    await this.locator(this.selectors.resultRatio, panel).first().waitFor({ state: 'visible', timeout: this.timeout });
    const normalize = value => value.replace(/\s+/g, ' ').trim();
    this.lastResultVerification = { expected_prompt_sha256: hash(prompt),
      expected_reference_count: referenceCount, expected_ingredient_identities: ingredientIdentities, expected_model: expectedModel, expected_ratio: aspectRatio };
    const rows = this.locator(this.selectors.resultMetadata, panel), metadata = [];
    for (let i = 0; i < await rows.count(); i++) metadata.push(normalize(await rows.nth(i).textContent()));
    const ratioSpans = this.locator(this.selectors.resultRatio, panel); let square = false;
    const actualRatios = [];
    for (let i = 0; i < await ratioSpans.count(); i++) { const text = normalize(await ratioSpans.nth(i).textContent()); actualRatios.push(text); if (text === aspectRatio) square = true; }
    this.lastResultVerification.actual_metadata = metadata; this.lastResultVerification.actual_ratio_spans = actualRatios;
    if (!metadata.some(text => text.replace(/^🍌\s*/u,'')===expectedModel) || !square) { await this.captureDiagnostic({ stage: 'returned_metadata_mismatch', error_code: 'flow_result_metadata_mismatch' }); return false; }
    const exactPrompt = this.locator(this.selectors.exactResultPrompt, panel);
    try { await exactPrompt.waitFor({ state: 'visible', timeout: this.timeout }); }
    catch (error) {
      if (error.name !== 'TimeoutError') throw error;
      await this.captureDiagnostic({ stage: 'asset_without_generation_prompt', error_code: 'flow_result_prompt_missing' });
      return false;
    }
    const actualPrompt = await exactPrompt.count() === 1 ? await exactPrompt.textContent() : '';
    this.lastResultVerification.actual_prompt_sha256=hash(actualPrompt||'');this.lastResultVerification.actual_prompt=actualPrompt;
    if (await exactPrompt.count() !== 1 || !await exactPrompt.isVisible() || normalize(actualPrompt) !== normalize(prompt)) {
      await this.captureDiagnostic({ stage: 'returned_prompt_mismatch', error_code: 'flow_result_prompt_mismatch' }); return false;
    }
    const actualReferenceCount = await this.locator(this.selectors.resultIngredient, panel).count(); this.lastResultVerification.actual_reference_count = actualReferenceCount;
    if (Number.isInteger(referenceCount) && actualReferenceCount !== referenceCount) { await this.captureDiagnostic({ stage: 'returned_reference_mismatch', error_code: 'flow_result_reference_mismatch' }); return false; }
    if (ingredientIdentities?.length) {
      const resultImages = this.locator(this.selectors.promptIngredientImage, panel);
      this.uiStage = 'recover.ingredient_thumbnail';
      try { await resultImages.nth(ingredientIdentities.length - 1).waitFor({ state: 'visible', timeout: this.timeout }); }
      catch {
        this.lastResultVerification.ingredient_markup = await this.locator(this.selectors.resultIngredient, panel).evaluateAll(elements => elements.map(e => e.outerHTML.slice(0, 4000)));
        await this.captureDiagnostic({ stage: 'returned_reference_thumbnail_unavailable', error_code: 'flow_reference_thumbnail_unavailable' });
        blocked('flow_reference_thumbnail_unavailable');
      }
      const actual = [];
      for (let i = 0; i < await resultImages.count(); i++) actual.push(await this.referenceIdentity(await resultImages.nth(i).getAttribute('src')));
      const expected = await Promise.all(ingredientIdentities.map(identity => this.referenceIdentity(identity)));
      this.lastResultVerification.actual_ingredient_identities = actual;
      if (JSON.stringify(actual.sort()) !== JSON.stringify(expected.sort())) {
        this.lastResultVerification.ingredient_markup = await this.locator(this.selectors.resultIngredient, panel).evaluateAll(elements => elements.map(e => e.outerHTML.slice(0, 4000)));
        await this.captureDiagnostic({ stage: 'returned_reference_identity_mismatch', error_code: 'flow_result_reference_mismatch' }); return false;
      }
    }
    return true;
  }
  async acquire(result, outputDirectory, generationId) {
    this.uiStage = 'acquire.validate_checkpoint';
    const record = path.join(path.resolve(outputDirectory), generationId + '-acquired.json');
    const reservationFile = record + '.download';
    if (fs.existsSync(record)) {
      const recovered = JSON.parse(fs.readFileSync(record, 'utf8'));
      if(result.equivalent_result_identities?.includes(recovered.proof.result_identity))result={...result,identity:recovered.proof.result_identity};
      if (recovered.proof.result_identity !== result.identity || hash(fs.readFileSync(recovered.asset.path)) !== recovered.asset.sha256 || !recovered.proof.screenshot_sha256 || hash(fs.readFileSync(recovered.proof.screenshot_path)) !== recovered.proof.screenshot_sha256) blocked('flow_acquired_record_changed');
      return recovered;
    }
    if (fs.existsSync(reservationFile)) {
      const reservation = JSON.parse(fs.readFileSync(reservationFile, 'utf8'));
      if(result.equivalent_result_identities?.includes(reservation.result_identity))result={...result,identity:reservation.result_identity};
      if (reservation.result_identity !== result.identity || reservation.generation_id !== generationId || path.dirname(reservation.path) !== path.resolve(outputDirectory)) blocked('flow_download_reservation_changed');
      if (fs.existsSync(reservation.path)) {
        const bytes = fs.readFileSync(reservation.path);
        const complete = (bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex')) && bytes.subarray(-8, -4).toString() === 'IEND') ||
          (bytes[0] === 255 && bytes[1] === 216 && bytes.at(-2) === 255 && bytes.at(-1) === 217) ||
          (bytes.length > 12 && bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP' && bytes.readUInt32LE(4) === bytes.length - 8);
        if (!complete || !reservation.screenshot_sha256 || hash(fs.readFileSync(reservation.screenshot_path)) !== reservation.screenshot_sha256) blocked('flow_download_reconcile_required', 'Interrupted original is preserved; confirm download before continuing');
        const recovered = { asset: { path: reservation.path, sha256: hash(bytes) }, proof: { ...reservation.verified_result, model: reservation.verified_result?.returned_model||'Nano Banana Pro', url: reservation.url, screenshot_path: reservation.screenshot_path, screenshot_sha256: reservation.screenshot_sha256, acquisition: { method: 'flow_download', recovered_after_save: true }, generation_id: generationId, result_identity: result.identity }, generation_id: generationId };
        fs.writeFileSync(record + '.tmp', JSON.stringify(recovered)); fs.renameSync(record + '.tmp', record); return recovered;
      }
    }
    const tile = await this.resultTile(result);
    this.uiStage = 'acquire.open_result';
    await tile.hover();
    if (this.selectors.openResult) {
      await (await this.unique(this.selectors.openResult, tile)).click();
      if (this.selectors.resultDetail) await this.locator(this.selectors.resultDetail).waitFor({ state: 'visible', timeout: this.timeout });
    }
    this.uiStage = 'acquire.asset_info';
    if (result.expected_prompt) {
      if (!await this.verifyResultPrompt(result.expected_prompt, result.reference_count, result.ingredient_identities, result.aspect_ratio || '1:1',result.model||'Nano Banana Pro')) blocked('flow_result_changed_before_download');
    } else {
      await this.locator(this.selectors.assetInfoButton).waitFor({ state: 'visible', timeout: this.timeout });
      await (await this.unique(this.selectors.assetInfoButton)).click();
      await this.locator(this.selectors.assetInfo).waitFor({ state: 'visible', timeout: this.timeout });
    }
    const screenshot = path.join(path.resolve(outputDirectory), generationId + '-flow-proof.png');
    fs.mkdirSync(path.resolve(outputDirectory), { recursive: true });
    await this.page.screenshot({ path: screenshot, fullPage: false });
    await this.page.keyboard.press('Escape');
    const scope = this.selectors.openResult ? this.page : tile;
    this.uiStage = 'acquire.download_menu';
    if (this.selectors.downloadMenu) {
      await this.locator(this.selectors.downloadMenu, scope).waitFor({ state: 'visible', timeout: this.timeout });
      await (await this.unique(this.selectors.downloadMenu, scope)).click();
    }
    await this.locator(this.selectors.downloadOriginal, this.selectors.downloadMenu ? this.page : scope).waitFor({ state: 'visible', timeout: this.timeout });
    const downloadControl = await this.unique(this.selectors.downloadOriginal, this.selectors.downloadMenu ? this.page : scope);
    const [download] = await Promise.all([
      this.page.waitForEvent('download', { timeout: this.config.downloadTimeoutMs || 60000 }), downloadControl.click()
    ]);
    this.uiStage = 'acquire.save_original';
    if (await download.failure()) blocked('flow_download_failed');
    const extension = path.extname(download.suggestedFilename()).toLowerCase();
    if (!['.png', '.jpg', '.jpeg', '.webp'].includes(extension)) blocked('flow_download_format_unsupported');
    const directory = path.resolve(outputDirectory); fs.mkdirSync(directory, { recursive: true });
    const target = path.join(directory, generationId + extension);
    if (fs.existsSync(target)) blocked('flow_original_already_exists', 'Existing original will not be overwritten');
    const screenshotHash = hash(fs.readFileSync(screenshot));
    const verifiedResult = { prompt_sha256: result.prompt_sha256, reference_count: result.reference_count, ingredient_identities: result.ingredient_identities, equivalent_result_identities: result.equivalent_result_identities, returned_model: result.model||'Nano Banana Pro', ...(result.model_policy_reference?{model_policy_reference:result.model_policy_reference}:{}), returned_ratio: result.aspect_ratio || '1:1' };
    const reservation = { generation_id: generationId, result_identity: result.identity, path: target, screenshot_path: screenshot, screenshot_sha256: screenshotHash, url: this.page.url(), verified_result: verifiedResult };
    fs.writeFileSync(reservationFile + '.tmp', JSON.stringify(reservation)); fs.renameSync(reservationFile + '.tmp', reservationFile);
    await download.saveAs(target);
    const bytes = fs.readFileSync(target);
    const raster = bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex')) || (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) || (bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP');
    if (!raster) blocked('flow_download_not_image');
    const proofUrl = this.page.url();
    const acquired = { asset: { path: target, sha256: hash(bytes) }, proof: { ...verifiedResult, model: verifiedResult.returned_model, url: proofUrl, screenshot_path: screenshot, screenshot_sha256: screenshotHash, acquisition: { method: 'flow_download' }, generation_id: generationId, result_identity: result.identity }, generation_id: generationId };
    fs.writeFileSync(record + '.tmp', JSON.stringify(acquired)); fs.renameSync(record + '.tmp', record);
    await (await this.unique(this.selectors.back)).click();
    return acquired;
  }
  async generate(item, references, outputDirectory, hooks = {}) {
    this.uiStage = 'generate.validate'; this.currentGeneration = null; this.lastResultVerification = null;
    try {
    if (typeof item.prompt !== 'string' || !item.prompt.trim()) blocked('flow_prompt_missing');
    const mandatory = this.config.mandatoryOutlineRule;
    if (!mandatory || !item.prompt.endsWith(mandatory)) blocked('flow_outline_rule_missing');
    if (!Array.isArray(references)) blocked('flow_references_invalid');
    references.forEach(r => { if (hash(fs.readFileSync(r.path)) !== r.sha256) blocked('flow_reference_hash_changed'); });
    const resume = hooks.resume;
    if(this.config.accountPolicy)await this.verifyAccount(this.accountState().active_email);
    const aspectRatio = item.aspect_ratio || '1:1';
    let generationId, recovery;
    if (resume?.status === 'generation_started') {
      generationId = resume.generation_id; recovery = resume.recovery;
      if ((recovery?.aspect_ratio || '1:1') !== aspectRatio) blocked('flow_generation_aspect_binding_changed');
      if(recovery?.project_key&&hooks.projectKey&&recovery.project_key!==hooks.projectKey)blocked('flow_generation_project_binding_changed');
      this.currentGeneration = generationId;
      if (!/^[a-zA-Z0-9_-]{1,100}$/.test(generationId || '')) blocked('flow_generation_reconcile_required');
    } else {
      if (resume && !['ready', 'generation_failed'].includes(resume.status)) blocked('flow_resume_state_unhandled');
      if (typeof hooks.beforeGenerate !== 'function') blocked('flow_durable_checkpoint_required');
      this.uiStage = 'generate.ensure_project'; await this.ensureProject(hooks.projectKey);
      if(resume?.retry_permit_id&&hooks.retryRecovery){
        const prior=hooks.retryRecovery;
        if(prior.status!=='generation_started'||!/^[a-zA-Z0-9_-]{1,100}$/.test(prior.generation_id||'')
          ||(prior.recovery?.aspect_ratio||'1:1')!==aspectRatio
          ||(prior.recovery?.project_key&&hooks.projectKey&&prior.recovery.project_key!==hooks.projectKey))blocked('flow_generation_reconcile_required');
        this.currentGeneration=prior.generation_id;
        const existing=await this.recover(prior.recovery,item.prompt,{completedOnly:true});
        if(existing){
          const acquired=await this.acquire(existing,outputDirectory,prior.generation_id);
          if(hooks.checkpoint)await hooks.checkpoint({event:'acquired',...acquired});
          return acquired;
        }
      }
      this.uiStage = 'generate.configure'; await this.configure(aspectRatio);
      this.uiStage = 'generate.upload'; await this.upload(references);
      this.uiStage = 'generate.fill_prompt';
      await this.fillPrompt(item.prompt);
      const generate = await this.waitForGenerate(item.prompt);
      generationId = randomUUID();
      this.currentGeneration = generationId;
      const ingredientImages = this.locator(this.selectors.promptIngredientImage);
      if (references.length) {
        this.uiStage = 'generate.ingredient_thumbnail';
        await ingredientImages.nth(references.length - 1).waitFor({ state: 'visible', timeout: this.timeout });
      }
      const ingredientIdentities = [];
      for (let i = 0; i < await ingredientImages.count(); i++) {
        const identity = await this.referenceIdentity(await ingredientImages.nth(i).getAttribute('src'));
        if (!identity) blocked('flow_reference_identity_unverified');
        ingredientIdentities.push(identity);
      }
      if (ingredientIdentities.length !== references.length) blocked('flow_reference_count_unverified');
      const failedBeforeClick=await this.failedTileTexts();
      if(await this.generationFailure(failedBeforeClick)==='flow_unusual_activity_required')blocked('flow_unusual_activity_required');
      this.failureBaseline=failedBeforeClick;
      recovery = { project_url: this.page.url(),project_key:hooks.projectKey, model:this.config.model||'Nano Banana Pro', ...(this.config.model==='Nano Banana 2.1'?{model_policy_reference:this.config.modelPolicy.reference}:{}), aspect_ratio:aspectRatio, prompt_sha256: hash(item.prompt), reference_count: references.length, ingredient_identities: ingredientIdentities,
        baseline: (await this.results()).map(r => r.identity), failure_baseline:this.failureBaseline||[], started_at: new Date().toISOString() };
      if (await this.generationFailure() === 'flow_unusual_activity_required') blocked('flow_unusual_activity_required');
      if(this.config.accountPolicy)await this.verifyAccount(this.accountState().active_email);
      await hooks.beforeGenerate({ generation_id: generationId, recovery });
      this.uiStage = 'generate.click';
      if(this.config.accountPolicy)await this.verifyAccount(this.accountState().active_email);
      // n8n validation may take seconds; recheck the composer before dispatch.
      if (semanticPrompt(await (await this.unique(this.selectors.prompt)).innerText()) !== semanticPrompt(item.prompt)) blocked('flow_prompt_changed_before_click');
      // After this durable marker any click failure is ambiguous and must reconcile.
      try { await generate.click({ noWaitAfter: true, timeout: Math.min(this.timeout, 5000) }); }
      catch (error) {
        if (hooks.checkpoint) await hooks.checkpoint({ event: 'generation_click_uncertain', generation_id: generationId, error_name: error.name });
        await this.captureDiagnostic({ stage: 'generate.click_uncertain', error_code: 'flow_generate_click_uncertain', error_name: error.name, click_error: diagnosticText(error.message) });
      }
    }
    const result = await this.recover(recovery, item.prompt);
    const acquired = await this.acquire(result, outputDirectory, generationId);
    if (hooks.checkpoint) await hooks.checkpoint({ event: 'acquired', ...acquired });
    return acquired;
    } catch (error) {
      if (!error.code) error.code = 'flow_generation_ui_failed';
      await this.captureDiagnostic({ stage: this.uiStage, error_code: error.code, error_name: error.name, error_message: diagnosticText(error.message),
        expected_prompt_sha256: typeof item.prompt === 'string' ? hash(item.prompt) : null });
      throw error;
    }
  }
  async close() {
    if(this.config.gologin){
      try{if(this.page&&!this.page.isClosed?.())await this.page.close();}finally{await this.connectedBrowser?.close();this.connectedBrowser=undefined;this.context=undefined;this.page=undefined;}
    }else{if (this.context) await this.context.close(); this.page = undefined;}
  }
  async restartBrowser() {
    await this.close();
    this.context = undefined;
    // GoLogin owns its profile lifecycle; reopen only the worker tab/connection.
    await this.start();
  }
  async recoverBrowser() {
    if (this.page && !this.page.isClosed?.() && this.context?.browser?.()?.isConnected?.() !== false) return this.readiness();
    try { if(this.config.gologin)await this.close();else await this.context?.close(); } catch { /* An already disconnected owned browser needs no cleanup. */ }
    this.context = undefined; this.page = undefined;
    await this.start();
    return this.readiness();
  }
}
module.exports = { FlowBrowser, official, hash, observedSelectors, imageIdentity, diagnosticUrl };
