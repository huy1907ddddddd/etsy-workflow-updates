'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const {atomic,claimProcessLock}=require('./native-n8n.cjs');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));

class PoolSupervisor{
  constructor(config,deps={}){
    this.config=config;this.spawn=deps.spawn||spawn;this.now=deps.now||Date.now;this.write=deps.atomic||atomic;this.stopping=false;
    if(!Array.isArray(config.lanes)||config.lanes.length!==3||new Set(config.lanes.map(x=>x.id)).size!==3)throw Error('exactly_three_flow_lanes_required');
    const configs=config.lanes.map(x=>read(x.configFile));
    if(new Set(configs.map(x=>path.resolve(x.profileDir))).size!==3||new Set(configs.map(x=>path.resolve(x.stateDir))).size!==3||new Set(config.lanes.map(x=>x.email)).size!==3||config.lanes.some((x,i)=>configs[i].workerLane!==x.id))throw Error('isolated_flow_lane_configuration_required');
    this.records=config.lanes.map(lane=>({...lane,restarts:0,next:0,child:null}));
  }
  launch(record){
    const config=read(record.configFile),stop=path.join(config.stateDir,'stop.request');
    if(fs.existsSync(stop))fs.unlinkSync(stop);
    fs.mkdirSync(config.logDir,{recursive:true});
    const base=path.join(config.logDir,'pool-'+this.now());
    const out=fs.openSync(base+'.stdout.private.log','a',0o600),err=fs.openSync(base+'.stderr.private.log','a',0o600);
    try{record.child=this.spawn(process.execPath,[path.join(this.config.workflowRoot,'scripts/flow-worker/runtime.cjs')],{cwd:this.config.workflowRoot,windowsHide:true,env:{...process.env,FLOW_WORKER_CONFIG:record.configFile},stdio:['ignore',out,err]});}
    finally{fs.closeSync(out);fs.closeSync(err);}
    record.started=this.now();record.status='running';
    const child=record.child;let handled=false;
    const exited=()=>{if(handled||record.child!==child)return;handled=true;record.child=null;if(this.stopping){record.status='stopped';return;}if(this.now()-record.started>60000)record.restarts=0;record.restarts++;record.next=this.now()+Math.min(60000,2000*2**Math.min(record.restarts,5));record.status=record.restarts>6?'restart_limit':'restart_pending';};
    child.once('exit',exited);child.once('error',exited);
  }
  status(){
    const workers=this.records.map(r=>{let current={};try{current=read(path.join(read(r.configFile).stateDir,'status.json'));}catch{}
      return {...current,worker_lane:r.id,email:r.email,pid:r.child?.pid||null,process_status:r.status||'not_started',...(r.status==='disabled'?{status:'disabled'}:{})};});
    const value={enabled:true,pid:process.pid,maximum_workers:3,workers,updated_at:new Date(this.now()).toISOString()};
    try{this.write(path.join(this.config.stateDir,'pool-status.json'),value);}
    catch(error){if(!['EPERM','EACCES','EBUSY'].includes(error.code))throw error;value.status_write_pending=true;}
    return value;
  }
  tick(){
    if(this.stopping)return this.status();
    for(const r of this.records){
      const config=read(r.configFile);
      if(fs.existsSync(path.join(config.stateDir,'worker.disabled.json'))){
        if(r.child&&!r.stopSent){fs.mkdirSync(config.stateDir,{recursive:true});fs.writeFileSync(path.join(config.stateDir,'stop.request'),'Disable exact lane for manual Chrome login');r.stopSent=true;}
        r.status='disabled';continue;
      }
      if(r.status==='disabled'){r.stopSent=false;r.restarts=0;r.next=0;}
      if(!r.child&&r.restarts<=6&&this.now()>=r.next)this.launch(r);
    }
    return this.status();
  }
  async stop(){this.stopping=true;for(const r of this.records)if(r.child){const config=read(r.configFile);fs.mkdirSync(config.stateDir,{recursive:true});fs.writeFileSync(path.join(config.stateDir,'stop.request'),new Date().toISOString());}this.status();}
  async run(){
    const release=claimProcessLock(path.join(this.config.stateDir,'pool-supervisor.lock'),'flow-pool');
    try{while(!this.stopping){if(fs.existsSync(path.join(this.config.stateDir,'pool.stop.request'))){await this.stop();break;}this.tick();await new Promise(r=>setTimeout(r,2000));}}
    finally{
      try{await this.stop();}
      finally{while(this.records.some(r=>r.child))await new Promise(r=>setTimeout(r,250));release();}
    }
  }
}
async function main(){const root='C:/Huy/etsy-workflow',file=path.join(root,'config/flow-worker-pool.private.json'),c=read(file);if(!c.enabled)throw Error('flow_pool_not_enabled');const stop=path.join(c.stateDir,'pool.stop.request');if(fs.existsSync(stop))fs.unlinkSync(stop);const p=new PoolSupervisor(c);process.once('SIGTERM',()=>p.stop());process.once('SIGINT',()=>p.stop());await p.run();}
if(require.main===module)main().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={PoolSupervisor};
