'use strict';

// Local work spool only. Production transitions and approvals remain n8n commands.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const clone = value => JSON.parse(JSON.stringify(value));
function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(k => [k, stable(value[k])]));
  return value;
}
const digest = value => hash(JSON.stringify(stable(value)));
const fail = message => { throw new Error(message); };
const kinds = ['flow_design_2d', 'flow_design_embroidery', 'flow_images'];

class FlowCoordinator {
  constructor(spoolRoot, options = {}) {
    this.root = path.resolve(spoolRoot);
    this.allowedRoots = (options.allowedRoots || ['C:/Huy/etsy-workflow']).map(p => fs.realpathSync(p));
    this.now = options.now || Date.now;
    this.leaseMs = options.leaseMs || 120000;
    this.maxSnapshotAgeMs = options.maxSnapshotAgeMs || 30000;
    this.outlineRule = options.outlineRule || JSON.parse(fs.readFileSync('C:/Huy/etsy-workflow/config/artwork-flow-prompts.json', 'utf8').replace(/^\uFEFF/, '')).mandatory_outline_rule;
    fs.mkdirSync(this.root, { recursive: true });
  }
  scoped(file) {
    const real = fs.realpathSync(file);
    if (!this.allowedRoots.some(root => {
      const rel = path.relative(root, real);
      return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel));
    })) fail('Asset path outside allowed roots');
    if (!fs.statSync(real).isFile()) fail('Asset must be a file');
    return real;
  }
  asset(value) {
    if (!value || !/^[a-f0-9]{64}$/i.test(value.sha256 || '')) fail('Asset needs SHA256');
    const file = this.scoped(value.path);
    if (hash(fs.readFileSync(file)) !== value.sha256.toLowerCase()) fail('Asset missing or SHA256 changed');
    return { path: file, sha256: value.sha256.toLowerCase() };
  }
  current(snapshot, id) {
    const stamp = Date.parse(snapshot?.observed_at);
    if (snapshot?.ok !== true || !Array.isArray(snapshot.tasks) || !Number.isFinite(stamp) || stamp > this.now() + 1000 || this.now() - stamp > this.maxSnapshotAgeMs) fail('Fresh n8n browser_queue snapshot required');
    const task = snapshot.tasks.find(t => t.id === id);
    if (!task || task.status !== 'pending' || !kinds.includes(task.kind)) fail('Task is not currently pending Flow work');
    const p = task.payload;
    if (!p || !Number.isInteger(task.revision) || task.revision < 1 || !/^[a-f0-9]{64}$/.test(task.fingerprint || '') || p.revision !== task.revision || p.provider !== 'Flow Nano Banana Pro' || p.executor !== 'codex_browser_session') fail('Invalid Flow task identity/provider');
    if (!Array.isArray(p.images) || !p.images.length || p.images.some(i => typeof i.prompt !== 'string' || !i.prompt.trimEnd().endsWith(this.outlineRule))) fail('Current mandatory outline rule must finish every prompt');
    const keys = p.images.map(i => i.region || i.name);
    if (new Set(keys).size !== keys.length) fail('Duplicate image keys');
    if (task.kind === 'flow_images' && p.images.length !== 6) fail('Mockup task needs six views');
    if (task.kind !== 'flow_images' && (p.brief_id !== task.brief_id || p.stage !== task.kind.replace('flow_design_', ''))) fail('Design brief/stage mismatch');
    if (task.kind === 'flow_images' && p.listing_code !== task.code) fail('Listing identity mismatch');
    for (const ref of Object.values(p.references || {})) this.asset(ref);
    for (const image of p.images) {
      for (const ref of image.references || []) this.asset(ref);
      if (task.kind === 'flow_design_embroidery' && !(image.references || []).some(r => r.role === 'exact_locked_2d')) fail('Embroidery requires exact locked 2D reference');
    }
    return task;
  }
  file(id) { return path.join(this.root, hash(id) + '.json'); }
  load(id) { return fs.existsSync(this.file(id)) ? JSON.parse(fs.readFileSync(this.file(id), 'utf8')) : null; }
  save(state) {
    const tmp = this.file(state.task_id) + '.' + crypto.randomUUID() + '.tmp';
    const fd = fs.openSync(tmp, 'wx');
    try { fs.writeFileSync(fd, JSON.stringify(state, null, 2)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, this.file(state.task_id));
  }
  exclusive(fn) {
    const lock = path.join(this.root, '.mutation-lock');
    try { fs.mkdirSync(lock); }
    catch (e) {
      if (e.code !== 'EEXIST') throw e;
      const ownerFile = path.join(lock, 'owner.json');
      if (!fs.existsSync(ownerFile)) fail('Coordinator lock held; retry after observing current process');
      const owner = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
      try { process.kill(owner.pid, 0); fail('Coordinator busy'); }
      catch (err) { if (err.code !== 'ESRCH') throw err; }
      const abandoned = lock + '.abandoned-' + crypto.randomUUID();
      fs.renameSync(lock, abandoned);
      fs.rmSync(abandoned, { recursive: true });
      return this.exclusive(fn);
    }
    fs.writeFileSync(path.join(lock, 'owner.json'), JSON.stringify({ pid: process.pid }));
    try { return fn(); } finally { fs.rmSync(lock, { recursive: true }); }
  }
  assertIdentity(task, state) {
    if (!state || state.revision !== task.revision || state.fingerprint !== task.fingerprint || state.payload_hash !== digest(task.payload)) fail('Task revision/fingerprint/payload changed');
    for (const image of Object.values(state.images)) {
      if (image.asset) this.asset(image.asset);
      if (image.proof) this.asset(image.proof.screenshot);
    }
  }
  claim(snapshot, { task_id, owner }) {
    if (typeof owner !== 'string' || !owner.trim()) fail('Executor owner required');
    return this.exclusive(() => {
      const task = this.current(snapshot, task_id);
      for (const file of fs.readdirSync(this.root).filter(name => /^[a-f0-9]{64}\.json$/.test(name))) {
        const other = JSON.parse(fs.readFileSync(path.join(this.root, file), 'utf8'));
        if (other.task_id !== task_id && other.lease?.expires_at > this.now()) fail('Browser executor already leased to another task');
      }
      const state = this.load(task_id) || { version: 1, task_id, revision: task.revision, fingerprint: task.fingerprint, payload_hash: digest(task.payload), images: {}, events: [] };
      this.assertIdentity(task, state);
      if (state.lease?.expires_at > this.now()) fail('Task already leased');
      state.lease = { owner, token: crypto.randomUUID(), expires_at: this.now() + this.leaseMs };
      state.events.push({ event: 'claimed', at: this.now(), owner });
      this.save(state);
      return { task: clone(task), lease: { task_id, ...state.lease }, checkpoints: clone(state.images), executor_required: 'active_codex_browser_session' };
    });
  }
  mutate(snapshot, lease, fn) {
    return this.exclusive(() => {
      const task = this.current(snapshot, lease.task_id);
      const state = this.load(lease.task_id);
      this.assertIdentity(task, state);
      if (!state.lease || state.lease.token !== lease.token || state.lease.owner !== lease.owner || state.lease.expires_at <= this.now()) fail('Lease expired or owned by another executor');
      const result = fn(task, state);
      this.save(state);
      return result;
    });
  }
  heartbeat(snapshot, lease) {
    return this.mutate(snapshot, lease, (_task, state) => {
      state.lease.expires_at = this.now() + this.leaseMs;
      return { task_id: state.task_id, ...state.lease };
    });
  }
  checkpoint(snapshot, lease, record) {
    return this.mutate(snapshot, lease, (task, state) => {
      const item = task.payload.images.find(i => (i.region || i.name) === record.image_key);
      if (!item || (task.missing_regions && !task.missing_regions.includes(record.image_key))) fail('Image is not requested by current task');
      const previous = state.images[record.image_key] || { status: 'ready' };
      if (record.event === 'generation_started') {
        if (previous.status !== 'ready') fail('Generation already started; observe/reconcile existing Flow result before retry');
        state.images[record.image_key] = { status: 'generation_started', at: this.now() };
      } else if (record.event === 'generation_failed') {
        if (previous.status !== 'generation_started' || record.observation?.outcome !== 'failed' || !/^https:\/\/flow\.google\.com\//.test(record.observation.url || '') || !record.observation.reason) fail('Observed terminal Flow failure required before retry');
        const screenshot = this.asset(record.observation.screenshot);
        state.images[record.image_key] = { status: 'ready', failed_attempt: { ...clone(record.observation), screenshot }, at: this.now() };
      } else if (record.event === 'acquired') {
        if (!['generation_started', 'acquired'].includes(previous.status)) fail('Acquisition requires recorded generation start');
        if (!['flow_download', 'flow_clipboard'].includes(record.acquisition?.method)) fail('Original Flow acquisition evidence required');
        const asset = this.asset(record.asset);
        if (task.payload.output_directory) {
          const rel = path.relative(path.resolve(task.payload.output_directory), asset.path);
          if (rel.startsWith('..') || path.isAbsolute(rel)) fail('Original must stay in task output directory');
        }
        if (previous.asset && previous.asset.sha256 !== asset.sha256) fail('Never replace checkpointed originals; revise task');
        if (record.acquisition.method === 'flow_clipboard' && record.acquisition.copy_confirmed !== true) fail('Clipboard acquisition requires observed Copy confirmation');
        state.images[record.image_key] = { status: 'acquired', asset, acquisition: clone(record.acquisition), at: this.now() };
      } else if (record.event === 'visually_inspected') {
        if (!['acquired', 'visually_inspected'].includes(previous.status)) fail('Inspect acquired original first');
        const proof = record.proof;
        if (proof?.model !== 'Nano Banana Pro' || proof.visually_verified !== true || !/^https:\/\/flow\.google\.com\//.test(proof.url || '') || typeof proof.operator !== 'string' || !proof.operator.trim()) fail('Real operator inspection and Flow UI proof required');
        const checks = task.kind === 'flow_images' ? ['outline', 'artwork', 'colors', 'garment', 'sizes'] : ['outline', 'composition', 'colors', ...(task.kind === 'flow_design_embroidery' ? ['locked_2d', 'tatami_satin'] : [])];
        if (checks.some(key => proof.checks?.[key] !== 'pass')) fail('All visual checks must be explicitly recorded by operator');
        state.images[record.image_key] = { ...previous, status: 'visually_inspected', proof: { ...clone(proof), screenshot: this.asset(proof.screenshot) } };
      } else fail('Unknown checkpoint event');
      state.events.push({ event: record.event, image_key: record.image_key, at: this.now(), owner: lease.owner,
        checkpoint: clone(state.images[record.image_key]) });
      return clone(state.images[record.image_key]);
    });
  }
  prepareAttach(snapshot, lease) {
    return this.mutate(snapshot, lease, (task, state) => {
      const expected = task.payload.images.filter(i => !task.missing_regions || task.missing_regions.includes(i.region));
      if (expected.some(i => state.images[i.region || i.name]?.status !== 'visually_inspected')) fail('Every requested image needs acquisition and real visual inspection');
      const images = expected.map(i => ({ item: i, result: state.images[i.region || i.name] }));
      if (!images.length) fail('No remaining images to attach');
      let command;
      if (task.kind === 'flow_images') {
        if (new Set(images.map(i => i.result.asset.sha256)).size !== 6) fail('Six mockup views must have distinct originals');
        command = { action: 'attach_images', listing_code: task.payload.listing_code, revision: task.revision, task_id: task.id, task_fingerprint: task.fingerprint,
          images: images.map(i => ({ name: i.item.name, ...i.result.asset })),
          proof: { visually_verified: true, images: images.map(i => ({ name: i.item.name, ...i.result.proof, acquisition: i.result.acquisition })) } };
      } else {
        const p = images[0].result.proof;
        command = { action: 'design_attach', brief_id: task.brief_id, revision: task.revision, stage: task.payload.stage, task_id: task.id, task_fingerprint: task.fingerprint,
          assets: Object.fromEntries(images.map(i => [i.item.region, i.result.asset])),
          proof: { visually_verified: true, model: p.model, url: p.url, screenshot_path: p.screenshot.path,
            images: images.map(i => ({ region: i.item.region, ...i.result.proof, acquisition: i.result.acquisition })) } };
      }
      const evidence = images[0].result.proof;
      command = { action: 'flow_attach', task_id: task.id, revision: task.revision, task_fingerprint: task.fingerprint,
        attachment: command,
        proof: { visually_verified: true, model: evidence.model, url: evidence.url, screenshot_path: evidence.screenshot.path,
          images: images.map(i => ({ image_key: i.item.region || i.item.name, ...i.result.proof, acquisition: i.result.acquisition })) } };
      state.attachment = { command_hash: digest(command), command, at: this.now() };
      state.events.push({ event: 'attachment_prepared', at: this.now(), command_hash: state.attachment.command_hash });
      return { ok: true, status: 'attachment_ready_for_n8n', command, command_hash: state.attachment.command_hash };
    });
  }
  release(snapshot, lease) {
    return this.mutate(snapshot, lease, (_task, state) => { state.lease.expires_at = this.now(); return { ok: true, checkpoints_preserved: true }; });
  }
}

module.exports = { FlowCoordinator, digest, hash };
if (require.main === module) {
  try {
    const input = JSON.parse(fs.readFileSync(0, 'utf8').replace(/^\uFEFF/, ''));
    const coordinator = new FlowCoordinator(input.spool_root || 'C:/Huy/etsy-workflow/workspace/flow-worker');
    const handlers = {
      claim: () => coordinator.claim(input.snapshot, input.claim),
      heartbeat: () => coordinator.heartbeat(input.snapshot, input.lease),
      checkpoint: () => coordinator.checkpoint(input.snapshot, input.lease, input.record),
      prepare_attach: () => coordinator.prepareAttach(input.snapshot, input.lease),
      release: () => coordinator.release(input.snapshot, input.lease),
    };
    if (!handlers[input.operation]) fail('Unknown coordinator operation');
    process.stdout.write(JSON.stringify(handlers[input.operation]()));
  } catch (error) { process.stderr.write(JSON.stringify({ ok: false, error: error.message })); process.exitCode = 1; }
}
