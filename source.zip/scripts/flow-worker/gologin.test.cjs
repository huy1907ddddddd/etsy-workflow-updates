'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {settings,endpoint,connect}=require('./gologin.cjs');
const id='6accb27efce399d31d86b8bd',ws='ws://127.0.0.1:29395/devtools/browser/0249c379-8466-4ba4-81ce-921e1e7b7714';
function fixture(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gologin-worker-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const config={stateDir:dir,gologin:{profileId:id,apiUrl:'http://127.0.0.1:36912'}};return {config,file:settings(config).file};}
function save(f,overrides={}){fs.writeFileSync(f.file,JSON.stringify({profile_id:id,api_url:f.config.gologin.apiUrl,ws_url:ws,...overrides}));}
test('GoLogin accepts only the explicitly configured local profile and loopback CDP endpoint',()=>{
 assert.equal(endpoint(ws),ws);
 for(const value of ['ws://evil.test:29395/devtools/browser/a','ws://127.0.0.1:80/devtools/browser/a',ws+'?token=x',ws+'#x',ws.replace('127.0.0.1','user:password@127.0.0.1'),ws.replace('ws:','wss:')])assert.throws(()=>endpoint(value),{code:'flow_gologin_endpoint_invalid'});
 for(const gologin of [{profileId:'../profile',apiUrl:'http://127.0.0.1:36912'},{profileId:id,apiUrl:'https://api.gologin.com'},{profileId:id,apiUrl:'http://evil.test:36912'}])assert.throws(()=>settings({stateDir:'fixture',gologin}),{code:'flow_gologin_config_invalid'});
});
test('existing managed GoLogin connection attaches without a token, launch, or profile mutation',async t=>{
 const f=fixture(t);save(f);const browser={connected:true};let calls=0;
 const result=await connect(f.config,{chromium:{connectOverCDP:async(url,options)=>{assert.equal(url,ws);assert.equal(options.timeout,10000);calls++;return browser;}}},async()=>assert.fail('must not call API'));
 assert.equal(result,browser);assert.equal(calls,1);
});
test('stopped profile starts through local API with the same profile id and returns a new saved connection',async t=>{
 const f=fixture(t);save(f);let attempts=0,apiCalls=0;
 const next=ws.replace('29395','29396');
 const result=await connect(f.config,{chromium:{connectOverCDP:async(url)=>{if(++attempts===1)throw Error('closed');assert.equal(url,next);return 'connected';}}},async(url,options)=>{
  apiCalls++;assert.equal(url,'http://127.0.0.1:36912/browser/start-profile');assert.equal(options.redirect,'error');assert.deepEqual(JSON.parse(options.body),{profileId:id,sync:true});assert.deepEqual(options.headers,{'content-type':'application/json'});
  return {ok:true,json:async()=>({status:'success',wsUrl:next})};
 });
 assert.equal(result,'connected');assert.equal(apiCalls,1);assert.equal(JSON.parse(fs.readFileSync(f.file)).ws_url,next);
});
test('changed cached profile binding is rejected before attachment or API calls',async t=>{
 const f=fixture(t);save(f,{profile_id:'0'.repeat(24)});
 await assert.rejects(connect(f.config,{chromium:{connectOverCDP:async()=>assert.fail()}},async()=>assert.fail()),{code:'flow_gologin_binding_changed'});
});
test('API access errors and remote endpoints are not bypassed or retried',async t=>{
 const f=fixture(t);let calls=0;
 await assert.rejects(connect(f.config,{},async()=>{calls++;return {ok:false,status:403};}),{code:'flow_gologin_profile_start_failed'});assert.equal(calls,1);assert.equal(fs.existsSync(f.file),false);
 await assert.rejects(connect(f.config,{},async()=>({ok:true,json:async()=>({status:'success',wsUrl:'ws://remote.test:29395/devtools/browser/a'})})),{code:'flow_gologin_endpoint_invalid'});
});
test('an unavailable local app blocks cleanly without stopping or altering a profile',async t=>{
 const f=fixture(t);let calls=0;
 await assert.rejects(connect(f.config,{},async(url)=>{calls++;assert.equal(url,'http://127.0.0.1:36912/browser/start-profile');throw Error('offline');}),{code:'flow_gologin_local_api_unavailable'});
 assert.equal(calls,1);assert.equal(fs.existsSync(f.file),false);
});
