'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { PassThrough } = require('node:stream');
const { NativeN8n, executionOutput, atomic, claimProcessLock, waitProcessLock } = require('./native-n8n.cjs');
const data = json => ({ data: { resultData: { lastNodeExecuted: 'Native Result', runData: { 'Native Result': [{ data: { main: [[{ json }]] } }] } } } });
test('extracts native final-node JSON and rejects failed or malformed execution', () => {
  assert.deepEqual(executionOutput('Startup notice\n' + JSON.stringify(data({ ok: true, title: 'Áo thêu' }))), { ok: true, title: 'Áo thêu' });
  for (const bad of ['not JSON', JSON.stringify({}), JSON.stringify(data({ ok: false })), JSON.stringify({ data: { resultData: { error: { message: 'failed' } } } })]) assert.throws(() => executionOutput(bad));
});
test('native uses official CLI, separate broker, private log and preserved Unicode', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-native-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const config = { stateDir: root, logDir: path.join(root, 'private-logs'), commandFile: path.join(root, 'command.json'), mainWorkflowId: 'main', cycleWorkflowId: 'cycle', n8nCli: 'official-n8n.js', workflowRoot: root, brokerPort: 5689, nativeTimeoutMs: 1000 };
  let args, options;
  const runner = new NativeN8n(config, { spawn: (_exe, commandArgs, commandOptions) => {
    args = commandArgs; options = commandOptions;
    const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.kill = () => {};
    setImmediate(() => { const bytes = Buffer.from(JSON.stringify(data({ ok: true, title: 'Áo thêu' }))); for (const byte of bytes) child.stdout.write(Buffer.from([byte])); child.stdout.end(); child.emit('close', 0); });
    return child;
  } });
  const command = { action: 'flow_auto_submit', task_id: 'only-image' };
  assert.equal((await runner.execute(command)).title, 'Áo thêu');
  assert.deepEqual(args, ['official-n8n.js', 'execute', '--id=main', '--rawOutput']);
  assert.equal(options.env.N8N_RUNNERS_BROKER_PORT, '5689'); assert.equal(options.windowsHide, true);
  assert.deepEqual(JSON.parse(fs.readFileSync(config.commandFile)), command);
  assert.equal(fs.readdirSync(config.logDir).length, 2); assert.equal(fs.existsSync(path.join(root, 'native-execution.lock')), false);
});

test('nonzero n8n preserves a typed Codex quota through nested HTTP errors and trailing CLI text', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-quota-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const config = { workflowRoot: root, stateDir: root, logDir: path.join(root, 'logs'), n8nCli: 'fixture.js', brokerPort: 5689, nativeTimeoutMs: 1000 };
  for (const [description, expected] of [['codex_usage_limit_exceeded', 'codex_usage_limit_exceeded'], ['Worker did not complete a text-only turn','codex_text_turn_invalid'], ['Bad gateway', 'n8n_native_failed_check_private_log']]) {
    const runner = new NativeN8n(config, { spawn: () => {
      const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.kill = () => {};
      setImmediate(() => { child.stdout.write(JSON.stringify({ data: { resultData: { error: { description } } } }) + '\nError executing workflow.'); child.emit('close', 1); });
      return child;
    } });
    await assert.rejects(runner.run('main'), { message: expected });
  }
  assert.throws(() => executionOutput(JSON.stringify({ data: { resultData: { error: { description: 'codex_usage_limit_exceeded' } } } })), /codex_usage_limit_exceeded/);
});
test('durable atomic JSON and lock do not overwrite live owner', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-lock-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const file = path.join(root, 'state.json'); atomic(file, { revision: 1 }); atomic(file, { revision: 2 }); assert.equal(JSON.parse(fs.readFileSync(file)).revision, 2);
  const lock = path.join(root, 'owner.lock'); const release = claimProcessLock(lock); assert.throws(() => claimProcessLock(lock), /already_running/); release(); assert.equal(fs.existsSync(lock), false);
});

test('a contender never reads an empty lock while another process publishes its owner',t=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'n8n-publish-race-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const file=path.join(root,'owner.lock'),write=fs.writeFileSync,link=fs.linkSync;let observed;
 const inspect=()=>{try{claimProcessLock(file);}catch(error){observed=error.message;}};
 fs.writeFileSync=function(target,value,options){
  if(target===file&&options?.flag==='wx'){
   const fd=fs.openSync(target,'wx',options.mode);try{inspect();write(fd,value);}finally{fs.closeSync(fd);}return;
  }
  return write.apply(this,arguments);
 };
 fs.linkSync=function(source,target){const result=link.apply(this,arguments);if(target===file)inspect();return result;};
 let release;
 try{release=claimProcessLock(file);assert.equal(observed,'worker_already_running');assert.equal(JSON.parse(fs.readFileSync(file)).pid,process.pid);}
 finally{fs.writeFileSync=write;fs.linkSync=link;release?.();}
});

test('a malformed existing lock stays intact and still requires review',t=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'n8n-malformed-lock-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const file=path.join(root,'owner.lock');fs.writeFileSync(file,'{"pid":');
 assert.throws(()=>claimProcessLock(file),/process_lock_needs_review/);assert.equal(fs.readFileSync(file,'utf8'),'{"pid":');
 assert.deepEqual(fs.readdirSync(root),['owner.lock']);
});

test('four real processes contend repeatedly without malformed locks or overlapping native owners',async t=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'n8n-real-contention-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const {execFile}=require('node:child_process'),{promisify}=require('node:util');
 const script=`const fs=require('node:fs'),path=require('node:path');const {waitProcessLock}=require(process.argv[1]);
 (async()=>{const root=process.argv[2];for(let i=0;i<15;i++){const release=await waitProcessLock(path.join(root,'native.lock'),10000);
 try{fs.writeFileSync(path.join(root,'critical'),String(process.pid),{flag:'wx'});await new Promise(r=>setTimeout(r,1));fs.unlinkSync(path.join(root,'critical'));}finally{release();}}
 console.log('15');})().catch(e=>{console.error(e.message);process.exitCode=1;});`;
 const results=await Promise.all(Array.from({length:4},()=>promisify(execFile)(process.execPath,['-e',script,path.join(__dirname,'native-n8n.cjs'),root],{windowsHide:true,timeout:20000})));
 assert(results.every(r=>r.stdout.trim()==='15'&&!r.stderr));assert.deepEqual(fs.readdirSync(root),[]);
});
test('Flow and KPI share command-file lock even with independent state directories', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-shared-lock-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const config = { workflowRoot: root, stateDir: path.join(root, 'kpi-state'), commandFile: path.join(root, 'command.json'), nativeLockTimeoutMs: 25 };
  const release = claimProcessLock(path.join(root, 'workspace/flow-worker/runtime/native-execution.lock'), 'flow');
  t.after(release);
  const runner = new NativeN8n(config, { spawn: () => { throw Error('must not spawn while Flow owns shared lock'); } });
  await assert.rejects(runner.execute({ action: 'kpi_sync_verified' }), /native_execution_busy/);
  assert.equal(fs.existsSync(config.commandFile), false);
});
test('native lock waits for release condition and stop cancels waiting', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-condition-lock-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const file = path.join(root, 'native.lock');
  const owner = claimProcessLock(file);
  const waiting = waitProcessLock(file, 1000);
  owner();
  const release = await waiting;
  assert.throws(() => claimProcessLock(file), /already_running/);
  release();
  const secondOwner = claimProcessLock(file); t.after(secondOwner);
  const abort = new AbortController();
  const canceled = waitProcessLock(file, 1000, abort.signal); abort.abort();
  await assert.rejects(canceled, /native_execution_stopped/);
});

test('long production command uses its own timeout and still releases the shared lock', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-production-budget-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const config = { workflowRoot: root, logDir: path.join(root, 'logs'), commandFile: path.join(root, 'command.json'), mainWorkflowId: 'main', nativeTimeoutMs: 10 };
  let killed = false;
  const runner = new NativeN8n(config, { spawn: () => {
    const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.kill = () => { killed = true; child.emit('close', null); };
    setTimeout(() => { child.stdout.write(JSON.stringify(data({ ok: true }))); child.emit('close', 0); }, 40);
    return child;
  } });
  assert.equal((await runner.execute({ action: 'advance' }, { timeoutMs: 1000 })).ok, true);
  assert.equal(killed, false);
  assert.equal(fs.existsSync(path.join(root, 'workspace/flow-worker/runtime/native-execution.lock')), false);
});

test('expired execution reports timeout after child closes and releases the lock', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'n8n-timeout-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runner = new NativeN8n({ workflowRoot: root, logDir: path.join(root, 'logs'), commandFile: path.join(root, 'command.json'), nativeTimeoutMs: 10 }, { spawn: () => {
    const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.kill = () => setImmediate(() => child.emit('close', null)); return child;
  } });
  await assert.rejects(runner.execute({ action: 'advance' }), /native_execution_timeout/);
  assert.equal(fs.existsSync(path.join(root, 'workspace/flow-worker/runtime/native-execution.lock')), false);
});

test('lane cycle uses Main with its exact current lease and retains shared command lock',async t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'n8n-lane-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const stateDir=path.join(root,'lane2');fs.mkdirSync(stateDir);
  fs.writeFileSync(path.join(stateDir,'image-provider.json'),JSON.stringify({batch_id:'batch-own'}));
  const config={workflowRoot:root,stateDir,workerLane:2,commandFile:path.join(root,'command.json'),mainWorkflowId:'main',cycleWorkflowId:'cycle',nativeTimeoutMs:1000};
  const runner=new NativeN8n(config);let workflow;
  runner.run=async id=>{workflow=id;assert.ok(fs.existsSync(path.join(root,'workspace/flow-worker/runtime/native-execution.lock')));return{ok:true};};
  await runner.cycle();assert.equal(workflow,'main');
  assert.deepEqual(JSON.parse(fs.readFileSync(config.commandFile)),{action:'flow_cycle',worker_lane:2,worker_lane_batch_id:'batch-own'});
  fs.writeFileSync(path.join(stateDir,'image-provider.json'),JSON.stringify({batch_id:null}));
  await runner.cycle();assert.equal(JSON.parse(fs.readFileSync(config.commandFile)).worker_lane_batch_id,undefined);
});
