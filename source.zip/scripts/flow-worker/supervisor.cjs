'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { atomic, claimProcessLock } = require('./native-n8n.cjs');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
function alive(pid) { if (!Number.isInteger(pid) || pid < 1) return false; try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; } }
class Supervisor {
  constructor(config, deps = {}) {
    this.config = config; this.spawn = deps.spawn || spawn; this.now = deps.now || Date.now;
    this.alive = deps.alive || alive; this.probe = deps.probe || this.httpProbe.bind(this); this.notify = deps.notify || this.httpNotify.bind(this);
    this.config.kpiConfigFile ||= path.join(config.workflowRoot, 'config/kpi-worker.private.json');
    const kpi = fs.existsSync(this.config.kpiConfigFile) ? read(this.config.kpiConfigFile) : {};
    this.config.kpiStateDir = kpi.stateDir || path.join(config.workflowRoot, 'workspace/kpi-worker/runtime');
    this.config.batchStateDir = path.join(config.workflowRoot, 'workspace/batch-worker/runtime');
    const relative = path.relative(path.resolve(config.workflowRoot, 'workspace/kpi-worker'), path.resolve(this.config.kpiStateDir));
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw Error('kpi_dedicated_directory_required');
    this.records = { bot: { crashes: 0, next: 0 }, worker: { crashes: 0, next: 0 }, kpi: { crashes: 0, next: 0 }, batch: { crashes: 0, next: 0 } };
    this.stopping = false; this.notice = null;
  }
  async httpProbe(kind) {
    const lark = read(this.config.larkConfigFile);
    const url = kind === 'n8n' ? 'http://127.0.0.1:5678/healthz' : 'http://127.0.0.1:8790/outbox';
    try {
      const response = await fetch(url, { headers: kind === 'bot' ? { 'x-review-token': lark.localToken } : {}, signal: AbortSignal.timeout(5000), redirect: 'error' });
      if (!response.ok) return false;
      return kind === 'n8n' || (await response.json()).ok === true;
    } catch { return false; }
  }
  botConfigFile(){return require('../review-transport.cjs').configFile(this.config.workflowRoot,this.config.larkConfigFile);}
  botPid(){const file=read(this.botConfigFile()).stateFile+'.lock';if(!fs.existsSync(file))return null;const raw=fs.readFileSync(file,'utf8');try{const value=JSON.parse(raw);return typeof value==='object'?value.pid:Number(value);}catch{return Number(raw);}}
  async httpNotify(code, status = 'blocked') {
      const config = read(this.config.larkConfigFile);
      const response = await fetch('http://127.0.0.1:8790/worker-status', { method: 'POST', headers: { 'content-type': 'application/json', 'x-review-token': config.localToken },
        body: JSON.stringify({ status, code, message: 'Bộ chạy Flow và KPI: ' + code + '. Checkpoint được giữ để tiếp tục.' }), signal: AbortSignal.timeout(5000), redirect: 'error' });
      if (!response.ok) throw Error('supervisor_notification_pending');
  }
  status(code) {
    const services = Object.fromEntries(Object.entries(this.records).map(([name, r]) => [name, { pid: r.child?.pid || r.reusedPid || null, ownership: r.child ? 'owned' : r.reused ? 'reused' : 'none', crashes: r.crashes, next_restart_at: r.next || null, status: r.status || 'not_started' }]));
    const result = { version: 1, pid: process.pid, status: code, services, updated_at: new Date(this.now()).toISOString() };
    atomic(path.join(this.config.stateDir, 'supervisor-status.json'), result); return result;
  }
  async noticeOnce(code, status = 'blocked') { if (this.notice === code) return; try { await this.notify(code, status); this.notice = code; } catch { /* Retry the same notification next tick. */ } }
  externalWorker(kind = 'worker') {
    const poolFile=path.join(this.config.workflowRoot,'config/flow-worker-pool.private.json'),pooled=kind==='worker'&&fs.existsSync(poolFile)&&read(poolFile).enabled===true;
    const file = path.join(kind === 'kpi' ? this.config.kpiStateDir : kind === 'batch' ? this.config.batchStateDir : this.config.stateDir, pooled?'pool-supervisor.lock':'worker.lock');
    if (!fs.existsSync(file)) return null;
    let lock; try { lock = read(file); } catch { throw Error('worker_lock_needs_review'); }
    if (lock.identity !== (kind === 'kpi' ? 'kpi-worker' : kind === 'batch' ? 'batch-worker' : pooled?'flow-pool':'flow-worker') || !Number.isInteger(lock.pid)) throw Error('worker_lock_needs_review');
    return this.alive(lock.pid) ? lock.pid : null;
  }
  launch(kind) {
    const record = this.records[kind];
    const poolFile=path.join(this.config.workflowRoot,'config/flow-worker-pool.private.json'),pooled=kind==='worker'&&fs.existsSync(poolFile)&&read(poolFile).enabled===true;
    const botFile=this.botConfigFile(),provider=require('../review-transport.cjs').choice(this.config.workflowRoot).provider;
    const stopFile = kind === 'bot' ? read(botFile).stateFile + '.stop.request' : path.join(kind === 'kpi' ? this.config.kpiStateDir : kind === 'batch' ? this.config.batchStateDir : this.config.stateDir, pooled?'pool.stop.request':'stop.request');
    if (fs.existsSync(stopFile)) fs.unlinkSync(stopFile);
    fs.mkdirSync(this.config.logDir, { recursive: true });
    const prefix = path.join(this.config.logDir, 'supervisor-' + kind + '-' + this.now());
    const stdout = fs.openSync(prefix + '.stdout.private.log', 'a', 0o600), stderr = fs.openSync(prefix + '.stderr.private.log', 'a', 0o600);
    const script = path.join(this.config.workflowRoot, 'scripts', kind === 'bot' ? (['telegram','web'].includes(provider)?provider+'-review/service.cjs':'lark-review/service.cjs') : kind === 'kpi' ? 'kpi-worker/runtime.cjs' : kind === 'batch' ? 'batch-worker/runtime.cjs' : pooled?'flow-worker/pool.cjs':'flow-worker/runtime.cjs');
    let child;
    try {
      child = this.spawn(process.execPath, [script], { cwd: this.config.workflowRoot, windowsHide: true,
        env: { ...process.env, LARK_REVIEW_CONFIG: this.config.larkConfigFile, TELEGRAM_REVIEW_CONFIG:botFile, WEB_REVIEW_CONFIG:botFile, FLOW_WORKER_CONFIG: this.config.workerConfigFile, KPI_WORKER_CONFIG: this.config.kpiConfigFile }, stdio: ['ignore', stdout, stderr] });
    } finally { fs.closeSync(stdout); fs.closeSync(stderr); }
    record.child = child; record.reused = false; record.status = 'starting'; record.started = this.now(); record.stopFile = stopFile;
    let handled = false;
    const exited = () => {
      if (handled) return; handled = true;
      if (record.child !== child) return;
      record.child = null;
      if (this.stopping) { record.status = 'stopped'; return; }
      if (this.now() - record.started >= 60000) record.crashes = 0;
      record.crashes++; record.next = this.now() + Math.min(60000, 2000 * 2 ** Math.min(record.crashes - 1, 5));
      record.status = record.crashes > 6 ? 'restart_limit' : 'restart_pending';
    };
    child.once('exit', exited); child.once('error', exited);
  }
  async tick() {
    if (this.stopping || fs.existsSync(path.join(this.config.stateDir, 'supervisor.stop.request'))) return this.stop();
    const bot = this.records.bot;
    const botReady = await this.probe('bot');
    if (!bot.child && botReady) {
      const pid = this.botPid();
      bot.reused = true; bot.reusedPid = this.alive(pid) ? pid : null; bot.status = 'running';
    }
    else if (!bot.child && !botReady && bot.crashes <= 6 && this.now() >= bot.next) {
      // An occupied, unhealthy bot is left for its owner; never launch over it.
      const lockFile = read(this.botConfigFile()).stateFile + '.lock';
      const lockPid = this.botPid();
      if (fs.existsSync(lockFile) && (!Number.isInteger(lockPid) || lockPid < 1)) throw Error('lark_lock_needs_review');
      if (this.alive(lockPid)) { bot.reused = true; bot.reusedPid = lockPid; bot.status = 'unhealthy_external'; }
      else this.launch('bot');
    }
    if (bot.child && botReady) bot.status = 'running';
    const n8nReady = await this.probe('n8n');
    for (const kind of ['worker', 'kpi', 'batch']) {
      const worker = this.records[kind];
      if (worker.child) worker.status = 'running';
      else {
        const external = this.externalWorker(kind);
        if (external) { worker.reused = true; worker.reusedPid = external; worker.status = 'running'; }
        else { worker.reused = false; worker.reusedPid = null;
          if (botReady && n8nReady && worker.crashes <= 6 && this.now() >= worker.next) this.launch(kind);
        }
      }
    }
    const code = Object.values(this.records).some(record => record.crashes > 6) ? 'supervisor_restart_limit' : !botReady ? 'lark_service_unavailable' : !n8nReady ? 'n8n_unavailable'
      : this.records.worker.status === 'restart_pending' ? 'flow_worker_restart_pending' : this.records.kpi.status === 'restart_pending' ? 'kpi_worker_restart_pending' : 'running';
    if (code !== 'running') await this.noticeOnce(code); else if (this.notice) { await this.noticeOnce('supervisor_recovered', 'recovered'); this.notice = null; }
    return this.status(code);
  }
  async stop() {
    this.stopping = true;
    for (const record of Object.values(this.records)) if (record.child && !record.stopSent) {
      fs.mkdirSync(path.dirname(record.stopFile), { recursive: true }); fs.writeFileSync(record.stopFile, new Date(this.now()).toISOString()); record.stopSent = true; record.status = 'stopping';
    }
    const pending = Object.values(this.records).some(record => record.child);
    return this.status(pending ? 'stopping' : 'stopped');
  }
}
async function main() {
  const workerConfigFile = process.env.FLOW_WORKER_CONFIG || 'C:/Huy/etsy-workflow/config/flow-worker.private.json';
  const worker = read(workerConfigFile), root = path.resolve(worker.workflowRoot);
  const expected = path.join(root, 'workspace/flow-worker');
  const relative = path.relative(expected, path.resolve(worker.stateDir));
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw Error('supervisor_state_directory_invalid');
  const config = { ...worker, workerConfigFile, workflowRoot: root, larkConfigFile: worker.larkConfigFile || path.join(root, 'config/lark-review.private.json') };
  fs.mkdirSync(config.stateDir, { recursive: true });
  const release = claimProcessLock(path.join(config.stateDir, 'supervisor.lock'), 'flow-supervisor');
  const stopFile = path.join(config.stateDir, 'supervisor.stop.request'); if (fs.existsSync(stopFile)) fs.unlinkSync(stopFile);
  const supervisor = new Supervisor(config);
  process.once('SIGINT', () => { supervisor.stopping = true; }); process.once('SIGTERM', () => { supervisor.stopping = true; });
  try {
    while (true) {
      const status = await supervisor.tick(); if (status.status === 'stopped') break;
      await new Promise(resolve => { const timer = setTimeout(done, 2000); const watcher = fs.watch(config.stateDir, (_event, filename) => { if (String(filename) === 'supervisor.stop.request') done(); });
        function done() { clearTimeout(timer); watcher.close(); resolve(); } });
    }
  } catch (error) {
    await supervisor.noticeOnce('supervisor_failed');
    // Wait for owned children to close gracefully; do not abandon or kill them.
    while ((await supervisor.stop()).status !== 'stopped') await new Promise(resolve => setTimeout(resolve, 1000));
    throw error;
  } finally { release(); }
}
if (require.main === module) main().catch(() => { console.error(JSON.stringify({ ok: false, code: 'supervisor_failed' })); process.exitCode = 1; });
module.exports = { Supervisor, alive };
