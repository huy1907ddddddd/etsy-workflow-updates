'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { FlowCoordinator, hash, digest } = require('./coordinator.cjs');

function fixture(t, kind = 'flow_design_2d') {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-coordinator-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  let now = 1000000;
  const make = (name, bytes) => { const file = path.join(root, name); fs.writeFileSync(file, bytes); return { path: file, sha256: hash(bytes) }; };
  const reference = make('reference.png', 'locked-reference');
  const screenshot = make('flow-proof.png', 'test-evidence-only-not-production');
  const p = { provider: 'Flow Nano Banana Pro', executor: 'codex_browser_session', revision: 1, brief_id: 'TEST', stage: '2d', output_directory: root,
    images: [{ region: 'chest', name: 'chest.png', prompt: 'BRIEF\nNO OUTLINE', references: [reference] }] };
  if (kind === 'flow_design_embroidery') { p.stage = 'embroidery'; p.images[0].references[0].role = 'exact_locked_2d'; }
  if (kind === 'flow_images') {
    delete p.brief_id; delete p.stage; p.listing_code = 'ANM_261015_01_PILOT'; p.references = { chest: reference };
    p.images = Array.from({ length: 6 }, (_, index) => ({ name: String(index) + '.jpg', prompt: 'MOCKUP\nNO OUTLINE' }));
  }
  const task = { id: 'test-task', kind, brief_id: kind === 'flow_images' ? undefined : 'TEST', code: p.listing_code, revision: 1, status: 'pending', payload: p, fingerprint: digest(p) };
  const config = { allowedRoots: [root], outlineRule: 'NO OUTLINE', now: () => now, leaseMs: 1000 };
  const worker = new FlowCoordinator(path.join(root, 'spool'), config);
  const snapshot = () => ({ ok: true, observed_at: new Date(now).toISOString(), tasks: [task] });
  const claim = () => worker.claim(snapshot(), { task_id: task.id, owner: 'active-test-session' });
  const key = item => item.region || item.name;
  const inspect = (lease, item, index = 0) => {
    worker.checkpoint(snapshot(), lease, { image_key: key(item), event: 'generation_started' });
    worker.checkpoint(snapshot(), lease, { image_key: key(item), event: 'acquired', asset: make('output-' + index + '.png', 'unique-output-' + index), acquisition: { method: 'flow_download', generation_id: 'fixture-' + index } });
    return worker.checkpoint(snapshot(), lease, { image_key: key(item), event: 'visually_inspected', proof: {
      model: 'Nano Banana Pro', url: 'https://flow.google.com/project/test', operator: 'test-fixture-only', visually_verified: true, screenshot,
      checks: Object.fromEntries(['outline', 'composition', 'colors', 'artwork', 'garment', 'sizes', 'locked_2d', 'tatami_satin'].map(name => [name, 'pass'])) } });
  };
  return { root, config, worker, task, make, reference, screenshot, snapshot, claim, inspect, advance: delta => { now += delta; } };
}

test('design packet prepares attachment without any production mutation', t => {
  const f = fixture(t); const { lease } = f.claim();
  f.inspect(lease, f.task.payload.images[0]);
  const result = f.worker.prepareAttach(f.snapshot(), lease);
  assert.equal(result.command.action, 'flow_attach');
  assert.equal(result.command.attachment.action, 'design_attach');
  assert.equal(result.command.task_fingerprint, f.task.fingerprint);
  assert.equal(result.command.proof.visually_verified, true);
  assert.equal(result.command.attachment.assets.chest.sha256, hash('unique-output-0'));
  assert.equal(f.task.status, 'pending');
});
test('rejects missing, superseded, stale and future queue snapshots', t => {
  const f = fixture(t);
  for (const bad of [{ ...f.snapshot(), tasks: [] }, { ...f.snapshot(), observed_at: new Date(0).toISOString() }, { ...f.snapshot(), observed_at: new Date(9000000).toISOString() }]) {
    assert.throws(() => f.worker.claim(bad, { task_id: f.task.id, owner: 'worker' }));
  }
  f.task.status = 'superseded'; assert.throws(f.claim, /pending/);
});
test('rejects changed revision, fingerprint and mutated payload', t => {
  for (const field of ['revision', 'fingerprint', 'payload']) {
    const f = fixture(t); const { lease } = f.claim();
    if (field === 'revision') { f.task.revision = 2; f.task.payload.revision = 2; }
    if (field === 'fingerprint') f.task.fingerprint = 'a'.repeat(64);
    if (field === 'payload') f.task.payload.images[0].prompt = 'CHANGED\nNO OUTLINE';
    assert.throws(() => f.worker.heartbeat(f.snapshot(), lease), /changed/);
  }
});
test('rejects wrong locked input hash before claim and before subsequent work', t => {
  const f = fixture(t); const { lease } = f.claim();
  fs.writeFileSync(f.reference.path, 'changed-reference');
  assert.throws(() => f.worker.heartbeat(f.snapshot(), lease), /SHA256/);
  f.advance(1001); assert.throws(f.claim, /SHA256/);
});
test('requires exact approved 2D reference and current outline suffix', t => {
  const f = fixture(t, 'flow_design_embroidery');
  delete f.task.payload.images[0].references[0].role; assert.throws(f.claim, /locked 2D/);
  f.task.payload.images[0].references[0].role = 'exact_locked_2d';
  f.task.payload.images[0].prompt += '\nOTHER REQUIREMENT'; assert.throws(f.claim, /outline/);
});
test('single browser lease blocks a duplicate and a different task', t => {
  const f = fixture(t); f.claim(); assert.throws(f.claim, /leased/);
  const second = { ...f.task, id: 'other-task' };
  assert.throws(() => f.worker.claim({ ...f.snapshot(), tasks: [second] }, { task_id: second.id, owner: 'other-worker' }), /another task/);
});
test('TTL and heartbeat prevent old owner writes after reclaim', t => {
  const f = fixture(t); const old = f.claim(); f.advance(501);
  const renewed = f.worker.heartbeat(f.snapshot(), old.lease); assert.equal(renewed.expires_at, 1001501);
  f.advance(1001); const current = f.claim();
  assert.notEqual(current.lease.token, old.lease.token);
  assert.throws(() => f.worker.heartbeat(f.snapshot(), old.lease), /Lease/);
});
test('crash after starting generation resumes by acquisition, never blind regeneration', t => {
  const f = fixture(t); const first = f.claim();
  f.worker.checkpoint(f.snapshot(), first.lease, { image_key: 'chest', event: 'generation_started' });
  f.advance(1001);
  const restarted = new FlowCoordinator(path.join(f.root, 'spool'), f.config);
  const next = restarted.claim(f.snapshot(), { task_id: f.task.id, owner: 'resumed-session' });
  assert.equal(next.checkpoints.chest.status, 'generation_started');
  assert.throws(() => restarted.checkpoint(f.snapshot(), next.lease, { image_key: 'chest', event: 'generation_started' }), /reconcile/);
  const asset = f.make('recovered.png', 'actual-existing-result');
  restarted.checkpoint(f.snapshot(), next.lease, { image_key: 'chest', event: 'acquired', asset, acquisition: { method: 'flow_download' } });
  assert.equal(restarted.load(f.task.id).images.chest.asset.sha256, asset.sha256);
});
test('acquired originals survive lease release and retry unchanged', t => {
  const f = fixture(t); const first = f.claim(); f.inspect(first.lease, f.task.payload.images[0]);
  const before = f.worker.prepareAttach(f.snapshot(), first.lease);
  f.worker.release(f.snapshot(), first.lease);
  const next = f.claim(); assert.equal(next.checkpoints.chest.status, 'visually_inspected');
  assert.equal(f.worker.prepareAttach(f.snapshot(), next.lease).command_hash, before.command_hash);
});
test('modified output or screenshot invalidates retry', t => {
  for (const name of ['output-0.png', 'flow-proof.png']) {
    const f = fixture(t); const { lease } = f.claim(); f.inspect(lease, f.task.payload.images[0]);
    fs.writeFileSync(path.join(f.root, name), 'tampered');
    assert.throws(() => f.worker.prepareAttach(f.snapshot(), lease), /SHA256/);
  }
});
test('operator evidence required; generated fixture cannot self approve', t => {
  const f = fixture(t); const { lease } = f.claim();
  assert.throws(() => f.worker.prepareAttach(f.snapshot(), lease), /visual/);
  f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'generation_started' });
  assert.throws(() => f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'acquired', asset: f.reference, acquisition: { method: 'screenshot' } }), /Original/);
  assert.throws(() => f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'acquired', asset: f.reference, acquisition: { method: 'flow_clipboard' } }), /Copy/);
  f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'acquired', asset: f.reference, acquisition: { method: 'flow_download' } });
  assert.throws(() => f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'visually_inspected', proof: { visually_verified: true } }), /operator/);
});
test('only observed terminal failure permits a generation retry', t => {
  const f = fixture(t); const { lease } = f.claim();
  f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'generation_started' });
  assert.throws(() => f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'generation_failed', observation: { outcome: 'unknown' } }), /terminal/);
  f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'generation_failed', observation: { outcome: 'failed', url: 'https://flow.google.com/project/test', reason: 'Observed failure message', screenshot: f.screenshot } });
  assert.equal(f.worker.checkpoint(f.snapshot(), lease, { image_key: 'chest', event: 'generation_started' }).status, 'generation_started');
});
test('mockup packet requires six distinct inspected originals in exact order', t => {
  const f = fixture(t, 'flow_images'); const { lease } = f.claim();
  f.task.payload.images.forEach((item, index) => f.inspect(lease, item, index));
  const result = f.worker.prepareAttach(f.snapshot(), lease);
  assert.equal(result.command.action, 'flow_attach');
  assert.equal(result.command.attachment.action, 'attach_images');
  assert.deepEqual(result.command.attachment.images.map(i => i.name), f.task.payload.images.map(i => i.name));
  assert.equal(new Set(result.command.attachment.images.map(i => i.sha256)).size, 6);
});
test('completed regions are excluded from new attachment after partial engine progress', t => {
  const f = fixture(t); f.task.payload.images.push({ ...f.task.payload.images[0], region: 'left_sleeve', name: 'left_sleeve.png' });
  const { lease } = f.claim(); f.inspect(lease, f.task.payload.images[0]); f.inspect(lease, f.task.payload.images[1], 1);
  f.task.missing_regions = ['left_sleeve'];
  const prepared = f.worker.prepareAttach(f.snapshot(), lease);
  assert.deepEqual(Object.keys(prepared.command.attachment.assets), ['left_sleeve']);
});
test('path scope rejects assets outside authorized workspace', t => {
  const f = fixture(t);
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-outside-'));
  t.after(() => fs.rmSync(outside, { recursive: true, force: true }));
  fs.writeFileSync(path.join(outside, 'ref'), 'data');
  f.task.payload.images[0].references = [{ path: path.join(outside, 'ref'), sha256: hash('data') }];
  assert.throws(f.claim, /outside/);
});
test('process crash mutation lock is recovered without destroying checkpoints', t => {
  const f = fixture(t);
  const script = `const {FlowCoordinator}=require(process.argv[1]); const w=new FlowCoordinator(process.argv[2],{allowedRoots:[process.argv[3]],outlineRule:'NO OUTLINE'}); w.exclusive(()=>process.exit(9));`;
  const child = spawnSync(process.execPath, ['-e', script, path.join(__dirname, 'coordinator.cjs'), path.join(f.root, 'spool'), f.root]);
  assert.equal(child.status, 9);
  assert.equal(f.claim().task.id, f.task.id);
});
