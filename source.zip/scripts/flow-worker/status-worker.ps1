$ErrorActionPreference = 'Stop'
$flowConfig = Get-Content -LiteralPath 'C:\Huy\etsy-workflow\config\flow-worker.private.json' -Raw | ConvertFrom-Json
$flowStatusPath = Join-Path $flowConfig.stateDir 'status.json'
if (Test-Path -LiteralPath $flowStatusPath) { Get-Content -LiteralPath $flowStatusPath -Raw }
else { '{"status":"not_started"}' }
