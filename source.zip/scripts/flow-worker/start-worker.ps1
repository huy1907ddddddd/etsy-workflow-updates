param([switch]$Check, [switch]$Login, [switch]$Once)
$ErrorActionPreference = 'Stop'
$flowWorkerRoot = 'C:\Huy\etsy-workflow'
$flowConfigPath = Join-Path $flowWorkerRoot 'config\flow-worker.private.json'
if (!(Test-Path -LiteralPath $flowConfigPath)) { throw 'Flow worker config missing. Prepare config before launch.' }
$flowConfig = Get-Content -LiteralPath $flowConfigPath -Raw | ConvertFrom-Json
$flowState = [IO.Path]::GetFullPath($flowConfig.stateDir)
$flowProfile = [IO.Path]::GetFullPath($flowConfig.profileDir)
$flowDedicatedRoot = [IO.Path]::GetFullPath((Join-Path $flowWorkerRoot 'workspace\flow-worker')) + [IO.Path]::DirectorySeparatorChar
foreach ($flowDirectory in @($flowState,$flowProfile)) {
    if (!$flowDirectory.StartsWith($flowDedicatedRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Worker state/profile must stay inside the dedicated directory.' }
}
$flowLock = Join-Path $flowState 'worker.lock'
if (Test-Path -LiteralPath $flowLock) {
    $flowOwner = Get-Content -LiteralPath $flowLock -Raw | ConvertFrom-Json
    if (Get-Process -Id $flowOwner.pid -ErrorAction SilentlyContinue) { throw 'Worker already running. Use status-worker.ps1; do not start twice.' }
}
New-Item -ItemType Directory -Path $flowState -Force | Out-Null
if ($Login) {
    if (Test-Path -LiteralPath (Join-Path $flowProfile 'SingletonLock')) { throw 'Worker Chrome profile is already open. Close only that browser before login.' }
    $flowChromeCandidates = @('C:\Program Files\Google\Chrome\Application\chrome.exe','C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',(Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'))
    $flowChrome = $flowChromeCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if (!$flowChrome) { throw 'Official Google Chrome not found.' }
    New-Item -ItemType Directory -Path $flowProfile -Force | Out-Null
    $flowUrl = if ($flowConfig.projectUrl) { $flowConfig.projectUrl } else { 'https://flow.google.com/' }
    Start-Process -FilePath $flowChrome -ArgumentList @('--user-data-dir="'+$flowProfile+'"','--no-first-run','--new-window',$flowUrl) -Wait
    Write-Output 'Close all windows of this dedicated Chrome profile after completing your login, then start the worker. No credentials were copied.'
    exit 0
}
$flowStop = Join-Path $flowState 'stop.request'
if (Test-Path -LiteralPath $flowStop) { Remove-Item -LiteralPath $flowStop }
$flowRuntime = Join-Path $PSScriptRoot 'runtime.cjs'
$flowNode = (Get-Command node -ErrorAction Stop).Source
if ($Check -or $Once) {
    $flowMode = if ($Check) { '--check' } else { '--once' }
    & $flowNode $flowRuntime $flowMode
    exit $LASTEXITCODE
}
$flowLogRoot = Join-Path $flowWorkerRoot ('logs\flow-worker-startup-'+[DateTimeOffset]::UtcNow.ToString('yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $flowLogRoot -Force | Out-Null
$flowProcess = Start-Process -FilePath $flowNode -ArgumentList @('"'+$flowRuntime+'"') -WorkingDirectory $flowWorkerRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $flowLogRoot 'worker.stdout.private.log') -RedirectStandardError (Join-Path $flowLogRoot 'worker.stderr.private.log') -PassThru
[pscustomobject]@{Started=$true;PID=$flowProcess.Id;StatusFile=(Join-Path $flowState 'status.json');Logs=$flowLogRoot} | ConvertTo-Json -Compress
