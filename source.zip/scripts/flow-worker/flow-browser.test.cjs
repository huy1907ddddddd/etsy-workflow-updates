'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { FlowBrowser, official, hash, imageIdentity, diagnosticUrl } = require('./flow-browser.cjs');
const project = 'https://flow.google.com/project/test-isolated';
test('reference identity resolves proxy thumbnails to the exact public media ID across result views',async t=>{
  const f=fixture(t),id='28fa3f7b-7344-4b47-9e5d-acee4366e984',direct='https://flow-content.google/image/'+id;
  const proxy='https://flow.google.com/asb/rotating-source=s512-rw',other='https://flow.google.com/asb/result-source=s256-rw';
  let current=project,rows=[{source:proxy,media_id:id,labels:['exact-upload.png']}];f.page.url=()=>current;
  f.adapter.locator=spec=>{assert.equal(spec,f.adapter.selectors.resultTile);return {evaluateAll:async()=>rows};};
  assert.equal(await f.adapter.referenceIdentity(proxy,'exact-upload.png Image'),direct);
  assert.equal(await f.adapter.referenceIdentity(direct),direct);
  current=project+'/edit/result';rows=[];
  assert.equal(await f.adapter.referenceIdentity(proxy),direct);
  rows=[{source:other,media_id:id,labels:['exact-upload.png']}];
  assert.equal(await f.adapter.referenceIdentity(other),direct);
  current='https://flow.google.com/project/another';rows=[];
  assert.equal(await f.adapter.referenceIdentity(proxy),proxy);
  rows=[{source:proxy,media_id:id,labels:[]},{source:proxy,media_id:'1c6bb51b-b376-472a-a099-767ea49466be',labels:[]}];
  await assert.rejects(f.adapter.referenceIdentity(proxy),{code:'flow_reference_identity_ambiguous'});
  assert.equal(await f.adapter.referenceIdentity('https://evil.test/image/'+id),undefined);
});
test('ingredient identity accepts the observed official asb route and keeps exact asset binding',()=>{
  const identity='https://flow.google.com/asb/observed_asset-123=s512-rw';
  assert.equal(imageIdentity(identity+'?transient=value#fragment'),identity);
  assert.notEqual(imageIdentity(identity),imageIdentity('https://flow.google.com/asb/different_asset=s512-rw'));
  assert.equal(imageIdentity('https://flow-content.google/image/legacy?transient=value'),'https://flow-content.google/image/legacy');
  for(const url of ['https://flow.google.com/asb/','https://flow.google.com/project/asset','https://flow.google.com.evil.invalid/asb/asset','http://flow.google.com/asb/asset','blob:https://flow.google.com/asset','https://user:password@flow.google.com/asb/asset','https://flow.google.com:444/asb/asset'])assert.equal(imageIdentity(url),undefined);
});
function fixture(t) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'flow-adapter-test-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aG0sAAAAASUVORK5CYII=', 'base64');
  const page = { url: () => project };
  const adapter = new FlowBrowser({ mandatoryOutlineRule: 'NO OUTLINE', projectUrl: project, generationTimeoutMs: 1000 }, { page });
  adapter.generationFailure = async () => null;
  adapter.failedTileTexts = async () => [];
  adapter.waitForGenerate = async () => adapter.unique(adapter.selectors.generate);
  adapter.referenceOptionReady = async () => true;
  return { directory, png, page, adapter, item: { prompt: 'fixture-only prompt\nNO OUTLINE' } };
}
test('unusual checkpoint accepts only an equivalent language parameter, preserving exact account/project/prompt/generation binding',async t=>{
  const f=fixture(t),url='https://flow.google.com/u/1/project/exact?hl=en';
  f.adapter.config.accountPolicy={enabled:true};
  let current='https://flow.google.com/u/1/project/exact';f.page.url=()=>current;
  const checkpoint={status:'generation_started',generation_id:'saved-failure',recovery:{project_url:url,prompt_sha256:hash(f.item.prompt)}};
  const evidence={generation_id:'saved-failure',failed_tiles:['Failed We noticed some unusual activity.']};
  assert.deepEqual(await f.adapter.resumeAfterUnusualFailure(f.item,checkpoint,evidence),evidence.failed_tiles);
  for(const changed of ['https://flow.google.com/u/2/project/exact','https://flow.google.com/u/1/project/other','https://flow.google.com/u/1/project/exact/edit/asset','https://flow.google.com/u/1/project/exact?unexpected=value']){
    current=changed;await assert.rejects(f.adapter.resumeAfterUnusualFailure(f.item,checkpoint,evidence),{code:'flow_unusual_retry_binding_invalid'});
  }
  current=url;
  for(const changed of [{...checkpoint,asset:{}},{...checkpoint,generation_id:'different'},{...checkpoint,recovery:{...checkpoint.recovery,prompt_sha256:hash('changed')}}])
    await assert.rejects(f.adapter.resumeAfterUnusualFailure(f.item,changed,evidence),{code:'flow_unusual_retry_binding_invalid'});
});

test('gallery candidates use one DOM snapshot while virtualized images disappear between locator calls', async t => {
  const { adapter } = fixture(t);
  const tile = (identity, overrides = {}) => ({
    isConnected: true, ownerDocument: { defaultView: { getComputedStyle: () => ({ visibility: 'visible' }) } },
    getBoundingClientRect: () => ({ width: 100, height: 100 }), getClientRects: () => [1], innerText: 'Completed image',
    querySelectorAll: () => [{ complete: true, naturalWidth: 100, getAttribute: attribute => { assert.equal(attribute, 'data-media-id'); return identity; } }],
    ...overrides,
  });
  const tiles = [tile('ready'), tile('loading', { querySelectorAll: () => [{ complete: false, naturalWidth: 0 }] }),
    tile('removed', { isConnected: false }), tile('hidden', { getClientRects: () => [] }),
    tile('ambiguous', { querySelectorAll: () => [{}, {}] }), tile(null),
    tile('invisible', { ownerDocument: { defaultView: { getComputedStyle: () => ({ visibility: 'hidden' }) } } })];
  let snapshots = 0;
  adapter.locator = selector => {
    if (selector === adapter.selectors.resultImage) return { count: async () => 1, evaluate: async () => true,
      getAttribute: async () => { throw new Error('virtualized image removed before getAttribute'); } };
    assert.equal(selector, adapter.selectors.resultTile);
    return {
      evaluateAll: async (callback, options) => { snapshots++; assert.equal(options.selector, 'img[data-media-id]'); return callback(tiles, options); },
      count: async () => tiles.length,
      nth: () => ({ isVisible: async () => true, innerText: async () => 'Completed image' }),
    };
  };
  assert.deepEqual(await adapter.results(), [{ identity: 'ready', text: 'Completed image', index: 0 }]);
  assert.equal(snapshots, 1);
  tiles.splice(0, tiles.length);
  assert.deepEqual(await adapter.results(), []);
});
test('previous-account retry verifies the authorized identity and saved project before baselining only its saved unusual failure',async t=>{
  const f=fixture(t),email='old@example.com',accountHash=hash(email),url='https://flow.google.com/u/1/project/old?hl=en';let current='https://flow.google.com/u/1/?hl=en',verified=0,ensured=0;
  f.adapter.config.profileDir=f.directory;f.adapter.config.accountPolicy={preferred_email:email,accounts:[{email,home_url:'https://flow.google.com/u/1/'}]};
  f.adapter.accountState=()=>({active_email:email,unavailable:{[email]:{reason:'flow_unusual_activity_required'}}});
  fs.writeFileSync(path.join(f.directory,'flow-worker-projects.json'),JSON.stringify({account_projects:{[accountHash]:{batch:{status:'ready',project_url:url}}}}));
  f.page.url=()=>current;f.page.goto=async value=>{current=value;};f.adapter.verifyAccount=async expected=>{assert.equal(expected,email);verified++;};f.adapter.ensureProject=async key=>{assert.equal(key,'batch');ensured++;};
  const image={status:'generation_started',generation_id:'old-generation',recovery:{project_url:url,prompt_sha256:hash(f.item.prompt),failure_baseline:['Failed history']}};
  const evidence={generation_id:'old-generation',failed_tiles:['Failed We noticed some unusual activity.']};
  assert.deepEqual(await f.adapter.resumeUnusualOnPreviousAccount(f.item,image,evidence,accountHash,'batch'),['Failed history',...evidence.failed_tiles]);assert.equal(verified,1);assert.equal(ensured,1);
  for(const [key,projectKey,checkpoint]of [[hash('other@example.com'),'batch',image],[accountHash,'another',image],[accountHash,'batch',{...image,recovery:{...image.recovery,project_url:'https://flow.google.com/u/2/project/other?hl=en'}}]])await assert.rejects(f.adapter.resumeUnusualOnPreviousAccount(f.item,checkpoint,evidence,key,projectKey),{code:'flow_unusual_retry_binding_invalid'});
  assert.equal(verified,1);
});
test('forced restart closes owned healthy Chrome and reopens the same persistent profile/project',async t=>{
  const f=fixture(t);let closed=0,launched=0,navigated;
  f.adapter.config.profileDir=path.join(f.directory,'owned-profile');
  f.adapter.context={close:async()=>{closed++;}};
  const page={setDefaultTimeout:()=>{},goto:async url=>{navigated=url;}};
  const context={pages:()=>[page]};
  f.adapter.dependencies.playwright={chromium:{launchPersistentContext:async(profile)=>{assert.equal(profile,f.adapter.config.profileDir);assert.equal(closed,1);launched++;return context;}}};
  await f.adapter.restartBrowser();
  assert.equal(closed,1);assert.equal(launched,1);assert.equal(navigated,project);assert.equal(f.adapter.context,context);assert.equal(f.adapter.page,page);
});

test('official UI URL validation excludes private or unrelated URLs', () => {
  assert.equal(official(project), true); assert.equal(official('https://labs.google/fx/tools/flow/project/test'), false);
  for (const url of ['http://flow.google.com/', 'https://flow.google.com.evil.test/', 'https://labs.google/private-api', 'javascript:alert(1)']) assert.equal(official(url), false);
});

test('GoLogin opens a worker-owned page and detaches without closing existing user pages or context',async t=>{
 const f=fixture(t);let pageClosed=0,disconnected=0,created=0;
 const page={setDefaultTimeout:()=>{},isClosed:()=>false,close:async()=>{pageClosed++;}};
 const context={newPage:async()=>{created++;return page;},close:async()=>assert.fail('must preserve external default context'),pages:()=>[{userPage:true}]};
 const browser={contexts:()=>[context],close:async()=>{disconnected++;}};
 const gologin={profileId:'6accb27efce399d31d86b8bd',apiUrl:'http://127.0.0.1:36912'};
 fs.writeFileSync(path.join(f.directory,'gologin-connection.private.json'),JSON.stringify({profile_id:gologin.profileId,api_url:gologin.apiUrl,ws_url:'ws://127.0.0.1:29395/devtools/browser/0249c379-8466-4ba4-81ce-921e1e7b7714'}));
 const adapter=new FlowBrowser({profileDir:f.directory,stateDir:f.directory,gologin},{playwright:{chromium:{connectOverCDP:async()=>browser,launchPersistentContext:async()=>assert.fail('must use GoLogin')}}});
 await adapter.launch();assert.equal(created,1);assert.equal(adapter.page,page);await adapter.close();assert.equal(pageClosed,1);assert.equal(disconnected,1);assert.equal(adapter.page,undefined);
});

test('account-scoped batch projects preserve legacy bindings and never cross account caches',async t=>{
 const f=fixture(t),a='first@example.com',b='second@example.com';let url='https://flow.google.com/u/1/',current=b,created=0;
 f.adapter.config.profileDir=f.directory;f.adapter.config.stateDir=f.directory;
 f.adapter.config.accountPolicy={enabled:true,reference:'Fixture user owns two signed-in accounts',preferred_email:b,accounts:[{email:a,home_url:'https://flow.google.com/'},{email:b,home_url:url}]};
 f.page.url=()=>url;f.page.goto=async value=>{url=value;current=value.includes('/u/1/')?b:a;};
 f.adapter.verifyAccount=async email=>{assert.equal(email,current);f.adapter.currentAccount=email;};
 f.adapter.readiness=async()=>({ready:true,needs_project:!url.includes('/project/')});
 f.adapter.unique=async()=>({click:async()=>{const next=new URL(url);next.pathname+='project/new-'+(++created);url=next.href;}});f.adapter.locator=()=>({waitFor:async()=>{}});
 const file=path.join(f.directory,'flow-worker-projects.json');fs.writeFileSync(file,JSON.stringify({projects:{'batch-a':{status:'ready',project_url:project}}}));
 await f.adapter.ensureProject('batch-a');const second=url;
 assert.notEqual(second,project);assert.equal(created,1);await f.adapter.ensureProject('batch-a');assert.equal(url,second);assert.equal(created,1);
 await f.adapter.switchAccount(a);await f.adapter.ensureProject('batch-a');assert.notEqual(url,second);assert.equal(created,2);
 await f.adapter.switchAccount(b);await f.adapter.ensureProject('batch-a');assert.equal(url,second);assert.equal(created,2);
 assert.equal(JSON.parse(fs.readFileSync(file)).projects['batch-a'].project_url,project);
 assert.equal(f.adapter.quotaTarget(),a);await f.adapter.switchAccount(a);assert.equal(f.adapter.quotaTarget(),null);
 const restarted=new FlowBrowser(f.adapter.config);assert.equal(Object.keys(restarted.accountState().unavailable).length,2);
 await assert.rejects(f.adapter.switchAccount(b),{code:'flow_accounts_exhausted'});
});

test('account UI localization keeps account/project path and existing query, legacy URLs unchanged',()=>{
 const browser=new FlowBrowser({accountPolicy:{enabled:true}});
 const url=new URL(browser.uiUrl('https://flow.google.com/u/1/project/owned?foo=bar&hl=vi'));
 assert.equal(url.pathname,'/u/1/project/owned');assert.equal(url.searchParams.get('hl'),'en');assert.equal(url.searchParams.get('foo'),'bar');
 assert.equal(new FlowBrowser({}).uiUrl(project),project);
 assert.throws(()=>browser.uiUrl('https://evil.test/'),{code:'flow_project_url_invalid'});
});

test('third signed-in account preserves unavailable history and unusual selects a different authorized account',async t=>{
 const f=fixture(t);f.adapter.config.stateDir=f.directory;
 fs.writeFileSync(path.join(f.directory,'flow-accounts.private.json'),JSON.stringify({policy_reference:'old',active_email:'second@example.com',unavailable:{'first@example.com':{reason:'previous_quota_evidence',at:'old-proof'},'second@example.com':{reason:'flow_quota_required'}}}));
 f.adapter.config.accountPolicy={enabled:true,reference:'User adds a third account',on_unusual_activity:'switch_account',preferred_email:'third@example.com',accounts:[
  {email:'first@example.com',home_url:'https://flow.google.com/'},{email:'second@example.com',home_url:'https://flow.google.com/u/1/'},{email:'third@example.com',home_url:'https://flow.google.com/u/2/'}]};
 f.adapter.currentAccount='third@example.com';
 const state=f.adapter.accountState();assert.equal(state.active_email,'third@example.com');assert.equal(state.unavailable['first@example.com'].at,'old-proof');
 assert.equal(f.adapter.unusualTarget('https://flow.google.com/u/1/project/exact?hl=en'),'third@example.com');
 assert.equal(f.adapter.accountState().unavailable['second@example.com'].reason,'flow_unusual_activity_required');
 assert.equal(f.adapter.accountState().unavailable['second@example.com'].previous_reason,'flow_quota_required');
 assert.equal(f.adapter.unusualTarget('https://flow.google.com/u/2/project/other'),null);
 assert.throws(()=>f.adapter.unusualTarget('https://evil.test/project/other'),{code:'flow_account_switch_binding_invalid'});
});

test('account verification rejects a changed identity and login redirect without credentials',async t=>{
 const f=fixture(t);let label='Tài khoản Google: Person (second@example.com), Gói thành viên';
 f.adapter.locator=()=>({waitFor:async()=>{},count:async()=>1,getAttribute:async()=>label});
 assert.equal(await f.adapter.verifyAccount('second@example.com'),'second@example.com');
 await assert.rejects(f.adapter.verifyAccount('first@example.com'),{code:'flow_account_identity_mismatch'});
 label='Google Account: unknown';await assert.rejects(f.adapter.verifyAccount('second@example.com'),{code:'flow_account_identity_mismatch'});
 f.page.url=()=> 'https://accounts.google.com/signin';await assert.rejects(f.adapter.verifyAccount('second@example.com'),{code:'flow_login_required'});
});

test('the observed Flow changelog is dismissed before account verification without changing identity or model',async t=>{
  const f=fixture(t);let open=true,clicks=0,verified=false;
  f.page.locator=selector=>{assert.equal(selector,'iframe[src^="https://www.gstatic.com/aitestkitchen/website/flow/changelogs/"]');return{count:async()=>open?1:0,isVisible:async()=>open,waitFor:async options=>{assert.equal(options.state,'hidden');assert.equal(open,false);}};};
  f.page.getByRole=(role,options)=>{assert.equal(role,'button');assert.equal(options.exact,true);assert(['Get started','View all changelogs'].includes(options.name));return{count:async()=>1,isVisible:async()=>open,click:async()=>{assert.equal(options.name,'Get started');clicks++;open=false;}};};
  f.adapter.locator=()=>({waitFor:async()=>{assert.equal(open,false);verified=true;},count:async()=>1,getAttribute:async()=> 'Google Account: Owner (owner@example.com)'});
  assert.equal(await f.adapter.verifyAccount('owner@example.com'),'owner@example.com');assert.equal(verified,true);assert.equal(clicks,1);
  assert.equal(await f.adapter.dismissChangelog(),false);assert.equal(clicks,1);
  await assert.rejects(f.adapter.verifyAccount('different@example.com'),{code:'flow_account_identity_mismatch'});
});

test('account verification dismisses a changelog that appears after the first render',async t=>{
  const f=fixture(t);let open=false,waits=0,clicks=0;
  f.page.locator=()=>({count:async()=>open?1:0,isVisible:async()=>open,waitFor:async()=>assert.equal(open,false)});
  f.page.getByRole=(_role,options)=>({count:async()=>1,isVisible:async()=>open,click:async()=>{assert.equal(options.name,'Get started');clicks++;open=false;}});
  f.adapter.locator=()=>({waitFor:async()=>{if(++waits===1){open=true;throw Error('late dialog');}assert.equal(open,false);},count:async()=>1,getAttribute:async()=> 'Google Account: Owner (owner@example.com)'});
  assert.equal(await f.adapter.verifyAccount('owner@example.com'),'owner@example.com');assert.equal(waits,2);assert.equal(clicks,1);
});

test('account verification reveals an offscreen header by scrolling the gallery and still checks exact identity',async t=>{
  const f=fixture(t);let top=800,wheels=0,label='Google Account: Owner (owner@example.com)';
  f.page.mouse={wheel:async(x,y)=>{assert.equal(x,0);assert.equal(y,-800);wheels++;top=0;}};
  f.page.waitForFunction=async(_fn,selector)=>{assert.equal(selector,f.adapter.selectors.recoveryGallery);assert.equal(top,0);};
  f.adapter.locator=spec=>spec===f.adapter.selectors.recoveryGallery
    ?{count:async()=>1,isVisible:async()=>true,evaluate:async fn=>fn({scrollTop:top}),hover:async()=>{}}
    :{waitFor:async()=>{if(top)throw Error('header offscreen');},count:async()=>1,getAttribute:async()=>label};
  assert.equal(await f.adapter.verifyAccount('owner@example.com'),'owner@example.com');assert.equal(wheels,1);
  label='Google Account: Different (other@example.com)';
  await assert.rejects(f.adapter.verifyAccount('owner@example.com'),{code:'flow_account_identity_mismatch'});assert.equal(wheels,1);
});

test('changelog dismissal ignores unrelated frames and preserves login/captcha gates',async t=>{
  const f=fixture(t);let count=0,clicked=0;
  f.page.locator=()=>({count:async()=>count,isVisible:async()=>true});
  f.page.getByRole=()=>({count:async()=>2,isVisible:async()=>true,click:async()=>clicked++});
  assert.equal(await f.adapter.dismissChangelog(),false);count=2;
  assert.equal(await f.adapter.dismissChangelog(),false);count=1;
  await assert.rejects(f.adapter.dismissChangelog(),{code:'flow_changelog_ui_changed'});assert.equal(clicked,0);
  f.adapter.selectors.login={text:'Fixture login'};f.adapter.selectors.captcha={text:'Fixture captcha'};
  f.adapter.visible=async spec=>spec===f.adapter.selectors.captcha;
  assert.deepEqual(await f.adapter.readiness(),{ready:false,code:'flow_captcha_required'});assert.equal(clicked,0);
  f.page.url=()=> 'https://accounts.google.com/signin';
  assert.equal(await f.adapter.dismissChangelog(),false);
  await assert.rejects(f.adapter.verifyAccount('owner@example.com'),{code:'flow_login_required'});assert.equal(clicked,0);
});

test('Flow cookie notice is declined through its scoped public button before readiness or configuration',async t=>{
  const f=fixture(t);let open=true,declined=0;
  f.page.locator=selector=>{assert.equal(selector,'#glue-cookie-notification-bar-1');return{count:async()=>1,isVisible:async()=>open,innerText:async()=> 'flow.google.com uses cookies to deliver and enhance the quality of its services.',getByRole:(role,options)=>{assert.equal(role,'button');assert.deepEqual(options,{name:'No thanks',exact:true});return{count:async()=>1,isVisible:async()=>true,click:async()=>{declined++;open=false;}};},waitFor:async options=>{assert.equal(options.state,'hidden');assert.equal(open,false);}};};
  f.adapter.dismissChangelog=async()=>{};f.adapter.visible=async spec=>spec===f.adapter.selectors.prompt;
  assert.deepEqual(await f.adapter.readiness(),{ready:true});assert.equal(declined,1);
  assert.equal(await f.adapter.dismissCookieNotice(),false);assert.equal(declined,1);
  open=true;f.adapter.dismissAssetPicker=async()=>{assert.equal(open,false);throw Object.assign(Error('end configure fixture'),{code:'fixture_end'});};
  await assert.rejects(f.adapter.configure(),{code:'fixture_end'});assert.equal(declined,2);
});

test('cookie notice rejects unknown or ambiguous controls and preserves login, captcha and origin gates',async t=>{
  const f=fixture(t);let count=1,buttonCount=2,text='flow.google.com uses cookies',clicks=0;
  f.page.locator=()=>({count:async()=>count,isVisible:async()=>true,innerText:async()=>text,getByRole:()=>({count:async()=>buttonCount,isVisible:async()=>true,click:async()=>clicks++})});
  count=0;assert.equal(await f.adapter.dismissCookieNotice(),false);count=2;assert.equal(await f.adapter.dismissCookieNotice(),false);count=1;
  await assert.rejects(f.adapter.dismissCookieNotice(),{code:'flow_cookie_notice_ui_changed'});buttonCount=1;text='Unrecognized notice';
  await assert.rejects(f.adapter.dismissCookieNotice(),{code:'flow_cookie_notice_ui_changed'});
  f.adapter.selectors.login={text:'Sign in'};f.adapter.selectors.captcha={text:'CAPTCHA'};
  for(const [selector,code]of [[f.adapter.selectors.login,'flow_login_required'],[f.adapter.selectors.captcha,'flow_captcha_required']]){f.adapter.visible=async spec=>spec===selector;assert.deepEqual(await f.adapter.readiness(),{ready:false,code});}
  f.page.url=()=> 'https://accounts.google.com/signin';assert.equal(await f.adapter.dismissCookieNotice(),false);assert.equal(clicks,0);
});

test('fixed-account pool records quota evidence and never selects another signed-in account',t=>{
 const f=fixture(t);f.adapter.config.stateDir=f.directory;
 f.adapter.config.accountPolicy={enabled:true,reference:'Fixture user chooses one account per Chrome',pool_fixed_account:true,preferred_email:'own@example.com',accounts:[{email:'own@example.com',home_url:'https://flow.google.com/'},{email:'other@example.com',home_url:'https://flow.google.com/u/1/'}]};
 f.adapter.currentAccount='own@example.com';assert.equal(f.adapter.quotaTarget(),null);
 assert.equal(f.adapter.accountState().unavailable['own@example.com'].reason,'flow_quota_required');
 assert.equal(f.adapter.accountState().active_email,'own@example.com');
});

test('each batch creates one project; restart and return to prior batch reuse their own project',async t=>{
 const f=fixture(t);f.adapter.config.profileDir=f.directory;
 let url=project,created=0;f.page.url=()=>url;f.page.goto=async value=>{url=value;};
 f.adapter.readiness=async()=>({ready:true,needs_project:url==='https://flow.google.com/'});
 f.adapter.unique=async()=>({click:async()=>{url='https://flow.google.com/project/batch-'+(++created);}});
 f.adapter.locator=()=>({waitFor:async()=>{}});
 await f.adapter.ensureProject('batch-a');const first=url;
 await f.adapter.ensureProject('batch-a');assert.equal(created,1);
 await f.adapter.ensureProject('batch-b');assert.equal(created,2);assert.notEqual(url,first);
 const resumed=new FlowBrowser(f.adapter.config,{page:f.page});resumed.readiness=f.adapter.readiness;
 await resumed.ensureProject('batch-a');assert.equal(url,first);assert.equal(created,2);
 const file=path.join(f.directory,'flow-worker-projects.json'),state=JSON.parse(fs.readFileSync(file));state.projects['batch-c']={status:'creating'};fs.writeFileSync(file,JSON.stringify(state));
 await assert.rejects(resumed.ensureProject('batch-c'),/creation_reconcile_required/);assert.equal(created,2);
});

test('only visible failed Retry tiles classify unusual activity; unrelated prompt text does not', async t => {
  const f = fixture(t);
  delete f.adapter.failedTileTexts;
  let tiles = [{ visible: true, text: 'warning\nFailed\nWe noticed some unusual activity.\nYou have not been charged for this generation.' }];
  f.adapter.locator = selector => {
    assert.equal(selector, f.adapter.selectors.generationFailed);
    return { count: async () => tiles.length, nth: i => ({ isVisible: async () => tiles[i].visible, innerText: async () => tiles[i].text }) };
  };
  const failure = () => FlowBrowser.prototype.generationFailure.call(f.adapter);
  assert.equal(await failure(), 'flow_unusual_activity_required');
  tiles[0].visible = false; assert.equal(await failure(), null);
  tiles[0] = { visible: true, text: 'Failed\nImage could not be generated.' }; assert.equal(await failure(), 'flow_generation_failed');
  tiles[0].text = 'Create typography saying Failed and We noticed some unusual activity.'; assert.equal(await failure(), null);
});

test('terminal failure appearing during result wait wakes recovery without another Generate or Retry', async t => {
  const f = fixture(t); let failure = null, waits = 0;
  f.adapter.readiness = async () => ({ ready: true }); f.adapter.results = async () => [];
  f.adapter.generationFailure = async () => failure; f.adapter.captureDiagnostic = async () => {};
  f.page.waitForFunction = async (_predicate, args) => { assert.equal(args.failureSelector, f.adapter.selectors.generationFailed); waits++; failure = 'flow_unusual_activity_required'; };
  await assert.rejects(f.adapter.recover({ baseline: [], project_url: project, prompt_sha256: hash(f.item.prompt) }, f.item.prompt), { code: 'flow_unusual_activity_required' });
  assert.equal(waits, 1);
});

test('one-minute retry evidence excludes historical failures and gives unusual activity priority',async t=>{
  const f=fixture(t),file=path.join(f.directory,'failure.png');
  const old='Failed Image could not be generated.';let texts=[old];
  f.adapter.failureBaseline=[old];f.adapter.failedTileTexts=async()=>texts;
  f.page.screenshot=async({path:file})=>fs.writeFileSync(file,f.png);
  await assert.rejects(f.adapter.generationFailureEvidence(file),{code:'flow_generation_failure_evidence_missing'});
  texts.push(old);const proof=await f.adapter.generationFailureEvidence(file);
  assert.deepEqual(proof.failed_tiles,[old]);assert.equal(proof.screenshot_sha256,hash(f.png));
  texts.push('Failed We noticed some unusual activity.');
  await assert.rejects(f.adapter.generationFailureEvidence(file),{code:'flow_unusual_activity_required'});
});
test('usage-limit and credit failures block as quota, never as a retryable generic failure',async t=>{
  const f=fixture(t),file=path.join(f.directory,'quota.png');
  for(const message of ["You've reached your usage limit. Please try again later.",'Not enough credits','Insufficient AI credits','Out of credits']){
    f.adapter.failedTileTexts=async()=>['warning Failed '+message];
    assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_quota_required');
    await assert.rejects(f.adapter.generationFailureEvidence(file),{code:'flow_quota_required'});
    assert.equal(fs.existsSync(file),false);
  }
  f.adapter.failedTileTexts=async()=>[];
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),null);
  f.adapter.failedTileTexts=async()=>['Failed Image could not be generated.'];
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_generation_failed');
  f.adapter.failedTileTexts=async()=>['Failed You have reached your usage limit.','Failed We noticed some unusual activity.'];
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_unusual_activity_required');
  f.adapter.failedTileTexts=async()=>['Failed You have reached your usage limit.','Failed Content was blocked by safety policies.'];
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_policy_review_required');
});

test('explicit policy blocks remain terminal; a might-violate Failed can use ordinary bounded retry',async t=>{
  const f=fixture(t),file=path.join(f.directory,'policy-warning.png');
  f.page.screenshot=async({path:file})=>fs.writeFileSync(file,'fixture-failed-screen');
  for(const text of ['Failed This generation violates our policies.','Failed Content was blocked by safety policies.','Failed This generation might violate our policies. Content was blocked.']){
    f.adapter.failedTileTexts=async()=>[text];
    assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_policy_review_required');
    await assert.rejects(f.adapter.generationFailureEvidence(file),{code:'flow_policy_review_required'});
    assert.equal(fs.existsSync(file),false);
  }
  const soft='Failed This generation might violate our policies. Please try a different prompt or send feedback.';
  f.adapter.failedTileTexts=async()=>[soft];
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),'flow_generation_might_violate');
  const evidence=await f.adapter.generationFailureEvidence(file);assert.deepEqual(evidence.failed_tiles,[soft]);assert.equal(fs.existsSync(file),true);
  f.adapter.failureBaseline=['Failed This generation might violate our policies.'];
  f.adapter.failedTileTexts=async()=>f.adapter.failureBaseline;
  assert.equal(await FlowBrowser.prototype.generationFailure.call(f.adapter),null);
});

test('acknowledged historical failures do not block a fresh Generate but a new failure is detected',async t=>{
  const f=fixture(t);const warning='Failed\nWe noticed some unusual activity.';let texts=[warning];
  f.adapter.locator=()=>({count:async()=>texts.length,nth:i=>({isVisible:async()=>true,innerText:async()=>texts[i]})});
  delete f.adapter.generationFailure;
  delete f.adapter.failedTileTexts;
  await f.adapter.acknowledgeFailedTiles();assert.equal(await f.adapter.generationFailure(),null);
  texts.push(warning);assert.equal(await f.adapter.generationFailure(),'flow_unusual_activity_required');
  texts=[warning,'Failed\nOther error'];assert.equal(await f.adapter.generationFailure(),'flow_generation_failed');
  await f.adapter.acknowledgeFailedTiles();assert.equal(await f.adapter.generationFailure(),null);
  texts.push('Failed\nOther error');assert.equal(await f.adapter.generationFailure(),'flow_generation_failed');
});

test('visible unusual activity blocks readiness before a new generation', async t => {
  const f = fixture(t);
  f.adapter.visible = async () => false; f.adapter.generationFailure = async () => 'flow_unusual_activity_required';
  assert.deepEqual(await f.adapter.readiness(), { ready: false, code: 'flow_unusual_activity_required' });
});
test('dedicated browser profile never attaches CDP or existing Chrome user directory', async () => {
  let launches = 0;
  const playwright = { chromium: { launchPersistentContext: async () => { launches++; throw Error('must not reach'); } } };
  for (const config of [{ profileDir: 'C:/Users/ADMIN/AppData/Local/Google/Chrome/User Data' }, { profileDir: 'C:/test-owned', cdpUrl: 'http://localhost:9222' }, { profileDir: 'C:/test-owned', storageState: {} }]) {
    const adapter = new FlowBrowser(config, { playwright });
    await assert.rejects(adapter.start(), { code: 'flow_dedicated_profile_required' });
  }
  assert.equal(launches, 0);
});
test('successful Flow startup retains its dedicated profile and navigates the configured project',async t=>{
  const f=fixture(t);let visited;
  const page={setDefaultTimeout:()=>{},goto:async url=>visited=url};
  const playwright={chromium:{launchPersistentContext:async profile=>{assert.equal(profile,path.resolve(f.directory));return {pages:()=>[page]};}}};
  const browser=new FlowBrowser({profileDir:f.directory,projectUrl:project},{playwright});
  await browser.start();assert.equal(visited,project);assert.equal(browser.projectStateFile,path.join(f.directory,'flow-worker-project.json'));
});
test('extension startup retries only a fresh 407 on the exact page once, then verifies the fixed account',async t=>{
  const f=fixture(t);let navigations=0,waits=0,verified=0;
  const browser=new FlowBrowser({profileDir:f.directory,enableExtensions:true});
  const page={setDefaultTimeout:()=>{},goto:async(url,options)=>{assert.equal(url,project+'?hl=en');assert.equal(options.waitUntil,'domcontentloaded');if(++navigations===1){browser.passiveEvents.push({event:'http_error',status:407,url:project});throw Error('net::ERR_HTTP_RESPONSE_CODE_FAILURE');}},waitForTimeout:async ms=>{assert.equal(ms,15000);waits++;}};
  browser.dependencies.playwright={chromium:{launchPersistentContext:async()=>({pages:()=>[page]})}};
  browser.config.accountPolicy={};browser.accountState=()=>({active_email:'owner@example.com'});browser.accountHome=()=>project;
  browser.verifyAccount=async email=>{assert.equal(email,'owner@example.com');assert.equal(navigations,2);verified++;};
  await browser.start();assert.equal(navigations,2);assert.equal(waits,1);assert.equal(verified,1);
});

test('startup does not retry other errors, stale or unrelated 407s, or a disabled extension configuration',async t=>{
  const f=fixture(t);
  for(const scenario of ['403','stale','unrelated','disabled','timeout','repeated']){
    let navigations=0,waits=0;
    const browser=new FlowBrowser({profileDir:f.directory,projectUrl:project,enableExtensions:scenario!=='disabled'});
    if(scenario==='stale')browser.passiveEvents.push({event:'http_error',status:407,url:project});
    const page={setDefaultTimeout:()=>{},goto:async()=>{navigations++;if(scenario!=='stale')browser.passiveEvents.push({event:'http_error',status:scenario==='403'?403:407,url:scenario==='unrelated'?project+'/other':project});throw Error(scenario==='timeout'?'Timeout':'net::ERR_HTTP_RESPONSE_CODE_FAILURE');},waitForTimeout:async()=>{waits++;}};
    browser.dependencies.playwright={chromium:{launchPersistentContext:async()=>({pages:()=>[page]})}};
    await assert.rejects(browser.start());assert.equal(navigations,scenario==='repeated'?2:1);assert.equal(waits,scenario==='repeated'?1:0);
  }
});

test('extensions require an explicit per-worker opt-in and remove only the disabling flag',async t=>{
  const f=fixture(t);
  for(const enabled of [undefined,false,'true',true]){
    let options;
    const page={setDefaultTimeout:()=>{}};
    const playwright={chromium:{launchPersistentContext:async(profile,opts)=>{assert.equal(profile,path.resolve(f.directory));options=opts;return{pages:()=>[page]};}}};
    const browser=new FlowBrowser({profileDir:f.directory,channel:'chrome',enableExtensions:enabled},{playwright});
    await browser.launch();
    assert.equal(options.channel,'chrome');assert.equal(options.headless,false);assert.equal(options.acceptDownloads,true);
    assert.deepEqual(options.viewport,{width:1440,height:1000});
    if(enabled===true)assert.deepEqual(options.ignoreDefaultArgs,['--disable-extensions']);
    else assert.equal(Object.hasOwn(options,'ignoreDefaultArgs'),false);
    assert.equal(options.args,undefined);assert.equal(options.ignoreHTTPSErrors,undefined);
  }
});

test('prompt outline rule and locked reference hashes validate before any UI actions', async t => {
  const f = fixture(t); let ui = 0; f.adapter.ensureProject = async () => { ui++; };
  await assert.rejects(f.adapter.generate({ prompt: 'missing rule' }, [], f.directory), { code: 'flow_outline_rule_missing' });
  const reference = path.join(f.directory, 'reference.png'); fs.writeFileSync(reference, f.png);
  await assert.rejects(f.adapter.generate(f.item, [{ path: reference, sha256: 'f'.repeat(64) }], f.directory), { code: 'flow_reference_hash_changed' });
  assert.equal(ui, 0);
});
test('durable checkpoint precedes Generate click; rejected checkpoint never clicks', async t => {
  const f = fixture(t); const order = [];
  f.adapter.failedTileTexts=async()=>['Failed Historical error'];
  f.adapter.ensureProject = f.adapter.configure = f.adapter.upload = async () => {};
  f.adapter.results = async () => [{ identity: 'old-media' }];
  f.adapter.locator = () => ({ count: async () => 0 });
  f.adapter.unique = async spec => spec === f.adapter.selectors.prompt ? { fill: async () => {}, innerText: async () => f.item.prompt } : { isEnabled: async () => true, click: async () => { order.push('click'); } };
  f.adapter.recover = async recovery => { assert.deepEqual(recovery.baseline, ['old-media']); assert.deepEqual(recovery.failure_baseline,['Failed Historical error']); return { identity: 'new-media', index: 0 }; };
  f.adapter.acquire = async () => ({ asset: { path: 'fake', sha256: 'fixture' }, proof: {} });
  await f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async metadata => { order.push('checkpoint'); assert.equal(metadata.recovery.prompt_sha256, hash(f.item.prompt)); } });
  assert.deepEqual(order, ['checkpoint', 'click']);
  order.length = 0;
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async () => { throw Error('durable storage failed'); } }));
  assert.deepEqual(order, []);
});
test('unknown click outcome remains reconcile-required, no repeated Generate', async t => {
  const f = fixture(t); let clicks = 0, marked;
  f.adapter.ensureProject = f.adapter.configure = f.adapter.upload = async () => {};
  f.adapter.results = async () => [];
  f.adapter.locator = () => ({ count: async () => 0 });
  f.adapter.unique = async spec => spec === f.adapter.selectors.prompt ? { fill: async () => {}, innerText: async () => f.item.prompt } : { isEnabled: async () => true, click: async () => { clicks++; throw Error('connection lost after browser click'); } };
  f.adapter.recover = async () => { throw Object.assign(Error('no correlated result'), { code: 'flow_generation_reconcile_required' }); };
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async m => { marked = m; } }), { code: 'flow_generation_reconcile_required' });
  assert.equal(clicks, 1); assert.ok(marked.generation_id);
  f.adapter.recover = async () => ({ identity: 'generated-result', index: 0 });
  f.adapter.acquire = async () => ({ asset: {}, proof: {} });
  await f.adapter.generate(f.item, [], f.directory, { resume: { status: 'generation_started', ...marked } });
  assert.equal(clicks, 1);
});

test('unusual activity arising during preparation blocks even the first Generate click', async t => {
  const f = fixture(t); let clicks = 0, checkpoints = 0;
  f.adapter.ensureProject = f.adapter.configure = f.adapter.upload = async () => {};
  f.adapter.results = async () => []; f.adapter.locator = () => ({ count: async () => 0 });
  f.adapter.unique = async spec => spec === f.adapter.selectors.prompt ? { fill: async () => {}, innerText: async () => f.item.prompt } : { isEnabled: async () => true, click: async () => { clicks++; } };
  f.adapter.generationFailure = async () => 'flow_unusual_activity_required'; f.adapter.captureDiagnostic = async () => {};
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async () => { checkpoints++; } }), { code: 'flow_unusual_activity_required' });
  assert.equal(clicks, 0); assert.equal(checkpoints, 0);
});
test('resume refuses missing recovery metadata without generating', async t => {
  const f = fixture(t);
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { resume: { status: 'generation_started', generation_id: 'test' } }), { code: 'flow_generation_reconcile_required' });
});
test('asset info requires exact full prompt, Nano Banana Pro and square ratio', async t => {
  const f = fixture(t); let promptText = f.item.prompt, metadata = ['Created today', '🍌 Nano Banana Pro', '1:1'];
  const diagnostics = []; f.adapter.captureDiagnostic = async value => diagnostics.push(value);
  let infoVisible = false;
  f.adapter.unique = async spec => spec === f.adapter.selectors.assetInfoButton ? { click: async () => { assert.equal(infoVisible, true); infoVisible = false; } } : {};
  const wait = { waitFor: async () => {} };
  f.adapter.locator = spec => spec === f.adapter.selectors.assetInfoButton ? { waitFor: async options => { assert.equal(options.state, 'visible'); infoVisible = true; } } : spec === f.adapter.selectors.resultMetadata ? { ...wait, first: () => wait, count: async () => metadata.length, nth: index => ({ textContent: async () => metadata[index] }) } : spec === f.adapter.selectors.resultRatio ? { ...wait, first: () => wait, count: async () => 1, nth: () => ({ textContent: async () => metadata.at(-1) }) } : { ...wait, count: async () => 1, isVisible: async () => true, textContent: async () => promptText };
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), true);
  promptText = 'other prompt'; assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), false);
  promptText = f.item.prompt + ' additional correction'; assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), false);
  promptText = f.item.prompt;
  metadata = ['Created today', 'Nano Banana 2 Lite', '1:1']; assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), false);
  metadata = ['Created today', 'Nano Banana Pro', '16:9']; assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), false);
  assert.equal(diagnostics.at(-1).error_code, 'flow_result_metadata_mismatch'); assert.deepEqual(f.adapter.lastResultVerification.actual_ratio_spans, ['16:9']);
  assert.deepEqual(f.adapter.lastResultVerification.actual_metadata, metadata);
  metadata = ['Created today', 'Nano Banana Pro', '9:16'];
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt, undefined, undefined, '9:16'), true);
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt), false);
  metadata=['Created today','🍌 Nano Banana 2.1','1:1'];
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt,undefined,undefined,'1:1','Nano Banana 2.1'),true);
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt),false);
});

test('authorized 2.1 selection verifies exact model; absent authority or changed model stops',async t=>{
 const f=fixture(t);let model='Nano Banana Pro',selected;
 f.adapter.config.model='Nano Banana 2.1';f.adapter.visible=async()=>false;
 f.adapter.locator=()=>({waitFor:async()=>{}});f.page.keyboard={press:async()=>{}};
 f.adapter.unique=async spec=>({click:async()=>{if(spec.role==='menuitem'){selected=spec;model='Nano Banana 2.1';}},getAttribute:async()=>'true',innerText:async()=>model});
 await assert.rejects(f.adapter.configure(),{code:'flow_model_not_authorized'});
 f.adapter.config.modelPolicy={enabled:true,model:'Nano Banana 2.1',reference:'Fixture user'};
 await f.adapter.configure();assert(new RegExp(selected.nameRegex,'u').test('🍌 Nano Banana 2.1'));
 f.adapter.config.model='Nano Banana 2 Lite';await assert.rejects(f.adapter.configure(),{code:'flow_model_not_authorized'});
});

test('quota fallback requires current project/prompt and quota evidence; new identical quota still blocks',async t=>{
 const f=fixture(t),quota='Failed You have reached your usage limit';f.adapter.config.stateDir=f.directory;
 f.adapter.generationFailure=FlowBrowser.prototype.generationFailure;
 f.adapter.readiness=async()=>({ready:true});f.adapter.failedTileTexts=async()=>[quota];
 f.page.screenshot=async({path:file})=>fs.writeFileSync(file,f.png);
 const checkpoint={status:'generation_started',generation_id:'quota-fixture',recovery:{project_url:project,prompt_sha256:hash(f.item.prompt),failure_baseline:[]}};
 const evidence=await f.adapter.resumeAfterQuotaFailure(f.item,checkpoint);assert.deepEqual(evidence.baseline,[quota]);
 assert.equal(evidence.screenshot_sha256,hash(f.png));assert.equal(await f.adapter.generationFailure([quota]),null);
 assert.equal(await f.adapter.generationFailure([quota,quota]),'flow_quota_required');
 await assert.rejects(f.adapter.resumeAfterQuotaFailure(f.item,{...checkpoint,asset:{}}),{code:'flow_model_switch_binding_invalid'});
 f.adapter.failedTileTexts=async()=>['Failed We noticed some unusual activity.'];
 await assert.rejects(f.adapter.resumeAfterQuotaFailure(f.item,checkpoint),{code:'flow_quota_evidence_required'});
});
test('result reference must load and match the exact uploaded ingredient before acquisition', async t => {
  const f = fixture(t), mediaId='28fa3f7b-7344-4b47-9e5d-acee4366e984', ingredient = 'https://flow-content.google/image/'+mediaId;
  let source = ingredient, loaded = false, absent = false;
  f.adapter.captureDiagnostic = async () => {};
  f.adapter.unique = async () => ({ click: async () => {} });
  const wait = { waitFor: async () => {}, first: () => wait };
  f.adapter.locator = spec => {
    if (spec === f.adapter.selectors.resultTile) return {evaluateAll:async()=>[{source,media_id:mediaId,labels:[]}]};
    if (spec === f.adapter.selectors.promptIngredientImage) return {
      count: async () => loaded ? 1 : 0,
      nth: () => ({ waitFor: async () => { if (absent) throw Error('thumbnail unavailable'); loaded = true; }, getAttribute: async () => source })
    };
    if (spec === f.adapter.selectors.resultIngredient) return { count: async () => 1, evaluateAll: async () => ['<flow-ingredient-chip></flow-ingredient-chip>'] };
    if (spec === f.adapter.selectors.resultMetadata) return { ...wait, count: async () => 1, nth: () => ({ textContent: async () => 'Nano Banana Pro' }) };
    if (spec === f.adapter.selectors.resultRatio) return { ...wait, count: async () => 1, nth: () => ({ textContent: async () => '1:1' }) };
    return { ...wait, count: async () => 1, isVisible: async () => true, textContent: async () => f.item.prompt };
  };
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt, 1, [ingredient]), true);
  source='https://flow.google.com/asb/result-proxy=s512-rw';
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt, 1, [ingredient]), true);
  source = 'https://flow-content.google/image/different-reference';
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt, 1, [ingredient]), false);
  absent = true;
  await assert.rejects(f.adapter.verifyResultPrompt(f.item.prompt, 1, [ingredient]), { code: 'flow_reference_thumbnail_unavailable' });
});
test('acquired original recovery checks exact result ID and SHA; no re-download or overwrite', async t => {
  const f = fixture(t), generation = 'fixture-generation';
  const assetPath = path.join(f.directory, generation + '.png'), proofPath = path.join(f.directory, generation + '-flow-proof.png');
  fs.writeFileSync(assetPath, f.png); fs.writeFileSync(proofPath, f.png);
  const acquired = { asset: { path: assetPath, sha256: hash(f.png) }, proof: { screenshot_path: proofPath, screenshot_sha256: hash(f.png), result_identity: 'media-1' } };
  fs.writeFileSync(path.join(f.directory, generation + '-acquired.json'), JSON.stringify(acquired));
  assert.deepEqual(await f.adapter.acquire({ identity: 'media-1' }, f.directory, generation), acquired);
  await assert.rejects(f.adapter.acquire({ identity: 'media-wrong' }, f.directory, generation), { code: 'flow_acquired_record_changed' });
  fs.writeFileSync(assetPath, 'changed-original');
  await assert.rejects(f.adapter.acquire({ identity: 'media-1' }, f.directory, generation), { code: 'flow_acquired_record_changed' });
});
test('crash immediately after saveAs recovers reserved complete original and actual screenshot', async t => {
  const f = fixture(t), generation = 'saved-but-uncheckpointed';
  const assetPath = path.join(f.directory, generation + '.png'), proofPath = path.join(f.directory, generation + '-flow-proof.png');
  fs.writeFileSync(assetPath, f.png); fs.writeFileSync(proofPath, f.png);
  const record = path.join(f.directory, generation + '-acquired.json');
  fs.writeFileSync(record + '.download', JSON.stringify({ generation_id: generation, result_identity: 'media-1', path: assetPath, screenshot_path: proofPath, screenshot_sha256: hash(f.png), url: project }));
  const result = await f.adapter.acquire({ identity: 'media-1' }, f.directory, generation);
  assert.equal(result.asset.sha256, hash(f.png)); assert.equal(result.proof.acquisition.recovered_after_save, true);
  assert.ok(fs.existsSync(record));
  fs.unlinkSync(record); fs.writeFileSync(assetPath, f.png.subarray(0, 25));
  await assert.rejects(f.adapter.acquire({ identity: 'media-1' }, f.directory, generation), { code: 'flow_download_reconcile_required' });
});
test('download receipt records the verified portrait ratio and preserves square default', async t => {
  const f = fixture(t);
  f.adapter.resultTile = async () => ({ hover: async () => {} });
  f.adapter.locator = () => ({ waitFor: async () => {} });
  f.adapter.unique = async () => ({ click: async () => {} });
  f.adapter.verifyResultPrompt = async (_prompt, _count, _refs, ratio) => { assert.equal(ratio, '9:16'); return true; };
  f.page.screenshot = async ({ path: file }) => fs.writeFileSync(file, f.png);
  f.page.keyboard = { press: async () => {} };
  f.page.waitForEvent = async () => ({ failure: async () => null, suggestedFilename: () => 'original.png', saveAs: async file => fs.writeFileSync(file, f.png) });
  const portrait = await f.adapter.acquire({ identity: 'portrait', expected_prompt: f.item.prompt, aspect_ratio: '9:16' }, f.directory, 'portrait');
  assert.equal(portrait.proof.returned_ratio, '9:16');
  const square = await f.adapter.acquire({ identity: 'square' }, f.directory, 'square');
  assert.equal(square.proof.returned_ratio, '1:1');
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.directory, 'portrait-acquired.json.download'))).verified_result.returned_ratio, '9:16');
});
test('reference selection waits for delayed auto-attach without requiring an Add button',async t=>{
  const f=fixture(t);let count=2,adds=0,readyWaits=0;
  f.adapter.locator=spec=>spec===f.adapter.selectors.referenceChip?{count:async()=>count}:spec===f.adapter.selectors.readyReferenceChip?
    {nth:index=>{assert.equal(index,2);return {waitFor:async()=>{readyWaits++;await Promise.resolve();count=3;}};}}:
    {waitFor:async()=>new Promise(()=>{})};
  f.adapter.unique=async()=>{adds++;throw Error('Add button vanished');};
  await f.adapter.attachSelectedReference(2);
  assert.equal(count,3);assert.equal(adds,0);assert.ok(readyWaits>=1);
});

test('reference selection reconciles Add disappearing between observation and click',async t=>{
  const f=fixture(t);let count=2,waits=0,adds=0,attach;
  const ready=new Promise(resolve=>{attach=resolve;});
  f.adapter.locator=spec=>spec===f.adapter.selectors.referenceChip?{count:async()=>count}:spec===f.adapter.selectors.readyReferenceChip?
    {nth:()=>({waitFor:async()=>{waits++;await ready;}})}:{waitFor:async()=>{}};
  f.adapter.unique=async()=>{adds++;count=3;attach();throw Object.assign(Error('Expected exactly one visible Flow control'),{code:'flow_ui_changed'});};
  await f.adapter.attachSelectedReference(2);
  assert.equal(count,3);assert.equal(adds,1);assert.ok(waits>=2);
});

test('reference selection still rejects missing or duplicate ingredients',async t=>{
  const f=fixture(t);let count=2;
  const timeout=()=>{throw Object.assign(Error('No chip or Add control'),{name:'TimeoutError'});};
  f.adapter.locator=spec=>spec===f.adapter.selectors.referenceChip?{count:async()=>count}:spec===f.adapter.selectors.readyReferenceChip?{nth:()=>({waitFor:async()=>timeout()})}:{waitFor:async()=>timeout()};
  await assert.rejects(f.adapter.attachSelectedReference(2),{name:'TimeoutError'});
  count=4;f.adapter.locator=spec=>spec===f.adapter.selectors.referenceChip?{count:async()=>count}:{nth:()=>({waitFor:async()=>{}})};
  await assert.rejects(f.adapter.attachSelectedReference(2),{code:'flow_reference_upload_unconfirmed'});
});

test('reference cache reuses exact project asset after restart, uploads on miss, rejects changed bytes and identity',async t=>{
  const f=fixture(t),refPath=path.join(f.directory,'locked.png');fs.writeFileSync(refPath,f.png);
  const ref={path:refPath,sha256:hash(f.png)};f.adapter.config.profileDir=f.directory;
  let chips=0,uploads=0,label,available=false,pickerReady=false,delayedAutoAttach=false,pendingAttach=false,missingCachedThumbnail=false,alwaysMissingThumbnail=false,currentProject=project,src='https://flow.google.com/asb/locked-cache-reference=s512-rw';
  const canonical='https://flow-content.google/image/28fa3f7b-7344-4b47-9e5d-acee4366e984';
  let unstable=0,clicks=0,alreadyAttached=false,alreadySelected=false,pickerSource=src,galleryMissing=false;
  f.page.url=()=>currentProject;f.page.keyboard={press:async()=>{}};
  f.page.waitForFunction=async()=>{};
  f.page.waitForEvent=async()=>({setFiles:async file=>{uploads++;label=path.basename(file)+' Image';available=true;missingCachedThumbnail=false;}});
  f.page.getByRole=(_role,options)=>({locator:()=>({waitFor:async()=>{},getAttribute:async()=>pickerSource}),count:async()=>pickerReady&&available&&options.name===label?1:0,isVisible:async()=>available,waitFor:async()=>{},getAttribute:async()=>alreadySelected?'true':'false',click:async()=>{
    clicks++;
    if(unstable>0){unstable--;if(alreadyAttached)chips++;throw Object.assign(Error('element is not stable; element was detached from the DOM'),{name:'TimeoutError'});}
    if(delayedAutoAttach)pendingAttach=true;
  }});
  const bind=adapter=>{
    adapter.referenceOptionReady=async()=>true;
    adapter.visible=async spec=>spec===adapter.selectors.clearPrompt;
    adapter.unique=async spec=>{if(spec===adapter.selectors.addToPrompt&&delayedAutoAttach)throw Object.assign(Error('Add button removed during asynchronous auto-attach'),{code:'flow_ui_changed'});return {click:async()=>{if(spec===adapter.selectors.clearPrompt)chips=0;if(spec===adapter.selectors.uploadButton)pickerReady=false;if(spec===adapter.selectors.addToPrompt)chips++;}};};
    adapter.locator=spec=>({evaluate:async()=>({scrollable:false}),evaluateAll:async()=>galleryMissing?[]:[{source:pickerSource,media_id:canonical.split('/').at(-1),labels:[label?.replace(/ Image$/,'')]}],count:async()=>spec===adapter.selectors.referenceChip?chips:1,waitFor:async()=>{if(spec===adapter.selectors.assetList)pickerReady=true;},nth:()=>({waitFor:async()=>{if(spec===adapter.selectors.readyReferenceChip&&pendingAttach){await Promise.resolve();chips++;pendingAttach=false;}},getAttribute:async()=>{if(missingCachedThumbnail||alwaysMissingThumbnail)throw Object.assign(Error('cached chip has no image'),{name:'TimeoutError'});return src;}})});
    adapter.captureDiagnostic=async()=>{};
  };
  bind(f.adapter);
  await f.adapter.upload([ref]);assert.equal(uploads,1);assert.equal(f.adapter.lastReferenceTransfers[0].method,'upload');
  const restarted=new FlowBrowser(f.adapter.config,{page:f.page});bind(restarted);
  await restarted.upload([ref]);assert.equal(uploads,1);assert.equal(restarted.lastReferenceTransfers[0].method,'existing_project_asset');
  src=pickerSource='https://flow.google.com/asb/refreshed-same-asset=s512-rw';
  await restarted.upload([ref]);assert.equal(uploads,1);assert.equal(chips,1);
  assert.equal(restarted.lastReferenceTransfers[0].identity,canonical);
  src=canonical;await restarted.upload([ref]);assert.equal(uploads,1);assert.equal(chips,1);
  pickerSource='https://flow.google.com/asb/another-token=s256-rw';await restarted.upload([ref]);assert.equal(uploads,1);
  galleryMissing=true;pickerSource='https://flow.google.com/asb/virtualized-original=s512-rw';
  await restarted.upload([ref]);assert.equal(uploads,1);galleryMissing=false;
  const recovered=new FlowBrowser(f.adapter.config,{page:f.page});recovered.locator=()=>({evaluateAll:async()=>[]});
  assert.equal(await recovered.referenceIdentity(pickerSource),canonical);
  let start=clicks;unstable=1;await restarted.upload([ref]);assert.equal(clicks-start,2);assert.equal(uploads,1);assert.equal(chips,1);
  start=clicks;unstable=1;alreadyAttached=true;await restarted.upload([ref]);assert.equal(clicks-start,1);assert.equal(chips,1);assert.equal(uploads,1);alreadyAttached=false;
  start=clicks;unstable=1;alreadySelected=true;await restarted.upload([ref]);assert.equal(clicks-start,1);assert.equal(chips,1);assert.equal(uploads,1);alreadySelected=false;
  start=clicks;unstable=2;await assert.rejects(restarted.upload([ref]),{name:'TimeoutError',code:'flow_upload_ui_failed'});assert.equal(clicks-start,2);assert.equal(uploads,1);
  delayedAutoAttach=true;await restarted.upload([ref]);assert.equal(uploads,1);assert.equal(chips,1);assert.equal(pendingAttach,false);
  delayedAutoAttach=false;
  available=false;await restarted.upload([ref]);assert.equal(uploads,2); // Missing/virtualized asset: ordinary upload fallback.
  currentProject='https://flow.google.com/project/another-project';await restarted.upload([ref]);assert.equal(uploads,3);
  src='https://flow-content.google/image/wrong-identity';
  await assert.rejects(restarted.upload([ref]),{code:'flow_reference_reuse_unverified'});assert.equal(uploads,3);
  src=pickerSource='https://flow.google.com/asb/locked-cache-reference=s512-rw';missingCachedThumbnail=true;
  await restarted.upload([ref]);assert.equal(uploads,4);assert.equal(chips,1);assert.equal(restarted.lastReferenceTransfers[0].method,'upload');
  alwaysMissingThumbnail=true;
  await assert.rejects(restarted.upload([ref]),{code:'flow_upload_ui_failed'});assert.equal(uploads,5); // Only one fresh-upload fallback; never recurse on that upload failure.
  fs.writeFileSync(refPath,'changed bytes');await assert.rejects(restarted.upload([ref]),{code:'flow_reference_hash_changed'});assert.equal(uploads,5);
});

test('reference upload clears old ingredients, stages exact bytes under unique filename and confirms ready chip', async t => {
  const f = fixture(t), refPath = path.join(f.directory, 'same-name.png'); fs.writeFileSync(refPath, f.png);
  let chipCount = 1, uploaded, optionName, fileCopy, clear = 0;
  f.page.waitForEvent = async () => ({ setFiles: async p => { fileCopy = p; uploaded = fs.readFileSync(p); } });
  f.page.waitForFunction = async () => { assert.equal(chipCount, 0); };
  f.page.getByRole = (role, options) => { assert.equal(role, 'option'); optionName = options.name; return { count: async () => 1, waitFor: async () => {}, click: async () => {} }; };
  f.adapter.visible = async spec => spec === f.adapter.selectors.clearPrompt;
  f.adapter.unique = async spec => ({ click: async () => {
    if (spec === f.adapter.selectors.clearPrompt) { chipCount = 0; clear++; }
    if (spec === f.adapter.selectors.addToPrompt) chipCount++;
  } });
  f.adapter.locator = spec => ({ count: async () => spec === f.adapter.selectors.referenceChip ? chipCount : 1,
    waitFor: async () => {}, nth: index => ({ waitFor: async () => { assert.equal(index, 0); } }) });
  await f.adapter.upload([{ path: refPath, sha256: hash(f.png) }]);
  assert.equal(clear, 1); assert.equal(chipCount, 1); assert.equal(hash(uploaded), hash(f.png));
  assert.notEqual(path.basename(fileCopy), 'same-name.png'); assert.equal(optionName, path.basename(fileCopy) + ' Image');
  assert.equal(fs.existsSync(fileCopy), false); assert.equal(hash(fs.readFileSync(refPath)), hash(f.png));
});

test('unstable asset selection never uploads on a retry miss or hides ambiguous and unrelated failures',async t=>{
  const f=fixture(t);let opens=0,escapes=0,finds=0;
  const failure=Object.assign(Error('element was detached from the DOM'),{name:'TimeoutError'});
  const option={click:async()=>{throw failure;},count:async()=>0};
  f.adapter.locator=()=>({count:async()=>0,waitFor:async()=>{}});
  f.adapter.unique=async()=>({click:async()=>{opens++;}});
  f.page.keyboard={press:async()=>{escapes++;}};
  f.adapter.findCachedReference=async({label})=>{assert.equal(label,'exact Image');finds++;return null;};
  await assert.rejects(f.adapter.selectReferenceOption(option,'exact Image',0),error=>error===failure);
  assert.equal(opens,1);assert.equal(escapes,1);assert.equal(finds,1);
  f.adapter.findCachedReference=async()=>{throw Object.assign(Error('duplicate exact labels'),{code:'flow_reference_cache_ambiguous'});};
  await assert.rejects(f.adapter.selectReferenceOption(option,'exact Image',0),{code:'flow_reference_cache_ambiguous'});
  const prior=opens;
  await assert.rejects(f.adapter.selectReferenceOption({click:async()=>{throw Object.assign(Error('browser closed'),{name:'TimeoutError'});}},'exact Image',0),{message:'browser closed'});
  assert.equal(opens,prior);
});

test('fresh upload reselects its exact staged asset after picker rerender without uploading twice',async t=>{
  const f=fixture(t),file=path.join(f.directory,'fresh.png');fs.writeFileSync(file,f.png);
  let uploads=0,clicks=0,chips=0,label;
  f.adapter.visible=async()=>false;
  f.page.keyboard={press:async()=>{}};
  f.page.waitForEvent=async()=>({setFiles:async p=>{uploads++;label=path.basename(p)+' Image';}});
  f.page.getByRole=(_role,options)=>({count:async()=>options.name===label?1:0,isVisible:async()=>true,waitFor:async()=>{},getAttribute:async()=> 'false',click:async()=>{
    if(++clicks===1)throw Object.assign(Error('element is not stable'),{name:'TimeoutError'});
    chips++;
  }});
  f.adapter.locator=spec=>({count:async()=>spec===f.adapter.selectors.referenceChip?chips:1,waitFor:async()=>{},nth:()=>({waitFor:async()=>{}})});
  f.adapter.unique=async()=>({click:async()=>{}});
  await f.adapter.upload([{path:file,sha256:hash(f.png)}]);
  assert.equal(uploads,1);assert.equal(clicks,2);assert.equal(chips,1);
});

test('upload timeout captures its exact step and dismisses the asset picker before another attempt',async t=>{
  const f=fixture(t),ref=path.join(f.directory,'reference.png');fs.writeFileSync(ref,f.png);
  let escaped=0,diagnostic;
  f.page.waitForEvent=async()=>({});f.page.keyboard={press:async key=>{assert.equal(key,'Escape');escaped++;}};
  f.adapter.visible=async spec=>spec===f.adapter.selectors.assetList;
  f.adapter.locator=()=>({count:async()=>0,waitFor:async()=>{throw Object.assign(Error('upload control timeout'),{name:'TimeoutError'});}});
  f.adapter.unique=async()=>({click:async()=>{}});f.adapter.captureDiagnostic=async details=>{diagnostic={...details,ui_stage:f.adapter.uiStage};};
  await assert.rejects(f.adapter.upload([{path:ref,sha256:hash(f.png)}]),{code:'flow_upload_ui_failed'});
  assert.equal(escaped,1);assert.equal(diagnostic.ui_stage,'upload.open_picker');assert.equal(diagnostic.error_message,'upload control timeout');
});
test('selecting the exact uploaded asset may attach immediately without an Add button',async t=>{
  const f=fixture(t),ref=path.join(f.directory,'reference.png');fs.writeFileSync(ref,f.png);let count=0,added=0;
  f.adapter.visible=async()=>false;
  f.page.waitForEvent=async()=>({setFiles:async()=>{}});
  f.page.getByRole=()=>({waitFor:async()=>{},count:async()=>1,click:async()=>{count++;}});
  f.adapter.unique=async spec=>{if(spec===f.adapter.selectors.addToPrompt){added++;throw Error('Add button is absent after auto-attach');}return {click:async()=>{}};};
  f.adapter.locator=spec=>({count:async()=>spec===f.adapter.selectors.referenceChip?count:1,waitFor:async()=>{},nth:()=>({waitFor:async()=>{}})});
  await f.adapter.upload([{path:ref,sha256:hash(f.png)}]);assert.equal(count,1);assert.equal(added,0);
});

test('configure dismisses a stale asset picker and waits for it to close before changing settings',async t=>{
  for (const visibleControl of ['assetList','uploadFile',null]) {
    const f=fixture(t);let escaped=0,hidden=0;
    f.adapter.config.model='unauthorized-model';f.adapter.visible=async spec=>visibleControl!==null&&spec===f.adapter.selectors[visibleControl];
    f.page.keyboard={press:async key=>{assert.equal(key,'Escape');escaped++;}};
    f.adapter.locator=spec=>({waitFor:async options=>{assert.ok([f.adapter.selectors.assetList,f.adapter.selectors.uploadFile].includes(spec));assert.equal(options.state,'hidden');hidden++;}});
    f.adapter.captureDiagnostic=async()=>{};
    await assert.rejects(f.adapter.configure(),{code:'flow_model_not_authorized'});assert.equal(escaped,visibleControl?1:0);assert.equal(hidden,visibleControl?2:0);
  }
});
test('empty picker is dismissed after upload failure while retaining the original blocker', async t => {
  const f=fixture(t),ref=path.join(f.directory,'reference.png');fs.writeFileSync(ref,f.png);let escaped=0;
  f.adapter.visible=async spec=>spec===f.adapter.selectors.uploadFile;
  f.page.keyboard={press:async()=>{escaped++;}};
  f.adapter.unique=async()=>({click:async()=>{throw new Error('original upload failure');}});
  f.page.waitForEvent=async()=>({});
  f.adapter.locator=()=>({count:async()=>0,waitFor:async options=>{assert.equal(options.state,'hidden');}});
  f.adapter.captureDiagnostic=async()=>{};
  await assert.rejects(f.adapter.upload([{path:ref,sha256:hash(f.png)}]),{message:'original upload failure',code:'flow_upload_ui_failed'});
  assert.equal(escaped,1);
});
test('picker that remains open stops configuration before any Settings click', async t => {
  const f=fixture(t);let clicks=0;
  f.adapter.visible=async spec=>spec===f.adapter.selectors.uploadFile;f.page.keyboard={press:async()=>{}};
  f.adapter.locator=()=>({waitFor:async()=>{throw Object.assign(new Error('picker remains open'),{name:'TimeoutError'});}});
  f.adapter.unique=async()=>{clicks++;};f.adapter.captureDiagnostic=async()=>{};
  await assert.rejects(f.adapter.configure(),{code:'flow_configuration_ui_failed',message:'picker remains open'});assert.equal(clicks,0);
});
test('retry recovers a late completed image without another Generate and keeps unknown outcomes blocked',async t=>{
 const f=fixture(t),prior={status:'generation_started',generation_id:'prior',recovery:{baseline:[],project_url:project,prompt_sha256:hash(f.item.prompt)}};
 let acquired=0,checkpoints=0;f.adapter.ensureProject=async()=>{};
 f.adapter.configure=async()=>{throw Error('must not configure or Generate');};
 f.adapter.recover=async(recovery,prompt,options)=>{assert.deepEqual(recovery,prior.recovery);assert.equal(prompt,f.item.prompt);assert.equal(options.completedOnly,true);return {identity:'late-result'};};
 f.adapter.acquire=async(result,_dir,id)=>{assert.equal(result.identity,'late-result');assert.equal(id,'prior');acquired++;return {generation_id:id};};
 const hooks={resume:{status:'ready',retry_permit_id:'permit'},retryRecovery:prior,beforeGenerate:async()=>{throw Error('duplicate Generate');},checkpoint:async e=>{assert.equal(e.generation_id,'prior');assert.equal(e.event,'acquired');checkpoints++;}};
 await f.adapter.generate(f.item,[],f.directory,hooks);assert.equal(acquired,1);assert.equal(checkpoints,1);
 f.adapter.recover=async()=>{throw Object.assign(Error('login'),{code:'flow_login_required'});};
 await assert.rejects(f.adapter.generate(f.item,[],f.directory,hooks),{code:'flow_login_required'});assert.equal(acquired,1);
 await assert.rejects(f.adapter.generate(f.item,[],f.directory,{...hooks,retryRecovery:{...prior,generation_id:'invalid/id'}}),{code:'flow_generation_reconcile_required'});
});

test('completed-only recovery returns absent only after checking candidates and keeps fresh failures blocked',async t=>{
 const f=fixture(t);f.adapter.readiness=async()=>({ready:true});f.adapter.results=async()=>[];
 const recovery={baseline:[],project_url:project,prompt_sha256:hash(f.item.prompt)};
 assert.equal(await f.adapter.recover(recovery,f.item.prompt,{completedOnly:true}),null);
 f.adapter.generationFailure=async()=>'flow_policy_review_required';
 await assert.rejects(f.adapter.recover(recovery,f.item.prompt,{completedOnly:true}),{code:'flow_policy_review_required'});
});

test('reserved download keeps its exact image when recovery finds multiple verified equivalents',async t=>{
 const f=fixture(t),generation='reserved-equivalent',assetPath=path.join(f.directory,generation+'.png'),proofPath=path.join(f.directory,generation+'-flow-proof.png');
 fs.writeFileSync(assetPath,f.png);fs.writeFileSync(proofPath,f.png);
 const record=path.join(f.directory,generation+'-acquired.json');
 fs.writeFileSync(record+'.download',JSON.stringify({generation_id:generation,result_identity:'reserved-z',path:assetPath,screenshot_path:proofPath,screenshot_sha256:hash(f.png),url:project}));
 await assert.rejects(f.adapter.acquire({identity:'other-a'},f.directory,generation),{code:'flow_download_reservation_changed'});
 const result=await f.adapter.acquire({identity:'other-a',equivalent_result_identities:['other-a','reserved-z']},f.directory,generation);
 assert.equal(result.proof.result_identity,'reserved-z');assert.equal(result.asset.sha256,hash(f.png));
 assert.deepEqual(await f.adapter.acquire({identity:'other-a',equivalent_result_identities:['other-a','reserved-z']},f.directory,generation),result);
});

test('equivalent verified results resolve deterministically while mismatches are excluded', async t => {
  const f = fixture(t); f.adapter.readiness = async () => ({ ready: true });
  f.adapter.results = async () => [{ identity: 'new-2', index: 0 }, { identity: 'wrong', index: 1 }, { identity: 'new-1', index: 2 }];
  let current;
  f.adapter.resultTile = async candidate => { current = candidate.identity; return {}; };
  f.adapter.unique = async () => ({ click: async () => {} });
  f.adapter.verifyResultPrompt = async () => current !== 'wrong';
  f.page.keyboard = { press: async () => {} };
  const result = await f.adapter.recover({ baseline: [], project_url: project, prompt_sha256: hash(f.item.prompt) }, f.item.prompt);
  assert.equal(result.identity, 'new-1'); assert.deepEqual(result.equivalent_result_identities, ['new-1', 'new-2']);
  assert.equal(result.expected_prompt, f.item.prompt);
});

test('recovery handles Escape returning to the bound project and still uses Back when it only closes Asset info', async t => {
  for (const escapeTarget of [project, project + '/edit/result', project + '-other']) {
    const f = fixture(t); let url = project, backClicks = 0;
    f.page.url = () => url;
    f.page.keyboard = { press: async () => { url = escapeTarget; } };
    f.adapter.readiness = async () => ({ ready: true });
    f.adapter.results = async () => [{ identity: 'matched' }];
    f.adapter.resultTile = async () => ({});
    f.adapter.unique = async spec => ({ click: async () => {
      if (spec === f.adapter.selectors.back) { assert.equal(url, project + '/edit/result'); backClicks++; url = project; }
      else url = project + '/edit/result';
    } });
    f.adapter.verifyResultPrompt = async () => true;
    const recovery = { project_url: project, baseline: [], prompt_sha256: hash(f.item.prompt) };
    if (escapeTarget === project + '-other') await assert.rejects(f.adapter.recover(recovery, f.item.prompt), { code: 'flow_generation_project_binding_changed' });
    else assert.equal((await f.adapter.recover(recovery, f.item.prompt)).identity, 'matched');
    assert.equal(backClicks, escapeTarget === project + '/edit/result' ? 1 : 0);
  }
});
test('historical recovery pages through virtualized gallery and still verifies exact locked references',async t=>{
  const f=fixture(t);let page=0,current,pages=0;const verified=[];
  f.adapter.readiness=async()=>({ready:true});
  f.adapter.oldestRecoveryPage=async()=>{};
  f.adapter.results=async()=>[{identity:page===0?'unrelated-mockup':'old-embroidery'}];
  f.adapter.resultTile=async candidate=>{current=candidate.identity;return {};};
  f.adapter.unique=async()=>({click:async()=>{}});f.page.keyboard={press:async()=>{}};
  f.adapter.nextRecoveryPage=async()=>{pages++;page++;return true;};
  f.adapter.verifyResultPrompt=async(prompt,count,refs)=>{assert.equal(prompt,f.item.prompt);assert.equal(count,1);assert.deepEqual(refs,['exact-locked-reference']);verified.push(current);return current==='old-embroidery';};
  const result=await f.adapter.recover({project_url:project,baseline:[],started_at:'2020-01-01T00:00:00Z',prompt_sha256:hash(f.item.prompt),reference_count:1,ingredient_identities:['exact-locked-reference']},f.item.prompt);
  assert.equal(result.identity,'old-embroidery');assert.equal(pages,1);assert.deepEqual(verified,['unrelated-mockup','old-embroidery']);
});

test('reconciliation retry skips rejected assets but rechecks a matching result if download must resume',async t=>{
  const f=fixture(t);let ready=false,current,wrongChecks=0,matchChecks=0;
  f.adapter.readiness=async()=>({ready:true});f.adapter.captureDiagnostic=async()=>{};
  f.adapter.results=async()=>ready?[{identity:'wrong'},{identity:'match'}]:[{identity:'wrong'}];
  f.adapter.resultTile=async candidate=>{current=candidate.identity;return {};};
  f.adapter.unique=async()=>({click:async()=>{}});f.page.keyboard={press:async()=>{}};
  f.page.waitForFunction=async()=>{throw Error('fixture timeout');};
  f.adapter.verifyResultPrompt=async()=>{if(current==='wrong'){wrongChecks++;return false;}matchChecks++;return true;};
  const recovery={project_url:project,baseline:[],prompt_sha256:hash(f.item.prompt)};
  await assert.rejects(f.adapter.recover(recovery,f.item.prompt),{code:'flow_generation_reconcile_required'});
  ready=true;assert.equal((await f.adapter.recover(recovery,f.item.prompt)).identity,'match');
  assert.equal((await f.adapter.recover(recovery,f.item.prompt)).identity,'match');
  assert.equal(wrongChecks,1);assert.equal(matchChecks,2);
});

test('recovery scroll uses the observed gallery and stops at its bottom without wrapping',async t=>{
  const f=fixture(t);let top=0,wheels=0;
  const gallery={evaluate:async()=>({top,height:1000,total:2000}),hover:async()=>{}};
  f.adapter.unique=async selector=>{assert.equal(selector,f.adapter.selectors.recoveryGallery);return gallery;};
  f.page.mouse={wheel:async(x,y)=>{assert.equal(x,0);assert.equal(y,800);wheels++;top+=y;}};
  f.page.waitForFunction=async(_fn,args)=>{assert.equal(args.top,0);assert.equal(args.selector,'.cdk-virtual-scrollable.page-container');};
  assert.equal(await f.adapter.nextRecoveryPage(),true);top=1000;
  assert.equal(await f.adapter.nextRecoveryPage(),false);assert.equal(wheels,1);
});

test('old recovery jumps to the oldest gallery page and searches toward newer assets',async t=>{
  const f=fixture(t);let top=0;const deltas=[];
  const gallery={evaluate:async()=>({top,height:1000,total:4000}),hover:async()=>{}};
  f.adapter.unique=async()=>gallery;
  f.page.mouse={wheel:async(_x,y)=>{deltas.push(y);top=Math.max(0,Math.min(3000,top+y));}};
  f.page.waitForFunction=async()=>{};
  await f.adapter.oldestRecoveryPage();assert.equal(top,3000);
  assert.equal(await f.adapter.nextRecoveryPage(-1),true);assert.equal(top,2200);assert.deepEqual(deltas,[4000,-800]);
});

test('unavailable reference on an unrelated candidate does not block the search or get permanently rejected',async t=>{
  const f=fixture(t);let current,loaded=false,checks=0;
  f.adapter.readiness=async()=>({ready:true});f.adapter.results=async()=>loaded?[{identity:'temporarily-unverifiable'}]:[{identity:'temporarily-unverifiable'},{identity:'verified'}];
  f.adapter.resultTile=async candidate=>{current=candidate.identity;return {};};
  f.adapter.unique=async()=>({click:async()=>{}});f.page.keyboard={press:async()=>{}};
  f.adapter.verifyResultPrompt=async()=>{if(current==='temporarily-unverifiable'){checks++;if(!loaded)throw Object.assign(Error('reference unavailable'),{code:'flow_reference_thumbnail_unavailable'});}return true;};
  const recovery={project_url:project,baseline:[],prompt_sha256:hash(f.item.prompt)};
  assert.equal((await f.adapter.recover(recovery,f.item.prompt)).identity,'verified');loaded=true;
  assert.equal((await f.adapter.recover(recovery,f.item.prompt)).identity,'temporarily-unverifiable');assert.equal(checks,2);
});
test('gallery reorder never changes the result selected for verification or download', async t => {
  const f = fixture(t); let selector, matches = 1;
  const tile = { waitFor: async () => {}, count: async () => matches };
  f.page.locator = value => { selector = value; return { observedImage: value }; };
  f.adapter.locator = () => ({ filter: ({ has }) => { assert.equal(has.observedImage, selector); return tile; }, nth: () => { throw Error('stale gallery index must not be used'); } });
  assert.equal(await f.adapter.resultTile({ identity: 'exact-new-image', index: 7 }), tile);
  assert.equal(selector, 'img[data-media-id][data-media-id="exact-new-image"]');
  matches = 2;
  await assert.rejects(f.adapter.resultTile({ identity: 'exact-new-image', index: 7 }), { code: 'flow_result_identity_ambiguous' });
});
test('gallery includes unmarked images for full asset-info verification instead of relying on hover buttons', async t => {
  const f = fixture(t), entries = [{ identity: 'generated', generated: true }, { identity: 'uploaded-reference', generated: false }];
  let observedRole;
  f.adapter.locator(f.adapter.selectors.generatedTileMarker, { getByRole: (_role, options) => { observedRole = options; } });
  assert.equal(observedRole.includeHidden, true); // Flow reveals this control only on hover.
  const tiles = entries.map(entry => ({
    isConnected: true, ownerDocument: { defaultView: { getComputedStyle: () => ({ visibility: 'visible' }) } },
    getBoundingClientRect: () => ({ width: 100, height: 100 }), getClientRects: () => [1], innerText: entry.identity,
    querySelectorAll: selector => { assert.equal(selector, 'img[data-media-id]'); return [{ complete: true, naturalWidth: 100, getAttribute: () => entry.identity }]; },
  }));
  f.adapter.locator = spec => { assert.equal(spec, f.adapter.selectors.resultTile); return { evaluateAll: async (callback, options) => callback(tiles, options) }; };
  assert.deepEqual((await f.adapter.results()).map(r => r.identity), ['generated', 'uploaded-reference']);
});
test('Generate readiness waits for actionability without sending or forcing a request', async t => {
  const f = fixture(t); let enabled = false, trials = 0;
  const button = { click: async options => { assert.equal(options.trial, true); assert.equal(options.force, undefined); assert.equal(options.timeout, f.adapter.timeout); trials++; enabled = true; }, isEnabled: async () => enabled };
  f.adapter.unique = async () => button;
  assert.equal(await FlowBrowser.prototype.waitForGenerate.call(f.adapter), button); assert.equal(trials, 1); assert.equal(enabled, true);
  button.click = async () => { throw Object.assign(Error('still disabled'), { name: 'TimeoutError' }); };
  enabled = false; f.adapter.readiness = async () => ({ ready: true });
  await assert.rejects(FlowBrowser.prototype.waitForGenerate.call(f.adapter), { code: 'flow_generate_disabled' });
  f.adapter.readiness = async () => ({ ready: false, code: 'flow_login_required' });
  await assert.rejects(FlowBrowser.prototype.waitForGenerate.call(f.adapter), { code: 'flow_login_required' });
});
test('Generate readiness restores an asynchronously emptied composer once without a real click', async t => {
  const f=fixture(t);let actual='',fills=0,trials=0;
  const prompt={innerText:async()=>actual,fill:async value=>{fills++;actual=value;}};
  const button={click:async options=>{assert.equal(options.trial,true);trials++;if(!actual)throw Error('disabled');},isEnabled:async()=>!!actual};
  f.adapter.unique=async spec=>spec===f.adapter.selectors.prompt?prompt:button;
  f.adapter.readiness=async()=>({ready:true});f.adapter.waitForGenerate=FlowBrowser.prototype.waitForGenerate;
  assert.equal(await f.adapter.waitForGenerate(f.item.prompt),button);
  assert.equal(fills,1);assert.equal(trials,2);assert.equal(actual,f.item.prompt);
});

test('Generate readiness never repeatedly fills, overwrites nonempty text, or bypasses login', async t => {
  const f=fixture(t);let actual='',fills=0;
  const prompt={innerText:async()=>actual,fill:async value=>{fills++;actual=value;}};
  const button={click:async options=>{assert.equal(options.trial,true);throw Error('disabled');},isEnabled:async()=>false};
  f.adapter.unique=async spec=>spec===f.adapter.selectors.prompt?prompt:button;
  f.adapter.readiness=async()=>({ready:true});f.adapter.waitForGenerate=FlowBrowser.prototype.waitForGenerate;
  await assert.rejects(f.adapter.waitForGenerate(f.item.prompt),{code:'flow_generate_disabled'});assert.equal(fills,1);
  actual='Other visible text';await assert.rejects(f.adapter.waitForGenerate(f.item.prompt),{code:'flow_generate_disabled'});assert.equal(fills,1);
  actual='';f.adapter.readiness=async()=>({ready:false,code:'flow_login_required'});
  await assert.rejects(f.adapter.waitForGenerate(f.item.prompt),{code:'flow_login_required'});assert.equal(fills,1);
});

test('click timeout recovers a verified completed image in the same attempt with exactly one real click', async t => {
  const f = fixture(t); const events = []; let clicks = 0, recoveries = 0;
  f.adapter.ensureProject = f.adapter.configure = f.adapter.upload = async () => {};
  f.adapter.results = async () => []; f.adapter.locator = () => ({ count: async () => 0 });
  f.adapter.unique = async spec => spec === f.adapter.selectors.prompt ? { fill: async () => {}, innerText: async () => f.item.prompt } : { click: async options => { assert.equal(options.noWaitAfter, true); assert.ok(options.timeout <= 5000); clicks++; throw Object.assign(Error('accepted then timeout'), { name: 'TimeoutError' }); } };
  f.adapter.recover = async () => { recoveries++; return { identity: 'confirmed-result' }; };
  f.adapter.acquire = async r => ({ asset: { path: r.identity }, proof: {} });
  const result = await f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async () => events.push('beforeGenerate'), checkpoint: async r => events.push(r.event) });
  assert.equal(clicks, 1); assert.equal(recoveries, 1); assert.equal(result.asset.path, 'confirmed-result');
  assert.deepEqual(events, ['beforeGenerate', 'generation_click_uncertain', 'acquired']);
});
test('an uploaded image without a generated prompt cannot be accepted as a recovery match', async t => {
  const f = fixture(t), panel = {};let model='Created today',promptWaits=0;
  f.adapter.unique = async spec => spec === f.adapter.selectors.assetInfoButton ? { click: async () => {} } : panel;
  const wait={waitFor:async()=>{},first:()=>wait};
  f.adapter.locator = spec => spec===f.adapter.selectors.resultMetadata||spec===f.adapter.selectors.resultRatio ? {
    ...wait,count:async()=>1,nth:()=>({textContent:async()=>spec===f.adapter.selectors.resultMetadata?model:'1:1'})
  } : {waitFor:async()=>{if(spec===f.adapter.selectors.exactResultPrompt){promptWaits++;throw Object.assign(Error('upload has no prompt'),{name:'TimeoutError'});}}};
  f.adapter.captureDiagnostic = async () => {};
  assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt, 0, []), false);
  assert.equal(promptWaits,0);
  model='Nano Banana Pro';assert.equal(await f.adapter.verifyResultPrompt(f.item.prompt,0,[]),false);assert.equal(promptWaits,1);
});
test('readiness waits for observed app control after DOMContentLoaded shell without fixed sleep', async t => {
  const f = fixture(t); let rendered = false, waits = 0;
  f.adapter.visible = async selector => rendered && selector === f.adapter.selectors.prompt;
  f.page.waitForFunction = async (_predicate, args, options) => { waits++; assert.equal(args.prompt, f.adapter.selectors.prompt); assert.ok(new RegExp(args.newProject.nameRegex).test('New project')); assert.ok(new RegExp(args.newProject.nameRegex).test('Dự án mới')); assert.equal(options.timeout, f.adapter.timeout); rendered = true; };
  assert.deepEqual(await f.adapter.readiness(), { ready: true }); assert.equal(waits, 1);
  await f.adapter.readiness(); assert.equal(waits, 1);
});
test('unrendered app still blocks after bounded condition wait; redirect requires login', async t => {
  const f = fixture(t); f.adapter.visible = async () => false;
  f.page.waitForFunction = async () => { throw Error('timeout'); };
  assert.deepEqual(await f.adapter.readiness(), { ready: false, code: 'flow_ui_changed' });
  f.page.waitForFunction = async () => { f.page.url = () => 'https://accounts.google.com/signin'; };
  assert.deepEqual(await f.adapter.readiness(), { ready: false, code: 'flow_login_required' });
});
test('configure skips selected Image radio and waits visible controls before configuring', async t => {
  const f = fixture(t); let imageClicks = 0, waits = 0, selected = true;
  f.adapter.visible = async () => false;
  f.page.keyboard = { press: async () => {} };
  f.adapter.locator = () => ({ waitFor: async () => { waits++; } });
  f.adapter.unique = async spec => ({ click: async () => { if (spec === f.adapter.selectors.imageMode) imageClicks++; },
    getAttribute: async () => spec === f.adapter.selectors.imageMode ? String(selected) : 'true', innerText: async () => '🍌 Nano Banana Pro' });
  await f.adapter.configure(); assert.equal(imageClicks, 0); assert.equal(waits, 2);
  selected = false; await f.adapter.configure(); assert.equal(imageClicks, 1);
});
test('configure leaves selected Agent mode through its explicit toggle before opening direct image settings',async t=>{
  const f=fixture(t);let pressed=true,agentClicks=0,settingsClicks=0;
  f.adapter.selectors.agentMode={role:'button',name:'Agent'};
  f.adapter.visible=async spec=>spec===f.adapter.selectors.agentMode||(!pressed&&spec===f.adapter.selectors.settingsButton);
  f.adapter.locator=spec=>({waitFor:async()=>{if(spec===f.adapter.selectors.settingsButton)assert.equal(pressed,false);}});
  f.page.keyboard={press:async()=>{}};
  f.adapter.unique=async spec=>{
    if(spec===f.adapter.selectors.settingsButton&&pressed)throw Object.assign(Error('Agent has no Settings trigger'),{code:'flow_ui_changed'});
    return {getAttribute:async name=>spec===f.adapter.selectors.agentMode&&name==='aria-pressed'?String(pressed):'true',
      innerText:async()=> 'Nano Banana Pro',click:async()=>{if(spec===f.adapter.selectors.agentMode){agentClicks++;pressed=false;}if(spec===f.adapter.selectors.settingsButton)settingsClicks++;}};
  };
  await f.adapter.configure();assert.equal(agentClicks,1);assert.equal(settingsClicks,1);assert.equal(pressed,false);
});

test('configure never toggles an unverified Agent control or substitutes generic Settings',async t=>{
  for(const state of ['false',null]){
    const f=fixture(t);let clicks=0;
    f.adapter.selectors.agentMode={role:'button',name:'Agent'};
    f.adapter.visible=async spec=>spec===f.adapter.selectors.agentMode;
    f.adapter.unique=async spec=>{if(spec===f.adapter.selectors.agentMode)return {getAttribute:async()=>state,click:async()=>{clicks++;}};throw Object.assign(Error('No direct settings'),{code:'flow_ui_changed'});};
    f.adapter.locator=()=>({waitFor:async()=>{throw Error('Direct settings did not appear');}});
    f.adapter.captureDiagnostic=async()=>{};
    await assert.rejects(f.adapter.configure());assert.equal(clicks,0);
  }
});

test('configure UI exception captures passive diagnostics and exposes stable code', async t => {
  const f = fixture(t); let detail;
  f.adapter.visible = async () => false;
  f.adapter.unique = async () => ({ click: async () => { throw Error('detached control'); } });
  f.adapter.captureDiagnostic = async record => { detail = record; };
  await assert.rejects(f.adapter.configure(), { code: 'flow_configuration_ui_failed' });
  assert.equal(detail.stage, 'configure'); assert.equal(detail.error_code, 'flow_configuration_ui_failed');
});
test('passive diagnostics never inspect account login page', async t => {
  const f = fixture(t); f.adapter.config.logDir = f.directory; f.page.url = () => 'https://accounts.google.com/signin';
  f.page.screenshot = async () => { throw Error('must not capture account page'); };
  await f.adapter.captureDiagnostic({ stage: 'configure' }); assert.equal(fs.existsSync(path.join(f.directory, 'last-blocked-flow.private.json')), false);
});
test('configure does not toggle an already open settings panel or reselect x1', async t => {
  const f = fixture(t); const clicks = [];
  f.adapter.visible = async spec => spec === f.adapter.selectors.imageMode;
  f.adapter.locator = () => ({ waitFor: async () => {} }); f.page.keyboard = { press: async () => {} };
  f.adapter.unique = async spec => ({ click: async () => clicks.push(spec), getAttribute: async () => 'true', innerText: async () => '🍌 Nano Banana Pro' });
  await f.adapter.configure(); assert.deepEqual(clicks, []);
});
test('portrait setting selects and verifies 9:16 while square remains the default',async t=>{
  const f=fixture(t),clicks=[];let selected='1:1';
  f.adapter.visible=async spec=>spec===f.adapter.selectors.imageMode;
  f.adapter.locator=()=>({waitFor:async()=>{}});f.page.keyboard={press:async()=>{}};
  f.adapter.unique=async spec=>({click:async()=>{clicks.push(spec.name);selected=spec.name;},
    getAttribute:async()=>spec.role==='radio'&&['1:1','9:16'].includes(spec.name)?String(selected===spec.name):'true',innerText:async()=>'Nano Banana Pro'});
  await f.adapter.configure('9:16');assert.equal(selected,'9:16');assert.deepEqual(clicks,['9:16']);
  await f.adapter.configure();assert.equal(selected,'1:1');
  await assert.rejects(f.adapter.configure('7:26'),{code:'flow_aspect_not_supported'});
});
test('resume binds the original portrait ratio before any UI interaction',async t=>{
  const f=fixture(t);f.item.aspect_ratio='9:16';
  await assert.rejects(f.adapter.generate(f.item,[],f.directory,{resume:{status:'generation_started',generation_id:'fixture',recovery:{aspect_ratio:'1:1'}}}),{code:'flow_generation_aspect_binding_changed'});
});
test('landscape setting selects and verifies the user requested 16:9 ratio',async t=>{
  const f=fixture(t);let selected='1:1';
  f.adapter.visible=async()=>true;f.adapter.locator=()=>({waitFor:async()=>{}});f.page.keyboard={press:async()=>{}};
  f.adapter.unique=async spec=>({click:async()=>{selected=spec.name;},getAttribute:async()=>spec.role==='radio'&&['1:1','16:9'].includes(spec.name)?String(selected===spec.name):'true',innerText:async()=>'Nano Banana Pro'});
  await f.adapter.configure('16:9');assert.equal(selected,'16:9');
});
test('configure waits for the clicked ratio to become selected and still rejects an unconfirmed selection',async t=>{
  const f=fixture(t);let selected=false,clicks=0,waits=0,timeout=false;
  f.adapter.dismissCookieNotice=async()=>false;
  f.adapter.visible=async()=>true;f.adapter.locator=()=>({waitFor:async()=>{}});f.page.keyboard={press:async()=>{}};
  const selectedFilter={};f.page.locator=selector=>{assert.equal(selector,'[aria-checked="true"]');return selectedFilter;};
  f.adapter.unique=async spec=>spec===f.adapter.selectors.squareOption?{
    click:async()=>{clicks++;},getAttribute:async()=>String(selected),
    and:filter=>{assert.equal(filter,selectedFilter);return {waitFor:async options=>{
      waits++;assert.equal(options.state,'visible');assert.equal(options.timeout,f.adapter.timeout);
      if(timeout)throw Error('selection never confirmed');selected=true;
    }};}
  }:{click:async()=>{},getAttribute:async()=>'true',innerText:async()=>'Nano Banana Pro'};
  await f.adapter.configure();assert.equal(clicks,1);assert.equal(waits,1);assert.equal(selected,true);
  selected=false;timeout=true;f.adapter.captureDiagnostic=async()=>{};
  await assert.rejects(f.adapter.configure(),{code:'flow_model_or_aspect_unverified'});assert.equal(waits,2);
});
test('configure waits once for x1 selection and still refuses an unconfirmed output count',async t=>{
  const f=fixture(t);let selected=false,clicks=0,waits=0,timeout=false;
  f.adapter.dismissCookieNotice=async()=>false;
  f.adapter.visible=async()=>true;f.adapter.locator=()=>({waitFor:async()=>{}});f.page.keyboard={press:async()=>{}};
  const selectedFilter={};f.page.locator=selector=>{assert.equal(selector,'[aria-checked="true"]');return selectedFilter;};
  f.adapter.unique=async spec=>spec===f.adapter.selectors.outputOne?{
    click:async()=>{clicks++;},getAttribute:async()=>String(selected),
    and:filter=>{assert.equal(filter,selectedFilter);return {waitFor:async options=>{
      waits++;assert.equal(options.state,'visible');assert.equal(options.timeout,f.adapter.timeout);
      if(timeout)throw Error('output count never confirmed');selected=true;
    }};}
  }:{click:async()=>{},getAttribute:async()=>'true',innerText:async()=>'Nano Banana Pro'};
  await f.adapter.configure();assert.equal(clicks,1);assert.equal(waits,1);assert.equal(selected,true);
  await f.adapter.configure();assert.equal(clicks,1);assert.equal(waits,1);
  selected=false;timeout=true;f.adapter.captureDiagnostic=async()=>{};
  await assert.rejects(f.adapter.configure(),{code:'flow_output_count_unverified'});assert.equal(clicks,2);assert.equal(waits,2);
});
test('passive page events exclude queries, fragments, userinfo and request headers', async t => {
  const f = fixture(t); const handlers = {}; f.adapter.config.logDir = f.directory;
  f.page.on = (event, handler) => { assert.equal(handlers[event], undefined); handlers[event] = handler; };
  f.adapter.attachDiagnosticEvents(); f.adapter.attachDiagnosticEvents(); assert.equal(Object.keys(handlers).length, 4);
  handlers.requestfailed({ url: () => 'https://user:password@flow.google.com/project/test?token=SECRET#fragment', resourceType: () => 'script', failure: () => ({ errorText: 'net::ERR_FAILED' }), headers: () => { throw Error('must never read headers'); } });
  handlers.console({ type: () => 'error', text: () => 'Failed https://flow.google.com/script.js?token=SECRET', location: () => ({ url: 'https://flow.google.com/index.js?auth=SECRET' }) });
  handlers.pageerror({ name: 'TypeError', message: 'Failed https://flow.google.com/app.js?secret=SECRET' });
  handlers.response({url:()=> 'https://user:password@flow.google.com/upload?token=SECRET',status:()=>403});
  handlers.response({url:()=> 'https://flow.google.com/ok',status:()=>200});
  const text = fs.readFileSync(path.join(f.directory, 'browser-events.private.jsonl'), 'utf8'); assert.equal(text.includes('SECRET'), false); assert.equal(text.includes('password'), false);
  assert.equal(f.adapter.passiveEvents.length, 4); assert.equal(f.adapter.passiveEvents.at(-1).status,403); assert.equal(diagnosticUrl('data:opaque-secret'), 'data:');
});
test('upload observations inspect only file input metadata and never replace a failed upload outcome',async t=>{
  const f=fixture(t);f.adapter.config.stateDir=f.directory;
  const input={isConnected:true,tagName:'INPUT',type:'file',accept:'image/*',multiple:false,files:[{name:'exact.png',size:123,type:'image/png'}],outerHTML:'<input type="file">'};
  await f.adapter.observeUpload({element:()=>({evaluate:async callback=>callback(input)})},'after_set_files',{sha256:'a'.repeat(64)});
  assert.equal(f.adapter.uploadObservations[0].input.files[0].size,123);
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.directory,'upload-observations.jsonl'),'utf8')).phase,'after_set_files');
  await f.adapter.observeUpload({element:()=>{throw Error('detached');}},'unavailable',{});assert.equal(f.adapter.uploadObservations.length,1);
});
test('ProseMirror visible multiline prompt is verified semantically despite paragraph textContent concatenation', async t => {
  const f = fixture(t); let actual = 'First paragraph\n\nSecond paragraph\nNO OUTLINE';
  f.adapter.unique = async () => ({ fill: async () => {}, innerText: async () => actual, textContent: async () => 'First paragraphSecond paragraphNO OUTLINE' });
  await f.adapter.fillPrompt('First paragraph\nSecond paragraph\nNO OUTLINE');
  let diagnostic; f.adapter.captureDiagnostic = async record => { diagnostic = record; };
  actual += '\nAdditional unapproved correction'; await assert.rejects(f.adapter.fillPrompt('First paragraph\nSecond paragraph\nNO OUTLINE'), { code: 'flow_prompt_fill_unverified' });
  assert.equal(diagnostic.stage, 'prompt'); assert.ok(diagnostic.expected_prompt_sha256);
});
test('Clear prompt awaits removed chips before verifying cleanup', async t => {
  const f = fixture(t); let chips = 2, waited = false;
  f.adapter.visible = async spec => spec === f.adapter.selectors.clearPrompt;
  f.adapter.unique = async () => ({ click: async () => {} });
  f.adapter.locator = () => ({ count: async () => chips });
  f.page.waitForFunction = async (_predicate, selector) => { assert.equal(selector, f.adapter.selectors.referenceChip); waited = true; chips = 0; };
  await f.adapter.upload([]); assert.equal(waited, true);
});
test('resume error records exact recovery stage and original generation without new Generate', async t => {
  const f = fixture(t); let diagnostic, clicks = 0;
  f.adapter.unique = async () => ({ click: async () => { clicks++; } });
  f.adapter.captureDiagnostic = async value => { diagnostic = value; };
  f.adapter.recover = async () => { f.adapter.uiStage = 'recover.asset_info_button'; const error = Error('missing UI control'); error.code = 'flow_ui_changed'; throw error; };
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { resume: { status: 'generation_started', generation_id: 'existing-generation', recovery: {} } }), { code: 'flow_ui_changed' });
  assert.equal(clicks, 0); assert.equal(f.adapter.currentGeneration, 'existing-generation'); assert.equal(diagnostic.stage, 'recover.asset_info_button');
  assert.equal(diagnostic.expected_prompt_sha256, hash(f.item.prompt));
});
test('composer changing while n8n validates prevents any Generate dispatch', async t => {
  const f = fixture(t); let actual = f.item.prompt, clicks = 0;
  f.adapter.ensureProject = f.adapter.configure = f.adapter.upload = async () => {};
  f.adapter.results = async () => []; f.adapter.locator = () => ({ count: async () => 0 });
  f.adapter.unique = async spec => spec === f.adapter.selectors.prompt ? { fill: async () => {}, innerText: async () => actual } : { click: async () => { clicks++; } };
  await assert.rejects(f.adapter.generate(f.item, [], f.directory, { beforeGenerate: async () => { actual = 'a different prompt'; } }), { code: 'flow_prompt_changed_before_click' });
  assert.equal(clicks, 0);
});

test('unusual wait baselines only the bound Failed, with no Delete or Retry action',async t=>{
  const f=fixture(t),text='Failed We noticed some unusual activity.';
  const checkpoint={status:'generation_started',generation_id:'failed-1',recovery:{project_url:project,prompt_sha256:hash(f.item.prompt),failure_baseline:[]}};
  const evidence={generation_id:'failed-1',failed_tiles:[text]};
  assert.equal(f.adapter.deleteUnusualFailedTile,undefined);
  assert.deepEqual(await f.adapter.resumeAfterUnusualFailure(f.item,checkpoint,evidence),[text]);
  let tiles=[text];f.adapter.failedTileTexts=async()=>tiles;delete f.adapter.generationFailure;
  assert.equal(await f.adapter.generationFailure(),null);tiles.push(text);assert.equal(await f.adapter.generationFailure(),'flow_unusual_activity_required');
  tiles=[text,'Failed You have reached your usage limit.'];assert.equal(await f.adapter.generationFailure(),'flow_quota_required');
  for(const bad of [{...checkpoint,asset:{path:'acquired'}},{...checkpoint,generation_id:'other'},{...checkpoint,recovery:{...checkpoint.recovery,project_url:project+'other'}}])await assert.rejects(f.adapter.resumeAfterUnusualFailure(f.item,bad,evidence),{code:'flow_unusual_retry_binding_invalid'});
  await assert.rejects(f.adapter.resumeAfterUnusualFailure(f.item,checkpoint,{...evidence,failed_tiles:['Failed quota']}),{code:'flow_unusual_retry_binding_invalid'});
});

test('cached picker searches virtual pages before choosing upload and refuses ambiguous or incomplete search',async t=>{
  const f=fixture(t);let position=2,checks=0;
  const option={count:async()=>{checks++;return position===3?1:0;},isVisible:async()=>true};
  f.page.getByRole=()=>option;f.page.waitForFunction=async()=>{};
  f.adapter.locator=()=>({evaluate:async(_fn,action)=>{const old=position;position=action==='top'?0:position+1;return {scrollable:true,moved:position!==old,signature:String(old)};}});
  assert.equal(await f.adapter.findCachedReference({label:'locked'}),option);assert.equal(position,3);assert.ok(checks>=4);
  f.page.getByRole=()=>({count:async()=>2});await assert.rejects(f.adapter.findCachedReference({label:'duplicate'}),{code:'flow_reference_cache_ambiguous'});
  f.page.getByRole=()=>({count:async()=>0});f.adapter.locator=()=>({evaluate:async()=>({scrollable:true,moved:true,signature:'more'})});
  await assert.rejects(f.adapter.findCachedReference({label:'too-far'}),{code:'flow_reference_cache_search_incomplete'});
});
test('repeated unusual evidence captures only newly failed tiles, preserving multiplicity without hiding quota',async t=>{
  const f=fixture(t),text='Failed We noticed some unusual activity.',file=path.join(f.directory,'repeated.png');
  delete f.adapter.generationFailure;f.page.screenshot=async({path:file})=>fs.writeFileSync(file,'evidence');
  for(let count=0;count<4;count++){
    f.adapter.failureBaseline=Array(count).fill(text);f.adapter.failedTileTexts=async()=>Array(count+1).fill(text);
    const evidence=await f.adapter.unusualActivityEvidence(file);assert.deepEqual(evidence.failed_tiles,[text]);
    const image={status:'generation_started',generation_id:'g'+count,recovery:{project_url:project,prompt_sha256:hash(f.item.prompt),failure_baseline:Array(count).fill(text)}};
    await f.adapter.resumeAfterUnusualFailure(f.item,image,{...evidence,generation_id:image.generation_id});assert.equal(f.adapter.failureBaseline.length,count+1);
    f.adapter.failedTileTexts=async()=>Array(count+2).fill(text);assert.equal(await f.adapter.generationFailure(),'flow_unusual_activity_required');
  }
  f.adapter.failedTileTexts=async()=>[...f.adapter.failureBaseline,text,'Failed You have reached your usage limit.'];
  await assert.rejects(f.adapter.unusualActivityEvidence(file),{code:'flow_quota_required'});
});

test('cached picker centers an offscreen rendered option before returning it for a click',async t=>{
  const f=fixture(t);let centered=false,checks=0;
  f.adapter.referenceOptionReady=FlowBrowser.prototype.referenceOptionReady;
  const option={count:async()=>1,isVisible:async()=>true,evaluateAll:async fn=>{
    checks++;
    const view={clientHeight:120,scrollHeight:1000,scrollTop:0,parentElement:null,getBoundingClientRect:()=>({left:0,right:200,top:0,bottom:120}),scrollBy:({top})=>{assert.ok(top>0);centered=true;}};
    const element={isConnected:true,parentElement:view,getBoundingClientRect:()=>({left:10,right:190,top:centered?10:600,bottom:centered?90:680,width:180,height:80})};
    const previous={getComputedStyle:global.getComputedStyle,innerWidth:global.innerWidth,innerHeight:global.innerHeight,requestAnimationFrame:global.requestAnimationFrame};
    Object.assign(global,{getComputedStyle:()=>({overflowY:'auto',overflowX:'visible'}),innerWidth:800,innerHeight:600,requestAnimationFrame:callback=>setImmediate(callback)});
    try{return await fn([element]);}finally{Object.assign(global,previous);}
  }};
  f.page.getByRole=()=>option;
  assert.equal(await f.adapter.findCachedReference({label:'exact Image'}),option);
  assert.equal(centered,true);assert.ok(checks>=2);
});

test('reference viewport check rejects an option that moves or detaches while frames settle',async t=>{
  const f=fixture(t);f.adapter.referenceOptionReady=FlowBrowser.prototype.referenceOptionReady;
  for(const mode of ['moving','detached']){
    let changed=false,frames=0;
    const element={get isConnected(){return !(changed&&mode==='detached');},parentElement:null,getBoundingClientRect:()=>({left:10,right:190,top:changed&&mode==='moving'?20:10,bottom:90,width:180,height:80})};
    const previous={innerWidth:global.innerWidth,innerHeight:global.innerHeight,requestAnimationFrame:global.requestAnimationFrame};
    Object.assign(global,{innerWidth:800,innerHeight:600,requestAnimationFrame:callback=>{if(++frames===2)changed=true;setImmediate(callback);}});
    try{assert.equal(await f.adapter.referenceOptionReady({evaluateAll:async fn=>fn([element])}),false);}
    finally{Object.assign(global,previous);}
  }
});

test('cached picker reacquires an option removed between visibility and viewport observation',async t=>{
  const f=fixture(t);f.adapter.referenceOptionReady=FlowBrowser.prototype.referenceOptionReady;
  let observations=0;
  const option={count:async()=>1,isVisible:async()=>true,evaluate:async()=>{throw Object.assign(Error('waiting for vanished option'),{name:'TimeoutError'});},evaluateAll:async fn=>++observations===1?fn([]):{ready:true}};
  f.page.getByRole=()=>option;
  assert.equal(await f.adapter.findCachedReference({label:'exact Image'}),option);
  assert.equal(observations,2);
});

test('reference viewport snapshot refuses duplicate labels and propagates browser failures',async t=>{
  const f=fixture(t);f.adapter.referenceOptionReady=FlowBrowser.prototype.referenceOptionReady;
  await assert.rejects(f.adapter.referenceOptionReady({evaluateAll:async fn=>fn([{},{}])}),{code:'flow_reference_cache_ambiguous'});
  const failure=Error('page closed');
  await assert.rejects(f.adapter.referenceOptionReady({evaluateAll:async()=>{throw failure;}}),error=>error===failure);
});
test('one empty cached chip refreshes only its SHA while good shared assets remain reused and logged',async t=>{
  const f=fixture(t);f.adapter.config.profileDir=f.directory;f.adapter.config.stateDir=f.directory;
  const refs=['A','B','C'].map(name=>{const file=path.join(f.directory,name+'.png');fs.writeFileSync(file,Buffer.concat([f.png,Buffer.from(name)]));return {path:file,sha256:hash(fs.readFileSync(file))};});
  const assets=new Map(refs.map((r,i)=>[r.sha256,{label:'cached-'+i+' Image',identity:'https://flow-content.google/image/asset-'+i,sha:r.sha256}]));
  fs.writeFileSync(path.join(f.directory,'flow-reference-assets.json'),JSON.stringify({version:1,projects:{[project]:Object.fromEntries([...assets].map(([sha,a])=>[sha,a]))}}));
  let chips=[],selected,emptyOnce=true;const uploaded=[];
  f.page.keyboard={press:async()=>{}};f.page.waitForFunction=async()=>{};
  f.page.waitForEvent=async()=>({setFiles:async file=>{const sha=hash(fs.readFileSync(file));uploaded.push(sha);const a={sha,label:path.basename(file)+' Image',identity:'https://flow-content.google/image/new-'+sha};assets.set(sha,a);}});
  f.page.getByRole=(_role,opts)=>({locator:()=>({waitFor:async()=>{},getAttribute:async()=>[...assets.values()].find(a=>a.label===opts.name)?.identity}),count:async()=>[...assets.values()].filter(a=>a.label===opts.name).length,isVisible:async()=>true,waitFor:async()=>{},click:async()=>{selected=[...assets.values()].find(a=>a.label===opts.name);assert.ok(selected);}});
  f.adapter.visible=async spec=>spec===f.adapter.selectors.clearPrompt;
  f.adapter.unique=async spec=>({click:async()=>{if(spec===f.adapter.selectors.clearPrompt)chips=[];if(spec===f.adapter.selectors.addToPrompt)chips.push(selected);}});
  f.adapter.locator=spec=>({count:async()=>spec===f.adapter.selectors.referenceChip?chips.length:1,waitFor:async()=>{},nth:index=>({waitFor:async()=>{},getAttribute:async()=>{const chip=chips[index];if(chip.sha===refs[1].sha256&&emptyOnce){emptyOnce=false;return null;}return chip.identity;}})});
  await f.adapter.upload(refs);
  assert.deepEqual(uploaded,[refs[1].sha256]);assert.equal(chips.length,3);
  const records=fs.readFileSync(path.join(f.directory,'reference-transfers.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
  assert.equal(records.filter(r=>r.method==='upload').length,1);assert.equal(records.find(r=>r.method==='upload').reason,'replace_bad_cached_asset');
  assert.ok(records.some(r=>r.sha256===refs[0].sha256&&r.method==='existing_project_asset'));assert.ok(records.some(r=>r.sha256===refs[2].sha256&&r.method==='existing_project_asset'));
});
