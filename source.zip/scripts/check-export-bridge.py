"""Check only rejection paths; never export files or display credentials."""
import json
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

root = Path('C:/Huy/etsy-workflow')
token = (root / 'bridge-token.txt').read_text(encoding='utf-8-sig').strip()
cases = [
    ('missing_auth', '/export-approved', {'product_id': 'pumpkin-cream-crewneck-pilot'}, {}, 401),
    ('wrong_product', '/export-approved', {'product_id': 'invalid'}, {'x-bridge-token': token}, 400),
    ('arbitrary_destination', '/export-approved', {'product_id': 'pumpkin-cream-crewneck-pilot', 'destination': 'C:/invalid'}, {'x-bridge-token': token}, 400),
    ('browser_origin', '/export-approved', {'product_id': 'pumpkin-cream-crewneck-pilot'}, {'x-bridge-token': token, 'Origin': 'http://localhost:5678'}, 403),
    ('old_chat_validation', '/ask', {}, {'x-bridge-token': token}, 400),
]
results = []
for name, route, body, headers, expected in cases:
    request = Request('http://127.0.0.1:8787' + route, json.dumps(body).encode(),
                      {'Content-Type': 'application/json', **headers}, method='POST')
    try:
        with urlopen(request, timeout=5) as response:
            status = response.status
    except HTTPError as error:
        status = error.code
    results.append({'case': name, 'http_status': status, 'expected': expected, 'passed': status == expected})
report = {'passed': all(item['passed'] for item in results), 'cases': results,
          'destination_not_created_by_rejected_requests': not Path('C:/Huy/Chưa xử lý/Áo thêu/HLW/HLW_261010_01').exists()}
(root / 'workspace/flow-test-01/export-pilot-HLW_261010_01/bridge-checks.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
assert report['passed'] and report['destination_not_created_by_rejected_requests']
