"""ChatGPT Chat browser jobs; mutations run inside the main n8n execution."""
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse


def selection(e):
    import flow_worker_pool
    file = flow_worker_pool.selection_file(e)
    return e['read'](file) if file.exists() else {'provider': 'flow'}


def tables(c):
    c.execute('''CREATE TABLE IF NOT EXISTS chatgpt_image_jobs(
        id TEXT PRIMARY KEY,source_id TEXT NOT NULL,source_fingerprint TEXT NOT NULL,
        test_only INTEGER NOT NULL,status TEXT NOT NULL,payload TEXT NOT NULL,result TEXT,created_at TEXT NOT NULL)''')


def source_task(c, task_id):
    for table, kind in [('production_batch_tasks', 'flow_batch_images'), ('design_tasks', None), ('tasks', None)]:
        if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
            continue
        row = c.execute('SELECT * FROM ' + table + ' WHERE id=?', (task_id,)).fetchone()
        if row:
            task = dict(row)
            if kind:
                task['kind'] = kind
            elif table == 'design_tasks' and task.get('stage') in ('2d', 'embroidery'):
                task['kind'] = 'flow_design_' + task['stage']
            task['payload'] = json.loads(task['payload'])
            if not str(task.get('kind', '')).startswith('flow_'):
                raise ValueError('Source must be an image task')
            return task
    raise ValueError('Source image task missing')


def enqueue(c, task, test_only, e, image_key=None):
    tables(c)
    if e['digest'](task['payload']) != task['fingerprint']:
        raise ValueError('Source task fingerprint differs')
    if not test_only:
        import flow_worker_pool
        journal = flow_worker_pool.runtime(e) / ('task-' + hashlib.sha256(task['id'].encode()).hexdigest() + '.json')
        if journal.exists() and e['read'](journal).get('images'):
            raise ValueError('Flow checkpoint contains generated or unresolved images; reconcile before provider transfer')
    images = [x for x in task['payload']['images'] if not image_key or x.get('region', x.get('name')) == image_key]
    if not images:
        raise ValueError('Requested source image missing')
    identity = e['digest']({'source': task['id'], 'fingerprint': task['fingerprint'], 'test_only': test_only, 'image_keys': [x.get('region', x.get('name')) for x in images]})
    job_id = 'chatgpt-' + identity[:32]
    if not c.execute('SELECT 1 FROM chatgpt_image_jobs WHERE id=?', (job_id,)).fetchone():
        output = (e['STORE'] / 'chatgpt-tests' / job_id if test_only else
                  Path(task['payload']['output_directory']) if task['payload'].get('output_directory') else
                  e['STORE'] / 'artifacts' / task['code'] / ('v%03d' % task['revision']) / 'flow-originals' / task['id'])
        payload = {'id': job_id, 'source_task': task, 'test_only': test_only, 'images': images,
                   'output_directory': str(output), 'provider': 'ChatGPT Chat', 'quality_verified': False}
        preference = selection(e).get('chat_reasoning')
        if preference:
            payload['chat_preferences'] = {'reasoning': preference, 'mode': 'Chat'}
        c.execute('INSERT INTO chatgpt_image_jobs VALUES(?,?,?,?,?,?,?,?)',
                  (job_id, task['id'], task['fingerprint'], int(test_only), 'pending', json.dumps(payload, ensure_ascii=False), None, e['now']()))
    return job_id


def verify_proof(proof, e):
    from PIL import Image
    if proof.get('executor') not in ('independent_chatgpt_worker', 'codex_chatgpt_browser') or proof.get('acquisition') != 'chatgpt_download' or proof.get('visually_verified') is True:
        raise ValueError('Actual ChatGPT download proof required; no automatic visual approval')
    if proof.get('executor') == 'codex_chatgpt_browser' and (proof.get('browser_transport') not in ('official_extension', 'windows_computer_use') or proof.get('requires_active_codex_session') is not True):
        raise ValueError('Codex browser evidence must name its supported transport and active session requirement')
    for record in [proof] + proof.get('images', []):
        url = urlparse(record.get('url', ''))
        if url.scheme != 'https' or url.hostname != 'chatgpt.com' or not url.path.startswith('/c/') or url.username or url.password:
            raise ValueError('ChatGPT conversation URL required')
        if not str(record.get('model', '')).strip() or record.get('visually_verified') is True:
            raise ValueError('Observed Chat model label required')
        file = e['scoped'](record['screenshot_path'])
        if e['sha'](file) != record.get('screenshot_sha256'):
            raise ValueError('ChatGPT screenshot changed')
        with Image.open(file) as image:
            image.verify()
        receipt = e['scoped'](record['receipt_path'])
        if e['sha'](receipt) != record.get('receipt_sha256'):
            raise ValueError('ChatGPT receipt changed')
        data = e['read'](receipt)
        if data.get('url') != record['url'] or data.get('prompt_sha256') != record.get('prompt_sha256') or data.get('reference_sha256') != record.get('reference_sha256') or data.get('acquisition') != 'chatgpt_download':
            raise ValueError('ChatGPT receipt not bound to prompt/references/conversation')
        if e['sha'](e['scoped'](data['asset']['path'])) != data['asset']['sha256']:
            raise ValueError('ChatGPT original changed')
        if data.get('model') != record.get('model') or not data.get('user_prompt_visible') or not data.get('download_button_label'):
            raise ValueError('ChatGPT visible prompt/model/download evidence missing')


def assert_route(c, cmd, e):
    tables(c)
    job = c.execute('SELECT * FROM chatgpt_image_jobs WHERE id=?', (cmd.get('proof', {}).get('chatgpt_job_id'),)).fetchone()
    if not job or job['test_only'] or job['source_id'] != cmd.get('task_id') or job['source_fingerprint'] != cmd.get('task_fingerprint'):
        raise ValueError('Explicit native ChatGPT source binding required')
    return job


def execute(c, cmd, e):
    tables(c)
    action = cmd['action']
    if action == 'chatgpt_worker_select':
        e['design_module']().authority(cmd)
        if cmd.get('mode') not in ('login', 'manual_login', 'extension', 'extension_production', 'test', 'production', 'flow'):
            raise ValueError('Choose login/manual_login/extension/extension_production/test/production/flow')
        choice = {'provider': 'flow' if cmd['mode'] == 'flow' else 'chatgpt', 'mode': cmd['mode'],
                  'reference': cmd['reference'], 'selected_at': e['now']()}
        preference = cmd.get('chat_reasoning', selection(e).get('chat_reasoning'))
        if preference is not None:
            if preference != 'highest_available':
                raise ValueError('Chat reasoning must be highest_available')
            choice['chat_reasoning'] = preference
        if 'unusual_activity_policy' in cmd:
            policy = cmd['unusual_activity_policy']
            if cmd['mode'] != 'flow' or not isinstance(policy, dict) or policy.get('enabled') is not True or policy.get('cooldown_ms') != 600000:
                raise ValueError('Flow unusual activity policy requires an explicit ten-minute cooldown')
            choice['unusual_activity_policy'] = {'enabled': True, 'cooldown_ms': 600000, 'reference': cmd['reference']}
            if 'retry_after_cooldown' in policy:
                if policy['retry_after_cooldown'] is not True:
                    raise ValueError('New Generate after cooldown requires explicit authorization')
                choice['unusual_activity_policy']['retry_after_cooldown'] = True
            if 'retry_unlimited' in policy:
                if policy['retry_unlimited'] is not True or policy.get('retry_after_cooldown') is not True:
                    raise ValueError('Unlimited unusual retries require explicit cooldown retry authorization')
                choice['unusual_activity_policy']['retry_unlimited'] = True
        elif cmd['mode']=='flow' and selection(e).get('unusual_activity_policy'):
            choice['unusual_activity_policy']=selection(e)['unusual_activity_policy']
        if 'generation_failure_policy' in cmd:
            policy=cmd['generation_failure_policy']
            if cmd['mode']!='flow' or not isinstance(policy,dict) or policy.get('enabled') is not True or policy.get('cooldown_ms')!=60000:
                raise ValueError('Flow generation failure policy requires an explicit one-minute cooldown')
            choice['generation_failure_policy']={'enabled':True,'cooldown_ms':60000,'reference':cmd['reference']}
        elif cmd['mode']=='flow' and selection(e).get('generation_failure_policy'):
            choice['generation_failure_policy']=selection(e)['generation_failure_policy']
        if 'model_fallback_policy' in cmd:
            policy=cmd['model_fallback_policy']
            if cmd['mode']!='flow' or not isinstance(policy,dict) or policy.get('enabled') is not True or policy.get('model')!='Nano Banana 2.1':
                raise ValueError('Flow fallback must explicitly authorize Nano Banana 2.1')
            choice['model_fallback_policy']={'enabled':True,'model':'Nano Banana 2.1','reference':cmd['reference']}
            key='flow_model_policy:'+__import__('hashlib').sha256(cmd['reference'].encode()).hexdigest()
            c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',(key,json.dumps(choice['model_fallback_policy'])))
        elif cmd['mode']=='flow' and selection(e).get('model_fallback_policy'):
            choice['model_fallback_policy']=selection(e)['model_fallback_policy']
        if 'account_policy' in cmd:
            from urllib.parse import urlparse
            import re
            policy=cmd['account_policy']
            accounts=policy.get('accounts',[]) if isinstance(policy,dict) else []
            if cmd['mode']!='flow' or not isinstance(policy,dict) or policy.get('enabled') is not True or not isinstance(accounts,list) or not 2 <= len(accounts) <= 3:
                raise ValueError('Flow account policy requires two or three authorized signed-in accounts')
            if policy.get('on_unusual_activity') not in (None,'switch_account'):
                raise ValueError('Flow unusual account handover must explicitly select switch_account')
            emails=[]
            for account in accounts:
                if not isinstance(account,dict):raise ValueError('Flow account identity/home URL invalid')
                email=account.get('email','')
                url=urlparse(account.get('home_url',''))
                if not re.fullmatch(r'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}',email) or url.scheme!='https' or url.netloc!='flow.google.com' or not re.fullmatch(r'/(?:u/\d+/)?',url.path) or url.query or url.fragment:
                    raise ValueError('Flow account identity/home URL invalid')
                emails.append(email)
            if len(set(emails))!=len(emails) or len({a['home_url'] for a in accounts})!=len(accounts) or policy.get('preferred_email') not in emails or any(email not in emails for email in policy.get('unavailable_accounts',[])):
                raise ValueError('Flow account policy binding invalid')
            choice['account_policy']={**policy,'reference':cmd['reference']}
        elif cmd['mode']=='flow' and selection(e).get('account_policy'):
            choice['account_policy']=selection(e)['account_policy']
        if cmd.get('resume_image_worker') is True:
            import production_batch
            active=production_batch.batch(c,cmd.get('batch_id'))
            run=production_batch.controls.get(c,'batch_run_plan')
            selected_waiter=bool(run and run.get('mode')=='selected_group' and run['status']=='preparing' and active['status'] in ('preparing','prepared') and any(x['batch_id']==active['batch_id'] for x in run['entries']))
            if cmd['mode']!='flow' or (active['status'] not in ('ready','active') and not selected_waiter):raise ValueError('Resume requires the exact active Flow batch or waiting member of the selected group')
            choice['batch_id']=active['batch_id']
            production_batch.controls.release_error_holds(e['ROOT'],active['batch_id'],c)
            import flow_worker_pool
            pause=flow_worker_pool.runtime(e)/'pause.request.json'
            if pause.exists():pause.rename(pause.with_name('pause.released-'+__import__('uuid').uuid4().hex+'.json'))
        elif cmd.get('bind_only') is True:
            import production_batch
            target=production_batch.batch(c,cmd.get('batch_id'))
            if cmd['mode']!='flow' or target['status']!='stopped':raise ValueError('Bind-only requires an existing stopped Flow batch')
            choice['batch_id']=target['batch_id']
            choice['batch_scope_reference']=cmd['reference']
        import flow_worker_pool
        e['write'](flow_worker_pool.selection_file(e), choice)
        return {'ok': True, 'status': 'image_worker_selected', 'worker_provider': choice['provider'], 'mode': choice['mode']}
    if action == 'chatgpt_image_enqueue':
        e['design_module']().authority(cmd)
        task = source_task(c, cmd['source_task_id'])
        if task['fingerprint'] != cmd.get('source_fingerprint'):
            raise ValueError('Source task changed')
        test_only = cmd.get('test_only') is True
        if not test_only and task['id'] not in [t['id'] for t in e['execute'](c, {'action': 'browser_queue'})['tasks']]:
            raise ValueError('Production transfer requires a current pending task')
        job_id = enqueue(c, task, test_only, e, cmd.get('image_key'))
        return {'ok': True, 'status': 'chatgpt_image_queued', 'job_id': job_id, 'test_only': test_only}
    if action == 'chatgpt_cycle':
        import flow_lark_orchestration as flow
        snapshot = flow.execute(c, {'action': 'flow_cycle'}, e)
        choice = selection(e)
        production = choice.get('mode') in ('production', 'extension_production')
        current = e['execute'](c, {'action': 'browser_queue'})['tasks'] if production else []
        issues = []
        if choice.get('provider') == 'chatgpt' and production:
            for task in current:
                if task['kind'].startswith('flow_'):
                    try:
                        enqueue(c, task, False, e)
                    except ValueError as error:
                        issues.append({'task_id': task['id'], 'error': str(error), 'requires_operator': True})
        tasks = [json.loads(r['payload']) for r in c.execute("SELECT payload FROM chatgpt_image_jobs WHERE status='pending' ORDER BY created_at,id")]
        if choice.get('mode') in ('test', 'extension'):
            tasks = [t for t in tasks if t['test_only']]
        elif production:
            identities = {(t['id'], t['fingerprint']) for t in current}
            tasks = [t for t in tasks if not t['test_only'] and
                     (t['source_task']['id'], t['source_task']['fingerprint']) in identities and
                     t['source_task']['id'] not in {issue['task_id'] for issue in issues}]
        return {'ok': True, 'status': 'chatgpt_cycle', 'worker_provider': 'chatgpt', 'observed_at': e['now'](),
                'tasks': tasks if choice.get('provider') == 'chatgpt' and choice.get('mode') in ('extension', 'extension_production', 'test', 'production') else [],
                'reviews': snapshot['reviews'], 'queue_issues': issues,
                'chat_preferences': {'mode': 'Chat', 'reasoning': choice.get('chat_reasoning')},
                'executor_required': 'active_codex_session_with_official_browser_extension' if choice.get('mode') in ('extension', 'extension_production') else 'independent_chatgpt_worker'}
    if action == 'chatgpt_image_attach':
        row = c.execute('SELECT * FROM chatgpt_image_jobs WHERE id=?', (cmd.get('job_id'),)).fetchone()
        if not row:
            raise ValueError('ChatGPT job missing')
        payload = json.loads(row['payload']); source = payload['source_task']
        if cmd.get('source_fingerprint') != row['source_fingerprint']:
            raise ValueError('ChatGPT source fingerprint changed')
        proof = cmd.get('proof', {}); verify_proof(proof, e)
        keys = [x.get('region', x.get('name')) for x in payload['images']]
        if [x.get('image_key') for x in cmd.get('assets', [])] != keys or [x.get('image_key') for x in proof.get('images', [])] != keys:
            raise ValueError('Exact ChatGPT image set required')
        for image, asset, record in zip(payload['images'], cmd['assets'], proof['images']):
            refs = image.get('references', list(source['payload'].get('references', {}).values()))
            if record.get('prompt_sha256') != hashlib.sha256(image['prompt'].encode()).hexdigest() or record.get('reference_sha256') != sorted(r['sha256'] for r in refs):
                raise ValueError('ChatGPT prompt/reference provenance differs')
            receipt = e['read'](e['scoped'](record['receipt_path']))
            if payload.get('chat_preferences', {}).get('reasoning') == 'highest_available':
                if (record.get('reasoning_policy') != 'highest_available' or
                    not str(record.get('reasoning_label', '')).strip() or
                    record.get('reasoning_menu_verified') is not True or
                    any(receipt.get(k) != record.get(k) for k in
                        ('reasoning_policy', 'reasoning_label', 'reasoning_menu_verified'))):
                    raise ValueError('Observed highest available Chat reasoning evidence required')
            if receipt['asset'] != {'path': asset['path'], 'sha256': asset['sha256']}:
                raise ValueError('ChatGPT receipt names another original')
            for ref in refs:
                if e['sha'](e['scoped'](ref['path'])) != ref['sha256']:
                    raise ValueError('ChatGPT locked reference changed')
            file = e['scoped'](asset['path']); output = e['scoped'](payload['output_directory'])
            if file == output or not file.is_relative_to(output) or e['sha'](file) != asset['sha256']:
                raise ValueError('ChatGPT original path/hash differs')
            from PIL import Image
            with Image.open(file) as im:
                if im.width != im.height or im.format not in ('PNG', 'JPEG', 'WEBP'):
                    raise ValueError('Square original raster required')
        if row['result']:
            return json.loads(row['result'])
        if row['test_only']:
            result = {'ok': True, 'status': 'chatgpt_test_completed', 'job_id': row['id'], 'assets': cmd['assets'], 'quality_verified': False}
        else:
            import flow_lark_orchestration as flow
            forward = {'action': 'flow_auto_submit', 'task_id': source['id'], 'task_fingerprint': source['fingerprint'],
                       'revision': source['revision'], 'assets': cmd['assets'], 'proof': dict(proof, chatgpt_job_id=row['id'])}
            result = flow.auto_submit(c, forward, e)
        c.execute("UPDATE chatgpt_image_jobs SET status='completed',result=? WHERE id=?", (json.dumps(result), row['id']))
        return result
    raise ValueError('Unknown ChatGPT worker action')
