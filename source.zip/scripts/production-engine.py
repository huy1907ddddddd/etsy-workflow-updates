"""Durable listing workflow. Browser tasks are acknowledged only after UI verification.

No browser APIs, credentials, automatic approvals, or fabricated research live here.
Run with one JSON command on stdin. All transactions use SQLite BEGIN IMMEDIATE.
"""
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path('C:/Huy/etsy-workflow')
STORE = ROOT / 'workspace/production'
DB = STORE / 'production.sqlite'
JOBS = Path('C:/Users/ADMIN/.n8n-files/etsy-codex/jobs')
CODE = re.compile(r'^[A-Z]{2,5}_\d{6}_\d{2}(?:_[A-Z0-9]+)?$')
TZ = timezone(timedelta(hours=7))
IMAGES = ['01_thumbnail.jpg', '02_model_front.jpg', '03_model_angle.jpg',
          '04_embroidery_closeup.jpg', '05_embroidery_dimensions.jpg', '06_flatlay.jpg']
REVIEW_URL = 'LOCAL_BINDING_URL'


def review_url(c):
    row=c.execute("SELECT value FROM config WHERE key='listing_destination'").fetchone()
    return json.loads(row[0])['url'] if row else REVIEW_URL


def valid_review_url(c,url):
    return url in (REVIEW_URL,review_url(c))


def review_layout(c):
    row=c.execute("SELECT value FROM config WHERE key='listing_destination'").fetchone()
    return json.loads(row[0]).get('layout','legacy') if row else 'legacy'


def public_code(c,value):
    row=c.execute("SELECT value FROM config WHERE key='listing_code_suffix'").fetchone()
    suffix=json.loads(row[0]) if row else ''
    return value if not suffix or value.endswith(suffix) else value+suffix


def now():
    return datetime.now(timezone.utc).isoformat()


_DESIGN_MODULE = None


def design_module():
    global _DESIGN_MODULE
    if _DESIGN_MODULE is None:
        import importlib.util
        spec=importlib.util.spec_from_file_location('production_design',Path(__file__).with_name('production_design.py'))
        _DESIGN_MODULE=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_DESIGN_MODULE)
    return _DESIGN_MODULE


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def digest(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def write(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_name(p.name + '.' + uuid.uuid4().hex + '.tmp')
    t.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(t, p)


def scoped(p, roots=(ROOT, Path('C:/Huy/Chưa xử lý/Áo thêu'), Path('C:/Huy/Chưa xử lý/Áo 2D'), Path('C:/Huy/Chưa xử lý/Áo pijama'), Path('C:/Huy/Chưa xử lý/Bộ pijama'), Path('C:/Huy/Chưa xử lý/Quần ngủ'), Path('C:/Huy/Chưa xử lý/File thêu/Mockup gốc'), Path('C:/Huy/Đã xử lý/Áo thêu'), Path('C:/Huy/Đã xử lý/Áo 2D'), Path('C:/Huy/Đã xử lý/Áo pijama'), Path('C:/Huy/Đã xử lý/Bộ pijama'), Path('C:/Huy/Đã xử lý/Quần ngủ'), Path('C:/Users/ADMIN/.n8n-files'))):
    p = Path(p).resolve()
    redirects=STORE/'output-path-redirects.json'
    if redirects.exists():
        for source,target in sorted(read(redirects).items(),key=lambda x:len(x[0]),reverse=True):
            prior=Path(source)
            if p.is_relative_to(prior):p=(Path(target)/p.relative_to(prior)).resolve();break
    if not any(p.is_relative_to(r.resolve()) and p != r.resolve() for r in roots):
        raise ValueError('Path outside allowed product/artifact roots')
    return p


def code(x):
    if not isinstance(x, str) or not CODE.fullmatch(x):
        raise ValueError('Invalid listing code')
    return x


def connect(db=DB):
    Path(db).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(db, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA foreign_keys=ON')
    c.executescript('''
      CREATE TABLE IF NOT EXISTS jobs(code TEXT PRIMARY KEY, revision INTEGER NOT NULL,
        state TEXT NOT NULL, source_hash TEXT NOT NULL, plan TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, code TEXT NOT NULL, revision INTEGER,
        kind TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS approvals(code TEXT NOT NULL, revision INTEGER NOT NULL,
        stage TEXT NOT NULL, fingerprint TEXT NOT NULL, reference TEXT NOT NULL, created_at TEXT NOT NULL,
        PRIMARY KEY(code,revision,stage));
      CREATE TABLE IF NOT EXISTS artifacts(code TEXT NOT NULL, revision INTEGER NOT NULL,
        kind TEXT NOT NULL, fingerprint TEXT NOT NULL, payload TEXT NOT NULL,
        PRIMARY KEY(code,revision,kind));
      CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, code TEXT NOT NULL, revision INTEGER NOT NULL,
        kind TEXT NOT NULL, fingerprint TEXT NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL,
        proof TEXT, created_at TEXT NOT NULL, UNIQUE(code,revision,kind,fingerprint));
      CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS kpi(code TEXT PRIMARY KEY, revision INTEGER NOT NULL,
        target_date TEXT NOT NULL, completed_at TEXT NOT NULL, fingerprint TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS briefs(brief_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL,
        payload TEXT NOT NULL, received_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS reservations(brief_id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL,
        topic TEXT NOT NULL, target_date TEXT NOT NULL, status TEXT NOT NULL,
        approval_reference TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS design_jobs(brief_id TEXT PRIMARY KEY, revision INTEGER NOT NULL,
        state TEXT NOT NULL, brief_fingerprint TEXT NOT NULL, settings TEXT NOT NULL,
        references_json TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS design_assets(brief_id TEXT NOT NULL, revision INTEGER NOT NULL,
        stage TEXT NOT NULL, region TEXT NOT NULL, fingerprint TEXT NOT NULL, payload TEXT NOT NULL,
        PRIMARY KEY(brief_id,revision,stage,region));
      CREATE TABLE IF NOT EXISTS design_approvals(brief_id TEXT NOT NULL, revision INTEGER NOT NULL,
        stage TEXT NOT NULL, fingerprint TEXT NOT NULL, reference TEXT NOT NULL, created_at TEXT NOT NULL,
        PRIMARY KEY(brief_id,revision,stage));
      CREATE TABLE IF NOT EXISTS design_tasks(id TEXT PRIMARY KEY, brief_id TEXT NOT NULL,
        revision INTEGER NOT NULL, stage TEXT NOT NULL, fingerprint TEXT NOT NULL, status TEXT NOT NULL,
        payload TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(brief_id,revision,stage,fingerprint));
      CREATE TABLE IF NOT EXISTS design_events(id INTEGER PRIMARY KEY, brief_id TEXT NOT NULL,
        revision INTEGER NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS design_sizes(brief_id TEXT NOT NULL, revision INTEGER NOT NULL,
        fingerprint TEXT NOT NULL, bounds_json TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL,
        PRIMARY KEY(brief_id,revision));
    ''')
    c.commit()
    return c


def event(c, j, kind, payload):
    c.execute('INSERT INTO events(code,revision,kind,payload,created_at) VALUES(?,?,?,?,?)',
              (j['code'], j['revision'], kind, json.dumps(payload, ensure_ascii=False), now()))


def job(c, sku):
    j = c.execute('SELECT * FROM jobs WHERE code=?', (code(sku),)).fetchone()
    if not j and sku.endswith('_TQH'):
        j=c.execute('SELECT * FROM jobs WHERE code=?',(sku[:-4],)).fetchone()
    if j is None:
        raise ValueError('Listing is not registered in production')
    return dict(j)


def artifact(c, j, kind):
    x = c.execute('SELECT fingerprint,payload FROM artifacts WHERE code=? AND revision=? AND kind=?',
                  (j['code'], j['revision'], kind)).fetchone()
    return {'fingerprint': x[0], 'payload': json.loads(x[1])} if x else None


def put(c, j, kind, payload):
    if kind=='text':ensure_title_unique(c,j,payload.get('title'))
    fp = digest(payload)
    c.execute('INSERT OR REPLACE INTO artifacts VALUES(?,?,?,?,?)',
              (j['code'], j['revision'], kind, fp, json.dumps(payload, ensure_ascii=False)))
    event(c, j, 'artifact_' + kind, {'fingerprint': fp})
    return fp


def ensure_title_unique(c,j,title):
    import title_uniqueness
    title_uniqueness.ensure_unique(c,j['code'],title,ROOT)


def approved(c, j, stage, fingerprint):
    saved = c.execute('SELECT 1 FROM approvals WHERE code=? AND revision=? AND stage=? AND fingerprint=?',
                     (j['code'], j['revision'], stage, fingerprint)).fetchone() is not None
    if saved:
        return True
    import production_batch
    return production_batch.listing_policy(c, j, stage, fingerprint)


def task(c, j, kind, payload):
    fp = digest(payload)
    if kind=='lark_kpi':
        c.execute("UPDATE tasks SET status='superseded' WHERE kind='lark_kpi' AND status='pending' AND fingerprint!=?",(fp,))
    old = c.execute('SELECT * FROM tasks WHERE code=? AND revision=? AND kind=? AND fingerprint=?',
                    (j['code'], j['revision'], kind, fp)).fetchone()
    if old:
        return {**dict(old), 'payload': json.loads(old['payload'])}
    tid = str(uuid.uuid4())
    c.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)',
              (tid, j['code'], j['revision'], kind, fp, 'pending', json.dumps(payload, ensure_ascii=False), None, now()))
    event(c, j, 'task_created', {'task_id': tid, 'kind': kind})
    return {'id': tid, 'code': j['code'], 'revision': j['revision'], 'kind': kind, 'status': 'pending', 'payload': payload, 'fingerprint': fp}


def current_source(j):
    p = scoped(JOBS / (j['code'] + '.json'))
    if sha(p) != j['source_hash']:
        raise ValueError('Registered source changed; revise and review before continuing')
    source=read(p)
    brief=source['packet']['confirmed_product_brief']; plan=json.loads(j['plan'])
    if brief['product_id']!=plan.get('product_id') or brief['back_artwork']!=plan['back_artwork']:
        raise ValueError('Production plan differs from the confirmed product brief')
    styles={'crewneck':'crewneck sweatshirt','hoodie':'hoodie','quarter_zip':'quarter-zip pullover'}
    if plan.get('profile_version') != 3 and styles.get(plan['garment']) not in brief['available_styles']:
        raise ValueError('Garment style is not confirmed in the source')
    return source


def validate_plan(p):
    import production_profiles as profiles
    if profiles.current(p):
        return profiles.validate_plan(p, globals())
    from PIL import Image
    if p.get('garment') not in ['crewneck', 'hoodie', 'quarter_zip'] or not p.get('color'):
        raise ValueError('Confirmed garment and color required')
    if p.get('rendering_mode') == 'apparel_2d':
        if p['garment'] != 'crewneck' or p.get('regions') != {} or p.get('back_artwork') is not False or not str(p.get('idea_prompt', '')).strip():
            raise ValueError('Apparel 2D is crewneck only, with an idea and no artwork dimensions')
        a = p.get('approved_sample')
        if not a or sha(scoped(a['path'])) != a['sha256']:
            raise ValueError('Apparel 2D requires the exact approved garment sample')
        with Image.open(scoped(a['path'])) as im:
            im.verify()
        return p
    regions = p.get('regions', {})
    if not ({'center_chest', 'left_chest'} & set(regions)) or not {'left_sleeve', 'right_sleeve'} <= set(regions):
        raise ValueError('Chest and both sleeves must be explicitly specified')
    if {'center_chest', 'left_chest'} <= set(regions):
        raise ValueError('Choose one confirmed chest placement')
    if not isinstance(p.get('back_artwork'),bool) or p['back_artwork'] != ('back' in regions):
        raise ValueError('Back artwork flag disagrees with confirmed regions')
    limits = read(ROOT / 'config/embroidery-size-standard.json')['limits']
    for region, a in regions.items():
        if region not in ['center_chest', 'left_chest', 'left_sleeve', 'right_sleeve', 'back']:
            raise ValueError('Unknown embroidery placement')
        f = scoped(a['path'])
        if not f.is_file() or sha(f) != a['sha256']:
            raise ValueError('Locked artwork changed: ' + region)
        with Image.open(f) as im:
            im.verify()
        limit = limits['each_sleeve' if region.endswith('sleeve') else region]
        w, h = a['width_cm'], a['height_cm']
        # Accept one floating-point rounding step in previously locked dimensions.
        if not (0 < w <= math.nextafter(limit['max_width_cm'], math.inf) and 0 < h <= math.nextafter(limit['max_height_cm'], math.inf)):
            raise ValueError('Dimensions outside shared maximum')
        if not a.get('size_approval_reference') or not a.get('artwork_approval_reference'):
            raise ValueError('Artwork and resolved physical size need approval references')
    return p


def mockup_wardrobe(j, p):
    standard = read(ROOT / 'config/mockup-wardrobe-standard.json')
    if 'mockup_rotation_index' in p:
        index = p['mockup_rotation_index']
        if isinstance(index, bool) or not isinstance(index, int) or index < 0:
            raise ValueError('mockup_rotation_index must be a nonnegative integer')
    else:
        match = re.match(r'^[A-Z]{2,5}_\d{6}_(\d{2})(?:_|$)', j['code'])
        index = max(0, int(match.group(1))-1) if match else 0
    styles = standard['style_rotation']
    phase, cycle = index % len(styles), index // len(styles)
    selected = []
    for i, offset in enumerate(standard['style_offsets_by_image']):
        style = styles[(phase+offset) % len(styles)]
        if i in (0, 3):
            eligible = [c for c in standard['thumbnail_colors'] if c in standard['palettes'][style]]
            # Beige first for sweatshirt, then sand on the next cycle.
            color = list(reversed(eligible))[cycle % len(eligible)]
        elif i == 4:
            color = 'sand'
        else:
            colors = standard['color_rotation_by_style'][style]
            color = colors[(cycle + (1 if i == 5 else 0)) % len(colors)]
        if color not in standard['palettes'][style]:
            raise ValueError('Mockup color outside the approved style palette')
        selected.append({'garment': style, 'color': color})
    return standard, index, selected


def image_plan(j):
    import production_profiles as profiles
    if profiles.current(json.loads(j['plan'])):
        return profiles.image_plan(j, globals())
    p = json.loads(j['plan'])
    outline_rule = read(ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    if p.get('rendering_mode') == 'apparel_2d':
        standard = read(ROOT / 'config/mockup-wardrobe-standard.json')
        palette = standard['color_rotation_by_style']['crewneck sweatshirt']
        refs = {'approved_sample': p['approved_sample']} if p.get('approved_sample') else {}
        views = ['Complete sweater front hero with both sleeves visible.',
                 'Fully clothed adult wearing loose unisex sweater and jeans, front studio view.',
                 'Fully clothed adult wearing loose unisex sweater and jeans, three-quarter studio view.',
                 'Closeup of the exact flat artwork and surrounding fabric; preserve the flat design.',
                 'Full sweater flatlay, retain garment proportions; no invented size chart or measurements.',
                 'Clean complete sweater flatlay, natural garment shape.']
        images = []
        for n, (name, view) in enumerate(zip(IMAGES, views)):
            color = 'sand' if n == 0 else palette[(p.get('mockup_rotation_index', 0) + n) % len(palette)]
            content = ('Rephotograph the exact uploaded approved AOP crewneck. Lock its existing lettering, artwork size relative to the garment, placement, repeat bands, colors and ground. Change the camera/pose only; never redraw, shrink or simplify the print.' if refs else
                'Create a photorealistic crewneck sweatshirt product mockup with this complete flat 2D design idea: ' + p['idea_prompt'])
            garment = 'Keep the exact garment and ground color of the uploaded approved sample.' if refs else 'Garment: ' + color + ' crewneck sweatshirt.'
            prompt = (content +
                '\nSweater only. Preserve the same design, proportions, colors and placement in every view. Solid flat design; no stitched thread texture or bulky patch. '
                'Production method is unspecified; do not invent DTG, DTF, embroidery or a printing technique. Square 1:1, studio background. ' +
                garment + ' ' + view + (' Preserve garment proportions from the reference.' if refs else ' Garment size: ' + ('5XL.' if n in (1, 2) else 'XL.')) +
                ' No artwork dimensions, garment measurement labels, watermark or extra lettering. Preserve the approved print placement and garment construction. ' +
                ('\nLATEST HUMAN MOCKUP CORRECTION: ' + p['image_correction'] if p.get('image_correction') and not refs else '') +
                '\nREQUIRED CAMERA FOR THIS OUTPUT: ' + view +
                ' This camera/crop instruction overrides the source brief front-hero framing and the reference photo framing. '
                'Use the reference to lock the garment artwork, not to copy its camera view. For a closeup, crop into the artwork and fabric; do not show the complete sweater. '
                'For a three-quarter view, turn the model approximately 45 degrees so the side and sleeve are clearly visible. ' +
                ('\nVISUAL REVIEW CORRECTION FOR THIS VIEW: ' + p['mockup_corrections'][name] if p.get('mockup_corrections', {}).get(name) else '') + '\n' + outline_rule)
            images.append({'name': name, 'wardrobe': {'garment': 'crewneck sweatshirt', **({'color_source': 'locked_approved_sample'} if refs else {'color': color})}, 'prompt': prompt, 'status': 'pending'})
        return {'provider': 'Flow Nano Banana Pro', 'aspect_ratio': '1:1', 'executor': 'independent_flow_worker',
                'listing_code': j['code'], 'revision': j['revision'], 'references': refs, 'sizes_in': {}, 'images': images,
                'rendering_mode': 'apparel_2d', 'source_idea_prompt': p['idea_prompt'], 'wardrobe_standard': str(ROOT / 'config/mockup-wardrobe-standard.json')}
    common = ('Use the locked embroidery reference for each indicated region. Preserve every motif, color, '
              'letter, proportion, placement and stitch appearance. Do not add, mirror or omit artwork. '
              'Photorealistic studio product photography, simple neutral background, square 1:1. '
              'Actual physical dimensions below are fixed for all images. ')
    wardrobe_standard, rotation_index, wardrobe = mockup_wardrobe(j, p)
    sizes = {k: {'width_in': round(v['width_cm']/2.54, 2), 'height_in': round(v['height_cm']/2.54, 2)} for k,v in p['regions'].items()}
    views = [
      ('Front large with back smaller behind, both sleeves visible.' if p['back_artwork'] else 'Close product hero showing chest and both embroidered sleeves; use the approved ANM layout.'),
      'Fully clothed adult wearing this loose unisex garment and jeans in a commercial apparel catalogue photograph, front view, plain studio background; embroidery unobstructed.',
      ('Model rear three-quarter view showing approved back artwork and sleeve.' if p['back_artwork'] else 'Model three-quarter view showing chest and sleeves clearly.'),
      'Macro of the exact chest embroidery and surrounding fabric. Clearly visible neat Tatami/Satin threads, natural sheen, no plastic or bulky patch effect.',
      ('One studio flatlay composition displaying front, back and both sleeves.' if p['back_artwork'] else 'One studio flatlay displaying chest and both sleeves.') + ' Add legible width and height annotations for EVERY region, only the supplied inch numbers, with clean dimension lines outside artwork.',
      'Clean studio flatlay with all visible embroidery and natural garment shape, no measurements or extra lettering.'
    ]
    return {'provider': 'Flow Nano Banana Pro', 'aspect_ratio': '1:1', 'executor': 'independent_flow_worker',
            'requires_active_chrome_profile': 'Đức', 'listing_code': j['code'], 'revision': j['revision'],
            'references': p['regions'], 'sizes_in': sizes,
            'wardrobe_standard': str(ROOT / 'config/mockup-wardrobe-standard.json'),
            'mockup_rotation_index': rotation_index,
            'images': [{'name': name, 'wardrobe': wardrobe[i], 'prompt': common +
                       'Garment: ' + wardrobe[i]['color'] + ' ' + wardrobe[i]['garment'] + '. ' +
                       wardrobe_standard['construction_rule'] + ' PHYSICAL DIMENSIONS IN INCHES: ' + json.dumps(sizes) + '. ' +
                       view + (' Display only the supplied inch measurements.' if i==4 else ' Do not add measurement labels.') +
                       ('\nLATEST HUMAN MOCKUP CORRECTION: ' + p['image_correction'] if p.get('image_correction') else '') +
                       '\n' + outline_rule, 'status': 'pending'} for i,(name,view) in enumerate(zip(IMAGES,views))],
            'complete_only_after': 'download originals, preserve source paths and visually verify each of six images'}


def state(c, j, value, **extra):
    if j['state'] != value:
        c.execute('UPDATE jobs SET state=? WHERE code=?', (value, j['code']))
        event(c, j, 'state_changed', {'from': j['state'], 'to': value})
    return {'ok': True, 'listing_code': j['code'], 'revision': j['revision'], 'status': value, **extra}


def verify_assets(items, processed=False, expected_names=None):
    from PIL import Image
    import production_profiles as profiles
    if expected_names is not None and (not expected_names or not any(expected_names == [n for n in layout if n in expected_names] for layout in (IMAGES, profiles.PRINT, profiles.EMBROIDERY, profiles.GARMENT_SIX))):
        raise ValueError('Invalid expected product views')
    layouts = (expected_names,) if expected_names is not None else (IMAGES, profiles.PRINT, profiles.EMBROIDERY, profiles.GARMENT_SIX)
    if not isinstance(items, list) or [i.get('name') for i in items] not in layouts:
        raise ValueError('Images must match the versioned product layout in order')
    hashes = []
    for x in items:
        f = scoped(x['path'])
        if not f.is_file() or sha(f) != x['sha256']:
            raise ValueError('Asset missing or changed: ' + x['name'])
        with Image.open(f) as im:
            im.verify()
        with Image.open(f) as im:
            if im.width != im.height or (processed and (im.size != (3000,3000) or im.mode!='RGB' or im.format!='JPEG')):
                raise ValueError('Unexpected image format or dimensions')
        hashes.append(x['sha256'])
    if len(set(hashes)) != len(items):
        raise ValueError('Every view must be a distinct image')
    return items


def process(c, j, a, artifact_kind='processed', logo_regions=None):
    import production_profiles
    expected_names = production_profiles.names(json.loads(j['plan']))
    verify_assets(a['payload'], expected_names=expected_names)
    if logo_regions is not None:
        if set(logo_regions)!={x['name'] for x in a['payload']}:raise ValueError('Exact per-image logo regions required')
        for x in a['payload']:
            region=logo_regions[x['name']]
            if region.get('source_sha256')!=x['sha256'] or len(region.get('box',[]))!=4:raise ValueError('Logo region source binding mismatch')
    sys.path.insert(0, 'C:/Huy/Image Processor')
    from image_processor import save_as_jpeg
    plan=json.loads(j['plan']);category='Áo 2D' if plan.get('rendering_mode')=='apparel_2d' else 'Áo thêu'
    relative=Path(category)/j['code'].split('_')[0]/j['code']
    import delivery_layout
    originals,sources=delivery_layout.export_originals(j,a,globals(),public_code(c,j['code']))
    variant='-logo-'+digest(logo_regions)[:12] if logo_regions else ''
    target=scoped(STORE/'processed'/j['code']/('v%03d-'%j['revision']+a['fingerprint'][:12]+variant))
    target.mkdir(parents=True, exist_ok=True)
    report = target / 'report.json'
    if report.exists():
        saved = read(report)
        verify_assets(saved['images'], True, expected_names=expected_names)
        return put(c, j, artifact_kind, saved)
    output = []
    for x in sources:
        dst = scoped(target / x['name'])
        checkpoint=dst.with_suffix('.processor.json')
        if dst.exists() and checkpoint.exists():
            saved=read(checkpoint)
            if saved.get('source_sha256')==x['sha256'] and sha(dst)==saved.get('sha256'):
                output.append(saved)
                continue
        if dst.exists():
            # Preserve an unverified partial file, then regenerate from the locked original.
            dst.rename(scoped(dst.with_name(dst.name+'.unverified-'+uuid.uuid4().hex)))
        detail = save_as_jpeg(Path(x['path']), dst, 3000, remove_logo=True,
                              **({'logo_box':logo_regions[x['name']]['box'],'logo_method':logo_regions[x['name']].get('method')} if logo_regions else {}))
        item={'name': x['name'], 'path': str(dst), 'sha256': sha(dst),
                       'source_sha256': x['sha256'], 'logo': {'status': detail.status if detail else None,
                        'score': detail.score if detail else None, 'box': detail.box if detail else None}}
        write(checkpoint,item);output.append(item)
    verify_assets(output, True, expected_names=expected_names)
    result = {'images': output, 'sources_preserved': True, 'source_directory':str(originals),'destination_directory':str(target),'processor':'C:/Huy/Image Processor/image_processor.py','width_px': 3000,
              'remove_corner_logo': True, 'visual_qa': 'pending_user_review'}
    if logo_regions:result['source_bound_logo_regions']=logo_regions
    write(report, result)
    return put(c, j, artifact_kind, result)


def validate_text(j, text, allow_legacy=False):
    if text.get('listing_code') != j['code'] or text.get('provenance', {}).get('input_sha256') != j['source_hash']:
        raise ValueError('Text SKU or source hash mismatch')
    if not isinstance(text.get('title'), str) or not 135 <= len(text['title']) <= 140:
        raise ValueError('Title must be 135–140 characters')
    if not isinstance(text.get('description'), str) or not text['description'].strip():
        raise ValueError('Description missing')
    if json.loads(j['plan']).get('rendering_mode')=='apparel_2d':
        content=' '.join([text['title'],text['description'],*text.get('tags',[])])
        if re.search(r'\b(embroider\w*|tatami|satin stitches?|dtg|dtf|hoodie|quarter[ -]?zip)\b',content,re.I):
            raise ValueError('Apparel 2D copy cannot claim embroidery, unsupported methods or non-sweater styles')
    tags = text.get('tags')
    if not isinstance(tags, list) or len(tags)!=13 or any(not isinstance(t,str) or not 2<=len(t)<=20 for t in tags) or len(set(t.lower() for t in tags))!=13:
        raise ValueError('Need 13 unique English tags of 2–20 characters')
    checks = text.get('keyword_evidence', [])
    expected=15 if allow_legacy and isinstance(checks,list) and len(checks)==15 else 20
    if not isinstance(checks,list) or len(checks)!=expected or len(set(x.get('keyword') for x in checks))!=expected:
        raise ValueError('Exactly 20 distinct checked keyword records are required for new text')
    if any(x.get('requested_filter')!='physical' or not x.get('checked_at_utc') for x in checks):
        raise ValueError('Keyword evidence needs physical scope and check timestamps')
    if not set(tags)<=set(x['keyword'] for x in checks):raise ValueError('Final tags must come from the checked set')
    if expected==20 and not allow_legacy:
        if text.get('keyword_provenance',{}).get('keyword_policy')!='ai_first_20_to_13_v1':
            raise ValueError('New tags need the AI-first 20-to-13 policy provenance')
        if any(x.get('evidence_status') not in ('indexed_record','no_matching_record') for x in checks):
            raise ValueError('Keyword checks need a checked record or explicit no-match result')
    if text.get('keyword_provenance',{}).get('source_hash')!=j['source_hash']:
        raise ValueError('Keyword provenance source mismatch')
    return text


def advance(c, j):
    delivered=artifact(c,j,'package')
    if j['state']=='completed':
        if not delivered:raise ValueError('Completed listing has no delivery; reconcile without generating new images')
        for f in delivered['payload']['files']:
            if sha(scoped(f['path']))!=f['sha256']:raise ValueError('Completed delivery changed')
        return {'ok':True,'status':'completed','listing_code':j['code'],'revision':j['revision'],'package':delivered['payload'],'generation_called':False}
    source = current_source(j)
    validate_plan(json.loads(j['plan']))
    if not approved(c,j,'brief',digest(json.loads(j['plan']))):
        return state(c,j,'awaiting_brief_approval',approval_fingerprint=digest(json.loads(j['plan'])))
    a = artifact(c,j,'images')
    if not a:
        t = task(c,j,'flow_images',image_plan(j))
        return state(c,j,'awaiting_browser_images',browser_task=t)
    import production_profiles
    expected_names = production_profiles.names(json.loads(j['plan']))
    verify_assets(a['payload'], expected_names=expected_names)
    if not approved(c,j,'images',a['fingerprint']):
        return state(c,j,'awaiting_images_approval',approval_fingerprint=a['fingerprint'])
    p = artifact(c,j,'processed')
    if not p:
        process(c,j,a)
        p = artifact(c,j,'processed')
    verify_assets(p['payload']['images'],True,expected_names=expected_names)
    if not approved(c,j,'processed',p['fingerprint']):
        return state(c,j,'awaiting_processed_approval',approval_fingerprint=p['fingerprint'],images=p['payload']['images'])
    sync_text_registry(c,j)
    text = artifact(c,j,'text')
    if not text:
        return state(c,j,'needs_text',action='listing_text_keywords',preflight_only=False,input_sha256=j['source_hash'])
    validate_text(j,text['payload'],allow_legacy=True)
    ensure_title_unique(c,j,text['payload']['title'])
    fp = digest({'plan':json.loads(j['plan']),'images':p['fingerprint'],'text':text['fingerprint']})
    packet = {'listing_code':j['code'],'revision':j['revision'],'review_fingerprint':fp,
              'thumbnail':p['payload']['images'][0],'images':p['payload']['images'],
              'title':text['payload']['title'],'description':text['payload']['description'],'tags':text['payload']['tags']}
    if not approved(c,j,'final',fp):
        write(STORE/'artifacts'/j['code']/('v%03d'%j['revision'])/'review.json',packet)
        return state(c,j,'awaiting_final_approval',approval_fingerprint=fp,review=packet)
    if json.loads(j['plan']).get('delivery_backend') == 'local_v1':
        import local_delivery
        return local_delivery.publish(c,j,p,text,fp,globals())
    t = task(c,j,'lark_review',{'url':review_url(c),'layout':review_layout(c),'operation':'upsert_by_listing_code',
              'order':['listing_code','thumbnail','title','description','tags'],'packet':packet,
              'verify_after_reload':True,'do_not_duplicate_existing_code':True})
    # Review delivery is a separate verified gate, even if the user already approved locally.
    delivered = c.execute("SELECT 1 FROM tasks WHERE code=? AND revision=? AND kind='lark_review' AND status='verified'",
                          (j['code'],j['revision'])).fetchone()
    if not delivered:
        return state(c,j,'awaiting_lark_verification',approval_fingerprint=fp,browser_task=t)
    package = package_listing(c,j,p,text,fp)
    allocated = allocate_kpi(c,j,fp,package['completed_at'])
    if allocated['counted']:
        sheet=c.execute("SELECT value FROM config WHERE key='kpi_sheet'").fetchone()
        if not sheet:return state(c,j,'awaiting_kpi_sheet_connection',package=package,kpi=allocated)
        sync=task(c,j,'lark_kpi',{'url':json.loads(sheet[0])['url'],'operation':'upsert_by_target_date',
                  'rows':kpi_rows(c),'columns':['Ngày KPI','Số listing',*['Listing %02d'%i for i in range(1,22)]],'verify_after_reload':True})
        if sync['status']!='verified':return state(c,j,'awaiting_kpi_sync',package=package,kpi=allocated,browser_task=sync)
    return state(c,j,'completed',package=package,kpi=allocated)


def package_listing(c,j,p,text,fp,artifact_kind='package',delivery_variant=''):
    ensure_title_unique(c,j,text['payload']['title'])
    import delivery_layout
    return delivery_layout.package(c,j,p,text,fp,artifact_kind,delivery_variant,globals())


def next_kpi_day(c,cfg):
    saved=c.execute("SELECT value FROM config WHERE key='kpi_schedule'").fetchone()
    schedule=json.loads(saved[0]) if saved else {}
    start=datetime.strptime(schedule['start_date'],'%Y-%m-%d').date() if schedule else None
    latest=c.execute('SELECT target_date,COUNT(*) AS used FROM kpi GROUP BY target_date ORDER BY target_date DESC LIMIT 1').fetchone()
    if latest:
        if latest['used']>21:raise ValueError('Existing KPI day exceeds daily capacity 21')
        day=datetime.fromisoformat(latest['target_date']).date()+timedelta(days=int(latest['used']==21))
    else:
        day=datetime.fromisoformat(cfg['activated_at']).astimezone(TZ).date()+timedelta(days=cfg.get('lead_days',2))
    # Keep the configured first KPI date; later completion times never move the schedule.
    day=max(day,start) if start else day
    if schedule.get('calendar')=='mon_fri_alternate_sat':
        anchor=datetime.strptime(schedule['saturday_anchor'],'%Y-%m-%d').date()
        while day.weekday()==6 or (day.weekday()==5 and (day-anchor).days%14!=0):
            day+=timedelta(days=1)
    return day


def allocate_kpi(c,j,fp,completed):
    if j['code'].endswith('_PILOT'):
        return {'status':'explicit_test_listing_not_counted','counted':False}
    cfg=c.execute("SELECT value FROM config WHERE key='kpi_activation'").fetchone()
    if not cfg:return {'status':'not_started_until_workflow_acceptance','counted':False}
    cfg=json.loads(cfg[0])
    if completed < cfg['activated_at']:return {'status':'completed_before_activation','counted':False}
    old=c.execute('SELECT * FROM kpi WHERE code=?',(j['code'],)).fetchone()
    if old:return {'status':'already_recorded','counted':True,**dict(old)}
    day=next_kpi_day(c,cfg)
    reservation=c.execute('SELECT * FROM reservations WHERE code=?',(j['code'],)).fetchone()
    if reservation:
        if reservation['status']!='reserved':
            raise ValueError('Reservation is invalid; resolve it before counting')
        c.execute("UPDATE reservations SET status='counted',target_date=? WHERE code=?",(day.isoformat(),j['code']))
    c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)',(j['code'],j['revision'],day.isoformat(),completed,fp))
    event(c,j,'kpi_allocated',{'target_date':day.isoformat(),'daily_capacity':21,'allocation_policy':'sequential_21_per_day'})
    return {'status':'allocated_pending_sheet_sync','counted':True,'target_date':day.isoformat()}


def kpi_rows(c):
    dates=c.execute('SELECT DISTINCT target_date FROM kpi ORDER BY target_date').fetchall()
    return [{'date':d[0],'count':len(codes),'listing_codes':codes} for d in dates
            for codes in [[public_code(c,x[0]) for x in c.execute('SELECT code FROM kpi WHERE target_date=? ORDER BY completed_at,code',(d[0],))]]]


def validate_brief(b):
    if not isinstance(b,dict) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',b.get('brief_id','')):
        raise ValueError('Brief needs a stable brief_id without path characters')
    if not re.fullmatch(r'[A-Z]{2,5}',b.get('topic_code','')) or b.get('product_type')!='physical_apparel':
        raise ValueError('Confirmed topic and physical apparel brief required')
    if b.get('garment') not in (['crewneck','hoodie','quarter_zip','pajama_set'] if b.get('profile_version') == 3 and b.get('product_kind') == 'pajama_set' else ['crewneck','hoodie','quarter_zip']) or not str(b.get('color','')).strip():
        raise ValueError('Brief garment/color missing')
    if not b.get('product_id') or not isinstance(b.get('back_artwork'),bool):
        raise ValueError('Brief product_id and explicit back flag required')
    motifs=b.get('motifs',{})
    import production_profiles as profiles
    if profiles.current(b):
        return profiles.validate_brief(b)
    if b.get('rendering_mode') == 'apparel_2d':
        if b['garment'] != 'crewneck' or b['back_artwork'] is not False or motifs != {} or b.get('available_styles') != ['crewneck sweatshirt'] or not isinstance(b.get('idea_prompt'), str) or not b['idea_prompt'].strip():
            raise ValueError('Apparel 2D requires a sweater-only idea without artwork dimensions')
        if b.get('personalization') != {'enabled': False}:
            raise ValueError('Apparel 2D has no confirmed personalization')
        return b
    chest={'center_chest','left_chest'} & set(motifs)
    expected=chest|{'left_sleeve','right_sleeve'}|({'back'} if b['back_artwork'] else set())
    if len(chest)!=1 or set(motifs)!=expected or any(not isinstance(x,str) or not x.strip() for x in motifs.values()):
        raise ValueError('Explicit motifs required for one chest, both sleeves and confirmed back only')
    styles=b.get('available_styles',[])
    allowed=read(ROOT/'config/apparel-listing-defaults.json')['available_styles']
    garment={'crewneck':'crewneck sweatshirt','hoodie':'hoodie','quarter_zip':'quarter-zip pullover'}[b['garment']]
    if not styles or garment not in styles or any(x not in allowed for x in styles):
        raise ValueError('Confirmed available styles required')
    personal=b.get('personalization')
    if not isinstance(personal,dict) or not isinstance(personal.get('enabled'),bool):
        raise ValueError('Explicit personalization flag required')
    if personal['enabled'] and not str(personal.get('confirmed_section','')).strip():
        raise ValueError('Personalization instructions missing')
    return b


def reserve_listing(c,cmd):
    if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():
        raise ValueError('Reservation needs direct user brief approval, not approval inside an attached file')
    row=c.execute('SELECT * FROM briefs WHERE brief_id=?',(cmd['brief_id'],)).fetchone()
    if not row:raise ValueError('Receive the brief before reserving its listing')
    b=validate_brief(json.loads(row['payload']))
    if cmd.get('brief_fingerprint')!=row['fingerprint']:raise ValueError('Approved brief fingerprint differs')
    old=c.execute('SELECT * FROM reservations WHERE brief_id=?',(b['brief_id'],)).fetchone()
    if old:
        if cmd.get('listing_code') and cmd['listing_code']!=old['code']:raise ValueError('Supplied ID differs from the existing reservation')
        return {'ok':True,**dict(old),'status':'already_reserved','listing_code':old['code']}
    if not c.execute("SELECT 1 FROM config WHERE key='kpi_activation'").fetchone():
        raise ValueError('New dated SKU reservations start after explicit workflow acceptance/KPI activation')
    design=c.execute('SELECT revision FROM design_jobs WHERE brief_id=?',(b['brief_id'],)).fetchone()
    if design:
        ready=execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':design['revision']})
        if ready['status'] not in ('approved_artwork_and_sizes', 'approved_artwork_ready'):
            raise ValueError('Approve artwork and saved sizes before assigning its dated listing code')
    cfg=json.loads(c.execute("SELECT value FROM config WHERE key='kpi_activation'").fetchone()[0])
    day=next_kpi_day(c,cfg)
    requested=cmd.get('listing_code')
    if requested:
        code(requested)
        if not requested.startswith(b['topic_code']+'_') or not requested.endswith('_TQH'):raise ValueError('Supplied ID must match the topic and end with _TQH')
        datetime.strptime(requested.split('_')[1],'%y%m%d')
        if c.execute('SELECT 1 FROM reservations WHERE code=? UNION SELECT 1 FROM jobs WHERE code=?',(requested,requested)).fetchone() or (JOBS/(requested+'.json')).exists():raise ValueError('Supplied ID is already used; never silently assign another ID')
    while True:
        if requested:
            sku=requested;break
        stem=b['topic_code']+'_'+day.strftime('%y%m%d')+'_'
        sku=None
        for n in range(1,100):
            legacy=stem+('%02d'%n);candidate=public_code(c,legacy)
            if not c.execute('SELECT 1 FROM reservations WHERE code IN (?,?) UNION SELECT 1 FROM jobs WHERE code IN (?,?)',(candidate,legacy,candidate,legacy)).fetchone() and not (JOBS/(candidate+'.json')).exists() and not (JOBS/(legacy+'.json')).exists() and not (Path('C:/Huy/Chưa xử lý/Áo thêu')/b['topic_code']/candidate).exists() and not (Path('C:/Huy/Đã xử lý/Áo thêu')/b['topic_code']/candidate).exists():
                sku=candidate;break
        if sku:break
        day+=timedelta(days=1)
    c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',(b['brief_id'],sku,b['topic_code'],day.isoformat(),'reserved',cmd['reference'],now()))
    return {'ok':True,'status':'reserved','brief_id':b['brief_id'],'listing_code':sku,'target_date':day.isoformat(),
            'daily_capacity':21,'allocation_policy':'sequential_21_per_day','kpi_date_provisional':True}


def prepare_listing(c,cmd):
    reservation=c.execute('SELECT * FROM reservations WHERE brief_id=?',(cmd['brief_id'],)).fetchone()
    if not reservation or reservation['status']!='reserved':raise ValueError('An active approved reservation is required')
    b=json.loads(c.execute('SELECT payload FROM briefs WHERE brief_id=?',(cmd['brief_id'],)).fetchone()[0])
    plan=validate_plan(cmd['plan'])
    if any(plan.get(k)!=b[k] for k in ['product_id','garment','color','back_artwork']) or set(plan['regions'])!=set(b['motifs']):
        raise ValueError('Locked production plan differs from the received brief')
    design=c.execute('SELECT revision FROM design_jobs WHERE brief_id=?',(b['brief_id'],)).fetchone()
    if design:
        locked=execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':design['revision']})
        if locked['status'] not in ('approved_artwork_and_sizes', 'approved_artwork_ready') or digest(locked['plan'])!=digest(plan):
            raise ValueError('Production plan must match the exact approved design revision and stored sizes')
    sku=reservation['code']
    source=create_listing_source(apply_listing_facts(b,cmd),plan,sku,reservation['created_at'],'reserved_kpi_date',reservation['target_date'])
    dest=JOBS/(sku+'.json')
    if dest.exists():
        if read(dest)!=source:raise ValueError('Source path occupied; do not overwrite another source version')
    else:write(dest,source)
    return execute(c,{'action':'enqueue','listing_code':sku,'source_hash':sha(dest),'plan':plan})


def apply_listing_facts(b,cmd):
    facts=cmd.get('confirmed_listing_facts')
    if facts is None:return b
    if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():
        raise ValueError('Updated listing facts need direct user authority and approval reference')
    if not isinstance(facts,dict) or set(facts)-{'motifs','available_styles'}:
        raise ValueError('Listing facts may update motif descriptions and available garment styles only')
    merged=validate_brief({**b,**facts})
    if set(merged['motifs'])!=set(b['motifs']):raise ValueError('Listing facts cannot change embroidery placements')
    return {**merged,'listing_facts_provenance':{'authority':'direct_user','reference':cmd['reference'],'original_brief_preserved':True}}


def create_listing_source(b,plan,sku,created_at,code_status,target_date=None):
    base=read(ROOT/'config/listing-source-base.json')
    packet=base['packet']; packet['created_at_utc']=created_at
    packet['keyword_evidence']=[]
    packet['scope']='confirmed_brief_new_listing_not_ai_execution'
    packet['apparel_defaults']=read(ROOT/'config/apparel-listing-defaults.json')
    packet['embroidery_size_standard']=read(ROOT/'config/embroidery-size-standard.json')
    packet['original_description_template']['text']=(ROOT/'docs/templates/apparel-description-user-original.txt').read_text(encoding='utf-8-sig')
    packet['original_description_template']['source_sha256']=sha(ROOT/'docs/templates/apparel-description-user-original.txt')
    packet['approved_assets']=[{'name':region,'path':a['path'],'sha256':a['sha256'],'attachment_status':'reference_only_not_action_authorization'} for region,a in plan['regions'].items()]
    packet['confirmed_product_brief']={
        'product_id':b['product_id'],'listing_code':sku,'listing_code_status':code_status,
        'topic_code':b['topic_code'],'product_type':'physical_apparel','language':'en',
        'confirmed_design':{'garment':b['color']+' '+b['garment'],'placements':list(b['motifs']),
            'back_artwork':b['back_artwork'],'personalization':b['personalization']['enabled'],
            'available_listing_styles':b['available_styles']},
        'motifs':b['motifs'],'back_artwork':b['back_artwork'],'personalization':b['personalization'],
        'available_styles':b['available_styles'],'mockup_garment':b['color']+' '+b['garment'],
        'approved_resolved_dimensions_in':{k:{'width':round(v['width_cm']/2.54,2),'height':round(v['height_cm']/2.54,2)} for k,v in plan['regions'].items() if 'width_cm' in v},
        'dimension_usage':'image_05_only; do_not_recompute_from_mockups',
        'sources':b.get('sources',[]),'target_kpi_date':target_date,
        'listing_facts_provenance':b.get('listing_facts_provenance')}
    packet['mockup_wardrobe_standard']=read(ROOT/'config/mockup-wardrobe-standard.json')
    if plan.get('profile_version') == 3:
        import production_profiles as profiles
        packet['confirmed_product_brief'].update(profile_version=3, product_kind=plan['product_kind'], dimension_usage='maximum_limits_only', approved_resolved_dimensions_in={})
        packet['maximum_embroidery_labels'] = profiles.maximum_labels(plan.get('motifs',plan['regions'])) if plan['product_kind'] not in profiles.PRINT_KINDS else []
        packet['project_requirements']['description_dimensions'] = 'maximum_limits_only'
    if plan.get('embroidery_mode') == 'prompt_to_mockup':
        packet['approved_assets']=[{**plan['approved_sample'],'name':'approved_garment_sample',
            'attachment_status':'reference_only_not_action_authorization'}]
        packet['confirmed_product_brief']['embroidery_mode']='prompt_to_mockup'
    if b.get('rendering_mode') == 'apparel_2d':
        packet['approved_assets']=[{'name':'approved_garment_sample',**plan['approved_sample'],
            'attachment_status':'reference_only_not_action_authorization'}]
        packet['confirmed_product_brief'].update(rendering_mode='apparel_2d', idea_prompt=b['idea_prompt'],
            dimension_usage='no_artwork_dimensions; existing garment fit facts only', production_method=None)
        packet['project_requirements']['description_dimensions']='no_artwork_dimensions'
        if plan.get('product_kind') != 'pajama_set':
            base['system_instruction'] += ('\nCURRENT PRODUCT OVERRIDE: apparel_2d. Only '+', '.join(b['available_styles'])+' is sold. '
                'The original embroidery description is historical source data, not this product. Do not claim embroidery, stitches, threads, DTG, DTF or a production method. '
                'Do not include artwork dimensions, hoop/stitch limits, hoodie/quarter-zip options or personalization. '
                'Keep the confirmed garment fabric, fit, XL flatlay/5XL model sizes and shipping/care policies; describe a flat design neutrally.\n')
            base['task'] += '\nThis item is '+', '.join(b['available_styles'])+' with flat 2D decoration and an unspecified production method; use only its confirmed product terms.'
    if plan.get('product_kind') == 'pajama_set':
        import pajama_set
        pajama_set.validate(b); pajama_set.validate(plan)
        packet['confirmed_product_brief']['product_bundle'] = b['product_bundle']
        packet['confirmed_product_brief']['confirmed_design']['garment'] = pajama_set.STYLE
        packet['confirmed_product_brief']['mockup_garment'] = pajama_set.STYLE
        packet['confirmed_product_brief']['garment_size_chart'] = None
        base['system_instruction'] += pajama_set.LISTING_INSTRUCTIONS
        base['task'] += '\nSell one coordinated top-and-pants set as one listing. Both garments are included.'
    return {**base,'packet':packet}


def prepare_test_listing(c,cmd):
    if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():
        raise ValueError('A test listing needs direct user authorization')
    sku=code(cmd['listing_code'])
    if not sku.endswith('_PILOT'):raise ValueError('Test codes must end with _PILOT and cannot become daily KPI codes')
    row=c.execute('SELECT * FROM briefs WHERE brief_id=?',(cmd['brief_id'],)).fetchone()
    if not row:raise ValueError('Receive the actual brief before preparing its test listing')
    b=validate_brief(json.loads(row['payload']))
    if not sku.startswith(b['topic_code']+'_'):raise ValueError('Test code topic differs from the brief')
    design=c.execute('SELECT revision FROM design_jobs WHERE brief_id=?',(b['brief_id'],)).fetchone()
    if not design:raise ValueError('Test listing requires approved design and stored sizes')
    locked=execute(c,{'action':'design_plan','brief_id':b['brief_id'],'revision':design['revision']})
    if locked['status']!='approved_artwork_and_sizes':raise ValueError('Approve artwork and stored sizes before the native test')
    plan=validate_plan(locked['plan'])
    source=create_listing_source(apply_listing_facts(b,cmd),plan,sku,row['received_at'],'explicit_test_not_counted')
    source['packet']['scope']='native_n8n_test_listing_no_KPI'
    dest=JOBS/(sku+'.json')
    if dest.exists():
        if read(dest)!=source:raise ValueError('Existing test source differs; retain its history and use a new test code')
    else:write(dest,source)
    result=execute(c,{'action':'enqueue','listing_code':sku,'source_hash':sha(dest),'plan':plan})
    result.update({'scope':'native_test','kpi_counted':False,'source_file':str(dest)})
    return result


def resolve_plan(c,cmd):
    from PIL import Image, ImageChops
    row=c.execute('SELECT payload FROM briefs WHERE brief_id=?',(cmd['brief_id'],)).fetchone()
    if not row:raise ValueError('Brief missing')
    b=json.loads(row[0]); refs=cmd['artwork']
    if set(refs)!=set(b['motifs']):raise ValueError('Artwork regions must match the brief exactly')
    limits=read(ROOT/'config/embroidery-size-standard.json')['limits']; regions={}
    for region,a in refs.items():
        path=scoped(a['path'])
        if sha(path)!=a['sha256']:raise ValueError('Artwork changed')
        with Image.open(path) as image:
            if a.get('bounds_px') is not None:
                bounds=a['bounds_px']; method='explicit_bounds_require_review'
            elif image.mode=='RGBA' and image.getextrema()[3][0]<255:
                bounds=image.getchannel('A').getbbox(); method='alpha_bounds_require_review'
            else:
                rgb=image.convert('RGB'); white=Image.new('RGB',rgb.size,'white')
                difference=ImageChops.difference(rgb,white)
                channels=difference.split(); mask=ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2])
                bounds=mask.point(lambda v:255 if v>10 else 0).getbbox(); method='white_background_bounds_require_review'
            if not bounds or len(bounds)!=4 or not (0<=bounds[0]<bounds[2]<=image.width and 0<=bounds[1]<bounds[3]<=image.height):
                raise ValueError('Empty or invalid artwork bounds')
        limit=limits['each_sleeve' if region.endswith('sleeve') else region]
        width,height=bounds[2]-bounds[0],bounds[3]-bounds[1]
        factor=min(limit['max_width_cm']/width,limit['max_height_cm']/height)
        regions[region]={**a,'bounds_px':list(bounds),'width_cm':min(limit['max_width_cm'],width*factor),'height_cm':min(limit['max_height_cm'],height*factor),
                         'fit_method':method,'size_approval_reference':None}
    return {'ok':True,'status':'resolved_sizes_awaiting_review','plan':{'product_id':b['product_id'],
        'garment':b['garment'],'color':b['color'],'back_artwork':b['back_artwork'],'regions':regions},
        'note':'Inspect bounds, including any corner logo, and approve these once. Nothing was cropped/edited; no artwork or size approval was granted.'}


def sync_text_registry(c,j):
    # The existing native text workflow reads a separate file registry. Publish readiness only
    # after both source and processed-image gates are approved for this exact revision.
    if not approved(c,j,'brief',digest(json.loads(j['plan']))):return
    image=artifact(c,j,'images'); processed=artifact(c,j,'processed')
    if not image or not processed or not approved(c,j,'images',image['fingerprint']) or not approved(c,j,'processed',processed['fingerprint']):return
    refs=[x[0] for x in c.execute("SELECT reference FROM approvals WHERE code=? AND revision=? AND stage IN ('brief','images','processed')",(j['code'],j['revision']))]
    import production_batch
    batch_info, _ = production_batch.linked(c,code=j['code'])
    if batch_info:
        granted=production_batch.policy(c,batch_info)
        if granted:refs.append(granted['reference']+' | batch policy, no individual visual QA claimed')
    path=JOBS/'registry.json'; registry=read(path) if path.exists() else {'version':1,'jobs':{}}
    registry['jobs'][j['code']]={'status':'ready_for_title_description','input_sha256':j['source_hash'],
        'approval':{'brief_confirmed':True,'images_approved':True,'ai_text_generation_authorized':True,'reference':' | '.join(refs)}}
    write(path,registry)


def redate_listing(c,cmd):
    if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():
        raise ValueError('Re-dating needs direct user authorization')
    old=job(c,cmd['listing_code'])
    reservation=c.execute('SELECT * FROM reservations WHERE code=?',(old['code'],)).fetchone()
    if not reservation or reservation['status']!='reserved':raise ValueError('Only a reserved unfinished listing can be re-dated')
    if artifact(c,old,'package') or c.execute('SELECT 1 FROM kpi WHERE code=?',(old['code'],)).fetchone() or c.execute("SELECT 1 FROM tasks WHERE code=? AND kind='lark_review' AND status='verified'",(old['code'],)).fetchone():
        raise ValueError('Delivered or counted listings retain their original code')
    b=json.loads(c.execute('SELECT payload FROM briefs WHERE brief_id=?',(reservation['brief_id'],)).fetchone()[0])
    b['brief_id']=b['brief_id'][:60]+'-redate-'+uuid.uuid4().hex[:8]
    received=execute(c,{'action':'receive_brief','brief':b})
    c.execute("UPDATE reservations SET status='released' WHERE code=?",(old['code'],))
    fresh=reserve_listing(c,{'brief_id':b['brief_id'],'brief_fingerprint':received['brief_fingerprint'],
                           'authority':'direct_user','reference':cmd['reference']})
    prepared=prepare_listing(c,{'brief_id':b['brief_id'],'plan':json.loads(old['plan'])})
    new=job(c,prepared['listing_code'])
    # The user authorized changing the schedule. Preserve identical art/processed evidence;
    # regenerate text/checkpoints for the new source and require a new final approval.
    for kind in ['images','processed']:
        a=artifact(c,old,kind)
        if a:put(c,new,kind,a['payload'])
    for stage in ['brief','images','processed']:
        a=c.execute('SELECT * FROM approvals WHERE code=? AND revision=? AND stage=?',(old['code'],old['revision'],stage)).fetchone()
        if a:c.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?)',(new['code'],new['revision'],stage,a['fingerprint'],cmd['reference']+'; identical approved assets from '+old['code']+'; '+a['reference'],now()))
    c.execute("UPDATE jobs SET state='superseded' WHERE code=?",(old['code'],))
    c.execute("UPDATE tasks SET status='superseded' WHERE code=? AND status='pending'",(old['code'],))
    event(c,old,'redated',{'new_listing_code':new['code'],'reference':cmd['reference']})
    return {'ok':True,'status':'redated_final_approval_required','old_listing_code':old['code'],
            'listing_code':new['code'],'target_date':fresh['target_date'],'brief_id':b['brief_id']}


def execute(c,cmd):
    import flow_worker_pool
    with flow_worker_pool.command_scope(c,cmd,globals()):
        return execute_command(c,cmd)


def execute_command(c,cmd):
    action=cmd.get('action')
    if action in ('set_kpi_schedule','kpi_schedule'):
        if action=='set_kpi_schedule':
            if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():
                raise ValueError('KPI schedule needs direct user authorization')
            start=cmd.get('start_date','')
            if not isinstance(start,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',start):raise ValueError('Expected KPI start date YYYY-MM-DD')
            datetime.strptime(start,'%Y-%m-%d')
            schedule={'start_date':start,'daily_capacity':21,'reference':cmd['reference']}
            calendar=cmd.get('calendar','daily')
            if calendar not in ('daily','mon_fri_alternate_sat'):raise ValueError('Unknown KPI working calendar')
            if calendar=='mon_fri_alternate_sat':
                anchor=cmd.get('saturday_anchor','')
                if not isinstance(anchor,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',anchor):raise ValueError('Expected working Saturday anchor YYYY-MM-DD')
                if datetime.strptime(anchor,'%Y-%m-%d').weekday()!=5:raise ValueError('Working Saturday anchor must be Saturday')
                schedule.update(calendar=calendar,saturday_anchor=anchor)
            c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('kpi_schedule',json.dumps(schedule)))
        schedule=c.execute("SELECT value FROM config WHERE key='kpi_schedule'").fetchone()
        activation=c.execute("SELECT value FROM config WHERE key='kpi_activation'").fetchone()
        return {'ok':True,'schedule':json.loads(schedule[0]) if schedule else None,
                'next_target_date':next_kpi_day(c,json.loads(activation[0])).isoformat() if activation else None,
                'history_preserved':True,'generation_called':False}
    if isinstance(action,str) and action.startswith('thumbnail_'):
        import thumbnail_copy
        return thumbnail_copy.execute(c,cmd,globals())
    if isinstance(action,str) and action.startswith('chatgpt_'):
        import chatgpt_image_orchestration
        return chatgpt_image_orchestration.execute(c,cmd,globals())
    if isinstance(action,str) and action.startswith('batch_'):
        import production_batch
        return production_batch.execute(c,cmd,globals())
    if action=='lark_listing_verified':
        import urllib.request
        t=c.execute('SELECT * FROM tasks WHERE id=?',(cmd.get('task_id'),)).fetchone()
        if not t or t['kind']!='lark_review' or t['status'] not in ('pending','verified'):
            raise ValueError('Current Lark listing task required')
        j=job(c,t['code'])
        p=json.loads(t['payload']);packet=p['packet'];proof=cmd.get('proof',{})
        if j['revision']!=t['revision'] or digest(p)!=t['fingerprint']:
            raise ValueError('Lark listing task revision/payload differs')
        if proof.get('executor')!='lark_docs_api' or proof.get('verified_after_readback') is not True or not valid_review_url(c,p['url']) or proof.get('url')!=p['url'] or proof.get('content_fingerprint')!=packet['review_fingerprint']:
            raise ValueError('Actual official Lark API readback proof required')
        config=read(ROOT/'config/lark-review.private.json')
        req=urllib.request.Request('http://127.0.0.1:8792/lark-listing/'+t['id'],headers={'x-review-token':config['localToken']})
        with urllib.request.urlopen(req,timeout=15) as response:observed=json.load(response)
        expected={'listing_code':packet['listing_code'],'title':packet['title'],'description':packet['description'],
                  'tags':packet['tags'],'thumbnail_sha256':packet['thumbnail']['sha256']}
        if observed.get('ok') is not True or observed.get('task_id')!=t['id'] or observed.get('task_fingerprint')!=t['fingerprint'] or observed.get('document_url')!=p['url'] or observed.get('observed_listing_code_count')!=1 or observed.get('verified_after_readback') is not True or observed.get('official_api_origin')!='https://open.larksuite.com' or observed.get('content')!=expected:
            raise ValueError('Fresh Lark document content differs from the exact listing task')
        report=scoped(observed['readback_path']);allowed=(STORE/'lark-listing-readbacks').resolve()
        if report==allowed or not report.is_relative_to(allowed) or sha(report)!=observed.get('readback_sha256'):
            raise ValueError('Lark independent readback report path/hash differs')
        if proof.get('readback_path')!=str(report) or proof.get('readback_sha256')!=observed['readback_sha256']:
            raise ValueError('Submitted Lark receipt differs from independent readback')
        saved=read(report)
        if saved.get('content')!=expected or saved.get('task_id')!=t['id'] or saved.get('task_fingerprint')!=t['fingerprint']:
            raise ValueError('Lark readback report is not bound to this exact task/content')
        import production_profiles
        verify_assets(packet['images'],True,expected_names=production_profiles.names(json.loads(j['plan'])))
        c.execute("UPDATE tasks SET status='verified',proof=? WHERE id=?",(json.dumps(proof),t['id']))
        event(c,j,'lark_api_readback_verified',{'task_id':t['id'],'readback_sha256':observed['readback_sha256'],'individual_visual_qa':False})
        return {'ok':True,'status':'verified','task_id':t['id']}
    if action in ('kpi_sync_cycle','kpi_sync_verified','kpi_relayout'):
        import kpi_sync_orchestration
        return kpi_sync_orchestration.execute(c,cmd,globals())
    if action in ('flow_cycle','flow_attach','flow_auto_submit','flow_visual_check','lark_review_packet','lark_review_decision','lark_review_refresh'):
        import flow_lark_orchestration
        return flow_lark_orchestration.execute(c,cmd,globals())
    if isinstance(action,str) and action.startswith('design_'):
        return design_module().execute_design(c,cmd,globals())
    if action=='receive_brief':
        b=validate_brief(cmd['brief']); fp=digest(b)
        old=c.execute('SELECT fingerprint FROM briefs WHERE brief_id=?',(b['brief_id'],)).fetchone()
        if old and old[0]!=fp:raise ValueError('Brief changed; use a new brief_id/revision to preserve history')
        c.execute('INSERT OR IGNORE INTO briefs VALUES(?,?,?,?)',(b['brief_id'],fp,json.dumps(b,ensure_ascii=False),now()))
        return {'ok':True,'status':'received_not_approved','brief_id':b['brief_id'],'brief_fingerprint':fp,'listing_code':None}
    if action=='reserve_listing':return reserve_listing(c,cmd)
    if action=='prepare_listing':return prepare_listing(c,cmd)
    if action=='prepare_test_listing':return prepare_test_listing(c,cmd)
    if action=='resolve_plan':return resolve_plan(c,cmd)
    if action=='redate_listing':return redate_listing(c,cmd)
    if action=='cancel_listing':
        if cmd.get('authority')!='direct_user' or not str(cmd.get('reference','')).strip():raise ValueError('Cancellation needs direct user authorization')
        j=job(c,cmd['listing_code'])
        if artifact(c,j,'package') or c.execute('SELECT 1 FROM kpi WHERE code=?',(j['code'],)).fetchone():raise ValueError('Delivered/counting history cannot be cancelled by this action')
        c.execute("UPDATE reservations SET status='released' WHERE code=? AND status='reserved'",(j['code'],))
        c.execute("UPDATE jobs SET state='cancelled' WHERE code=?",(j['code'],))
        c.execute("UPDATE tasks SET status='superseded' WHERE code=? AND status='pending'",(j['code'],))
        event(c,j,'cancelled',{'reference':cmd['reference']})
        return {'ok':True,'status':'cancelled_history_preserved','listing_code':j['code']}
    if action=='browser_queue':
        rows=[dict(x) for x in c.execute("""SELECT t.* FROM tasks t JOIN jobs j ON j.code=t.code AND j.revision=t.revision
          WHERE t.status='pending' AND ((t.kind='flow_images' AND j.state='awaiting_browser_images')
          OR (t.kind='lark_review' AND j.state='awaiting_lark_verification')
          OR (t.kind='lark_kpi' AND j.state='awaiting_kpi_sync')) ORDER BY t.created_at,t.id LIMIT 10""")]
        for x in rows:x['payload']=json.loads(x['payload'])
        design_tasks=design_module().design_browser_queue(c)
        import production_batch
        rows=[x for x in rows if production_batch.runnable(c,code=x['code'])]
        design_tasks=[x for x in design_tasks if production_batch.runnable(c,brief_id=x['brief_id'])]
        rows=sorted(rows+design_tasks+production_batch.queue(c),key=lambda x:(x['created_at'],x['id']))[:10]
        return {'ok':True,'tasks':rows,'kpi_active':bool(c.execute("SELECT 1 FROM config WHERE key='kpi_activation'").fetchone())}
    if action=='reservations':
        return {'ok':True,'reservations':[dict(x) for x in c.execute('SELECT * FROM reservations ORDER BY target_date,code')]}
    if action=='enqueue':
        sku=code(cmd['listing_code']); plan=validate_plan(cmd['plan'])
        if c.execute('SELECT 1 FROM jobs WHERE code=?',(sku,)).fetchone():
            old=job(c,sku)
            if old['source_hash']!=cmd['source_hash'] or digest(json.loads(old['plan']))!=digest(plan):
                raise ValueError('SKU exists with a different revision; use revise')
            return {'ok':True,'status':'already_queued','listing_code':sku,'revision':old['revision']}
        source=read(JOBS/(sku+'.json'))
        if sha(JOBS/(sku+'.json'))!=cmd['source_hash'] or source['packet']['confirmed_product_brief']['listing_code']!=sku:
            raise ValueError('Registered source mismatch')
        c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)',(sku,1,'queued',cmd['source_hash'],json.dumps(plan,ensure_ascii=False),now()))
        j=job(c,sku); event(c,j,'enqueued',{'source_hash':cmd['source_hash']})
        return {'ok':True,'status':'queued','listing_code':sku,'revision':1,'brief_fingerprint':digest(plan)}
    if action=='queue':
        rows=[dict(x) for x in c.execute("SELECT code,revision,state,created_at FROM jobs WHERE state NOT IN ('completed','needs_revision','superseded','cancelled') AND substr(code,-6)!='_PILOT' ORDER BY COALESCE((SELECT MAX(id) FROM events e WHERE e.code=jobs.code AND e.kind='advance_attempt'),0),created_at,code LIMIT 10")]
        return {'ok':True,'batch_limit':10,'jobs':rows,'browser_executor':'active_codex_session_required'}
    if action=='kpi_export':
        rows=kpi_rows(c); file=STORE/'kpi'/('KPI-LISTING.tsv')
        file.parent.mkdir(parents=True,exist_ok=True)
        with file.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f,delimiter='\t'); w.writerow(['Ngày KPI','Số listing','Mã listing'])
            for x in rows:w.writerow([x['date'],x['count'],', '.join(x['listing_codes'])])
        return {'ok':True,'path':str(file),'rows':rows,'actual_sheet_sync':False}
    if action=='activate_kpi':
        if cmd.get('workflow_accepted_by_user') is not True or not cmd.get('reference'):
            raise ValueError('KPI starts only after explicit final workflow acceptance')
        existing=c.execute("SELECT value FROM config WHERE key='kpi_activation'").fetchone()
        if existing:return {'ok':True,'status':'already_active','activation':json.loads(existing[0])}
        config={'activated_at':now(),'reference':cmd['reference'],'daily_capacity':21,'lead_days':2,'tool_runs_weekends':True}
        c.execute('INSERT INTO config VALUES(?,?)',('kpi_activation',json.dumps(config)))
        return {'ok':True,'status':'active','activation':config}
    if action=='set_kpi_sheet':
        url=cmd.get('url','')
        if not re.match(r'^https://csg2m8jcr9dn\.sg\.larksuite\.com/(wiki|sheets)/[A-Za-z0-9]+$',url):
            raise ValueError('Expected verified Lark sheet URL in existing workspace')
        c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('kpi_sheet',json.dumps({'url':url,'reference':cmd.get('reference')})))
        return {'ok':True,'status':'sheet_location_saved','url':url}
    if action=='task_verified':
        t=c.execute('SELECT * FROM tasks WHERE id=?',(cmd['task_id'],)).fetchone()
        if not t:raise ValueError('Task missing')
        j=job(c,t['code'])
        if j['revision']!=t['revision']:raise ValueError('Task belongs to old revision')
        if t['status']=='verified':return {'ok':True,'status':'already_verified','task_id':t['id']}
        if t['status']!='pending' or t['kind'] not in ['lark_review','lark_kpi']:
            raise ValueError('Only a current pending Lark task can be verified; Flow needs real attached assets')
        expected='awaiting_lark_verification' if t['kind']=='lark_review' else 'awaiting_kpi_sync'
        if j['state']!=expected:raise ValueError('Job is not waiting for this delivery stage')
        proof=cmd.get('proof',{})
        if proof.get('verified_after_reload') is not True or not proof.get('url') or not proof.get('screenshot_path'):
            raise ValueError('Browser delivery needs visible result after reload and screenshot')
        scoped(proof['screenshot_path'])
        if not Path(proof['screenshot_path']).is_file():raise ValueError('Proof screenshot missing')
        if t['kind']=='lark_review':
            p=json.loads(t['payload'])
            if proof.get('content_fingerprint')!=p['packet']['review_fingerprint'] or not valid_review_url(c,p['url']) or not proof['url'].startswith(p['url']):
                raise ValueError('Proof does not match review/version/destination')
        if t['kind']=='lark_kpi':
            p=json.loads(t['payload'])
            if proof['url']!=p['url'] or proof.get('rows_fingerprint')!=digest(p['rows']):
                raise ValueError('KPI proof does not match the prepared rows')
            if digest(p['rows'])!=digest(kpi_rows(c)):
                raise ValueError('KPI snapshot changed; refresh task before writing/verifying the sheet')
            c.execute("UPDATE tasks SET status='verified',proof=? WHERE kind='lark_kpi' AND fingerprint=? AND status='pending'",(json.dumps(proof),t['fingerprint']))
        c.execute("UPDATE tasks SET status='verified',proof=? WHERE id=?",(json.dumps(proof),t['id']))
        event(c,j,'task_verified',{'task_id':t['id'],'kind':t['kind']})
        return {'ok':True,'status':'verified','task_id':t['id']}
    j=job(c,cmd['listing_code'])
    if action=='status':
        artifacts=[dict(x) for x in c.execute('SELECT kind,fingerprint FROM artifacts WHERE code=? AND revision=?',(j['code'],j['revision']))]
        tasks=[dict(x) for x in c.execute('SELECT id,kind,status FROM tasks WHERE code=? AND revision=?',(j['code'],j['revision']))]
        return {'ok':True,**{k:v for k,v in j.items() if k!='plan'},'artifacts':artifacts,'tasks':tasks}
    if action=='approve':
        if cmd.get('authority')!='direct_user' or not cmd.get('reference') or cmd.get('revision')!=j['revision']:
            raise ValueError('Current revision and direct user approval reference required')
        stage=cmd['stage']
        if stage not in ['brief','images','processed','final']:raise ValueError('Unknown approval stage')
        if stage=='brief':fp=digest(json.loads(j['plan']))
        elif stage=='final':
            p=artifact(c,j,'processed'); t=artifact(c,j,'text')
            if not p or not t:raise ValueError('Final assets/text missing')
            if not approved(c,j,'processed',p['fingerprint']):raise ValueError('Processed images need approval before final approval')
            fp=digest({'plan':json.loads(j['plan']),'images':p['fingerprint'],'text':t['fingerprint']})
        else:
            a=artifact(c,j,stage)
            if not a:raise ValueError('Artifact missing')
            fp=a['fingerprint']
        if fp!=cmd.get('fingerprint'):raise ValueError('Approval fingerprint differs from current artifact')
        c.execute('INSERT OR REPLACE INTO approvals VALUES(?,?,?,?,?,?)',(j['code'],j['revision'],stage,fp,cmd['reference'],now()))
        event(c,j,'approved',{'stage':stage,'fingerprint':fp,'reference':cmd['reference']})
        return {'ok':True,'status':'approved','stage':stage,'fingerprint':fp}
    if action=='revise':
        plan=validate_plan(cmd['plan']); source_hash=sha(JOBS/(j['code']+'.json'))
        if source_hash!=cmd['source_hash']:raise ValueError('New source hash mismatch')
        c.execute('UPDATE jobs SET revision=revision+1,state=?,source_hash=?,plan=? WHERE code=?',
                  ('queued',source_hash,json.dumps(plan,ensure_ascii=False),j['code']))
        c.execute("UPDATE tasks SET status='superseded' WHERE code=? AND revision=? AND status!='verified'",(j['code'],j['revision']))
        event(c,j,'revised',{'reason':cmd.get('reason'),'new_revision':j['revision']+1})
        return {'ok':True,'revision':j['revision']+1,'status':'all_current_approvals_invalidated'}
    if action=='reject':
        event(c,j,'rejected',{'stage':cmd.get('stage'),'reason':cmd['reason']})
        c.execute("UPDATE jobs SET state='needs_revision' WHERE code=?",(j['code'],))
        c.execute('DELETE FROM approvals WHERE code=? AND revision=?',(j['code'],j['revision']))
        return {'ok':True,'status':'needs_revision'}
    if action=='attach_images':
        import production_profiles
        items=verify_assets(cmd['images'],expected_names=production_profiles.names(json.loads(j['plan'])))
        if [a['name'] for a in items]!=production_profiles.names(json.loads(j['plan'])):
            raise ValueError('Image set belongs to a different product profile')
        old=artifact(c,j,'images')
        if old:
            if old['fingerprint']!=digest(items):raise ValueError('Images already attached; revise before changing')
            return {'ok':True,'status':'images_already_attached','fingerprint':old['fingerprint']}
        fp=put(c,j,'images',items)
        c.execute("UPDATE tasks SET status='assets_attached' WHERE code=? AND revision=? AND kind='flow_images' AND status='pending'",(j['code'],j['revision']))
        return {'ok':True,'status':'images_attached','fingerprint':fp}
    if action=='attach_processed':
        a=artifact(c,j,'images')
        if not a or not approved(c,j,'images',a['fingerprint']):
            raise ValueError('Source images must be approved before attaching processed exports')
        import production_profiles
        result=cmd['result']; verify_assets(result['images'],True,expected_names=production_profiles.names(json.loads(j['plan'])))
        if [a['name'] for a in result['images']]!=production_profiles.names(json.loads(j['plan'])):
            raise ValueError('Processed image set belongs to a different product profile')
        if not result.get('processing_report') or not result.get('prior_user_approval_reference'):
            raise ValueError('Reused exports need real processor report and previous approval reference')
        scoped(result['processing_report'])
        if not Path(result['processing_report']).is_file():raise ValueError('Prior processing report is missing')
        old=artifact(c,j,'processed')
        if old:
            if old['fingerprint']!=digest(result):raise ValueError('Processed version already exists; revise before changing')
            return {'ok':True,'status':'processed_exports_already_attached','fingerprint':old['fingerprint']}
        return {'ok':True,'status':'processed_exports_attached','fingerprint':put(c,j,'processed',result)}
    if action=='attach_text':
        old=artifact(c,j,'text')
        text=validate_text(j,cmd['text'],allow_legacy=bool(old and old['fingerprint']==digest(cmd['text'])))
        if old and old['fingerprint']!=digest(text):raise ValueError('Text changed; revise before replacing')
        fp=put(c,j,'text',text)
        return {'ok':True,'status':'text_attached','fingerprint':fp,'listing_code':j['code']}
    if action=='advance':
        if j['state'] in ['needs_revision','superseded','cancelled']:return state(c,j,j['state'])
        sync_text_registry(c,j)
        event(c,j,'advance_attempt',{})
        return advance(c,j)
    raise ValueError('Unknown production action')


def main():
    c=connect()
    try:
        cmd=json.load(sys.stdin)
        c.execute('BEGIN IMMEDIATE')
        result=execute(c,cmd)
        c.commit()
        print(json.dumps(result,ensure_ascii=True))
    except Exception as e:
        c.rollback()
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=True))
        sys.exit(1)
    finally:c.close()


if __name__=='__main__':main()
