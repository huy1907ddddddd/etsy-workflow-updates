"""Native KPI synchronization gates. No allocation, activation, AI or external API calls."""
import json
import re
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.error import HTTPError


EXECUTOR = 'independent_lark_sheets_worker'
COLUMNS = ['Ngày KPI','Số listing',*['Listing %02d'%i for i in range(1,22)]]


def activation(c):
    row = c.execute("SELECT value FROM config WHERE key='kpi_activation'").fetchone()
    return json.loads(row[0]) if row else None


def eligible(c, ledger, engine):
    if ledger['code'].endswith('_PILOT'):
        return None
    j = engine['job'](c, ledger['code'])
    package = engine['artifact'](c, j, 'package')
    if j['revision'] != ledger['revision'] or not package or j['state'] not in ('awaiting_kpi_sync', 'completed'):
        raise ValueError('KPI ledger is not bound to a current delivered package')
    p = package['payload']
    if (p.get('listing_code') != j['code'] or p.get('revision') != j['revision']
            or p.get('review_fingerprint') != ledger['fingerprint'] or p.get('completed_at') != ledger['completed_at']
            or engine['digest'](p) != package['fingerprint']):
        raise ValueError('KPI ledger/package fingerprint mismatch')
    if not p.get('files'):
        raise ValueError('Delivered package has no files')
    for asset in p['files']:
        if engine['sha'](engine['scoped'](asset['path'])) != asset['sha256']:
            raise ValueError('Delivered package changed after counting')
    delivered = False
    for row in c.execute("SELECT id,fingerprint,payload,proof FROM tasks WHERE code=? AND revision=? AND kind='lark_review' AND status='verified'", (j['code'], j['revision'])):
        payload, proof = json.loads(row['payload']), json.loads(row['proof'] or '{}')
        if (payload.get('packet', {}).get('review_fingerprint') == ledger['fingerprint']
                and proof.get('content_fingerprint') == ledger['fingerprint']
                and proof.get('executor') == 'lark_docs_api'
                and proof.get('verified_after_readback') is True
                and engine['valid_review_url'](c,payload.get('url')) and proof.get('url') == payload.get('url')):
            report = engine['scoped'](proof.get('readback_path', ''))
            allowed = (engine['STORE'] / 'lark-listing-readbacks').resolve()
            if report != allowed and report.is_relative_to(allowed) and report.is_file() and engine['sha'](report) == proof.get('readback_sha256'):
                saved = engine['read'](report)
                packet = payload['packet']
                expected = {'listing_code': j['code'], 'title': packet['title'], 'description': packet['description'],
                            'tags': packet['tags'], 'thumbnail_sha256': packet['thumbnail']['sha256']}
                delivered = delivered or (saved.get('task_id') == row['id'] and saved.get('task_fingerprint') == row['fingerprint']
                    and saved.get('verified_after_readback') is True and saved.get('observed_listing_code_count') == 1
                    and saved.get('official_api_origin') == 'https://open.larksuite.com'
                    and saved.get('document_url') == payload.get('url') and saved.get('content') == expected)
        if (payload.get('packet', {}).get('review_fingerprint') == ledger['fingerprint']
                and proof.get('content_fingerprint') == ledger['fingerprint']
                and proof.get('verified_after_reload') is True
                and engine['valid_review_url'](c,payload.get('url')) and str(proof.get('url', '')).startswith(payload['url'])):
            screenshot = engine['scoped'](proof.get('screenshot_path', ''))
            if screenshot.is_file():
                delivered = True
    if not delivered:
        raise ValueError('KPI requires exact current Lark review delivery verification')
    return j


def authoritative(c, engine):
    active = activation(c)
    if not active:
        return [], []
    rows, jobs = {}, []
    for record in c.execute('SELECT * FROM kpi ORDER BY target_date,completed_at,code').fetchall():
        ledger = dict(record)
        if ledger['code'].endswith('_PILOT'):
            continue
        if datetime.fromisoformat(ledger['completed_at']) < datetime.fromisoformat(active['activated_at']):
            raise ValueError('KPI contains a package completed before activation')
        datetime.strptime(ledger['target_date'], '%Y-%m-%d')
        j = eligible(c, ledger, engine)
        rows.setdefault(ledger['target_date'], []).append(engine['public_code'](c,ledger['code']))
        jobs.append(j)
    result = [{'date': date, 'count': len(codes), 'listing_codes': codes} for date, codes in sorted(rows.items())]
    if any(row['count'] > 21 for row in result):
        raise ValueError('Authoritative KPI date exceeds daily capacity 21')
    return result, jobs


def receipts(c):
    c.execute('''CREATE TABLE IF NOT EXISTS kpi_sync_receipts(command_hash TEXT PRIMARY KEY,
      task_id TEXT NOT NULL, result TEXT NOT NULL, proof TEXT NOT NULL, created_at TEXT NOT NULL)''')


def task_states(c):
    exists = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='kpi_sync_receipts'").fetchone()
    result = []
    for row in c.execute('''SELECT t.id,t.status,t.revision,t.fingerprint,t.code,j.revision AS current_revision
        FROM tasks t JOIN jobs j ON j.code=t.code WHERE t.kind='lark_kpi' ORDER BY t.created_at,t.id'''):
        record = dict(row)
        receipt = c.execute('SELECT result FROM kpi_sync_receipts WHERE task_id=? ORDER BY created_at DESC LIMIT 1', (row['id'],)).fetchone() if exists else None
        record['receipt'] = json.loads(receipt[0]) if receipt else None
        result.append(record)
    return result


def cycle(c, engine):
    import review_transport
    if review_transport.local_delivery(engine):
        import local_delivery
        proof = local_delivery.export_kpi(c, engine)
        grouped = {}
        for row in c.execute("SELECT * FROM kpi WHERE code NOT LIKE '%_PILOT' ORDER BY target_date,completed_at,code"):
            grouped.setdefault(row['target_date'], []).append(engine['public_code'](c,row['code']))
        rows = [{'date': date, 'count': len(codes), 'listing_codes': codes} for date,codes in grouped.items()]
        return {'ok': True, 'status': 'idle', 'delivery_backend': 'local_v1', 'observed_at': engine['now'](),
                'kpi_active': bool(activation(c)), 'rows': rows, 'rows_fingerprint': engine['digest'](rows),
                'tasks': [], 'task_states': task_states(c), 'local_export': proof, 'remote_api_calls': False}
    rows, jobs = authoritative(c, engine)
    tasks = []
    sheet = c.execute("SELECT value FROM config WHERE key='kpi_sheet'").fetchone()
    waiting = [j for j in jobs if j['state'] == 'awaiting_kpi_sync']
    if waiting and sheet:
        payload = {'url': json.loads(sheet[0])['url'], 'operation': 'upsert_by_target_date', 'rows': rows,
                   'columns': COLUMNS, 'verify_after_reload': True}
        # Reuse the native task routine so stale aggregate tasks are superseded durably.
        for j in waiting:
            prepared = engine['task'](c, j, 'lark_kpi', payload)
            row = c.execute('SELECT * FROM tasks WHERE id=?', (prepared['id'],)).fetchone()
            if row['status'] == 'pending':
                task = dict(row)
                task['payload'] = json.loads(task['payload'])
                tasks.append(task)
    return {'ok': True, 'observed_at': engine['now'](), 'kpi_active': bool(activation(c)),
            'rows': rows, 'rows_fingerprint': engine['digest'](rows), 'tasks': tasks, 'task_states': task_states(c),
            'executor_required': EXECUTOR if tasks else None,
            'status': 'awaiting_sheet_connection' if waiting and not sheet else 'ready' if tasks else 'idle'}


def proof_file(cmd, engine):
    proof = cmd.get('proof', {})
    if (proof.get('executor') != EXECUTOR or proof.get('verified_after_readback') is not True
            or not re.fullmatch('[a-f0-9]{64}', str(proof.get('sha256', '')))):
        raise ValueError('KPI API readback proof is required')
    path = engine['scoped'](proof.get('path', ''), (engine['ROOT'] / 'workspace/kpi-worker',))
    if not path.is_file() or engine['sha'](path) != proof['sha256']:
        raise ValueError('KPI readback proof file changed or missing')
    evidence = engine['read'](path)
    if (evidence.get('executor') != EXECUTOR or evidence.get('verified_after_readback') is not True
            or evidence.get('official_api_origin') != 'https://open.larksuite.com'
            or evidence.get('write_response', {}).get('code') != 0 or evidence.get('read_response', {}).get('code') != 0
            or not evidence.get('spreadsheet_token') or not evidence.get('sheet_id') or not evidence.get('range')):
        raise ValueError('Official Sheets API success/readback evidence missing')
    stamp = datetime.fromisoformat(str(evidence.get('readback_at', '')).replace('Z', '+00:00'))
    current = datetime.fromisoformat(engine['now']())
    if stamp.tzinfo is None or stamp > current:
        raise ValueError('KPI readback timestamp invalid')
    for key in ('task_id', 'revision', 'task_fingerprint', 'rows_fingerprint', 'target_url'):
        if evidence.get(key) != cmd.get(key):
            raise ValueError('KPI readback proof identity mismatch')
    return evidence


def canonical_readback(engine):
    config = engine['read'](engine['ROOT'] / 'config/lark-review.private.json')
    request = Request('http://127.0.0.1:8791/kpi-sheet', headers={'x-review-token': config['localToken']})
    with urlopen(request, timeout=35) as response:
        result = json.load(response)
    if result.get('ok') is not True or not isinstance(result.get('readback'), dict):
        raise ValueError('Canonical official Sheets readback is unavailable')
    return result['readback']


def normalize(rows, dates=None):
    if not isinstance(rows, list):
        raise ValueError('KPI normalized rows are required')
    result = {}
    for row in rows:
        date = row.get('date')
        if dates is not None and date not in dates:
            continue
        datetime.strptime(date, '%Y-%m-%d')
        codes, count = row.get('listing_codes'), row.get('count')
        if (date in result or not isinstance(codes, list) or any(not isinstance(code, str) for code in codes)
                or len(set(codes)) != len(codes) or type(count) is not int or count != len(codes)):
            raise ValueError('KPI duplicate date/code or inconsistent count')
        result[date] = {'date': date, 'count': count, 'listing_codes': sorted(codes)}
    return result


def verified(c, cmd, engine):
    evidence = proof_file(cmd, engine)
    receipts(c)
    command_hash = engine['digest'](cmd)
    prior = c.execute('SELECT result FROM kpi_sync_receipts WHERE command_hash=?', (command_hash,)).fetchone()
    t = c.execute("SELECT * FROM tasks WHERE id=? AND kind='lark_kpi'", (cmd.get('task_id'),)).fetchone()
    if not t:
        raise ValueError('KPI task missing')
    j = engine['job'](c, t['code'])
    if cmd.get('revision') != t['revision'] or j['revision'] != t['revision'] or cmd.get('task_fingerprint') != t['fingerprint']:
        raise ValueError('KPI task belongs to stale revision/fingerprint')
    if prior:
        ledger = c.execute('SELECT * FROM kpi WHERE code=?', (j['code'],)).fetchone()
        if not ledger or not eligible(c, dict(ledger), engine):
            raise ValueError('KPI receipt no longer matches a current delivered package')
        return json.loads(prior[0])
    if not activation(c) or t['status'] != 'pending' or j['state'] != 'awaiting_kpi_sync':
        raise ValueError('Current counted KPI task is not eligible for verification')
    rows, jobs = authoritative(c, engine)
    payload = json.loads(t['payload'])
    sheet = c.execute("SELECT value FROM config WHERE key='kpi_sheet'").fetchone()
    if (engine['digest'](payload) != t['fingerprint'] or engine['digest'](rows) != cmd.get('rows_fingerprint')
            or engine['digest'](payload['rows']) != cmd['rows_fingerprint']
            or cmd.get('target_url') != payload['url'] or not sheet or json.loads(sheet[0])['url'] != payload['url']):
        raise ValueError('KPI task, authoritative rows or destination changed')
    expected, remote = normalize(rows), normalize(evidence.get('rows'), {r['date'] for r in rows})
    if any(remote.get(date) != row for date, row in expected.items()):
        raise ValueError('Sheets readback does not match authoritative KPI dates/codes/counts')
    actual = canonical_readback(engine)
    if (actual.get('official_api_origin') != 'https://open.larksuite.com' or actual.get('read_response', {}).get('code') != 0
            or any(actual.get(key) != evidence.get(key) for key in ('target_url', 'spreadsheet_token', 'sheet_id', 'range'))):
        raise ValueError('Canonical Sheets destination does not match worker readback proof')
    stamp = datetime.fromisoformat(str(actual.get('readback_at', '')).replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('Canonical Sheets readback timestamp is stale')
    age = (datetime.fromisoformat(engine['now']()) - stamp).total_seconds()
    if age < -1 or age > 60:
        raise ValueError('Canonical Sheets readback timestamp is stale')
    canonical = normalize(actual.get('rows'), set(expected))
    if any(canonical.get(date) != row for date, row in expected.items()):
        raise ValueError('Actual official Sheets readback differs from authoritative KPI')
    verified_ids, completed = [], []
    for waiting in jobs:
        if waiting['state'] != 'awaiting_kpi_sync':
            continue
        prepared = engine['task'](c, waiting, 'lark_kpi', payload)
        c.execute("UPDATE tasks SET status='verified',proof=? WHERE id=? AND status='pending'", (json.dumps(cmd['proof']), prepared['id']))
        verified_ids.append(prepared['id'])
        engine['event'](c, waiting, 'kpi_api_sync_verified', {'task_id': prepared['id'], 'rows_fingerprint': cmd['rows_fingerprint'], 'proof': cmd['proof']})
        # Package and ledger already exist. This terminal gate never calls advance().
        engine['state'](c, waiting, 'completed')
        completed.append(waiting['code'])
    result = {'ok': True, 'status': 'verified_after_api_readback', 'task_id': t['id'],
              'revision': t['revision'], 'rows_fingerprint': cmd['rows_fingerprint'],
              'verified_task_ids': verified_ids, 'completed_listing_codes': completed, 'receipt_id': command_hash}
    c.execute('INSERT INTO kpi_sync_receipts VALUES(?,?,?,?,?)',
              (command_hash, t['id'], json.dumps(result), json.dumps(cmd['proof']), engine['now']()))
    return result


def execute(c, cmd, engine):
    if cmd['action']=='kpi_relayout':
        if cmd.get('authority')!='direct_user' or not cmd.get('reference'):raise ValueError('Explicit KPI layout instruction required')
        rows,_=authoritative(c,engine);config=engine['read'](engine['ROOT']/'config/lark-review.private.json')
        request=Request('http://127.0.0.1:8791/kpi-layout',data=json.dumps({'rows':rows}).encode(),headers={'x-review-token':config['localToken'],'Content-Type':'application/json'},method='POST')
        try:
            with urlopen(request,timeout=180) as response:result=json.load(response)
        except HTTPError as error:
            detail=json.load(error);raise ValueError('KPI layout: '+str(detail.get('code','provider_failed')))
        if result.get('ok') is not True or result.get('layout')!='one_listing_per_cell_v1':raise ValueError('KPI layout migration failed')
        actual=canonical_readback(engine)
        if actual.get('layout')!='one_listing_per_cell_v1' or normalize(actual.get('rows'),{r['date'] for r in rows})!=normalize(rows):raise ValueError('KPI per-cell canonical readback mismatch')
        c.execute('INSERT INTO events(code,revision,kind,payload,created_at) VALUES(?,?,?,?,?)',('SYSTEM',0,'kpi_layout_migrated',json.dumps({'reference':cmd['reference'],'sheet_id':result.get('sheet_id'),'rows':rows}),engine['now']()))
        return {'ok':True,'status':'kpi_one_listing_per_cell','layout':actual['layout'],'url':result.get('url'),'rows':rows,'kpi_allocation_unchanged':True}
    if cmd['action'] == 'kpi_sync_cycle':
        return cycle(c, engine)
    if cmd['action'] == 'kpi_sync_verified':
        return verified(c, cmd, engine)
    raise ValueError('Unknown KPI synchronization action')
