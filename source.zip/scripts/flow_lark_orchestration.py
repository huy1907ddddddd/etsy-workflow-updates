"""Image review gates used only inside a native n8n production execution."""
import json
import re
import urllib.request
import hashlib
import production_profiles
from datetime import datetime, timedelta
from types import SimpleNamespace


def check_hashes(value, e):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value:
            if e['sha'](e['scoped'](value['path'])) != value['sha256']:
                raise ValueError('Attached image changed')
        for child in value.values():
            check_hashes(child, e)
    elif isinstance(value, list):
        for child in value:
            check_hashes(child, e)


def review_generation(c, binding, e):
    c.execute('CREATE TABLE IF NOT EXISTS lark_review_generations(binding TEXT PRIMARY KEY,generation INTEGER NOT NULL)')
    key = e['digest'](binding)
    row = c.execute('SELECT generation FROM lark_review_generations WHERE binding=?', (key,)).fetchone()
    return key, row['generation'] if row else 0


def candidate_table(c):
    c.execute('CREATE TABLE IF NOT EXISTS flow_candidates(candidate_id TEXT PRIMARY KEY,entity TEXT NOT NULL,revision INTEGER NOT NULL,stage TEXT NOT NULL,fingerprint TEXT NOT NULL,assets TEXT NOT NULL,proof TEXT NOT NULL,result TEXT NOT NULL)')


def authorize_generation_retry(c, command, e):
    e['design_module']().authority(command)
    request = command['generation_retry']
    if not isinstance(request, dict) or not str(request.get('reason', '')).strip():
        raise ValueError('Explicit reason required for generation retry')
    tasks = e['execute'](c, {'action': 'browser_queue'})['tasks']
    task = next((t for t in tasks if t['id'] == request.get('task_id')), None)
    if not task or task['fingerprint'] != request.get('task_fingerprint') or task['revision'] != request.get('revision'):
        raise ValueError('Retry must name the exact current pending task')
    key = request.get('image_key')
    if key not in [i.get('region', i.get('name')) for i in task['payload']['images']]:
        raise ValueError('Retry region is not in current task')
    import flow_worker_pool
    journal_path = flow_worker_pool.runtime(e) / ('task-' + hashlib.sha256(task['id'].encode()).hexdigest() + '.json')
    journal = json.loads(journal_path.read_text(encoding='utf-8'))
    image = journal.get('images', {}).get(key, {})
    if journal.get('fingerprint') != task['fingerprint'] or journal.get('revision') != task['revision'] or image.get('status') != 'generation_started' or image.get('asset') or image.get('generation_id') != request.get('generation_id'):
        raise ValueError('Only the exact unresolved generation may be retried; acquired assets are preserved')
    if 'return_account_sha256' in request or 'return_generation_id' in request:
        choice = json.loads(flow_worker_pool.selection_file(e).read_text(encoding='utf-8'))
        policy = choice.get('account_policy', {})
        preferred = policy.get('preferred_email', '')
        import production_batch
        linked_batch = production_batch.linked(c, brief_id=task.get('brief_id'), code=task.get('code'))[0] if not task.get('batch_id') else None
        batch_id = task.get('batch_id') or (linked_batch or {}).get('batch_id')
        prior = next((v.get('prior_generation', {}) for v in journal.get('events', []) if v.get('event') == 'generation_retry_authorized' and v.get('image_key') == key and v.get('prior_generation', {}).get('generation_id') == request.get('return_generation_id')), {})
        evidence = next((v.get('unusual_activity_cooldown', {}) for v in journal.get('events', []) if v.get('event') == 'unusual_account_handover' and v.get('image_key') == key and v.get('generation_id') == request.get('return_generation_id')), {})
        if (request.get('cooldown_ms') != 600000 or not batch_id or choice.get('batch_id') != batch_id or policy.get('on_unusual_activity') == 'switch_account'
                or not preferred or request.get('return_account_sha256') != hashlib.sha256(preferred.encode()).hexdigest()
                or not any(a.get('email') == preferred for a in policy.get('accounts', [])) or prior.get('status') != 'generation_started'
                or prior.get('asset') or evidence.get('generation_id') != prior.get('generation_id') or not evidence.get('failed_tiles')):
            raise ValueError('Previous-account retry requires explicit timed permit and matching saved unusual history')
    permit = {**request, 'reference': command['reference'], 'authorized_at': e['now']()}
    if 'cooldown_ms' in request:
        if request['cooldown_ms'] != 600000:
            raise ValueError('Generation replacement cooldown must be ten minutes')
        permit['not_before'] = (datetime.fromisoformat(permit['authorized_at']) + timedelta(minutes=10)).isoformat()
    permit['permit_id'] = e['digest'](request)
    config_key = 'flow_generation_retry:' + permit['permit_id']
    prior = c.execute('SELECT value FROM config WHERE key=?', (config_key,)).fetchone()
    if prior:
        return json.loads(prior['value'])
    c.execute('INSERT INTO config VALUES(?,?)', (config_key, json.dumps(permit)))
    return permit


def current_candidate(c, entity, revision, stage, fingerprint, images, e):
    candidate_table(c)
    canonical = sorted((e['scoped'](a['path']).as_posix(), a['sha256']) for a in images)
    for row in c.execute('SELECT * FROM flow_candidates WHERE entity=? AND revision=? AND stage=? AND fingerprint=?',
                         (json.dumps(entity, sort_keys=True), revision, stage, fingerprint)):
        assets = json.loads(row['assets'])
        if sorted((e['scoped'](a['path']).as_posix(), a['sha256']) for a in assets) == canonical:
            check_hashes(assets, e)
            verify_candidate_proof(json.loads(row['proof']), e, c)
            return dict(row)
    return None


def auto_submit(c, cmd, e):
    from PIL import Image
    import production_batch
    result = production_batch.auto_submit(c,cmd,e)
    if result is not None:
        return result
    candidate_table(c)
    candidate_id = 'candidate-' + e['digest'](cmd)
    prior = c.execute('SELECT * FROM flow_candidates WHERE candidate_id=?', (candidate_id,)).fetchone()
    if prior:
        entity = json.loads(prior['entity'])
        j = e['design_module']().job(c, entity['brief_id']) if entity.get('brief_id') else e['job'](c, entity['listing_code'])
        if j['revision'] != cmd.get('revision'):
            raise ValueError('Candidate task revision changed')
        check_hashes(cmd, e)
        check_hashes(json.loads(prior['assets']), e)
        verify_candidate_proof(cmd['proof'], e, c)
        return json.loads(prior['result'])
    tasks = e['execute'](c, {'action': 'browser_queue'})['tasks']
    matches = [task for task in tasks if task['id'] == cmd.get('task_id')]
    if len(matches) != 1:
        raise ValueError('A current pending Flow task is required')
    task = matches[0]
    p = task['payload']
    if task['revision'] != cmd.get('revision') or task['fingerprint'] != cmd.get('task_fingerprint') or e['digest'](p) != task['fingerprint']:
        raise ValueError('Candidate task revision/fingerprint/payload changed')
    if cmd.get('proof', {}).get('executor') in ('independent_chatgpt_worker', 'codex_chatgpt_browser'):
        from chatgpt_image_orchestration import assert_route
        assert_route(c, cmd, e)
    elif p['provider'] != 'Flow Nano Banana Pro':
        raise ValueError('Independent worker must preserve Flow Nano Banana Pro')
    rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    items = [i for i in p['images'] if not task.get('missing_regions') or i.get('region') in task['missing_regions']]
    expected = [i.get('region', i.get('name')) for i in items]
    assets = cmd.get('assets')
    if not isinstance(assets, list) or [a.get('image_key') for a in assets] != expected or not expected:
        raise ValueError('Candidate assets must cover exact requested regions/views in order')
    proof = cmd.get('proof', {})
    verify_candidate_proof(proof, e, c)
    if not isinstance(proof.get('images'), list) or [image.get('image_key') for image in proof['images']] != expected:
        raise ValueError('Exact actual Flow proof required for every generated candidate region/view')
    provenance = proof.get('prompt_provenance', [])
    if not isinstance(provenance, list) or [a.get('image_key') for a in provenance] != expected:
        raise ValueError('Exact prompt provenance required for every candidate')
    import hashlib
    for item, record in zip(items, provenance):
        if not item['prompt'].rstrip().endswith(rule):
            raise ValueError('Current mandatory outline rule must finish the task prompt')
        refs = item.get('references', list(p.get('references', {}).values()))
        for ref in refs:
            if e['sha'](e['scoped'](ref['path'])) != ref['sha256']:
                raise ValueError('Locked reference changed')
        expected_hash = hashlib.sha256(item['prompt'].encode('utf-8')).hexdigest()
        if record.get('prompt_sha256') != expected_hash or record.get('reference_sha256') != sorted(ref['sha256'] for ref in refs):
            raise ValueError('Candidate prompt or reference provenance differs')
    design = task['kind'].startswith('flow_design_')
    if not design and task['kind'] != 'flow_images':
        raise ValueError('Only Flow image generation candidates supported')
    output = (e['scoped'](p['output_directory']) if design else
              (e['STORE'] / 'artifacts' / task['code'] / ('v%03d' % task['revision']) / 'flow-originals' / task['id']).resolve())
    for asset, spec in zip(assets, items):
        file = e['scoped'](asset['path'])
        if not file.is_relative_to(output) or file == output or e['sha'](file) != asset['sha256']:
            raise ValueError('Candidate original path/hash differs from task output')
        with Image.open(file) as image:
            image.verify()
        with Image.open(file) as image:
            import embroidery_layout
            if not embroidery_layout.ratio_ok(image.width, image.height, spec.get('aspect_ratio', '1:1')) or image.format not in ('PNG', 'JPEG', 'WEBP'):
                raise ValueError('Candidate original does not match the requested generator aspect ratio')
    proof = dict(proof, native_candidate_id=candidate_id)
    rejected = []
    if design:
        stage = p['stage']
        accepted = []
        for asset, spec in zip(assets, items):
            if spec.get('output_aspect_ratio') in ('7:26','9:16','16:9'):
                try:
                    embroidery_layout.normalize(asset, e)
                except embroidery_layout.SleeveCanvasRejected as error:
                    rejected.append({'image_key': asset['image_key'], 'reason': str(error)})
                    continue
            accepted.append(asset)
        result = None
        if accepted:
            attachment = {'action': 'design_attach', 'brief_id': task['brief_id'], 'revision': task['revision'], 'stage': stage,
                          'task_id': task['id'], 'assets': {a['image_key']: {'path': a['path'], 'sha256': a['sha256']} for a in accepted}, 'proof': proof}
            result = e['design_module']().execute_design(c, attachment, e, candidate=True)
        j = e['design_module']().job(c, task['brief_id'])
        assets = [dict(a, image_key=region) for region, a in e['design_module']().checked_assets(c, j, stage, SimpleNamespace(**e)).items()]
        fp = e['digest']({'partial': True, 'assets': assets}) if rejected else e['design_module']().fingerprint(c, j, stage, SimpleNamespace(**e))
        proof['basis_events'] = [row['id'] for row in c.execute("SELECT id FROM design_events WHERE brief_id=? AND revision=? AND kind='assets_attached'", (task['brief_id'], task['revision']))]
        entity = {'brief_id': task['brief_id']}
    else:
        stage = 'images'
        images = [{'name': a['image_key'], 'path': a['path'], 'sha256': a['sha256']} for a in assets]
        result = e['execute'](c, {'action': 'attach_images', 'listing_code': task['code'], 'images': images})
        fp = result['fingerprint']
        entity = {'listing_code': task['code']}
        j = e['job'](c, task['code'])
        e['state'](c, j, 'awaiting_images_approval', approval_fingerprint=fp)
        e['event'](c, j, 'flow_candidate_generated', {'fingerprint': fp, 'native_candidate_id': candidate_id, 'proof': proof})
    result = {'ok': True, 'status': 'design_canvas_rejected' if rejected else 'generated_candidate_awaiting_human_visual_review', **entity,
              'revision': task['revision'], 'stage': stage, 'fingerprint': fp, 'native_candidate_id': candidate_id,
              'quality_verified': False, 'attachment_result': result}
    if rejected:
        result.update(rejected_images=rejected, retained_regions=[a['image_key'] for a in assets])
    c.execute('INSERT INTO flow_candidates VALUES(?,?,?,?,?,?,?,?)',
              (candidate_id, json.dumps(entity, sort_keys=True), task['revision'], stage, fp, json.dumps(assets), json.dumps(proof), json.dumps(result)))
    return result


def authorized_flow_model(c, proof):
    if proof.get('model') == 'Nano Banana Pro':
        return True
    reference = proof.get('model_policy_reference')
    if c is None or proof.get('model') != 'Nano Banana 2.1' or not isinstance(reference, str) or not reference.strip():
        return False
    key = 'flow_model_policy:' + hashlib.sha256(reference.encode()).hexdigest()
    row = c.execute('SELECT value FROM config WHERE key=?', (key,)).fetchone()
    return bool(row and json.loads(row['value']) == {'enabled': True, 'model': 'Nano Banana 2.1', 'reference': reference})


def verify_candidate_proof(proof, e, c=None):
    if proof.get('executor') in ('independent_chatgpt_worker', 'codex_chatgpt_browser'):
        from chatgpt_image_orchestration import verify_proof
        return verify_proof(proof, e)
    from PIL import Image
    from urllib.parse import urlparse
    url = urlparse(proof.get('url', ''))
    if proof.get('executor') != 'independent_flow_worker' or not authorized_flow_model(c, proof) or proof.get('acquisition') != 'flow_download' or proof.get('visually_verified') is True or url.scheme != 'https' or url.hostname != 'flow.google.com' or url.username or url.password:
        raise ValueError('Real independent Flow original-download proof required; quality remains pending')
    records = [proof] + proof.get('images', [])
    for record in records:
        record_url = urlparse(record.get('url', ''))
        acquisition = record.get('acquisition')
        acquisition = acquisition.get('method') if isinstance(acquisition, dict) else acquisition
        if record.get('visually_verified') is True or not authorized_flow_model(c, record) or acquisition != 'flow_download' or record_url.scheme != 'https' or record_url.hostname != 'flow.google.com':
            raise ValueError('Each candidate image must retain actual Flow model/origin proof, without operator QA claims')
        screenshot = e['scoped'](record['screenshot_path'])
        if e['sha'](screenshot) != record.get('screenshot_sha256'):
            raise ValueError('Candidate screenshot SHA256 differs')
        with Image.open(screenshot) as image:
            image.verify()


def review_in_batch(c, review, batch_id):
    import production_batch
    entity = review.get('entity', {})
    if entity.get('brief_id') or entity.get('listing_code'):
        linked_batch, _ = production_batch.linked(c, brief_id=entity.get('brief_id'), code=entity.get('listing_code'))
        return bool(linked_batch and linked_batch['batch_id'] == batch_id)
    return entity.get('batch_id') == batch_id or review.get('batch_policy', {}).get('batch_id') == batch_id


def review_packet(c, entity, e):
    if entity.get('batch_id'):
        import production_batch
        b=production_batch.batch(c,entity['batch_id'])
        i = production_batch.item(c,b['batch_id'],entity['item_id'])
        return production_batch.sample_review(c,b,i,e) or production_batch.mockup_review(c,b,i,e)
    candidate = None
    design = bool(entity.get('brief_id'))
    if design:
        d = e['design_module']()
        j = d.job(c, entity['brief_id'])
        states = {'awaiting_design_2d_approval': '2d',
                  'awaiting_design_embroidery_approval': 'embroidery',
                  'approved_artwork_ready_for_sizes': 'sizes'}
        stage = states.get(j['state'])
        if not stage:
            return None
        if stage == 'sizes':
            row = c.execute('SELECT fingerprint,result FROM design_sizes WHERE brief_id=? AND revision=?',
                            (j['brief_id'], j['revision'])).fetchone()
            if not row:
                return None
            fp = row['fingerprint']
            details = json.loads(row['result'])
        else:
            fp = d.fingerprint(c, j, stage, SimpleNamespace(**e))
            details = None
        assets = d.checked_assets(c, j, 'embroidery' if stage == 'sizes' else stage, SimpleNamespace(**e))
        images = [dict(a, label=region) for region, a in assets.items()]
        proof_stage = 'embroidery' if stage == 'sizes' else stage
        events = c.execute("SELECT id,payload FROM design_events WHERE brief_id=? AND revision=? AND kind='assets_attached'",
                           (j['brief_id'], j['revision']))
        checked = set()
        proof_ids = []
        for event in events:
            payload = json.loads(event['payload'])
            proof = payload.get('proof', {})
            regions = set(payload.get('regions', []))
            if payload.get('stage') == proof_stage and proof.get('visually_verified') is True and regions - checked:
                checked.update(regions)
                proof_ids.append(event['id'])
        candidate_fp = d.fingerprint(c, j, proof_stage, SimpleNamespace(**e))
        candidate = current_candidate(c, {'brief_id': j['brief_id']}, j['revision'], proof_stage, candidate_fp, images, e)
        if not set(assets) <= checked and not candidate:
            raise ValueError('Actual operator visual evidence is required before Lark review')
        if not set(assets) <= checked:
            proof_ids = []
        entity = {'brief_id': j['brief_id']}
    else:
        j = e['job'](c, entity['listing_code'])
        import production_batch
        if production_batch.listing_policy(c,j,'brief',e['digest'](json.loads(j['plan']))):
            return None
        stage = {'awaiting_images_approval': 'images', 'awaiting_processed_approval': 'processed'}.get(j['state'])
        if not stage:
            return None
        a = e['artifact'](c, j, stage)
        if not a:
            raise ValueError('Review assets missing')
        fp = a['fingerprint']
        images = a['payload'] if stage == 'images' else a['payload']['images']
        e['verify_assets'](images, stage == 'processed', expected_names=production_profiles.names(json.loads(j['plan'])))
        proof = c.execute("SELECT id,payload FROM events WHERE code=? AND revision=? AND kind='flow_visual_checked' ORDER BY id DESC",
                          (j['code'], j['revision'])).fetchall()
        proof_ids = sorted(x['id'] for x in proof if json.loads(x['payload']).get('fingerprint') == fp)[:1]
        candidate = current_candidate(c, {'listing_code': j['code']}, j['revision'], stage, fp, images, e)
        if not candidate and stage == 'processed':
            source = e['artifact'](c, j, 'images')
            if source and e['approved'](c, j, 'images', source['fingerprint']):
                prior_candidate = current_candidate(c, {'listing_code': j['code']}, j['revision'], 'images', source['fingerprint'], source['payload'], e)
                expected_sources = {a['name']: a['sha256'] for a in source['payload']}
                if prior_candidate and all(a.get('source_sha256') == expected_sources.get(a['name']) for a in images):
                    candidate = prior_candidate
        if not proof_ids and not candidate:
            raise ValueError('This exact image set needs operator visual verification before Lark review')
        details = None
        entity = {'listing_code': j['code']}
    for a in images:
        if e['sha'](e['scoped'](a['path'])) != a['sha256']:
            raise ValueError('Review image changed')
    binding = {'entity': entity, 'revision': j['revision'], 'stage': stage, 'fingerprint': fp}
    _, generation = review_generation(c, binding, e)
    return {'review_id': 'flow-' + e['digest'](dict(binding, generation=generation))[:24], **binding,
            'summary': json.dumps({'stage': stage, 'entity': entity, 'revision': j['revision'],
                                   'sizes': details}, ensure_ascii=False),
            'images': [dict(a, label=a.get('label', a.get('name', 'artwork'))) for a in images],
            'visual_qa': ({'passed': False, 'status': 'awaiting_human_visual_review', 'executor': json.loads(candidate['proof']).get('executor', 'independent_flow_worker'),
                           'native_candidate_id': candidate['candidate_id'], 'reference': 'Stored native candidate ' + candidate['candidate_id'] + '; human visual review required'}
                          if candidate and not proof_ids else {'passed': True, 'reference': 'Stored operator visual evidence events: ' + str(proof_ids)})}


def canonical_decision(event_id, e):
    if not isinstance(event_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,180}', event_id):
        raise ValueError('Invalid Lark event id')
    import review_transport
    config = review_transport.config(e)
    request = urllib.request.Request('http://127.0.0.1:8790/outbox/' + event_id,
                                     headers={'x-review-token': config['localToken']})
    with urllib.request.urlopen(request, timeout=5) as response:
        result = json.load(response)
    envelope = result.get('envelope', {})
    body = envelope.get('body', {})
    if result.get('ok') is not True or envelope.get('status') not in ('pending', 'delivered'):
        raise ValueError('No authentic current Lark decision in bot outbox')
    if body.get('event_id') != event_id or body.get('authority') != 'direct_user':
        raise ValueError('Lark decision identity differs')
    review_transport.authorize(body, config)
    return body


def apply_decision(c, body, e):
    c.execute('CREATE TABLE IF NOT EXISTS lark_decisions(event_id TEXT PRIMARY KEY,review_id TEXT NOT NULL,result TEXT NOT NULL)')
    decision_key = body['event_id'] + ':' + body['review_id']
    prior = c.execute('SELECT result FROM lark_decisions WHERE event_id IN (?,?)', (decision_key, body['event_id'])).fetchone()
    if prior:
        return {'ok': True, 'accepted': True, 'status': 'already_applied', 'result': json.loads(prior['result'])}
    if body.get('entity',{}).get('batch_id'):
        import production_batch
        result=production_batch.sample_decision(c,body,e)
        if result.get('accepted'):
            c.execute('INSERT INTO lark_decisions VALUES(?,?,?)',(decision_key,body['review_id'],json.dumps(result)))
        return result
    packet = review_packet(c, body['entity'], e)
    fields = ('review_id', 'entity', 'revision', 'stage', 'fingerprint')
    if not packet or any(body.get(k) != packet.get(k) for k in fields):
        return {'ok': True, 'accepted': False, 'code': 'stale_review', 'status': 'stale_review'}
    if not body.get('reference') or not body.get('message_id'):
        raise ValueError('Actual Lark message evidence required')
    common = {**body['entity'], 'revision': body['revision'], 'stage': body['stage'],
              'fingerprint': body['fingerprint'], 'authority': 'direct_user', 'reference': body['reference']}
    decision = body.get('decision')
    if decision == 'approve':
        action = ('design_approve_sizes' if body['stage'] == 'sizes' else 'design_approve') if 'brief_id' in common else 'approve'
        result = e['execute'](c, dict(common, action=action))
        if body['stage'] == 'embroidery':
            result = e['execute'](c, {'action': 'design_plan', 'brief_id': common['brief_id'], 'revision': common['revision']})
    elif decision in ('revise', 'reject'):
        reason = body.get('reason', '').strip() or (body.get('text', '').strip() if decision == 'reject' else '')
        if not reason:
            raise ValueError('Correction or rejection needs the human reason')
        if 'brief_id' in common and body['stage'] in ('2d', 'embroidery') and decision == 'revise':
            result = e['execute'](c, dict(common, action='design_revise', reason=reason))
        elif 'brief_id' in common:
            d = e['design_module']()
            j = d.job(c, common['brief_id'])
            c.execute("UPDATE design_jobs SET state='needs_design_revision' WHERE brief_id=?", (j['brief_id'],))
            d.event(c, j, 'lark_correction_requested', dict(common, reason=reason), SimpleNamespace(**e))
            result = {'ok': True, 'status': 'needs_design_revision', 'reason': reason}
        elif decision == 'revise' and body['stage'] in ('images', 'processed'):
            result = revise_images(c, common, reason, e)
        else:
            result = e['execute'](c, dict(common, action='reject', reason=reason))
    else:
        raise ValueError('Unsupported human image decision')
    c.execute('INSERT INTO lark_decisions VALUES(?,?,?)', (decision_key, body['review_id'], json.dumps(result)))
    return {'ok': True, 'accepted': True, 'status': 'applied', 'result': result,
            'entity': body['entity'], 'decision': decision}


def revise_images(c, common, reason, e):
    j = e['job'](c, common['listing_code'])
    plan = json.loads(j['plan'])
    previous = c.execute('SELECT reference FROM approvals WHERE code=? AND revision=? AND stage=? AND fingerprint=?',
                         (j['code'], j['revision'], 'brief', e['digest'](plan))).fetchone()
    if not previous:
        raise ValueError('Approved locked brief/artwork/sizes required before image-only revision')
    e['validate_plan'](plan)
    plan['image_correction'] = reason
    c.execute('UPDATE jobs SET revision=revision+1,state=?,plan=? WHERE code=?', ('queued', json.dumps(plan, ensure_ascii=False), j['code']))
    c.execute("UPDATE tasks SET status='superseded' WHERE code=? AND revision=? AND status='pending'", (j['code'], j['revision']))
    updated = e['job'](c, j['code'])
    reference = previous['reference'] + '\nHuman image-only correction: ' + common['reference']
    c.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?)',
              (j['code'], updated['revision'], 'brief', e['digest'](plan), reference, e['now']()))
    e['event'](c, updated, 'image_revision_requested', {'prior_revision': j['revision'], 'prior_stage': common['stage'],
                                                     'reason': reason, 'reference': common['reference'], 'locked_inputs_retained': True})
    task = e['task'](c, updated, 'flow_images', e['image_plan'](updated))
    return e['state'](c, updated, 'awaiting_browser_images', browser_task=task)


def execute(c, cmd, e):
    action = cmd['action']
    if action == 'flow_auto_submit':
        return auto_submit(c, cmd, e)
    if action == 'lark_review_packet':
        entity = {k: cmd[k] for k in ('brief_id', 'listing_code','batch_id','item_id') if k in cmd}
        if len(entity) != 1 and set(entity)!={'batch_id','item_id'}:
            raise ValueError('Exactly one review entity required')
        packet = review_packet(c, entity, e)
        return {'ok': True, 'status': 'review_ready' if packet else 'no_image_review', 'review': packet}
    if action == 'lark_review_decision':
        return apply_decision(c, canonical_decision(cmd.get('event_id'), e), e)
    if action == 'lark_review_refresh':
        entity = {k: cmd[k] for k in ('brief_id', 'listing_code', 'batch_id', 'item_id') if k in cmd}
        if len(entity) != 1 and set(entity) != {'batch_id', 'item_id'}:
            raise ValueError('Exactly one review entity required')
        packet = review_packet(c, entity, e)
        if not packet or packet['review_id'] != cmd.get('review_id'):
            raise ValueError('Only the exact current image review can be refreshed')
        binding = {k: packet[k] for k in ('entity', 'revision', 'stage', 'fingerprint')}
        key, generation = review_generation(c, binding, e)
        c.execute('INSERT OR REPLACE INTO lark_review_generations VALUES(?,?)', (key, generation + 1))
        return {'ok': True, 'status': 'review_refreshed', 'review': review_packet(c, entity, e)}
    if action == 'flow_cycle':
        skipped_mockup = None
        if 'mockup_skip' in cmd:
            import production_batch
            skipped_mockup = production_batch.skip_mockup(c, cmd, e)
        if 'generation_failure_policy' in cmd:
            e['design_module']().authority(cmd)
            policy = cmd['generation_failure_policy']
            from chatgpt_image_orchestration import selection
            choice = selection(e)
            if choice.get('provider') != 'flow' or not isinstance(policy, dict) or policy.get('enabled') is not True or policy.get('cooldown_ms') != 60000:
                raise ValueError('Flow generation failure policy requires an explicit one-minute cooldown')
            choice['generation_failure_policy'] = {'enabled': True, 'cooldown_ms': 60000, 'reference': cmd['reference']}
            import flow_worker_pool
            e['write'](flow_worker_pool.selection_file(e), choice)
        if 'generation_retry' in cmd:
            if 'model_fallback' in cmd:
                from chatgpt_image_orchestration import selection
                fallback = selection(e).get('model_fallback_policy', {})
                if fallback.get('enabled') is not True or fallback.get('model') != 'Nano Banana 2.1' or cmd['model_fallback'] != 'Nano Banana 2.1' or fallback.get('reference') != cmd.get('reference'):
                    raise ValueError('Exact authorized Flow model fallback required')
            authorize_generation_retry(c, cmd, e)
            if 'model_fallback' in cmd:
                import flow_worker_pool
                e['write'](flow_worker_pool.runtime(e) / 'flow-model.json', {'model': fallback['model'], 'policy_reference': fallback['reference']})
        import production_batch
        # Image polling must not repeatedly run Google delivery and completion scans.
        batch_cycle=production_batch.cycle_step(c,e)
        for row in c.execute("SELECT brief_id,revision FROM design_jobs WHERE state NOT IN ('needs_design_revision','approved_artwork_and_sizes')").fetchall():
            if not production_batch.runnable(c,brief_id=row['brief_id']):continue
            e['execute'](c, {'action': 'design_advance', 'brief_id': row['brief_id'], 'revision': row['revision']})
        # Advance only the image gates. Text, delivery and KPI remain outside this cycle.
        for row in c.execute("SELECT code FROM jobs WHERE state IN ('queued','awaiting_browser_images','awaiting_images_approval')").fetchall():
            if not production_batch.runnable(c,code=row['code']):continue
            j = e['job'](c, row['code'])
            processed = e['artifact'](c, j, 'processed')
            if processed and e['approved'](c, j, 'processed', processed['fingerprint']):
                continue
            if e['approved'](c, j, 'brief', e['digest'](json.loads(j['plan']))):
                e['execute'](c, {'action': 'advance', 'listing_code': row['code']})
        queue = e['execute'](c, {'action': 'browser_queue'})
        reviews, review_issues = [], []
        entities = [{'brief_id': row['brief_id']} for row in c.execute('SELECT brief_id FROM design_jobs').fetchall()]
        entities += [{'listing_code': row['code']} for row in c.execute('SELECT code FROM jobs').fetchall()]
        for entity in entities:
            if not production_batch.runnable(c,**({'brief_id':entity['brief_id']} if entity.get('brief_id') else {'code':entity['listing_code']})):continue
            try:
                packet = review_packet(c, entity, e)
                if packet:
                    reviews.append(packet)
            except ValueError as error:
                review_issues.append({'entity': entity, 'error': str(error), 'requires_operator': True})
        tasks = [t for t in queue['tasks'] if t['kind'].startswith('flow_')]
        for task in tasks:
            linked_batch=production_batch.linked(c,brief_id=task.get('brief_id'),code=task.get('code'))[0] if task.get('brief_id') or task.get('code') else None
            task['flow_project_key']=task.get('batch_id') or (linked_batch['batch_id'] if linked_batch else 'listing-'+str(task.get('code') or task.get('brief_id')))
        from chatgpt_image_orchestration import selection
        choice = selection(e)
        if choice.get('batch_id'):
            tasks=[task for task in tasks if task.get('flow_project_key')==choice['batch_id']]
            reviews=[review for review in reviews if review_in_batch(c, review, choice['batch_id'])]
        if choice.get('provider') == 'chatgpt':
            tasks = []
        # Include durable task identities after completion/supersession so a worker
        # can retire an old unknown-submit journal without guessing from queue absence.
        task_states = [dict(row) for row in c.execute('''
            SELECT t.id,t.revision,t.fingerprint,t.status,j.revision AS current_revision
            FROM design_tasks t JOIN design_jobs j ON j.brief_id=t.brief_id
            UNION ALL
            SELECT t.id,t.revision,t.fingerprint,t.status,j.revision AS current_revision
            FROM tasks t JOIN jobs j ON j.code=t.code WHERE t.kind='flow_images'
        ''')]
        task_states += production_batch.task_states(c)
        reviews += batch_cycle.get('reviews',[])
        # Parked group members still need their own review cards, independent of the active Flow project.
        reviews += production_batch.controls.group_reviews(c, e)
        reviews = list({review['review_id']: review for review in reviews}.values())
        return {'ok': True, 'observed_at': e['now'](), 'tasks': tasks, 'operator_reviews': batch_cycle.get('operator_reviews', []),
                **({'mockup_skip_receipt': skipped_mockup} if skipped_mockup else {}),
                'unusual_activity_policy': choice.get('unusual_activity_policy') if choice.get('provider') == 'flow' else None,
                'generation_failure_policy': choice.get('generation_failure_policy') if choice.get('provider') == 'flow' else None,
                'account_policy': choice.get('account_policy') if choice.get('provider') == 'flow' else None,
                'model_fallback_policy': choice.get('model_fallback_policy') if choice.get('provider') == 'flow' else None,
                'generation_retries': [json.loads(r['value']) for r in c.execute("SELECT value FROM config WHERE key LIKE 'flow_generation_retry:%'")],
                'task_states': task_states,
                'reviews': reviews, 'review_issues': review_issues,
                'executor_required': 'independent_flow_worker' if tasks else ('human_visual_review' if review_issues else None)}
    if action == 'flow_attach':
        c.execute('CREATE TABLE IF NOT EXISTS flow_attachments(command_hash TEXT PRIMARY KEY,task_id TEXT NOT NULL,result TEXT NOT NULL)')
        command_hash = e['digest'](cmd)
        prior = c.execute('SELECT result FROM flow_attachments WHERE command_hash=? AND task_id=?',
                          (command_hash, cmd.get('task_id'))).fetchone()
        if prior:
            attach = cmd['attachment']
            current = (e['design_module']().job(c, attach['brief_id']) if attach.get('brief_id')
                       else e['job'](c, attach['listing_code']))
            if current['revision'] != cmd.get('revision'):
                raise ValueError('Flow task revision changed')
            check_hashes(attach, e)
            return json.loads(prior['result'])
        matches = [t for t in e['execute'](c, {'action': 'browser_queue'})['tasks'] if t['id'] == cmd.get('task_id')]
        if len(matches) != 1:
            raise ValueError('A current pending Flow task is required')
        t = matches[0]
        if t['revision'] != cmd.get('revision') or t['fingerprint'] != cmd.get('task_fingerprint'):
            raise ValueError('Flow task revision or fingerprint changed')
        attach = dict(cmd['attachment'])
        if t['kind'].startswith('flow_design_'):
            for k, value in {'action': 'design_attach', 'brief_id': t['brief_id'], 'revision': t['revision'],
                             'stage': t['stage'], 'task_id': t['id']}.items():
                if attach.get(k) != value:
                    raise ValueError('Attachment does not match claimed design task')
            result = e['execute'](c, attach)
            c.execute('INSERT INTO flow_attachments VALUES(?,?,?)', (command_hash, t['id'], json.dumps(result)))
            return result
        if t['kind'] != 'flow_images' or attach.get('action') != 'attach_images' or attach.get('listing_code') != t['code']:
            raise ValueError('Only a matching mockup image task can be attached')
        for a in t['payload']['references'].values():
            if e['sha'](e['scoped'](a['path'])) != a['sha256']:
                raise ValueError('Locked embroidery reference changed')
        proof = cmd.get('proof', {})
        if proof.get('visually_verified') is not True or proof.get('model') != 'Nano Banana Pro' or not proof.get('url', '').startswith('https://flow.google.com/'):
            raise ValueError('Actual Flow visual inspection and model evidence required')
        from PIL import Image
        with Image.open(e['scoped'](proof['screenshot_path'])) as im:
            im.verify()
        result = e['execute'](c, attach)
        j = e['job'](c, t['code'])
        e['event'](c, j, 'flow_visual_checked', {'fingerprint': result['fingerprint'], 'proof': proof})
        c.execute('INSERT INTO flow_attachments VALUES(?,?,?)', (command_hash, t['id'], json.dumps(result)))
        return result
    if action == 'flow_visual_check':
        j = e['job'](c, cmd['listing_code'])
        stage = cmd.get('stage')
        if stage not in ('images', 'processed') or cmd.get('revision') != j['revision']:
            raise ValueError('Exact current image stage required')
        a = e['artifact'](c, j, stage)
        if not a or a['fingerprint'] != cmd.get('fingerprint'):
            raise ValueError('Visual inspection must match exact image set')
        proof = cmd.get('proof', {})
        if proof.get('visually_verified') is not True or not proof.get('reference'):
            raise ValueError('Operator visual inspection required')
        from PIL import Image
        with Image.open(e['scoped'](proof['screenshot_path'])) as im:
            im.verify()
        e['verify_assets'](a['payload'] if stage == 'images' else a['payload']['images'], stage == 'processed', expected_names=production_profiles.names(json.loads(j['plan'])))
        e['event'](c, j, 'flow_visual_checked', {'fingerprint': a['fingerprint'], 'proof': proof})
        return {'ok': True, 'status': 'visual_inspection_recorded'}
    raise ValueError('Unknown Flow/Lark orchestration action')
