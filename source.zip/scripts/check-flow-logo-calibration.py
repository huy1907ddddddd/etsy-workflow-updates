"""Synthetic Image Processor checks; no production image files are modified."""
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
from PIL import Image

sys.path.insert(0,'C:/Huy/Image Processor')
from gemini_logo import remove_calibrated_logo
from gemini_logo import LogoResult
from image_processor import save_as_jpeg

alpha=np.load(Path('C:/Huy/Image Processor/flow-sparkle-alpha-1024.npy'))
y,x=np.mgrid[:1024,:1024]
background=np.stack([220+.01*x+.003*y,209+.008*x+.004*y,193+.009*x+.006*y],axis=-1)
background=np.clip(np.rint(background),0,255).astype(np.uint8)
for strength in (.95,1.,1.65):
    source=background.copy()
    opacity=(alpha*strength)[...,None]
    source[884:960,884:960]=np.rint(background[884:960,884:960]*(1-opacity)+255*opacity).astype(np.uint8)
    corrected,report=remove_calibrated_logo(Image.fromarray(source),(884,884,960,960),adaptive=True)
    actual=np.asarray(corrected)
    assert report.status=='removed'
    assert np.array_equal(actual[:884],source[:884]) and np.array_equal(actual[:, :884],source[:, :884])
    mask=alpha>0
    assert np.array_equal(actual[884:960,884:960][~mask],source[884:960,884:960][~mask])
    assert float(np.abs(actual[884:960,884:960].astype(float)-background[884:960,884:960])[mask].mean())<.8
    legacy,_=remove_calibrated_logo(Image.fromarray(source),(891,891,953,953))
    assert np.array_equal(np.asarray(legacy)[:891],source[:891])
try:
    remove_calibrated_logo(Image.fromarray(background),(891,891,953,953),adaptive=True)
    raise AssertionError('Partial calibration region was accepted')
except ValueError:
    pass
with tempfile.TemporaryDirectory(prefix='processor-mask-check-') as folder:
    source=Path(folder)/'source.png';destination=Path(folder)/'output.jpg'
    Image.fromarray(background).save(source)
    with patch('image_processor.remove_corner_logo',return_value=(Image.fromarray(background),LogoResult('removed',.9,(888,889,955,956)))) as detector:
        save_as_jpeg(source,destination,1024,logo_box=(884,884,960,960),logo_method='flow_auto_v1')
        detector.assert_called_once()
    with patch('image_processor.remove_corner_logo',return_value=(Image.fromarray(background),LogoResult('removed',.9,(10,10,70,70)))):
        try:
            save_as_jpeg(source,destination,1024,logo_box=(884,884,960,960),logo_method='flow_auto_v1')
            raise AssertionError('Detector escaped source-bound reviewed region')
        except ValueError:
            pass
print('Adaptive opacity inversion passed at three strengths; unchanged pixels outside the calibrated alpha mask and legacy bounds verified.')
