"""Native durable Lark batches. Human sample approval grants a named batch policy;
it never fabricates individual approvals or operator visual inspection.
"""
import hashlib
import json
import re
import urllib.request
from urllib.error import HTTPError
import uuid
import production_profiles as profiles
import production_batch_controls as controls
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

KINDS = ('embroidery_brief', 'embroidery_prompts', 'apparel_2d')


def tables(c):
    schema = '''
      CREATE TABLE IF NOT EXISTS production_batches(batch_id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL,queue_order INTEGER NOT NULL,reference TEXT,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS production_batch_items(batch_id TEXT NOT NULL,item_id TEXT NOT NULL,position INTEGER NOT NULL,state TEXT NOT NULL,revision INTEGER NOT NULL,brief_id TEXT NOT NULL,plan TEXT,images TEXT NOT NULL,listing_code TEXT,error TEXT,PRIMARY KEY(batch_id,item_id));
      CREATE TABLE IF NOT EXISTS production_batch_tasks(id TEXT PRIMARY KEY,batch_id TEXT NOT NULL,item_id TEXT NOT NULL,revision INTEGER NOT NULL,stage TEXT NOT NULL,fingerprint TEXT NOT NULL,status TEXT NOT NULL,payload TEXT NOT NULL,proof TEXT,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS production_batch_policies(batch_id TEXT PRIMARY KEY,batch_fingerprint TEXT NOT NULL,sample_fingerprint TEXT NOT NULL,reference TEXT NOT NULL,message_id TEXT NOT NULL,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS production_batch_events(event_id TEXT PRIMARY KEY,result TEXT NOT NULL);
    '''
    for statement in schema.split(';'):
        if statement.strip():
            c.execute(statement)


def batch(c, bid):
    tables(c)
    row = c.execute('SELECT * FROM production_batches WHERE batch_id=?', (bid,)).fetchone()
    if not row:
        raise ValueError('Batch not found')
    return dict(row)


def item(c, bid, iid):
    row = c.execute('SELECT * FROM production_batch_items WHERE batch_id=? AND item_id=?', (bid, iid)).fetchone()
    if not row:
        raise ValueError('Batch item not found')
    return dict(row)


def manifest(b):
    return json.loads(b['payload'])


def policy(c, b):
    row = c.execute('SELECT * FROM production_batch_policies WHERE batch_id=? AND batch_fingerprint=?', (b['batch_id'], b['fingerprint'])).fetchone()
    return dict(row) if row else None


def delegated_samples(c,b):
    row=c.execute('SELECT value FROM config WHERE key=?',('review_delegation:'+b['batch_id'],)).fetchone()
    return bool(row and json.loads(row[0]).get('batch_fingerprint')==b['fingerprint'] and manifest(b)['kind']=='apparel_2d')


def linked(c, brief_id=None, code=None):
    tables(c)
    field, value = ('brief_id', brief_id) if brief_id else ('listing_code', code)
    row = c.execute('SELECT * FROM production_batch_items WHERE ' + field + '=?', (value,)).fetchone()
    return (batch(c, row['batch_id']), dict(row)) if row else (None, None)


def design_policy(c, j, stage):
    b, i = linked(c, brief_id=j['brief_id'])
    if not b or b['status'] in ('stopped', 'cancelled') or i['state'] == 'failed':
        return None
    p = policy(c, b)
    if stage == 'sizes' and b['status'] != 'submitted':
        return (b['reference'] + '\nConfirmed batch sizing policy: derive largest uniform fit within shared limits once.',)
    if p and i['position'] > 0 and stage in ('2d', 'embroidery'):
        return (p['reference'] + '\nBatch policy; this item was not individually visually reviewed.',)
    return None


def listing_policy(c, j, stage, fingerprint):
    b, i = linked(c, code=j['code'])
    if not b or b['status'] in ('stopped', 'cancelled') or i['state'] == 'failed' or not policy(c, b):
        return False
    plan = json.loads(j['plan'])
    if not i['plan'] or json.loads(i['plan'])!=plan or plan.get('batch_fingerprint') != b['fingerprint'] or stage not in ('brief', 'images', 'processed', 'final'):
        return False
    if stage == 'processed' and delegated_samples(c, b):
        return False  # The delegated operator must inspect all final images, including logo removal.
    if stage == 'brief':
        return fingerprint == __import__('hashlib').sha256(json.dumps(plan, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if stage in ('images', 'processed'):
        a = c.execute('SELECT fingerprint FROM artifacts WHERE code=? AND revision=? AND kind=?', (j['code'], j['revision'], stage)).fetchone()
        return bool(a and a['fingerprint'] == fingerprint)
    return True


def set_item(c, i, state, **fields):
    values = {'state': state, **fields}
    c.execute('UPDATE production_batch_items SET ' + ','.join(k + '=?' for k in values) + ' WHERE batch_id=? AND item_id=?',
              (*values.values(), i['batch_id'], i['item_id']))


def normalize(cmd, e):
    if cmd.get('embroidery_mode') is not None and not profiles.current(cmd):
        raise ValueError('Embroidery creation mode requires the current product profile')
    if profiles.current(cmd):
        return profiles.normalize(cmd, e, normalize)
    bid = cmd.get('batch_id')
    if not isinstance(bid, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', bid):
        raise ValueError('Batch ID must be a safe stable identifier')
    kind = cmd.get('kind')
    inputs = cmd.get('items')
    if kind not in KINDS or not isinstance(inputs, list) or not 1 <= len(inputs) <= 500 or len(json.dumps(inputs)) > 2000000:
        raise ValueError('Choose one supported batch kind and 1 to 500 items within 2 MB')
    items = []
    for n, data in enumerate(inputs):
        if not isinstance(data, dict):
            raise ValueError('Batch items must be objects')
        requested = data.get('listing_code')
        if requested is not None:
            if not isinstance(requested,str) or not e['CODE'].fullmatch(requested) or not requested.endswith('_TQH'):
                raise ValueError('Supplied listing code must have format UST_261015_01_TQH')
            datetime.strptime(requested.split('_')[1],'%y%m%d')
            if data.get('topic_code',requested.split('_')[0])!=requested.split('_')[0]:
                raise ValueError('Supplied listing code conflicts with topic_code')
        iid = data.get('item_id', requested or '%04d' % (n + 1))
        if requested and iid!=requested:
            raise ValueError('Supplied listing code conflicts with item_id')
        if not isinstance(iid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', iid):
            raise ValueError('Invalid batch item ID')
        title = str(data.get('title', '')).strip()
        if not title or len(title) > 300:
            raise ValueError('Every batch item needs a short title')
        brief_id = 'B-' + hashlib.sha256((bid + ':' + iid).encode()).hexdigest()[:32]
        source = data.get('brief')
        if isinstance(source, dict):
            brief = dict(source, brief_id=brief_id)
        else:
            idea = data.get('idea_prompt') if kind == 'apparel_2d' else source
            if kind == 'embroidery_prompts':
                idea = title
            if not isinstance(idea, str) or not idea.strip() or len(idea) > 30000:
                raise ValueError('Every item needs its complete brief/idea')
            chest_region=data.get('chest_region','center_chest')
            if kind=='embroidery_brief':
                labels=list(re.finditer(r'(?im)^\s*(NGỰC|NGUC|CHEST|TAY|SLEEVES?)\s*:\s*',idea))
                parts={}
                for k,label in enumerate(labels):
                    region='chest' if label.group(1).upper() in ('NGỰC','NGUC','CHEST') else 'sleeves'
                    if region in parts:raise ValueError('Brief requires exactly one NGỰC/CHEST and one TAY/SLEEVE block')
                    parts[region]=idea[label.end():labels[k+1].start() if k+1<len(labels) else len(idea)].strip()
                if set(parts)!={'chest','sleeves'} or not all(parts.values()):
                    raise ValueError('Brief chưa chia vùng. Dùng NGỰC: ... và TAY: ... trên hai dòng, hoặc gửi brief JSON đầy đủ.')
            elif kind=='embroidery_prompts':
                rule=e['read'](e['ROOT']/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
                parts={'chest':e['design_module']().prompt_body(data.get('chest_prompt'),rule),
                       'sleeves':e['design_module']().prompt_body(data.get('sleeve_prompt'),rule)}
            else:
                parts={'chest':idea,'sleeves':idea}
            brief = {'brief_id': brief_id, 'topic_code': requested.split('_')[0] if requested else str(data.get('topic_code', 'GEN')),
                     'product_type': 'physical_apparel', 'product_id': brief_id, 'garment': 'crewneck',
                     'color': 'sand', 'available_styles': ['crewneck sweatshirt'] if kind == 'apparel_2d' else
                     ['crewneck sweatshirt', 'hoodie', 'quarter-zip pullover'],
                     'back_artwork': False, 'personalization': {'enabled': False}, 'sources': [],
                     'motifs': {} if kind == 'apparel_2d' else {chest_region: title + '\n' + parts['chest'],
                          'left_sleeve': title + '\n' + parts['sleeves'], 'right_sleeve': title + '\n' + parts['sleeves']}}
            if kind == 'apparel_2d':
                brief.update(rendering_mode='apparel_2d', idea_prompt=idea.strip())
        if kind == 'apparel_2d':
            brief.update(rendering_mode='apparel_2d', garment='crewneck', available_styles=['crewneck sweatshirt'], motifs={}, back_artwork=False)
            if not isinstance(brief.get('idea_prompt'), str) or not brief['idea_prompt'].strip():
                raise ValueError('Apparel 2D requires an idea_prompt')
        if requested and brief.get('topic_code')!=requested.split('_')[0]:
            raise ValueError('Supplied listing code conflicts with brief topic')
        e['validate_brief'](brief)
        record = {'item_id': iid, 'title': title, 'brief': brief}
        if requested:record['listing_code']=requested
        if kind == 'embroidery_prompts':
            rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
            d = e['design_module']()
            chest = data.get('chest_region', 'center_chest')
            if chest not in brief['motifs'] or chest not in ('center_chest', 'left_chest'):
                raise ValueError('Custom chest must match the brief')
            record['prompt_pack'] = {'chest_region': chest,
                'chest_prompt': d.prompt_body(data.get('chest_prompt'), rule),
                'sleeve_prompt': d.prompt_body(data.get('sleeve_prompt'), rule)}
        items.append(record)
    if len({x['item_id'] for x in items}) != len(items):
        raise ValueError('Duplicate item IDs')
    return {'batch_id': bid, 'name': str(cmd.get('name', bid))[:300], 'kind': kind, 'items': items,
            'sizing_policy': 'derive_once_largest_uniform_fit', 'completion_policy': 'human_first_sample_authorizes_bound_batch',
            'apparel_profile': 'crewneck_only_no_artwork_dimensions_no_unconfirmed_production_method'}


def batch_status(c, bid=None):
    tables(c)
    rows = c.execute('SELECT * FROM production_batches' + (' WHERE batch_id=?' if bid else '') + ' ORDER BY queue_order,created_at', (bid,) if bid else ()).fetchall()
    return {'ok': True, 'status': 'batch_status', 'batches': [{**{k: r[k] for k in ('batch_id', 'fingerprint', 'status', 'queue_order')},
            'name': manifest(dict(r))['name'], 'kind': manifest(dict(r))['kind'],
            'profile_version': manifest(dict(r)).get('profile_version', 1),
            'items': [dict(i) for i in c.execute('SELECT item_id,position,state,revision,brief_id,listing_code,error FROM production_batch_items WHERE batch_id=? ORDER BY position', (r['batch_id'],))]} for r in rows],
            'run_plan': controls.get(c, 'batch_run_plan')}


def task(c, b, i, stage, payload, e):
    fp = e['digest'](payload)
    old = c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=? AND item_id=? AND revision=? AND stage=? AND fingerprint=?',
                    (b['batch_id'], i['item_id'], i['revision'], stage, fp)).fetchone()
    if not old:
        c.execute('INSERT INTO production_batch_tasks VALUES(?,?,?,?,?,?,?,?,?,?)',
                  (str(uuid.uuid4()), b['batch_id'], i['item_id'], i['revision'], stage, fp, 'pending', json.dumps(payload, ensure_ascii=False), None, e['now']()))
        old = c.execute('SELECT * FROM production_batch_tasks WHERE batch_id=? AND item_id=? AND revision=? AND fingerprint=?',
                        (b['batch_id'], i['item_id'], i['revision'], fp)).fetchone()
    return {**dict(old), 'kind': 'flow_batch_images', 'payload': json.loads(old['payload'])}


def queue(c):
    import flow_worker_pool
    tables(c)
    rows = c.execute("""SELECT t.* FROM production_batch_tasks t JOIN production_batch_items i ON i.batch_id=t.batch_id AND i.item_id=t.item_id
        JOIN production_batches b ON b.batch_id=t.batch_id WHERE t.status='pending' AND i.revision=t.revision
        AND b.status='active' AND i.state IN ('generating_sample','generating_mockups') ORDER BY t.created_at,t.id""").fetchall()
    return [{**dict(r), 'kind': 'flow_batch_images', 'payload': json.loads(r['payload']), 'skipped_images': skipped_task(c, r['id'])} for r in rows if flow_worker_pool.in_scope(r['batch_id'])]


def skipped_task(c, task_id):
    return [json.loads(r[0]) for r in c.execute('SELECT value FROM config WHERE key LIKE ? ORDER BY key', ('flow_mockup_skip:' + task_id + ':%',))]


def item_names(c, b, i):
    omitted = {x['image_key'] for r in c.execute('SELECT id FROM production_batch_tasks WHERE batch_id=? AND item_id=? AND revision=?', (b['batch_id'], i['item_id'], i['revision'])) for x in skipped_task(c, r['id'])}
    return profiles.names({**manifest(b), 'skipped_mockups': sorted(omitted)})


def skip_mockup(c, cmd, e):
    """Record an exact provider-rejected mockup, without changing its immutable task payload."""
    from PIL import Image
    e['design_module']().authority(cmd)
    request = cmd['mockup_skip']; tables(c)
    t = c.execute('SELECT * FROM production_batch_tasks WHERE id=?', (request.get('task_id'),)).fetchone()
    if not t: raise ValueError('Only a current batch mockup can be skipped; never a design')
    b, i = batch(c, t['batch_id']), item(c, t['batch_id'], t['item_id'])
    if b['status'] not in ('active', 'stopped') or i['revision'] != t['revision'] or i['state'] != 'generating_mockups' or t['stage'] != 'mockups' or t['status'] != 'pending' or i['listing_code']:
        raise ValueError('Only a pending mockup may be skipped; representative review must remain real')
    if request.get('task_fingerprint') != t['fingerprint'] or request.get('revision') != t['revision']:
        raise ValueError('Skipped mockup task binding changed')
    p = json.loads(t['payload']); key = request.get('image_key')
    if e['digest'](p) != t['fingerprint'] or key not in [x['name'] for x in p['images']]: raise ValueError('Skipped mockup payload/image changed')
    config_key = 'flow_mockup_skip:' + t['id'] + ':' + key
    old = c.execute('SELECT value FROM config WHERE key=?', (config_key,)).fetchone()
    if old:
        receipt = json.loads(old[0])
        if receipt['generation_id'] != request.get('generation_id'): raise ValueError('Skipped generation changed')
        return receipt
    import flow_worker_pool
    owner = flow_worker_pool.lane_for_batch(c,b['batch_id'])
    journal = e['read'](flow_worker_pool.runtime(e,owner) / ('task-' + hashlib.sha256(t['id'].encode()).hexdigest() + '.json'))
    image = journal.get('images', {}).get(key, {})
    if journal.get('revision') != t['revision'] or journal.get('fingerprint') != t['fingerprint'] or image.get('status') != 'generation_started' or image.get('asset') or image.get('generation_id') != request.get('generation_id') or not image.get('generation_id'):
        raise ValueError('Only the exact failed generation may be skipped; acquired assets are preserved')
    evidence = request.get('evidence', {}); texts = evidence.get('failed_tiles', [])
    if not texts or not all(isinstance(x, str) for x in texts) or not any('this generation might violate our policies' in x.lower() for x in texts) or re.search(r'unusual activity|usage limit|credits|content (?:was |has been )?blocked|safety polic|policy violation', ' '.join(texts), re.I):
        raise ValueError('Actual might-violate Failed evidence required; no quota or security bypass')
    file = e['scoped'](evidence['screenshot_path'])
    if e['sha'](file) != evidence.get('screenshot_sha256'): raise ValueError('Skipped mockup evidence changed')
    with Image.open(file) as im: im.verify()
    if len(item_names(c, b, i)) <= 1: raise ValueError('Cannot skip every mockup; at least one valid image required')
    if len([x for x in p['images'] if x['name'] not in {r['image_key'] for r in skipped_task(c, t['id'])} and x['name'] != key]) == 0: raise ValueError('At least one acquired view required in the task submission')
    receipt = {k:request[k] for k in ('task_id', 'task_fingerprint', 'revision', 'image_key', 'generation_id')}
    receipt.update(batch_id=b['batch_id'], item_id=i['item_id'], reason='flow_generation_might_violate', evidence=evidence, reference=cmd['reference'], skipped_at=e['now']())
    c.execute('INSERT INTO config VALUES(?,?)', (config_key, json.dumps(receipt)))
    e['event'](c, {'code':b['batch_id'], 'revision':i['revision']}, 'mockup_skipped', receipt)
    return receipt


def runnable(c, brief_id=None, code=None):
    import flow_worker_pool
    b, i = linked(c, brief_id=brief_id, code=code)
    if not b:
        return not flow_worker_pool.enabled(c) and not c.execute("SELECT 1 FROM production_batches WHERE status='active'").fetchone()
    return b['status'] == 'active' and flow_worker_pool.in_scope(b['batch_id']) and i['state'] not in ('failed', 'completed', 'awaiting_kpi_activation')


def task_states(c):
    tables(c)
    return [dict(r) for r in c.execute('''SELECT t.id,t.revision,t.fingerprint,t.status,i.revision AS current_revision
        FROM production_batch_tasks t JOIN production_batch_items i ON i.batch_id=t.batch_id AND i.item_id=t.item_id''')]


def plan_images(c, b, i, sample, e):
    e = {**e, 'IMAGES': profiles.names(manifest(b))}
    data = manifest(b)['items'][i['position']]
    brief = data['brief']
    import embroidery_direct
    plan = json.loads(i['plan']) if i['plan'] else {'garment': 'crewneck', 'color': 'sand', 'back_artwork': False,
        'product_id': brief['product_id'], 'regions': {}, 'rendering_mode': 'apparel_2d', 'idea_prompt': brief['idea_prompt'],
        'mockup_rotation_index': i['position']}
    plan.pop('region_mapping_version', None)
    if embroidery_direct.enabled(manifest(b)):
        plan = json.loads(i['plan']) if i['plan'] else embroidery_direct.plan(brief)
    if profiles.current(manifest(b)):
        plan.update(profile_version=3, product_kind=manifest(b)['kind'])
        if manifest(b)['kind'] == 'pajama_set':
            plan.update(garment=brief['garment'], product_bundle=brief['product_bundle'])
        if manifest(b).get('mockup_set'):
            plan['mockup_set'] = manifest(b)['mockup_set']
    if manifest(b).get('reference_image'):
        plan['reference_image'] = manifest(b)['reference_image']
    if manifest(b).get('mockup_prompt_set'):
        plan['mockup_prompt_set'] = manifest(b)['mockup_prompt_set']
    if manifest(b).get('mockup_layout'):
        plan['mockup_layout'] = manifest(b)['mockup_layout']
    if manifest(b).get('layout_profile'):
        plan['layout_profile'] = manifest(b)['layout_profile']
    shared_correction = profiles.corrections(c, b['batch_id'], 'mockups')
    if shared_correction:
        plan['image_correction'] = shared_correction
    images = json.loads(i['images'])
    if not sample and images.get(e['IMAGES'][0]):
        plan['approved_sample'] = images[e['IMAGES'][0]]
    dummy = {'code': b['batch_id'] + '-' + i['item_id'], 'revision': i['revision'], 'plan': json.dumps(plan)}
    p = e['image_plan'](dummy)
    p.update(batch_id=b['batch_id'], item_id=i['item_id'], stage='sample_mockup' if sample else 'mockups', revision=i['revision'],
        output_directory=str(e['STORE'] / 'batches' / b['batch_id'] / i['item_id'] / ('v%03d' % i['revision']) / ('sample' if sample else 'mockups')))
    p.pop('listing_code', None)
    if sample:
        p['images'] = p['images'][:1]
    elif images.get(e['IMAGES'][0]):
        p['images'] = [image for image in p['images'] if image['name'] not in images]
        p['retained_images'] = [images[name] for name in e['IMAGES'] if name in images]
        p['references'] = dict(p['references'], approved_sample={**images[e['IMAGES'][0]], 'role': 'same_listing_layout_anchor'})
        rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for image in p['images']:
            if image.get('name') == profiles.EMBROIDERY[6] and manifest(b)['kind'] not in profiles.PRINT_KINDS:
                continue
            image['prompt'] = image['prompt'][:-len(rule)].rstrip() + '\nUse the same-listing photo for artwork placement and relative scale continuity. Preserve artwork colors and composition from the isolated sources; follow this shot\'s fixed garment style/color, pose and camera.\n' + rule
    return p


def sample_review(c, b, i, e):
    e = {**e, 'IMAGES': profiles.names(manifest(b))}
    images = json.loads(i['images'])
    asset = images.get(e['IMAGES'][0])
    if i['state'] != 'awaiting_sample_approval' or not asset:
        return None
    from flow_lark_orchestration import check_hashes, review_generation
    check_hashes(asset, e)
    fp = e['digest']({'batch_fingerprint': b['fingerprint'], 'revision': i['revision'], 'sample': asset})
    binding = {'entity': {'batch_id': b['batch_id'], 'item_id': i['item_id']}, 'revision': i['revision'], 'stage': 'sample_mockup', 'fingerprint': fp}
    _, generation = review_generation(c, binding, e)
    review_identity = dict(binding, generation=generation) if generation else binding
    task_proof = c.execute("SELECT proof FROM production_batch_tasks WHERE batch_id=? AND item_id=? AND revision=? AND stage='sample_mockup' AND status='assets_attached' ORDER BY created_at DESC LIMIT 1", (b['batch_id'], i['item_id'], i['revision'])).fetchone()
    executor = json.loads(task_proof['proof']).get('executor', 'independent_flow_worker') if task_proof and task_proof['proof'] else 'independent_flow_worker'
    return {'review_id': 'flow-' + e['digest'](review_identity)[:24], **binding, 'images': [dict(asset, name=e['IMAGES'][0], label='Mẫu đại diện')],
            'batch_policy': {'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'],
                'scope': 'representative_for_immutable_batch', 'kind': manifest(b)['kind'], 'item_count': len(manifest(b)['items'])},
            'summary': 'DUYỆT mẫu này đồng thời cho phép hoàn thiện toàn bộ batch bất biến ' + b['batch_id'] +
                       ' (' + str(len(manifest(b)['items'])) + ' mục): tạo ảnh, xử lý ảnh, SEO, giao file; KPI vẫn tuân thủ điều kiện kích hoạt. Các mục còn lại không được coi là đã kiểm tra bằng mắt riêng.',
            'visual_qa': {'passed': False, 'status': 'awaiting_human_visual_review', 'executor': executor,
                'reference': 'Stored original batch sample and provider task evidence; actual human review required.'}}


def sample_decision(c, body, e,delegated=False):
    b = batch(c, body['entity']['batch_id'])
    i = item(c, b['batch_id'], body['entity']['item_id'])
    review = sample_review(c, b, i, e) or mockup_review(c, b, i, e)
    if not review or any(body.get(k) != review[k] for k in ('review_id', 'entity', 'revision', 'stage', 'fingerprint')):
        return {'ok': True, 'accepted': False, 'status': 'stale_review'}
    if not body.get('message_id') or not body.get('reference'):
        raise ValueError('Real human sample message evidence required')
    if delegated and not body['message_id'].startswith('codex-visual-review:'):raise ValueError('Delegated review evidence required')
    decision = body.get('decision')
    if review['stage'] == 'mockups':
        if decision == 'approve':
            c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',
                      ('mockup_review:' + b['batch_id'] + ':' + i['item_id'] + ':' + str(i['revision']), json.dumps({'fingerprint': review['fingerprint'], 'reference': body['reference'], 'message_id': body['message_id']})))
        elif decision == 'reject':
            c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?", (b['batch_id'],))
            controls.stop_plan(c, b['batch_id'])
        else:
            raise ValueError('Hold the batch and use batch_revise_mockups to correct selected views without replacing approved originals')
        return {'ok': True, 'accepted': True, 'status': 'batch_mockups_' + decision, 'batch_id': b['batch_id']}
    if decision == 'approve':
        c.execute('INSERT OR IGNORE INTO production_batch_policies VALUES(?,?,?,?,?,?)',
                  (b['batch_id'], b['fingerprint'], review['fingerprint'], body['reference'], body['message_id'], e['now']()))
        set_item(c, i, 'ready_mockups')
    elif decision == 'revise':
        reason = str(body.get('reason', '')).strip()
        if not reason:
            raise ValueError('Sample correction needs a human reason')
        plan = json.loads(i['plan']) if i['plan'] else {'rendering_mode': 'apparel_2d', 'idea_prompt': manifest(b)['items'][i['position']]['brief']['idea_prompt'],
            'garment': 'crewneck', 'color': 'sand', 'back_artwork': False, 'regions': {}, 'product_id': i['brief_id'], 'mockup_rotation_index': i['position']}
        plan['image_correction'] = reason
        profiles.save_correction(c, b['batch_id'], 'mockups', reason, body['reference'])
        set_item(c, i, 'ready_sample', revision=i['revision'] + 1, images='{}', plan=json.dumps(plan, ensure_ascii=False))
        c.execute("UPDATE production_batch_tasks SET status='superseded' WHERE batch_id=? AND item_id=? AND status='pending'", (b['batch_id'], i['item_id']))
    elif decision == 'reject':
        c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?", (b['batch_id'],))
        controls.stop_plan(c, b['batch_id'])
    else:
        raise ValueError('Unsupported sample decision')
    return {'ok': True, 'accepted': True, 'status': 'batch_sample_' + decision, 'batch_id': b['batch_id'], 'policy_granted': decision == 'approve'}


def auto_submit(c, cmd, e):
    from PIL import Image
    from flow_lark_orchestration import verify_candidate_proof, check_hashes
    tables(c)
    row = c.execute('SELECT * FROM production_batch_tasks WHERE id=?', (cmd.get('task_id'),)).fetchone()
    if not row:
        return None
    t = dict(row)
    b, i = batch(c, t['batch_id']), item(c, t['batch_id'], t['item_id'])
    if b['status'] not in ('active', 'stopped') or i['state'] == 'cancelled' or i['revision'] != t['revision'] or cmd.get('revision') != t['revision'] or cmd.get('task_fingerprint') != t['fingerprint']:
        raise ValueError('Batch candidate is stale or stopped')
    p = json.loads(t['payload'])
    if e['digest'](p) != t['fingerprint']:
        raise ValueError('Batch task payload changed')
    skipped = {x['image_key'] for x in skipped_task(c, t['id'])}
    requested = [x for x in p['images'] if x['name'] not in skipped]
    expected = [x['name'] for x in requested]
    incoming = cmd.get('assets')
    if not isinstance(incoming, list) or [x.get('image_key') for x in incoming] != expected:
        raise ValueError('Batch originals must cover the exact requested views in order')
    proof = cmd.get('proof', {})
    if proof.get('executor') in ('independent_chatgpt_worker', 'codex_chatgpt_browser'):
        from chatgpt_image_orchestration import assert_route
        assert_route(c, cmd, e)
    verify_candidate_proof(proof, e, c)
    if [x.get('image_key') for x in proof.get('images', [])] != expected or [x.get('image_key') for x in proof.get('prompt_provenance', [])] != expected:
        raise ValueError('Exact per-view Flow proof/provenance required')
    rule = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
    for image, record in zip(requested, proof['prompt_provenance']):
        refs = image.get('references', list(p.get('references', {}).values()))
        check_hashes(refs, e)
        if not image['prompt'].endswith(rule) or record.get('prompt_sha256') != hashlib.sha256(image['prompt'].encode()).hexdigest() or record.get('reference_sha256') != sorted(r['sha256'] for r in refs):
            raise ValueError('Batch prompt/reference provenance changed')
    images = json.loads(i['images'])
    output = e['scoped'](p['output_directory'])
    for a in incoming:
        file = e['scoped'](a['path'])
        if file == output or not file.is_relative_to(output) or e['sha'](file) != a['sha256']:
            raise ValueError('Batch original output path/hash changed')
        with Image.open(file) as im:
            im.verify()
        with Image.open(file) as im:
            if im.width != im.height or im.format not in ('PNG', 'JPEG', 'WEBP'):
                raise ValueError('Batch originals must be square raster files')
        saved = {'name': a['image_key'], 'path': str(file), 'sha256': a['sha256']}
        if saved['name'] in images and images[saved['name']] != saved:
            raise ValueError('Do not replace locked batch artwork; revise the sample')
        images[saved['name']] = saved
    if t['status'] not in ('pending', 'assets_attached'):
        raise ValueError('Batch task no longer accepts assets')
    if t['status'] == 'assets_attached':
        return {'ok': True, 'status': 'batch_candidate_already_attached', 'batch_id': b['batch_id'], 'item_id': i['item_id'],
                'revision': i['revision'], 'stage': t['stage'], 'quality_verified': False}
    c.execute("UPDATE production_batch_tasks SET status='assets_attached',proof=? WHERE id=?", (json.dumps(proof), t['id']))
    status = ('awaiting_sample_approval' if i['position'] == 0 or delegated_samples(c,b) else 'ready_mockups') if t['stage'] == 'sample_mockup' else 'images_ready'
    set_item(c, i, status, images=json.dumps(images))
    return {'ok': True, 'status': 'generated_candidate_awaiting_human_visual_review' if t['stage'] == 'sample_mockup' else 'batch_images_generated_under_policy',
            'batch_id': b['batch_id'], 'item_id': i['item_id'], 'revision': i['revision'], 'stage': t['stage'],
            'quality_verified': False, 'batch_policy_reference': (policy(c, b) or {}).get('reference')}


def canonical_command(event_id, e):
    if not isinstance(event_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,180}', event_id):
        raise ValueError('Invalid batch event identity')
    import review_transport
    config = review_transport.config(e)
    req = urllib.request.Request('http://127.0.0.1:8790/batch-outbox/' + event_id, headers={'x-review-token': config['localToken']})
    with urllib.request.urlopen(req, timeout=5) as response:
        result = json.load(response)
    env = result.get('envelope', {})
    body = env.get('body', {})
    if result.get('ok') is not True or env.get('status') not in ('pending', 'delivered') or body.get('event_id') != event_id:
        raise ValueError('No authentic current batch command')
    if body.get('authority') != 'direct_user' or body.get('sender_open_id') != config['humanOpenId'] or body.get('chat_id') != config['chatId'] or not body.get('message_id') or not body.get('reference'):
        raise ValueError('Batch command sender/chat evidence is unauthorized')
    review_transport.authorize(body, config)
    return body


def completion_reports(c, e):
    import local_delivery
    google_file = e['ROOT'] / 'config/google-delivery.json'
    google_config = e['read'](google_file) if google_file.is_file() else None
    reports = []
    for row in c.execute("SELECT * FROM production_batches WHERE status='completed' ORDER BY queue_order"):
        b = dict(row)
        items = [dict(r) for r in c.execute('SELECT * FROM production_batch_items WHERE batch_id=? ORDER BY position', (b['batch_id'],))]
        if any(i['state'] not in ('completed', 'cancelled') for i in items):
            continue
        done = [i for i in items if i['state'] == 'completed']
        codes, folders, identities, file_count, kpi_count = [], set(), [], 0, 0
        for i in done:
            j = c.execute("SELECT * FROM jobs WHERE code=? AND state='completed'", (i['listing_code'],)).fetchone()
            package = e['artifact'](c, dict(j), 'package') if j else None
            if not package or not package['payload'].get('files'):
                break
            ledger = c.execute('SELECT * FROM kpi WHERE code=? AND revision=?', (j['code'], j['revision'])).fetchone()
            if not j['code'].endswith('_PILOT'):
                verified = c.execute("SELECT 1 FROM tasks WHERE code=? AND revision=? AND kind='lark_kpi' AND status='verified'", (j['code'], j['revision'])).fetchone()
                local = json.loads(j['plan']).get('delivery_backend') == 'local_v1' and local_delivery.verified(c, dict(j), e)
                if not ledger or not (verified or local) or ledger['fingerprint'] != package['payload']['review_fingerprint']:
                    break
                kpi_count += 1
            codes.append(e['public_code'](c, j['code']))
            folders.add(str(Path(package['payload']['destination']).parent))
            file_count += len(package['payload']['files'])
            identities.append([i['item_id'], j['revision'], package['payload']['review_fingerprint']])
        else:
            if not done:
                continue
            local_jobs = [e['job'](c, i['listing_code']) for i in done if i['listing_code'] and json.loads(e['job'](c, i['listing_code'])['plan']).get('delivery_backend') == 'local_v1']
            documents = [local_delivery.bundle(c, b['batch_id'], local_jobs, e)] if local_jobs else []
            reports.append({'report_id': 'batch-done-' + e['digest']([b['batch_id'], b['fingerprint'], identities])[:40],
                'kind': 'batch_completed', 'batch_id': b['batch_id'], 'queue_order': b['queue_order'], 'name': manifest(b).get('name'),
                'completed_count': len(done), 'item_count': len(items), 'cancelled_count': sum(i['state'] == 'cancelled' for i in items),
                'listing_codes': codes, 'file_count': file_count, 'kpi_count': kpi_count, 'output_directories': sorted(folders),
                'documents': documents, 'docs_url': None if local_jobs else e['review_url'](c), 'kpi_url': None if local_jobs else controls.get(c, 'kpi_sheet', {}).get('url')})
            if google_config and datetime.fromisoformat(b['created_at']) >= datetime.fromisoformat(google_config['start_after']):
                eligible = [e['job'](c, i['listing_code']) for i in done if not i['listing_code'].endswith('_PILOT')]
                receipts = [e['artifact'](c, j, 'google_delivery') for j in eligible]
                verified = [a['payload'] for a in receipts if a and a['payload'].get('verified_after_readback') is True]
                report = reports[-1]
                report['google_pending'] = len(eligible) - len(verified)
                report['google_enabled'] = google_config.get('enabled', False)
                if eligible and len(verified) == len(eligible):
                    report.update(docs_url=verified[0]['docs']['url'], kpi_url=verified[0]['sheets']['url'])
                    reports.append({**report, 'kind': 'google_completed', 'report_id': 'google-' + report['report_id'],
                                    'documents': [], 'google_files': [{'listing_code': code, 'url': receipt['drive']['url'], 'path': receipt['drive']['relative_path']}
                                                                      for code, receipt in zip([e['public_code'](c, j['code']) for j in eligible], verified)]})
    run = controls.get(c, 'batch_run_plan')
    by_id = {r['batch_id']: r for r in reports if r['kind'] == 'batch_completed'}
    if run and run['status'] == 'completed' and run['entries'] and all(x['batch_id'] in by_id for x in run['entries']):
        members = [by_id[x['batch_id']] for x in run['entries']]
        reports.append({'report_id': 'group-done-' + e['digest'](run['entries'])[:40], 'kind': 'group_completed',
            'batch_id': members[-1]['batch_id'], 'batch_ids': [r['batch_id'] for r in members], 'batches': members,
            'completed_count': sum(r['completed_count'] for r in members), 'item_count': sum(r['item_count'] for r in members),
            'kpi_count': sum(r['kpi_count'] for r in members), 'docs_url': members[-1]['docs_url'], 'kpi_url': members[-1]['kpi_url']})
    return reports


def cycle(c, e):
    result = cycle_step(c, e)
    import google_delivery
    google = google_delivery.sync(c, e)
    # Every caller sees durable completion facts, even when another worker observed the transition.
    return dict(result, completion_reports=completion_reports(c, e), google_sync=google)


def cycle_step(c, e):
    tables(c)
    active = controls.choose(c, e)
    if not active:
        run=controls.get(c,'batch_run_plan')
        if run and run['status']=='blocked':
            return {'ok':True,'status':'batch_run_plan_blocked','batch_id':run['entries'][run['index']]['batch_id'],'error':'Approved source or correction version changed; review the current plan before continuing','tasks':[],'reviews':[],'production_jobs':[]}
        if run and run['status']=='preparing':
            return {'ok': True, 'status': 'batch_group_waiting_approval', 'tasks': [], 'reviews': controls.group_reviews(c, e), 'production_jobs': []}
        return {'ok': True, 'status': 'batch_idle', 'tasks': [], 'reviews': [], 'production_jobs': []}
    b = batch(c, active['batch_id'])
    e = {**e, 'IMAGES': profiles.names(manifest(b))}
    result = {'ok': True, 'status': 'batch_active', 'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'], 'tasks': [], 'reviews': [], 'production_jobs': []}
    pending = c.execute("SELECT * FROM production_batch_items WHERE batch_id=? AND state NOT IN ('completed','cancelled') ORDER BY position", (b['batch_id'],)).fetchall()
    if controls.prep(c, b['batch_id']):
        pending = [r for r in pending if r['position'] == 0]
    if not pending:
        c.execute("UPDATE production_batches SET status='completed' WHERE batch_id=?", (b['batch_id'],))
        return dict(result, status='batch_completed')
    from chatgpt_image_orchestration import selection
    choice = selection(e)
    previous = c.execute('SELECT status FROM production_batches WHERE batch_id=?', (choice.get('batch_id'),)).fetchone()
    if choice.get('provider') == 'flow' and previous and previous['status'] == 'completed' and choice['batch_id'] != b['batch_id']:
        updated = dict(choice, batch_id=b['batch_id'], batch_scope_reference=b['reference'], batch_scope_updated_at=e['now']())
        import flow_worker_pool
        e['write'](flow_worker_pool.selection_file(e), updated)
        e['event'](c, {'code': b['batch_id'], 'revision': 1}, 'flow_batch_scope_advanced',
                   {'previous_batch_id': choice['batch_id'], 'batch_id': b['batch_id'], 'reference': b['reference']})
    # Image preparation can continue while KPI allocation is explicitly disabled.
    enabled = bool(c.execute("SELECT 1 FROM config WHERE key='kpi_activation'").fetchone())
    candidates = [r for r in pending if enabled or r['state'] != 'awaiting_kpi_activation']
    if not candidates:
        return dict(result, status='awaiting_kpi_activation')
    i = dict(candidates[0])
    result['active_item'] = {k: i[k] for k in ('item_id', 'position', 'state', 'revision', 'brief_id', 'listing_code')}
    if i['state'] == 'failed':
        return dict(result, status='batch_item_failed', error=i['error'])
    data = manifest(b)['items'][i['position']]
    try:
        if i['state'] in ('queued', 'designing'):
            import embroidery_direct
            if embroidery_direct.enabled(manifest(b)):
                set_item(c, i, 'ready_sample', plan=json.dumps(embroidery_direct.plan(data['brief']),ensure_ascii=False))
            elif manifest(b)['kind'] in profiles.PRINT_KINDS:
                set_item(c, i, 'ready_sample')
            else:
                d = e['design_module']()
                existing = c.execute('SELECT revision FROM design_jobs WHERE brief_id=?', (i['brief_id'],)).fetchone()
                if not existing:
                    received = e['execute'](c, {'action': 'receive_brief', 'brief': data['brief']})
                    command = {'action': 'design_start', 'brief_id': i['brief_id'], 'brief_fingerprint': received['brief_fingerprint'],
                               'authority': 'direct_user', 'reference': b['reference']}
                    if manifest(b).get('reference_image'):
                        command['references'] = {r: [manifest(b)['reference_image']] for r in data['brief']['motifs']}
                    if data.get('prompt_pack'):
                        staged = e['execute'](c, dict(command, action='design_prompt_pack', prompt_pack=data['prompt_pack']))
                        command['prompt_pack_fingerprint'] = staged['prompt_pack_fingerprint']
                    e['execute'](c, command)
                design = e['execute'](c, {'action': 'design_advance', 'brief_id': i['brief_id']})
                set_item(c, i, 'designing')
                if design['status'] in ('approved_artwork_ready_for_sizes', 'approved_artwork_and_sizes', 'approved_artwork_ready'):
                    plan = e['execute'](c, {'action': 'design_plan', 'brief_id': i['brief_id'], 'revision': d.job(c, i['brief_id'])['revision']})['plan']
                    if not profiles.current(plan):
                        for a in plan['regions'].values():
                            a['size_approval_reference'] = b['reference'] + '\nConfirmed automatic batch sizing policy.'
                    plan['mockup_rotation_index'] = i['position']
                    set_item(c, i, 'ready_sample' if profiles.current(plan) or i['position'] == 0 or delegated_samples(c,b) else 'ready_mockups', plan=json.dumps(plan))
        i = item(c, b['batch_id'], i['item_id'])
        if controls.prep(c, b['batch_id']) and policy(c, b):
            controls.preparation_checkpoint(c, b, i, e)
            return dict(result, status='batch_prepared', tasks=[], reviews=[])
        if i['state'] in ('ready_sample', 'ready_mockups'):
            sample = i['state'] == 'ready_sample'
            if not sample and not policy(c, b):
                raise ValueError('Sample policy approval required before remaining mockups')
            p = plan_images(c, b, i, sample, e)
            task(c, b, i, p['stage'], p, e)
            set_item(c, i, 'generating_sample' if sample else 'generating_mockups')
        elif i['state'] == 'awaiting_sample_approval':
            result['reviews'] = [sample_review(c, b, i, e)]
        elif i['state'] in ('images_ready', 'awaiting_kpi_activation', 'production'):
            images = json.loads(i['images'])
            expected_names = item_names(c, b, i)
            full = [images[name] for name in expected_names]
            e['verify_assets'](full, expected_names=expected_names)
            review = mockup_review(c, b, i, e)
            if review:
                approved = c.execute('SELECT value FROM config WHERE key=?', ('mockup_review:' + b['batch_id'] + ':' + i['item_id'] + ':' + str(i['revision']),)).fetchone()
                if not approved or json.loads(approved[0]).get('fingerprint') != review['fingerprint']:
                    return dict(result, status='awaiting_operator_mockup_review', operator_reviews=[review])
            if not enabled:
                set_item(c, i, 'awaiting_kpi_activation')
            else:
                code = i['listing_code'] or handoff(c, b, i, full, e)
                j = e['job'](c, code)
                if j['state'] == 'completed':
                    set_item(c, i, 'completed')
                else:
                    set_item(c, i, 'production')
                    result['production_jobs'] = [{'listing_code': code, 'status': j['state']}]
    except (ValueError, KeyError, OSError) as error:
        set_item(c, i, 'failed', error=str(error))
        return dict(result, status='batch_item_failed', error=str(error))
    controls.preparation_checkpoint(c, b, item(c, b['batch_id'], i['item_id']), e)
    result['tasks'] = queue(c)
    return result


def handoff(c, b, i, images, e):
    data = manifest(b)['items'][i['position']]
    brief = data['brief']
    received = e['execute'](c, {'action': 'receive_brief', 'brief': brief})
    reservation = e['execute'](c, {'action': 'reserve_listing', 'brief_id': i['brief_id'],
        'brief_fingerprint': received['brief_fingerprint'], 'authority': 'direct_user', 'reference': policy(c, b)['reference'],
        **({'listing_code':data.get('listing_code',i['item_id'])} if data.get('listing_code') or (e['CODE'].fullmatch(i['item_id']) and i['item_id'].endswith('_TQH')) else {})})
    reservation = dict(c.execute('SELECT * FROM reservations WHERE brief_id=?',(i['brief_id'],)).fetchone())
    code = reservation['code']
    plan = json.loads(i['plan']) if i['plan'] else {'rendering_mode': 'apparel_2d', 'idea_prompt': brief['idea_prompt'], 'regions': {},
        'product_id': brief['product_id'], 'garment': 'crewneck', 'color': 'sand', 'back_artwork': False}
    plan.update(batch_id=b['batch_id'], batch_fingerprint=b['fingerprint'], mockup_rotation_index=i['position'])
    if manifest(b).get('mockup_prompt_set'):
        plan['mockup_prompt_set'] = manifest(b)['mockup_prompt_set']
    if manifest(b).get('mockup_layout'):
        plan['mockup_layout'] = manifest(b)['mockup_layout']
    if manifest(b).get('reference_image'):
        plan['reference_image'] = manifest(b)['reference_image']
    if manifest(b).get('layout_profile'):
        plan['layout_profile'] = manifest(b)['layout_profile']
    import review_transport
    if review_transport.local_delivery(e):
        plan['delivery_backend'] = 'local_v1'
    if profiles.current(manifest(b)):
        plan.update(profile_version=3, product_kind=manifest(b)['kind'])
        if manifest(b)['kind'] == 'pajama_set':
            plan.update(garment=brief['garment'], product_bundle=brief['product_bundle'])
        if manifest(b).get('mockup_set'):
            plan['mockup_set'] = manifest(b)['mockup_set']
    omitted = [n for n in profiles.names(manifest(b)) if n not in item_names(c, b, i)]
    if omitted: plan['skipped_mockups'] = omitted
    import embroidery_direct
    if plan.get('rendering_mode') == 'apparel_2d' or embroidery_direct.enabled(plan):
        plan['approved_sample'] = images[0]
    e['validate_plan'](plan)
    source = e['create_listing_source'](brief, plan, code, reservation['created_at'], 'reserved_kpi_date', reservation['target_date'])
    dest = e['JOBS'] / (code + '.json')
    if dest.exists() and e['read'](dest) != source:
        raise ValueError('Batch source path occupied by different version')
    if not dest.exists():
        e['write'](dest, source)
    e['execute'](c, {'action': 'enqueue', 'listing_code': code, 'source_hash': e['sha'](dest), 'plan': plan})
    set_item(c, i, 'production', listing_code=code,plan=json.dumps(plan,ensure_ascii=False))
    j = e['job'](c, code)
    e['put'](c, j, 'images', images)
    e['event'](c, j, 'batch_policy_applied', {'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'],
        'reference': policy(c, b)['reference'], 'individual_visual_qa': False})
    return code


def preserve_delivery_time(c,j,package,old,e,kind):
    ledger=c.execute('SELECT completed_at,fingerprint FROM kpi WHERE code=?',(j['code'],)).fetchone()
    if ledger and ledger['fingerprint']!=package['review_fingerprint']:raise ValueError('Correction cannot change counted review fingerprint')
    original=ledger['completed_at'] if ledger else old['payload']['completed_at']
    if package['completed_at']!=original:
        package['processing_exported_at']=package['completed_at'];package['completed_at']=original
        e['write'](e['scoped'](Path(package['destination'])/'manifest.json'),package)
        e['put'](c,j,kind,package)


def mockup_review(c, b, i, e):
    e = {**e, 'IMAGES': item_names(c, b, i)}
    if i['state'] not in ('images_ready', 'awaiting_kpi_activation') or i['listing_code'] or not delegated_samples(c, b):
        return None
    images = json.loads(i['images'])
    full = [images[name] for name in e['IMAGES']]
    e['verify_assets'](full, expected_names=e['IMAGES'])
    fp = e['digest']({'batch_fingerprint': b['fingerprint'], 'revision': i['revision'], 'images': full})
    binding = {'entity': {'batch_id': b['batch_id'], 'item_id': i['item_id']}, 'revision': i['revision'], 'stage': 'mockups', 'fingerprint': fp}
    return {'review_id': 'flow-' + e['digest'](binding)[:24], **binding, 'images': full,
            'summary': 'Codex kiểm tra thật đủ sáu originals và đối chiếu mẫu đã duyệt trước xử lý/SEO/Docs/KPI.',
            'visual_qa': {'passed': False, 'status': 'awaiting_delegated_visual_review', 'executor': 'independent_flow_worker'}}


def revise_mockups(c, cmd, e):
    from flow_lark_orchestration import check_hashes, verify_candidate_proof
    event_id = 'mockup-revision:' + str(cmd.get('evidence_sha256'))
    old = c.execute('SELECT result FROM production_batch_events WHERE event_id=?', (event_id,)).fetchone()
    if old:
        return json.loads(old[0])
    b = batch(c, cmd['batch_id']); i = item(c, b['batch_id'], cmd['item_id'])
    row = c.execute('SELECT * FROM production_batch_tasks WHERE id=?', (cmd.get('task_id'),)).fetchone()
    if not row:
        raise ValueError('Current mockup task required')
    t = dict(row); p = json.loads(t['payload'])
    if (b['status'] != 'stopped' or not delegated_samples(c, b) or not policy(c, b) or i['listing_code']
            or i['state'] not in ('generating_mockups', 'images_ready') or t['stage'] != 'mockups'
            or t['status'] not in ('pending', 'assets_attached') or t['batch_id'] != b['batch_id']
            or t['item_id'] != i['item_id'] or t['revision'] != i['revision'] or cmd.get('revision') != i['revision']
            or cmd.get('fingerprint') != t['fingerprint'] or e['digest'](p) != t['fingerprint']):
        raise ValueError('Stop the exact delegated pre-delivery mockup task before revision')
    file = e['scoped'](cmd['evidence_path'])
    if not file.is_relative_to((e['STORE'] / 'delegated-reviews').resolve()) or e['sha'](file) != cmd.get('evidence_sha256'):
        raise ValueError('Mockup visual evidence hash/path changed')
    evidence = e['read'](file)
    if (evidence.get('reviewer') != 'Codex' or evidence.get('task_id') != t['id'] or evidence.get('revision') != i['revision']
            or evidence.get('fingerprint') != t['fingerprint'] or evidence.get('human_viewing_claimed') is not False):
        raise ValueError('Exact delegated Codex mockup observations required')
    journal_file = e['scoped'](cmd['journal_path'])
    if e['sha'](journal_file) != cmd.get('journal_sha256'):
        raise ValueError('Worker journal changed')
    journal = e['read'](journal_file)
    if journal.get('task_id') != t['id'] or journal.get('revision') != i['revision'] or journal.get('fingerprint') != t['fingerprint']:
        raise ValueError('Worker journal does not match current task')
    observations = evidence.get('images', {})
    corrections = evidence.get('corrections', {})
    images = json.loads(i['images']); kept = {}
    for image in p['images']:
        name = image['name']; record = journal.get('images', {}).get(name, {})
        if record.get('status') == 'acquired':
            asset = record['asset']; finding = observations.get(name, {})
            path = e['scoped'](asset['path'])
            if (not path.is_relative_to(e['scoped'](p['output_directory'])) or e['sha'](path) != asset['sha256']
                    or finding.get('image_sha256') != asset['sha256'] or not str(finding.get('visual_findings', '')).strip()
                    or finding.get('decision') not in ('retain', 'revise')):
                raise ValueError('Actual per-image visual findings and unchanged original required')
            check_hashes(list(p.get('references', {}).values()), e)
            proof = record['proof']
            verify_candidate_proof(dict(proof, executor='independent_flow_worker', acquisition='flow_download'), e, c)
            if proof.get('prompt_sha256') != hashlib.sha256(image['prompt'].encode()).hexdigest():
                raise ValueError('Retained Flow prompt provenance changed')
            if finding['decision'] == 'retain':
                kept[name] = {'name': name, 'path': str(path), 'sha256': asset['sha256']}
                continue
        elif record.get('generation_id'):
            failure = next((event for event in reversed(journal.get('events', []))
                if event.get('event') == 'unusual_activity_cooldown_started' and event.get('image_key') == name
                and event.get('generation_id') == record['generation_id']), None)
            if not failure:
                raise ValueError('Reconcile unknown generation before superseding the task')
            from datetime import datetime
            if datetime.fromisoformat(e['now']()) < datetime.fromisoformat(failure['not_before'].replace('Z', '+00:00')):
                raise ValueError('Preserve unusual activity cooldown before replacing the task')
        if not str(corrections.get(name, '')).strip():
            raise ValueError('Every replacement view needs a specific visual correction')
        images.pop(name, None)
    if not corrections or set(corrections) - {image['name'] for image in p['images']}:
        raise ValueError('Only current requested mockup views can be corrected')
    images.update(kept)
    brief = manifest(b)['items'][i['position']]['brief']
    plan = json.loads(i['plan']) if i['plan'] else {'rendering_mode': 'apparel_2d', 'idea_prompt': brief['idea_prompt'],
        'garment': 'crewneck', 'color': 'sand', 'back_artwork': False, 'regions': {}, 'product_id': i['brief_id'], 'mockup_rotation_index': i['position']}
    plan['mockup_corrections'] = corrections
    set_item(c, i, 'ready_mockups', revision=i['revision'] + 1, images=json.dumps(images), plan=json.dumps(plan, ensure_ascii=False), error=None)
    c.execute("UPDATE production_batch_tasks SET status='superseded' WHERE id=?", (t['id'],))
    result = {'ok': True, 'status': 'batch_mockups_revised', 'batch_id': b['batch_id'], 'item_id': i['item_id'],
              'revision': i['revision'] + 1, 'retained_images': list(images), 'sample_approval_preserved': True}
    c.execute('INSERT INTO production_batch_events VALUES(?,?)', (event_id, json.dumps(result)))
    e['event'](c, {'code': b['batch_id'], 'revision': i['revision']}, 'delegated_mockup_visual_revision',
               {'item_id': i['item_id'], 'evidence_path': str(file), 'evidence_sha256': cmd['evidence_sha256'],
                'retained_images': list(images), 'human_viewing_claimed': False})
    return result


def execute(c, cmd, e):
    tables(c)
    action = cmd['action']
    if action.startswith('batch_pool_'):
        import flow_worker_pool
        return flow_worker_pool.execute(c,cmd,e)
    if action == 'batch_lark_command':
        body = canonical_command(cmd.get('event_id'), e)
        old = c.execute('SELECT result FROM production_batch_events WHERE event_id=?', (body['event_id'],)).fetchone()
        if old:
            return json.loads(old['result'])
        command = body.get('command', {})
        if command.get('action') not in ('batch_submit', 'batch_confirm', 'batch_confirm_start', 'batch_start', 'batch_reorder', 'batch_status', 'batch_stop', 'batch_retry', 'batch_accept_workflow', 'batch_prepare_reviews', 'batch_review_bundle', 'batch_approve_bundle', 'batch_run_plan', 'batch_run_selected', 'batch_discard_remaining'):
            raise ValueError('Unsupported signed batch command')
        c.execute('SAVEPOINT batch_human_command')
        try:
            if 'card_expected_status' in command:
                current=batch(c,command['batch_id'])
                bound_control = body.get('interaction_type') == 'card_action' or (body.get('transport') == 'web' and body.get('interaction_type') == 'web_control')
                if not bound_control or current['fingerprint']!=command.get('batch_fingerprint') or current['status'] not in command['card_expected_status']:
                    raise ValueError('Card expired: batch state or fingerprint changed')
                if command.get('card_item_revision') is not None and item(c,current['batch_id'],command['item_id'])['revision']!=command['card_item_revision']:
                    raise ValueError('Card expired: item revision changed')
            result = execute(c, dict(command, authority='direct_user', reference=body['reference'], event_id=body['event_id'], message_id=body.get('message_id')), e)
            import flow_worker_pool
            if not flow_worker_pool.enabled(c) and command.get('action') in ('batch_start','batch_confirm_start'):
                from chatgpt_image_orchestration import selection
                worker_bid=result.get('worker_batch_id',command['batch_id'])
                active=c.execute("SELECT batch_id FROM production_batches WHERE status='active' AND batch_id<>?",(worker_bid,)).fetchone()
                if not active and selection(e).get('provider')=='flow':
                    e['execute'](c,{'action':'chatgpt_worker_select','mode':'flow','resume_image_worker':True,'batch_id':worker_bid,'authority':'direct_user','reference':body['reference']})
            elif not flow_worker_pool.enabled(c) and command.get('action') in ('batch_prepare_reviews','batch_run_plan','batch_run_selected'):
                from chatgpt_image_orchestration import selection
                chosen=controls.choose(c,e)
                if not chosen and command.get('action')=='batch_run_selected':
                    run=controls.get(c,'batch_run_plan')
                    chosen=batch(c,run['entries'][0]['batch_id'])
                if chosen and selection(e).get('provider')=='flow':
                    e['execute'](c,{'action':'chatgpt_worker_select','mode':'flow','resume_image_worker':True,'batch_id':chosen['batch_id'],'authority':'direct_user','reference':body['reference']})
        except ValueError as error:
            c.execute('ROLLBACK TO batch_human_command')
            result = {'ok': True, 'accepted': False, 'retryable': False,
                      'status': 'batch_command_rejected', 'code': 'batch_command_rejected',
                      'error': str(error), 'event_id': body['event_id']}
        c.execute('RELEASE batch_human_command')
        c.execute('INSERT INTO production_batch_events VALUES(?,?)', (body['event_id'], json.dumps(result)))
        return result
    if action == 'batch_status':
        return batch_status(c, cmd.get('batch_id'))
    if action == 'batch_profile_preflight':
        prompts={}
        for kind in profiles.PRINT_KINDS:
            plan={'profile_version':3,'product_kind':kind,'regions':{},'idea_prompt':'Configuration check only; do not generate'}
            if kind == 'pajama_set':
                import pajama_set
                plan['product_bundle'] = dict(pajama_set.CONTRACT)
            prompts[kind]=len(profiles.image_plan({'code':'CONFIG_CHECK','revision':1,'plan':json.dumps(plan)},e)['images'])
        return {'ok':True,'status':'workflow3_configuration_verified','profile_version':3,'printed_photo_counts':prompts,'embroidery_photo_count':len(profiles.GARMENT_SIX),'default_embroidery_mockup_set':profiles.GARMENT_SET,'embroidery_photo_names':profiles.GARMENT_SIX,'legacy_embroidery_photo_count':len(profiles.EMBROIDERY),'mockup_prompt_policy':'garment_only_flatlay_folded_v1','macro_artwork_references':1,'per_listing_layout_anchor':True,'mockup_skip_supported':True,'manual_batch_selection':True,'selected_group_run':True,'all_representatives_required':True,'individual_group_reviews':True,'generation_called':False,'existing_batches_unchanged':True}
    if action == 'batch_cycle':
        return cycle(c, e)
    if action == 'batch_delete':
        import production_batch_delete
        return production_batch_delete.execute(c, cmd, e)
    e['design_module']().authority(cmd)
    if action in ('batch_prepare_reviews', 'batch_review_bundle', 'batch_approve_bundle', 'batch_run_plan', 'batch_run_selected', 'batch_discard_remaining'):
        return controls.execute(c, cmd, e)
    if action == 'batch_confirm_start':
        current=batch(c,cmd['batch_id'])
        if current['status']!='submitted' or cmd.get('batch_fingerprint')!=current['fingerprint']:
            raise ValueError('Confirm-and-start requires the exact current submitted batch')
        execute(c,dict(cmd,action='batch_confirm'),e)
        return execute(c,dict(cmd,action='batch_start'),e)
    if action == 'batch_revise_mockups':
        return revise_mockups(c, cmd, e)
    if action=='batch_delegate_reviews':
        b=batch(c,cmd['batch_id'])
        if cmd.get('batch_fingerprint')!=b['fingerprint']:raise ValueError('Delegate only the exact immutable batch')
        grant={'batch_id':b['batch_id'],'batch_fingerprint':b['fingerprint'],'reviewer':'Codex','reference':cmd['reference'],'delegated_at':e['now']()}
        c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('review_delegation:'+b['batch_id'],json.dumps(grant)))
        return {'ok':True,'status':'batch_review_delegated','batch_id':b['batch_id'],'reviewer':'Codex','automatic_blind_approval':False}
    if action=='batch_operator_review':
        b=batch(c,cmd['batch_id']);i=item(c,b['batch_id'],cmd['item_id']);review=sample_review(c,b,i,e) or mockup_review(c,b,i,e)
        row=c.execute('SELECT value FROM config WHERE key=?',('review_delegation:'+b['batch_id'],)).fetchone()
        grant=json.loads(row[0]) if row else {}
        if not review or grant.get('batch_fingerprint')!=b['fingerprint'] or cmd.get('fingerprint')!=review['fingerprint'] or cmd.get('revision')!=i['revision']:raise ValueError('Current delegated review fingerprint/revision required')
        file=e['scoped'](cmd['evidence_path'])
        if not file.is_relative_to((e['STORE']/'delegated-reviews').resolve()) or e['sha'](file)!=cmd.get('evidence_sha256'):raise ValueError('Delegated visual review evidence hash/path changed')
        evidence=e['read'](file)
        exact_images = evidence.get('images') == [{'name': image['name'], 'sha256': image['sha256']} for image in review['images']] if review['stage'] == 'mockups' else evidence.get('image_sha256') == review['images'][0]['sha256']
        if evidence.get('reviewer')!='Codex' or evidence.get('review_id')!=review['review_id'] or not exact_images or not str(evidence.get('visual_findings','')).strip() or evidence.get('decision') not in ('approve','revise','reject'):raise ValueError('Actual Codex visual findings for exact image required')
        body={k:review[k] for k in ('review_id','entity','revision','stage','fingerprint')}
        body.update(decision=evidence['decision'],reason=evidence.get('reason',''),message_id='codex-visual-review:'+cmd['evidence_sha256'],reference=grant['reference']+'\nCodex delegated visual review: '+str(file)+'; findings: '+evidence['visual_findings'])
        result=sample_decision(c,body,e,delegated=True)
        e['event'](c,{'code':b['batch_id'],'revision':i['revision']},'delegated_sample_visual_review' if review['stage']=='sample_mockup' else 'delegated_mockup_visual_review',{'item_id':i['item_id'],'evidence_path':str(file),'evidence_sha256':cmd['evidence_sha256'],'decision':evidence['decision'],'reviewer':'Codex','human_viewing_claimed':False})
        return result
    if action=='batch_enable_tqh':
        c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('listing_code_suffix',json.dumps('_TQH')))
        e['event'](c,{'code':'SYSTEM','revision':0},'listing_suffix_enabled',{'suffix':'_TQH','reference':cmd['reference'],'immutable_internal_codes_preserved':True})
        return {'ok':True,'status':'tqh_suffix_enabled'}
    if action=='batch_relabel_tqh':
        identifier=e['code'](cmd['listing_code']);public=e['public_code'](c,identifier)
        if public==identifier:raise ValueError('Existing unsuffixed listing required')
        source=e['read'](e['STORE']/'layout-migration/proofs'/(identifier+'.json'))
        original=e['read'](e['STORE']/'layout-migration/tasks'/(source['task_id']+'.json'))
        task=dict(original);packet=dict(task['payload']['packet']);packet['listing_code']=public;packet.pop('review_fingerprint',None);packet['review_fingerprint']=e['digest'](packet)
        task.update(id='tqh-'+source['task_id'].removeprefix('hub2-'),code=public,payload={**task['payload'],'packet':packet})
        task['fingerprint']=e['digest'](task['payload']);e['write'](e['STORE']/'layout-migration/tasks'/(task['id']+'.json'),task)
        token=e['read'](e['ROOT']/'config/lark-review.private.json')['localToken']
        body={'source_task_id':source['task_id'],'task_id':task['id'],'task_fingerprint':task['fingerprint']}
        req=urllib.request.Request('http://127.0.0.1:8792/listing-hub/relabel',data=json.dumps(body).encode(),headers={'x-review-token':token,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=180) as response:proof=json.load(response)
        expected={'listing_code':public,'title':packet['title'],'description':packet['description'],'tags':packet['tags'],'thumbnail_sha256':packet['thumbnail']['sha256']}
        if proof.get('content')!=expected or proof.get('task_fingerprint')!=task['fingerprint'] or proof.get('verified_after_readback') is not True:raise ValueError('TQH Docs cloud readback mismatch')
        e['write'](e['STORE']/'layout-migration/proofs'/(public+'.json'),proof)
        if identifier.startswith('TXT_'):
            out=e['STORE']/'thumbnail-copy/outputs'/public;out.mkdir(parents=True,exist_ok=True)
            e['write'](out/'listing.json',expected)
            (out/'listing.md').write_text('# '+public+'\n\n## Title\n\n'+packet['title']+'\n\n## Mô tả\n\n'+packet['description']+'\n\n## Tags\n\n'+', '.join(packet['tags'])+'\n',encoding='utf-8')
            row=c.execute('SELECT folder FROM thumbnail_items WHERE listing_code=?',(identifier,)).fetchone()
            if row:
                index=Path(row['folder'])/'KET_QUA_NOI_DUNG.json'
                if index.exists():
                    data=e['read'](index)
                    if isinstance(data,dict) and data.get('generator')=='etsy-thumbnail-copy-v1':
                        for entry in data['items']:
                            if entry.get('copy_id')==identifier:entry.update(copy_id=public,url=proof['document_url']+'#'+proof['block_ids'][0])
                        e['write'](index,data)
        e['event'](c,{'code':identifier,'revision':task['revision']},'listing_public_code_updated',{'public_code':public,'reference':cmd['reference']})
        return {'ok':True,'status':'tqh_listing_relabelled','listing_code':public,'url':proof['document_url']+'#'+proof['block_ids'][0],'kpi_count_unchanged':True}
    if action=='batch_prepare_listing_layout':
        token=e['read'](e['ROOT']/'config/lark-review.private.json')['localToken']
        req=urllib.request.Request('http://127.0.0.1:8792/listing-hub/prepare',data=b'{}',headers={'x-review-token':token,'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=120) as response:result=json.load(response)
        except HTTPError as error:
            detail=json.load(error);raise ValueError('Listing layout: '+str(detail.get('code','provider_failed')))
        if result.get('ok') is not True or result.get('layout')!='sections_v2' or not result.get('url','').startswith('https://csg2m8jcr9dn.sg.larksuite.com/wiki/'):raise ValueError('Listing layout destination required')
        c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('listing_destination',json.dumps(result)))
        return {'ok':True,'status':'listing_layout_ready','url':result['url'],'layout':'sections_v2'}
    if action=='batch_publish_listing_layout':
        if e['review_layout'](c)!='sections_v2':raise ValueError('Prepare separate listing layout first')
        if cmd.get('copy_id'):
            row=c.execute("SELECT * FROM thumbnail_items WHERE id=? AND state='completed'",(cmd['copy_id'],)).fetchone()
            if not row:raise ValueError('Completed thumbnail copy required')
            old=json.loads(row['task']);packet=dict(old['payload']['packet']);identifier=row['listing_code'];j={'code':identifier,'revision':1}
        else:
            j=e['job'](c,cmd['listing_code'])
            if j['state']!='completed':raise ValueError('Completed listing required')
            row=c.execute("SELECT * FROM tasks WHERE code=? AND revision=? AND kind='lark_review' AND status='verified' ORDER BY created_at LIMIT 1",(j['code'],j['revision'])).fetchone()
            if not row:raise ValueError('Verified original content required')
            old=dict(row);packet=dict(json.loads(old['payload'])['packet']);identifier=j['code']
            package=e['artifact'](c,j,'package')['payload'];thumb=next(f for f in package['files'] if f.get('role',f['name'])=='01_thumbnail.jpg')
            packet['thumbnail']={'path':thumb['path'],'sha256':thumb['sha256']}
        if e['public_code'](c,identifier)!=identifier:
            return execute(c,{**cmd,'action':'batch_relabel_tqh','listing_code':identifier},e)
        packet.pop('review_fingerprint',None);packet['review_fingerprint']=e['digest'](packet)
        task={'id':'hub2-'+old['id'],'code':identifier,'revision':j['revision'],'kind':'lark_review','status':'pending',
              'payload':{'url':e['review_url'](c),'layout':'sections_v2','packet':packet,'scope':'layout_copy_existing_content'}}
        task['fingerprint']=e['digest'](task['payload']);e['write'](e['STORE']/'layout-migration/tasks'/(task['id']+'.json'),task)
        token=e['read'](e['ROOT']/'config/lark-review.private.json')['localToken']
        req=urllib.request.Request('http://127.0.0.1:8792/listing-hub/deliver',data=json.dumps({'task_id':task['id'],'task_fingerprint':task['fingerprint']}).encode(),headers={'x-review-token':token,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=180) as response:proof=json.load(response)
        expected={'listing_code':identifier,'title':packet['title'],'description':packet['description'],'tags':packet['tags'],'thumbnail_sha256':packet['thumbnail']['sha256']}
        if proof.get('ok') is not True or proof.get('task_fingerprint')!=task['fingerprint'] or proof.get('content')!=expected or proof.get('document_url')!=e['review_url'](c):raise ValueError('Separate listing layout cloud readback required')
        e['write'](e['STORE']/'layout-migration/proofs'/(identifier+'.json'),proof)
        e['event'](c,j,'listing_layout_published',{'url':proof['document_url'],'reference':cmd['reference'],'original_approval_preserved':True})
        return {'ok':True,'status':'listing_layout_published','listing_code':identifier,'url':proof['document_url']+'#'+proof['block_ids'][0],'content_unchanged':True,'kpi_unchanged':True}
    if action == 'batch_repair_outputs':
        b=batch(c,cmd['batch_id']);i=next((dict(r) for r in c.execute('SELECT * FROM production_batch_items WHERE batch_id=? AND listing_code=?',(b['batch_id'],cmd['listing_code']))),None)
        if not i or i['state']!='completed':raise ValueError('Completed current batch listing required for output routing repair')
        j=e['job'](c,i['listing_code']);old=e['artifact'](c,j,'package');previous=e['artifact'](c,j,'processed')
        if not old or not previous:raise ValueError('Completed package and processor evidence required')
        e['process'](c,j,e['artifact'](c,j,'images'),'processed_routed')
        fresh=e['artifact'](c,j,'processed_routed')
        if [(a['name'],a['sha256']) for a in fresh['payload']['images']]!=[(a['name'],a['sha256']) for a in previous['payload']['images']]:
            raise ValueError('Rerun processor changed image bytes; review required before publishing repaired package')
        package=e['package_listing'](c,j,fresh,e['artifact'](c,j,'text'),old['payload']['review_fingerprint'],'package_routed')
        prior=Path(old['payload']['destination']).resolve()
        plan=json.loads(j['plan']);category='Áo 2D' if plan.get('rendering_mode')=='apparel_2d' else 'Áo thêu'
        raw_parent=e['scoped'](Path('C:/Huy/Chưa xử lý')/category/j['code'].split('_')[0]/j['code']).resolve()
        archive=None
        if prior.is_relative_to(raw_parent):
            import shutil
            archive=e['STORE']/'output-route-archive'/j['code']/prior.name
            physical=prior if prior.exists() else archive
            for f in old['payload']['files']:
                if not (physical/f['name']).is_file() or e['sha'](physical/f['name'])!=f['sha256']:raise ValueError('Legacy package changed; retain files and reconcile before moving')
            if prior.exists():
                if archive.exists():raise ValueError('Archive path already occupied')
                archive.parent.mkdir(parents=True,exist_ok=True)
                shutil.move(str(prior),str(archive))
        preserve_delivery_time(c,j,package,old,e,'package_routed')
        e['event'](c,j,'output_routes_repaired',{'prior_package':old['payload'],'archive':str(archive) if archive else None,'destination':package['destination'],'reference':cmd['reference']})
        e['put'](c,j,'package',package)
        return {'ok':True,'status':'output_routes_repaired','batch_id':b['batch_id'],'listing_code':j['code'],
                'source_directory':fresh['payload']['source_directory'],'destination':package['destination'],'legacy_archive':str(archive) if archive else None,'processor_rerun_verified':True,'image_bytes_unchanged':True,'kpi_unchanged':True}
    if action == 'batch_compact_outputs':
        b=batch(c,cmd['batch_id']);i=c.execute('SELECT * FROM production_batch_items WHERE batch_id=? AND listing_code=?',(b['batch_id'],cmd['listing_code'])).fetchone()
        if not i or i['state']!='completed':raise ValueError('Completed current batch listing required')
        import delivery_layout
        return delivery_layout.compact(c,e['job'](c,cmd['listing_code']),e)
    if action == 'batch_correct_logos':
        b=batch(c,cmd['batch_id']);i=c.execute('SELECT * FROM production_batch_items WHERE batch_id=? AND listing_code=?',(b['batch_id'],cmd['listing_code'])).fetchone()
        if not i:raise ValueError('Current batch listing required')
        j=e['job'](c,cmd['listing_code'])
        before_delivery = b['status']=='active' and i['state']=='production' and j['state']=='awaiting_processed_approval' and delegated_samples(c,b)
        if i['state']!='completed' and not before_delivery:raise ValueError('Completed listing or current delegated processed-review gate required')
        old=e['artifact'](c,j,'package')
        e['process'](c,j,e['artifact'](c,j,'images'),'processed_logo_corrected',cmd['logo_regions'])
        fresh=e['artifact'](c,j,'processed_logo_corrected')
        if any(x['logo']['status']!='removed' for x in fresh['payload']['images']):raise ValueError('Logo correction incomplete')
        if before_delivery:
            prior=e['artifact'](c,j,'processed')
            if not e['artifact'](c,j,'processed_before_logo_correction'):e['put'](c,j,'processed_before_logo_correction',prior['payload'])
            e['put'](c,j,'processed',fresh['payload'])
            e['event'](c,j,'pre_delivery_logo_correction',{'prior_processed_fingerprint':prior['fingerprint'],'processed_fingerprint':fresh['fingerprint'],'reference':cmd['reference'],'visual_qa':'pending_operator_review'})
            return {'ok':True,'status':'processed_logos_corrected_awaiting_visual_review','listing_code':j['code'],'processed_fingerprint':fresh['fingerprint'],'source_directory':fresh['payload']['source_directory'],'destination_directory':fresh['payload']['destination_directory'],'kpi_unchanged':True}
        package_kind='package_logo_corrected_'+fresh['fingerprint'][:12]
        package=e['package_listing'](c,j,fresh,e['artifact'](c,j,'text'),old['payload']['review_fingerprint'],package_kind,'logo-'+fresh['fingerprint'][:12])
        preserve_delivery_time(c,j,package,old,e,package_kind)
        e['event'](c,j,'post_delivery_logo_correction',{'prior_package':old['payload'],'processed_fingerprint':fresh['fingerprint'],
                 'destination':package['destination'],'reference':cmd['reference'],'individual_visual_approval':False})
        e['put'](c,j,'package',package)
        return {'ok':True,'status':'logo_correction_exported','listing_code':j['code'],'destination':package['destination'],
                'source_directory':fresh['payload']['source_directory'],'kpi_unchanged':True,'visual_qa':'pending_user_review'}
    if action == 'batch_repair_docs':
        b=batch(c,cmd['batch_id']);i=c.execute('SELECT * FROM production_batch_items WHERE batch_id=? AND listing_code=?',(b['batch_id'],cmd['listing_code'])).fetchone()
        if not i or i['state']!='completed':raise ValueError('Completed batch listing required')
        j=e['job'](c,i['listing_code']);t=c.execute("SELECT * FROM tasks WHERE code=? AND revision=? AND kind='lark_review' AND status='verified'",(j['code'],j['revision'])).fetchone()
        if not t:raise ValueError('Verified current document task required')
        token=e['read'](e['ROOT']/'config/lark-review.private.json')['localToken']
        req=urllib.request.Request('http://127.0.0.1:8792/lark-layout/'+t['id'],data=json.dumps({'expected_fingerprint':t['fingerprint']}).encode(),headers={'x-review-token':token,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=120) as response:proof=json.load(response)
        packet=json.loads(t['payload'])['packet']
        if proof.get('ok') is not True or proof.get('content',{}).get('title')!=packet['title'] or proof.get('task_fingerprint')!=t['fingerprint']:raise ValueError('Actual repaired Docs readback required')
        e['event'](c,j,'document_field_labels_repaired',{'task_id':t['id'],'readback_path':proof['readback_path'],'reference':cmd['reference']})
        return {'ok':True,'status':'docs_field_labels_repaired','listing_code':j['code'],'batch_id':b['batch_id'],'url':proof['document_url']+'#'+proof['block_ids'][0],'title':proof['content']['title'],'verified_after_readback':True}
    if action == 'batch_accept_workflow':
        if cmd.get('workflow_accepted_by_user') is not True:
            raise ValueError('Explicit final workflow acceptance required before KPI activation')
        ready = c.execute("""SELECT 1 FROM production_batch_items i JOIN production_batch_policies p ON p.batch_id=i.batch_id
            WHERE i.state IN ('awaiting_kpi_activation','production','completed') LIMIT 1""").fetchone()
        if not ready:
            raise ValueError('Run and review a representative batch, then finish its six images before accepting the workflow')
        return e['execute'](c, {'action': 'activate_kpi', 'workflow_accepted_by_user': True,
                              'authority': cmd['authority'], 'reference': cmd['reference']})
    if action == 'batch_submit':
        prior = c.execute('SELECT payload FROM production_batches WHERE batch_id=?', (cmd.get('batch_id'),)).fetchone()
        layout = json.loads(prior['payload']).get('layout_profile') if prior else 'current'
        data = normalize(cmd, {**e, 'shared_layout_profile': layout, **({'shared_mockup_layout':json.loads(prior['payload']).get('mockup_layout')} if prior else {})})
        fp = e['digest'](data)
        old = c.execute('SELECT fingerprint FROM production_batches WHERE batch_id=?', (data['batch_id'],)).fetchone()
        if old and old['fingerprint'] != fp:
            raise ValueError('Submitted batch is immutable; use a new batch ID')
        if not old:
            for record in data['items']:
                requested=record.get('listing_code') or (record['item_id'] if e['CODE'].fullmatch(record['item_id']) and record['item_id'].endswith('_TQH') else None)
                # Cancelled, unallocated intake must not reserve the user's code forever.
                if requested and (c.execute("SELECT 1 FROM reservations WHERE code=? UNION SELECT 1 FROM jobs WHERE code=? UNION SELECT 1 FROM production_batch_items WHERE (item_id=? OR listing_code=?) AND (state!='cancelled' OR listing_code IS NOT NULL)",(requested,requested,requested,requested)).fetchone() or (e['JOBS']/(requested+'.json')).exists()):
                    raise ValueError('Supplied listing code is already used by active or allocated work: '+requested+'; keep this code and resolve the existing work before retrying')
            order = c.execute('SELECT COALESCE(MAX(queue_order),0)+1 FROM production_batches').fetchone()[0]
            c.execute('INSERT INTO production_batches VALUES(?,?,?,?,?,?,?)', (data['batch_id'], fp, json.dumps(data, ensure_ascii=False), 'submitted', order, None, e['now']()))
            for n, record in enumerate(data['items']):
                c.execute('INSERT INTO production_batch_items VALUES(?,?,?,?,?,?,?,?,?,?)',
                    (data['batch_id'], record['item_id'], n, 'queued', 1, record['brief']['brief_id'], None, '{}', None, None))
        return {'ok': True, 'status': 'batch_preview', 'batch_id': data['batch_id'], 'batch_fingerprint': fp,
                'profile_version':data.get('profile_version',1),'positions':data.get('positions'),
                'kind': data['kind'], 'name': data['name'], 'item_count': len(data['items']),
                'items': [{'item_id': x['item_id'], 'title': x['title'], **({'listing_code':x['listing_code']} if x.get('listing_code') else {})} for x in data['items']], 'generation_started': False,
                'approval_policy': data['completion_policy'], 'sizing_policy': data['sizing_policy']}
    if action == 'batch_reorder':
        ids = cmd.get('batch_ids')
        current = [r[0] for r in c.execute("SELECT batch_id FROM production_batches WHERE status IN ('confirmed','ready') ORDER BY queue_order")]
        if not isinstance(ids, list) or len(ids) != len(set(ids)) or set(ids) != set(current):
            raise ValueError('Reorder must include every waiting confirmed/ready batch exactly once; active batch cannot move')
        for n, bid in enumerate(ids):
            c.execute('UPDATE production_batches SET queue_order=? WHERE batch_id=?', (n + 1, bid))
        return batch_status(c)
    b = batch(c, cmd['batch_id'])
    if action in ('batch_confirm', 'batch_start'):
        if cmd.get('batch_fingerprint') != b['fingerprint']:
            raise ValueError('Confirm/start must match the exact submitted batch fingerprint')
        if action == 'batch_confirm':
            if b['status'] == 'submitted':
                c.execute("UPDATE production_batches SET status='confirmed',reference=? WHERE batch_id=?", (cmd['reference'], b['batch_id']))
            return {'ok': True, 'status': 'batch_confirmed', 'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint']}
        if b['status'] not in ('confirmed', 'ready', 'active', 'completed', 'stopped', 'prepared'):
            raise ValueError('Confirm the immutable preview before starting the batch')
        if b['status'] == 'completed':
            controls.release_error_holds(e['ROOT'], b['batch_id'], c, completed=True)
            return {'ok': True, 'status': 'batch_completed', 'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'], 'generation_called': False}
        import flow_worker_pool
        pooled = flow_worker_pool.resume(c,b,e,cmd['reference'])
        if pooled:
            return pooled
        if b['status'] != 'completed':
            resumed = controls.resume_selected_group(c, b['batch_id'], e, cmd['reference'])
            if resumed:
                controls.release_error_holds(e['ROOT'], b['batch_id'], c)
                return {'ok': True, 'status': 'batch_queued', 'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint'], **resumed}
            run = controls.get(c, 'batch_run_plan')
            if run and run.get('mode') == 'selected_group' and run['status'] in ('preparing','running'):
                raise ValueError('These batches belong to the selected group; approve every representative or stop the group before starting a single batch')
            controls.put(c, 'batch_preparation:' + b['batch_id'], False)
            controls.activate(c, b, e, cmd['reference'])
            controls.release_error_holds(e['ROOT'], b['batch_id'], c)
        return {'ok': True, 'status': 'batch_queued', 'batch_id': b['batch_id'], 'batch_fingerprint': b['fingerprint']}
    if action == 'batch_stop':
        if b['status'] == 'completed':
            raise ValueError('Completed history cannot be stopped')
        c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?", (b['batch_id'],))
        controls.put(c, 'batch_preparation:' + b['batch_id'], False)
        controls.stop_plan(c, b['batch_id'])
        return {'ok': True, 'status': 'batch_stopped', 'batch_id': b['batch_id']}
    if action == 'batch_retry':
        i = item(c, b['batch_id'], cmd['item_id'])
        if i['state'] != 'failed':
            raise ValueError('Retry only the blocked current item, preserving exact versions')
        pending = c.execute("SELECT stage FROM production_batch_tasks WHERE batch_id=? AND item_id=? AND revision=? AND status='pending'", (b['batch_id'], i['item_id'], i['revision'])).fetchone()
        next_state = ('generating_sample' if pending['stage'] == 'sample_mockup' else 'generating_mockups') if pending else ('images_ready' if len(json.loads(i['images'])) == len(item_names(c, b, i)) else 'designing')
        set_item(c, i, next_state, error=None)
        resumed = None
        import flow_worker_pool
        if flow_worker_pool.enabled(c):
            resumed=flow_worker_pool.resume(c,b,e,cmd['reference'])
        elif b['status'] == 'stopped':
            resumed = controls.resume_selected_group(c, b['batch_id'], e, cmd['reference'])
            if not resumed:
                controls.activate(c, b, e, cmd['reference'])
            controls.release_error_holds(e['ROOT'], b['batch_id'], c)
        return {'ok': True, 'status': 'batch_item_retry', 'batch_id': b['batch_id'], 'item_id': i['item_id'], **(resumed or {})}
    raise ValueError('Unknown batch action')
