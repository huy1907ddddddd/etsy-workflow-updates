"""Independent-worker candidate gates on isolated images/DB; no real AI/browser."""
import copy
import hashlib
import importlib.util
import json
import unittest
from pathlib import Path
from PIL import Image

spec = importlib.util.spec_from_file_location('flow_tests', Path(__file__).with_name('check-flow-lark-orchestration.py'))
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
engine, flow = legacy.engine, legacy.flow


class AutoSubmitTests(legacy.FlowLarkTests):
    def test_authorized_model_fallback_keeps_real_label_and_human_gate(self):
        from unittest.mock import patch
        import chatgpt_image_orchestration as chat
        reference='Fixture user: on usage limit use Nano Banana 2.1'
        selection={'action':'chatgpt_worker_select','mode':'flow','authority':'direct_user','reference':reference,
                   'model_fallback_policy':{'enabled':True,'model':'Nano Banana 2.1'}}
        written=[]
        with patch.dict(self.env,{'ROOT':self.root,'write':lambda p,v:written.append(v)}), patch.object(chat,'selection',return_value={}):
            for changed in ({**selection,'authority':'attached_document'},
                            {**selection,'model_fallback_policy':{'enabled':True,'model':'wrong-model'}}):
                with self.assertRaises(ValueError):chat.execute(self.c,changed,self.env)
            chat.execute(self.c,selection,self.env)
        command=self.command()
        for record in [command['proof']]+command['proof']['images']:
            record.update(model='Nano Banana 2.1',model_policy_reference=reference)
        for changed in ('missing-authority','wrong-model'):
            bad=copy.deepcopy(command)
            bad['proof']['images'][0].update(model_policy_reference='unapproved' if changed=='missing-authority' else reference,
                                          model='Nano Banana 2.1' if changed=='missing-authority' else 'Other model')
            with self.assertRaises(ValueError):flow.execute(self.c,bad,self.env)
        result=flow.execute(self.c,command,self.env)
        self.assertFalse(result['quality_verified'])
        packet=flow.review_packet(self.c,{'brief_id':self.brief_id},self.env)
        self.assertEqual(packet['visual_qa']['status'],'awaiting_human_visual_review')
        self.assertEqual(json.loads(self.c.execute('SELECT proof FROM flow_candidates').fetchone()[0])['model'],'Nano Banana 2.1')
        with patch.dict(self.env,{'ROOT':self.root,'write':lambda p,v:written.append(v)}), patch.object(chat,'selection',return_value=written[0]):
            chat.execute(self.c,{k:v for k,v in selection.items() if k!='model_fallback_policy'},self.env)
        self.assertEqual(written[-1]['model_fallback_policy']['reference'],reference)

    def link_review_fixture(self, entity, batch_id='fixture-selected-batch'):
        import production_batch
        production_batch.tables(self.c)
        self.c.execute('INSERT OR IGNORE INTO production_batches VALUES(?,?,?,?,?,?,?)',
                       (batch_id, 'fixture-fingerprint', '{}', 'active', 0, 'Fixture batch', engine.now()))
        self.c.execute('INSERT INTO production_batch_items VALUES(?,?,?,?,?,?,?,?,?,?)',
                       (batch_id, 'fixture-item-' + str(self.c.total_changes), 0, 'designing', 1,
                        entity.get('brief_id', 'fixture-other-brief'), None, '[]', entity.get('listing_code'), None))

    def test_cycle_keeps_selected_batch_design_review_without_changing_approval_binding(self):
        from unittest.mock import patch
        import production_batch
        import chatgpt_image_orchestration as chat
        packet = self.attached_packet()
        self.link_review_fixture(packet['entity'])
        with patch.object(production_batch, 'cycle_step', return_value={'reviews': []}), \
             patch.object(chat, 'selection', return_value={'provider': 'flow', 'batch_id': 'fixture-selected-batch'}):
            snapshot = flow.execute(self.c, {'action': 'flow_cycle'}, self.env)
        self.assertIn(packet, snapshot['reviews'])
        current = engine.design_module().job(self.c, self.brief_id)
        self.assertEqual(current['state'], 'awaiting_design_2d_approval')
        self.assertIsNone(engine.design_module().approval(self.c, current, '2d', packet['fingerprint']))

    def test_review_scope_uses_canonical_brief_or_listing_membership(self):
        for entity in ({'brief_id': self.brief_id}, {'listing_code': 'fixture-listing'}):
            self.link_review_fixture(entity)
            packet = {'entity': entity}
            with self.subTest(entity=entity):
                self.assertTrue(flow.review_in_batch(self.c, packet, 'fixture-selected-batch'))
                self.assertFalse(flow.review_in_batch(self.c, packet, 'fixture-other-batch'))
                self.assertEqual(packet, {'entity': entity})
        self.assertFalse(flow.review_in_batch(self.c, {'entity': {'brief_id': 'unlinked'}}, 'fixture-selected-batch'))
        self.assertFalse(flow.review_in_batch(self.c, {'entity': {'listing_code': 'unlinked'}}, 'fixture-selected-batch'))
        self.assertTrue(flow.review_in_batch(self.c, {'entity': {'batch_id': 'fixture-selected-batch', 'item_id': 'sample'}}, 'fixture-selected-batch'))
        self.assertTrue(flow.review_in_batch(self.c, {'entity': {}, 'batch_policy': {'batch_id': 'fixture-selected-batch'}}, 'fixture-selected-batch'))
        self.assertFalse(flow.review_in_batch(self.c, {'entity': {'batch_id': 'fixture-other-batch'}}, 'fixture-selected-batch'))

    def test_two_signed_in_accounts_require_explicit_native_authority_and_valid_binding(self):
        from unittest.mock import patch
        import chatgpt_image_orchestration as chat
        policy={'enabled':True,'preferred_email':'second@example.com','accounts':[
            {'email':'first@example.com','home_url':'https://flow.google.com/'},
            {'email':'second@example.com','home_url':'https://flow.google.com/u/1/'}], 'unavailable_accounts':['first@example.com']}
        command={'action':'chatgpt_worker_select','mode':'flow','authority':'direct_user','reference':'Fixture owner authorizes two signed-in accounts','account_policy':policy}
        written=[]
        with patch.dict(self.env,{'ROOT':self.root,'write':lambda p,v:written.append(v)}), patch.object(chat,'selection',return_value={}):
            chat.execute(self.c,command,self.env)
            self.assertEqual(written[-1]['account_policy']['reference'],command['reference'])
            for changed in ({**command,'authority':'attached_document'},{**command,'account_policy':{}},
                            {**command,'account_policy':{**policy,'preferred_email':'unapproved@example.com'}},
                            {**command,'account_policy':{**policy,'accounts':[policy['accounts'][0],{'email':'second@example.com','home_url':'https://evil.test/'}]}}):
                with self.assertRaises(ValueError):chat.execute(self.c,changed,self.env)
        with patch.dict(self.env,{'ROOT':self.root,'write':lambda p,v:written.append(v)}), patch.object(chat,'selection',return_value=written[0]):
            chat.execute(self.c,{k:v for k,v in command.items() if k!='account_policy'},self.env)
            self.assertEqual(written[-1]['account_policy'],written[0]['account_policy'])

    def test_three_signed_in_accounts_and_immediate_unusual_switch_need_explicit_valid_policy(self):
        from unittest.mock import patch
        import chatgpt_image_orchestration as chat
        accounts=[{'email':f'account{i}@example.com','home_url':'https://flow.google.com/'+(f'u/{i}/' if i else '')} for i in range(3)]
        policy={'enabled':True,'preferred_email':accounts[2]['email'],'accounts':accounts,'on_unusual_activity':'switch_account'}
        command={'action':'chatgpt_worker_select','mode':'flow','authority':'direct_user','reference':'Fixture user adds a third account and explicitly cancels the ten-minute wait','account_policy':policy}
        written=[]
        with patch.dict(self.env,{'ROOT':self.root,'write':lambda p,v:written.append(v)}),patch.object(chat,'selection',return_value={}):
            chat.execute(self.c,command,self.env)
            self.assertEqual(written[-1]['account_policy']['on_unusual_activity'],'switch_account')
            self.assertEqual(len(written[-1]['account_policy']['accounts']),3)
            for changed in ({**command,'authority':'attached_document'}, {**command,'account_policy':{**policy,'accounts':accounts[:1]}},
                            {**command,'account_policy':{**policy,'on_unusual_activity':'ignore_security'}},
                            {**command,'account_policy':{**policy,'accounts':accounts+[{'email':'fourth@example.com','home_url':'https://flow.google.com/u/3/'}]}},
                            {**command,'account_policy':{**policy,'accounts':[accounts[0],{**accounts[1],'home_url':accounts[0]['home_url']},accounts[2]]}}):
                with self.assertRaises(ValueError):chat.execute(self.c,changed,self.env)

    def test_native_failed_retry_policy_preserves_provider_scope_and_unusual_cooldown(self):
        from unittest.mock import patch
        file=self.root/'workspace/flow-worker/runtime/image-provider.json'
        file.parent.mkdir(parents=True)
        original={'provider':'flow','mode':'flow','batch_id':'fixture-batch',
                  'unusual_activity_policy':{'enabled':True,'cooldown_ms':600000,'reference':'Earlier fixture user'}}
        file.write_text(json.dumps(original))
        command={'action':'flow_cycle','authority':'direct_user','reference':'Fixture user: retry Failed after one minute',
                 'generation_failure_policy':{'enabled':True,'cooldown_ms':60000}}
        with patch.dict(self.env,{'ROOT':self.root}):
            snapshot=flow.execute(self.c,command,self.env)
            saved=json.loads(file.read_text())
            self.assertEqual(saved['batch_id'],original['batch_id'])
            self.assertEqual(saved['unusual_activity_policy'],original['unusual_activity_policy'])
            self.assertEqual(snapshot['generation_failure_policy']['cooldown_ms'],60000)
            self.assertEqual(snapshot['generation_failure_policy']['reference'],command['reference'])
            before=file.read_bytes()
            for changed in ({**command,'authority':'attached_document'},
                            {**command,'generation_failure_policy':{'enabled':True,'cooldown_ms':59999}}):
                with self.assertRaises(ValueError):flow.execute(self.c,changed,self.env)
                self.assertEqual(file.read_bytes(),before)

    def test_native_timed_generation_replacement_preserves_deadline_on_retry(self):
        from unittest.mock import patch
        journal_path=self.root/'workspace/flow-worker/runtime'/('task-'+hashlib.sha256(self.task['id'].encode()).hexdigest()+'.json')
        journal_path.parent.mkdir(parents=True)
        journal={'revision':1,'fingerprint':self.task['fingerprint'],'images':{'center_chest':{'status':'generation_started','generation_id':'old-failed'}}}
        journal_path.write_text(json.dumps(journal))
        command={'authority':'direct_user','reference':'Fixture human asks for ten minutes then a new Generate',
                 'generation_retry':{'task_id':self.task['id'],'task_fingerprint':self.task['fingerprint'],'revision':1,
                                     'image_key':'center_chest','generation_id':'old-failed','reason':'Earlier unusual activity, tile now gone','cooldown_ms':600000}}
        with patch.dict(self.env,{'ROOT':self.root,'now':lambda:'2026-10-15T00:00:00+00:00','execute':lambda c,cmd:{'tasks':[self.task]}}):
            first=flow.authorize_generation_retry(self.c,command,self.env)
            self.assertEqual(first['not_before'],'2026-10-15T00:10:00+00:00')
            self.env['now']=lambda:'2026-10-15T00:05:00+00:00'
            self.assertEqual(flow.authorize_generation_retry(self.c,command,self.env),first)
            journal['images']['center_chest']['asset']=self.asset;journal_path.write_text(json.dumps(journal))
            with self.assertRaises(ValueError):flow.authorize_generation_retry(self.c,command,self.env)

    def test_unlimited_unusual_retries_need_explicit_ten_minute_retry_policy(self):
        import chatgpt_image_orchestration as chat
        from unittest.mock import patch
        command = {'action': 'chatgpt_worker_select', 'mode': 'flow', 'authority': 'direct_user', 'reference': 'User explicitly requests unlimited ten-minute unusual retries',
                   'unusual_activity_policy': {'enabled': True, 'cooldown_ms': 600000, 'retry_after_cooldown': True, 'retry_unlimited': True}}
        with patch.dict(self.env, {'ROOT': self.root}):
            for policy in [{'enabled': True, 'cooldown_ms': 600000, 'retry_unlimited': True}, {**command['unusual_activity_policy'], 'retry_unlimited': 'yes'}, {**command['unusual_activity_policy'], 'cooldown_ms': 1}]:
                with self.assertRaises(ValueError):
                    chat.execute(self.c, {**command, 'unusual_activity_policy': policy}, self.env)
            with self.assertRaises(ValueError):
                chat.execute(self.c, {**command, 'authority': 'attached_document'}, self.env)
            chat.execute(self.c, command, self.env)
            self.assertTrue(chat.selection(self.env)['unusual_activity_policy']['retry_unlimited'])

    def test_previous_account_retry_requires_explicit_timed_current_binding_and_saved_history(self):
        from unittest.mock import patch
        directory = self.root / 'workspace/flow-worker/runtime'
        directory.mkdir(parents=True)
        file = directory / ('task-' + hashlib.sha256(self.task['id'].encode()).hexdigest() + '.json')
        journal = {'revision': 1, 'fingerprint': self.task['fingerprint'], 'images': {'center_chest': {'status': 'generation_started', 'generation_id': 'current'}},
                   'events': [{'event': 'generation_retry_authorized', 'image_key': 'center_chest', 'prior_generation': {'status': 'generation_started', 'generation_id': 'old'}},
                              {'event': 'unusual_account_handover', 'image_key': 'center_chest', 'generation_id': 'old', 'unusual_activity_cooldown': {'generation_id': 'old', 'failed_tiles': ['Failed We noticed some unusual activity.']}}]}
        file.write_text(json.dumps(journal))
        policy = {'preferred_email': 'old@example.com', 'accounts': [{'email': 'old@example.com'}]}
        (directory / 'image-provider.json').write_text(json.dumps({'batch_id': 'fixture-batch', 'account_policy': policy}))
        task = {**self.task, 'batch_id': 'fixture-batch'}
        request = {'task_id': task['id'], 'task_fingerprint': task['fingerprint'], 'revision': 1, 'image_key': 'center_chest', 'generation_id': 'current',
                   'reason': 'User explicitly returns previous account after ten minutes', 'cooldown_ms': 600000, 'return_generation_id': 'old', 'return_account_sha256': hashlib.sha256(b'old@example.com').hexdigest()}
        command = {'authority': 'direct_user', 'reference': 'Fixture direct authorization', 'generation_retry': request}
        with patch.dict(self.env, {'ROOT': self.root, 'execute': lambda c, cmd: {'tasks': [task]}}):
            permit = flow.authorize_generation_retry(self.c, command, self.env)
            self.assertEqual(permit['generation_id'], 'current')
            self.assertIn('not_before', permit)
            for change in [{'generation_id': 'old'}, {'return_generation_id': 'unknown'}, {'cooldown_ms': 0}, {'return_account_sha256': 'f' * 64}]:
                with self.assertRaises(ValueError):
                    flow.authorize_generation_retry(self.c, {**command, 'generation_retry': {**request, **change}}, self.env)
            with self.assertRaises(ValueError):
                flow.authorize_generation_retry(self.c, {**command, 'authority': 'attached_document'}, self.env)

    def test_native_model_fallback_requires_policy_and_exact_unresolved_generation(self):
        from unittest.mock import patch
        import chatgpt_image_orchestration as chat
        file=self.root/'workspace/flow-worker/runtime'/('task-'+hashlib.sha256(self.task['id'].encode()).hexdigest()+'.json')
        file.parent.mkdir(parents=True)
        file.write_text(json.dumps({'revision':1,'fingerprint':self.task['fingerprint'],'images':{'center_chest':{'status':'generation_started','generation_id':'quota-old'}}}))
        request={'action':'flow_cycle','authority':'direct_user','reference':'Fixture fallback permission','model_fallback':'Nano Banana 2.1',
                 'generation_retry':{'task_id':self.task['id'],'task_fingerprint':self.task['fingerprint'],'revision':1,'image_key':'center_chest','generation_id':'quota-old','reason':'Human requests continuation after observed quota'}}
        policy={'enabled':True,'model':'Nano Banana 2.1','reference':request['reference']}
        output=self.root/'workspace/flow-worker/runtime/flow-model.json'
        with patch.dict(self.env,{'ROOT':self.root}), patch.object(chat,'selection',return_value={'provider':'flow','model_fallback_policy':policy}):
            for bad in ({**request,'reference':'wrong'}, {**request,'generation_retry':{**request['generation_retry'],'generation_id':'stale'}}):
                with self.assertRaises(ValueError):flow.execute(self.c,bad,self.env)
                self.assertFalse(output.exists())
            result=flow.execute(self.c,request,self.env)
            self.assertEqual(json.loads(output.read_text()),{'model':'Nano Banana 2.1','policy_reference':policy['reference']})
            self.assertEqual(result['generation_retries'][0]['generation_id'],'quota-old')

    def test_cycle_retains_native_task_identity_for_unknown_submit_recovery(self):
        snapshot = flow.execute(self.c, {'action': 'flow_cycle'}, self.env)
        identity = next(t for t in snapshot['task_states'] if t['id'] == self.task['id'])
        self.assertEqual(identity['revision'], 1)
        self.assertEqual(identity['current_revision'], 1)
        self.assertEqual(identity['fingerprint'], self.task['fingerprint'])
        self.assertEqual(identity['status'], 'pending')

    def command(self):
        items = self.task['payload']['images']
        proof = {k: v for k, v in self.proof.items() if k != 'visually_verified'}
        proof.update(executor='independent_flow_worker', acquisition='flow_download',
                     screenshot_sha256=engine.sha(proof['screenshot_path']),
                     prompt_provenance=[{'image_key': i['region'], 'prompt_sha256': hashlib.sha256(i['prompt'].encode()).hexdigest(),
                                         'reference_sha256': sorted(r['sha256'] for r in i['references'])} for i in items])
        proof['images'] = [dict(proof, image_key=i['region']) for i in items]
        return {'action': 'flow_auto_submit', 'task_id': self.task['id'], 'revision': 1,
                'task_fingerprint': self.task['fingerprint'],
                'assets': [dict(self.asset, image_key=i['region']) for i in items], 'proof': proof}

    def test_native_candidate_is_pending_quality_and_not_self_approved(self):
        result = flow.execute(self.c, self.command(), self.env)
        self.assertFalse(result['quality_verified'])
        self.assertEqual(result['status'], 'generated_candidate_awaiting_human_visual_review')
        packet = flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        self.assertFalse(packet['visual_qa']['passed'])
        self.assertEqual(packet['visual_qa']['status'], 'awaiting_human_visual_review')
        self.assertEqual(packet['visual_qa']['native_candidate_id'], result['native_candidate_id'])
        self.assertIsNone(engine.design_module().approval(self.c, engine.design_module().job(self.c, self.brief_id), '2d', packet['fingerprint']))

    def test_candidate_can_be_approved_only_by_actual_bound_human_decision(self):
        flow.execute(self.c, self.command(), self.env)
        packet = flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        result = flow.apply_decision(self.c, self.decision(packet), self.env)
        self.assertTrue(result['accepted'])
        self.assertEqual(result['result']['status'], 'awaiting_design_embroidery')

    def test_candidate_cannot_forge_legacy_operator_qa(self):
        cmd = self.command()
        cmd['proof']['visually_verified'] = True
        with self.assertRaises(ValueError):
            flow.execute(self.c, cmd, self.env)

    def test_candidate_flag_in_raw_design_attach_cannot_bypass_legacy_gate(self):
        cmd = copy.deepcopy(self.attachment)
        cmd['proof'].pop('visually_verified')
        cmd['candidate'] = True
        cmd['proof']['executor'] = 'independent_flow_worker'
        with self.assertRaises(ValueError):
            engine.execute(self.c, cmd)

    def test_candidate_retry_returns_exact_result_and_checks_current_hash(self):
        cmd = self.command()
        first = flow.execute(self.c, cmd, self.env)
        self.assertEqual(flow.execute(self.c, cmd, self.env), first)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM flow_candidates').fetchone()[0], 1)
        Path(self.asset['path']).write_bytes(b'changed-original')
        with self.assertRaises(ValueError):
            flow.execute(self.c, cmd, self.env)

    def test_candidate_wrong_provenance_or_stale_task_never_attaches(self):
        for change in ['prompt', 'reference', 'fingerprint', 'revision', 'region', 'screenshot', 'image_key', 'image_model', 'image_url', 'image_acquisition']:
            cmd = self.command()
            if change == 'prompt': cmd['proof']['prompt_provenance'][0]['prompt_sha256'] = 'a' * 64
            if change == 'reference': cmd['proof']['prompt_provenance'][0]['reference_sha256'] = ['a' * 64]
            if change == 'fingerprint': cmd['task_fingerprint'] = 'a' * 64
            if change == 'revision': cmd['revision'] = 2
            if change == 'region': cmd['assets'][0]['image_key'] = 'unknown'
            if change == 'screenshot': cmd['proof']['screenshot_sha256'] = 'a' * 64
            if change == 'image_key': cmd['proof']['images'][0]['image_key'] = 'wrong-key'
            if change == 'image_model': cmd['proof']['images'][0]['model'] = 'Other Model'
            if change == 'image_url': cmd['proof']['images'][0]['url'] = 'https://example.com'
            if change == 'image_acquisition': cmd['proof']['images'][0]['acquisition'] = 'screenshot'
            with self.subTest(change=change), self.assertRaises(ValueError):
                flow.execute(self.c, cmd, self.env)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM design_assets').fetchone()[0], 0)

    def test_candidate_review_cannot_use_mutated_file(self):
        flow.execute(self.c, self.command(), self.env)
        Path(self.asset['path']).write_bytes(b'mutated')
        with self.assertRaises(ValueError):
            flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)

    def auto_mockups(self):
        code, legacy_cmd = self.mockup_task()
        rule = engine.read(engine.ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        payload = {'provider': 'Flow Nano Banana Pro', 'revision': 1, 'listing_code': code, 'references': {'center_chest': self.asset},
                   'images': [{'name': name, 'prompt': 'isolated mockup ' + str(i) + '\n' + rule} for i, name in enumerate(engine.IMAGES)]}
        fp = engine.digest(payload)
        self.c.execute('UPDATE tasks SET fingerprint=?,payload=? WHERE id=?', (fp, __import__('json').dumps(payload), 'mockup-task-test'))
        directory = engine.STORE / 'artifacts' / code / 'v001/flow-originals/mockup-task-test'
        directory.mkdir(parents=True)
        assets = []
        for i, name in enumerate(engine.IMAGES):
            image = directory / name
            Image.new('RGB', (100, 100), (30 + i * 20, 80, 100)).save(image, 'JPEG')
            assets.append({'image_key': name, 'path': str(image), 'sha256': engine.sha(image)})
        proof = self.command()['proof']
        proof['prompt_provenance'] = [{'image_key': i['name'], 'prompt_sha256': hashlib.sha256(i['prompt'].encode()).hexdigest(),
                                      'reference_sha256': [self.asset['sha256']]} for i in payload['images']]
        proof['images'] = [dict(self.command()['proof'], image_key=i['name']) for i in payload['images']]
        return code, {'action': 'flow_auto_submit', 'task_id': 'mockup-task-test', 'revision': 1, 'task_fingerprint': fp, 'assets': assets, 'proof': proof}

    def test_mockup_candidate_reviews_pending_quality_then_human_approval(self):
        code, cmd = self.auto_mockups()
        result = flow.execute(self.c, cmd, self.env)
        packet = flow.review_packet(self.c, {'listing_code': code}, self.env)
        self.assertEqual(len(packet['images']), 6)
        self.assertFalse(packet['visual_qa']['passed'])
        self.assertEqual(packet['visual_qa']['native_candidate_id'], result['native_candidate_id'])
        flow.apply_decision(self.c, self.decision(packet), self.env)
        self.assertTrue(engine.approved(self.c, engine.job(self.c, code), 'images', packet['fingerprint']))

    def test_mockup_candidate_refuses_six_duplicate_images(self):
        _, cmd = self.auto_mockups()
        for asset in cmd['assets'][1:]:
            asset['path'], asset['sha256'] = cmd['assets'][0]['path'], cmd['assets'][0]['sha256']
        with self.assertRaisesRegex(ValueError, 'distinct'):
            flow.execute(self.c, cmd, self.env)

    def test_processed_pending_review_requires_approved_candidate_source_hashes(self):
        code, cmd = self.auto_mockups()
        result = flow.execute(self.c, cmd, self.env)
        original = engine.artifact(self.c, engine.job(self.c, code), 'images')
        flow.apply_decision(self.c, self.decision(flow.review_packet(self.c, {'listing_code': code}, self.env)), self.env)
        processed = []
        for i, asset in enumerate(original['payload']):
            file = self.root / ('processed-' + asset['name'])
            Image.new('RGB', (3000, 3000), (40 + i * 20, 90, 150)).save(file, 'JPEG')
            processed.append({'name': asset['name'], 'path': str(file), 'sha256': engine.sha(file), 'source_sha256': asset['sha256']})
        engine.put(self.c, engine.job(self.c, code), 'processed', {'images': processed})
        self.c.execute("UPDATE jobs SET state='awaiting_processed_approval' WHERE code=?", (code,))
        packet = flow.review_packet(self.c, {'listing_code': code}, self.env)
        self.assertFalse(packet['visual_qa']['passed'])
        self.assertEqual(packet['visual_qa']['native_candidate_id'], result['native_candidate_id'])
        processed[0]['source_sha256'] = 'a' * 64
        engine.put(self.c, engine.job(self.c, code), 'processed', {'images': processed})
        with self.assertRaisesRegex(ValueError, 'visual verification'):
            flow.review_packet(self.c, {'listing_code': code}, self.env)

    def test_partial_operator_then_auto_candidate_preserves_all_regions(self):
        partial = copy.deepcopy(self.attachment)
        partial['assets'] = {'center_chest': self.asset}
        engine.execute(self.c, partial)
        task = engine.execute(self.c, {'action': 'browser_queue'})['tasks'][0]
        cmd = self.command()
        cmd['assets'] = [a for a in cmd['assets'] if a['image_key'] in task['missing_regions']]
        cmd['proof']['prompt_provenance'] = [a for a in cmd['proof']['prompt_provenance'] if a['image_key'] in task['missing_regions']]
        cmd['proof']['images'] = [a for a in cmd['proof']['images'] if a['image_key'] in task['missing_regions']]
        result = flow.execute(self.c, cmd, self.env)
        packet = flow.review_packet(self.c, {'brief_id': self.brief_id}, self.env)
        self.assertEqual(len(packet['images']), 3)
        self.assertEqual(packet['visual_qa']['native_candidate_id'], result['native_candidate_id'])
        self.assertFalse(packet['visual_qa']['passed'])

    def test_human_mockup_correction_creates_new_image_revision_without_seo(self):
        code, cmd = self.auto_mockups()
        plan = {'garment': 'crewneck', 'color': 'sand', 'back_artwork': False,
                'regions': {region: dict(self.asset, width_cm=7, height_cm=7, artwork_approval_reference='test human approved', size_approval_reference='test approved sizes') for region in ['center_chest', 'left_sleeve', 'right_sleeve']}}
        self.c.execute('UPDATE jobs SET plan=? WHERE code=?', (json.dumps(plan), code))
        self.c.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?)', (code, 1, 'brief', engine.digest(plan), 'test approved locked brief', engine.now()))
        flow.execute(self.c, cmd, self.env)
        packet = flow.review_packet(self.c, {'listing_code': code}, self.env)
        result = flow.apply_decision(self.c, self.decision(packet, decision='revise', reason='Keep the chest motif centered'), self.env)
        self.assertTrue(result['accepted'])
        j = engine.job(self.c, code)
        self.assertEqual(j['revision'], 2)
        self.assertEqual(j['state'], 'awaiting_browser_images')
        self.assertIsNone(engine.artifact(self.c, j, 'images'))
        self.assertIsNone(engine.artifact(self.c, j, 'text'))
        new_task = result['result']['browser_task']
        self.assertEqual(new_task['kind'], 'flow_images')
        for image in new_task['payload']['images']:
            self.assertIn('Keep the chest motif centered', image['prompt'])
            self.assertTrue(image['prompt'].endswith(engine.read(engine.ROOT / 'config/artwork-flow-prompts.json')['mandatory_outline_rule']))
        self.assertEqual(json.loads(j['plan'])['regions'], plan['regions'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
