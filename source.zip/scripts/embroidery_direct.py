"""Explicit prompt-to-garment mode; no isolated artwork tasks or invented artwork approvals."""
import json

MODE = 'prompt_to_mockup'


def enabled(value):
    return value.get('embroidery_mode') == MODE


def mode(value):
    selected = value.get('embroidery_mode')
    if selected is not None and (value.get('product_kind', value.get('kind')) != 'embroidery_prompts' or selected not in ('artwork_stages', MODE)):
        raise ValueError('Choose a supported embroidery creation mode')
    return selected


def validate(value):
    import production_profiles as profiles
    mode(value)
    if not enabled(value) or not profiles.current(value) or value.get('regions') != {}:
        raise ValueError('Direct embroidery requires confirmed prompt motifs and no isolated artwork assets')
    regions = set(profiles.selected(value.get('positions')))
    if 'left_sleeve' in regions:
        regions.add('right_sleeve')
    motifs = value.get('motifs', {})
    if set(motifs) != regions or any(not isinstance(text, str) or not text.strip() or len(text) > 30000 for text in motifs.values()):
        raise ValueError('Supply a confirmed prompt for every selected embroidery region')
    if value.get('back_artwork') != ('back' in regions):
        raise ValueError('Direct embroidery back selection changed')
    if 'left_sleeve' in regions and motifs['left_sleeve'] != motifs['right_sleeve']:
        raise ValueError('Both sleeves must use the same complete unmirrored motif')
    return value


def plan(brief):
    keys = ('profile_version', 'product_kind', 'positions', 'garment', 'color', 'back_artwork', 'product_id',
            'mockup_set', 'mockup_layout', 'layout_profile', 'mockup_prompt_set', 'reference_image')
    result = {key: brief[key] for key in keys if key in brief}
    result.update(embroidery_mode=MODE, motifs=dict(brief['motifs']), regions={}, dimension_policy='maximum_limits_only')
    return validate(result)


def instructions(plan, image, e):
    validate(plan)
    rules = e['read'](e['ROOT'] / 'config/artwork-flow-prompts.json')
    preview = rules['embroidery_preview']
    stitches = preview[preview.index('Use Tatami fill stitches'):preview.index('Place the complete isolated embroidery design')].strip()
    lines = ['PROMPT TO EMBROIDERED GARMENT — CONFIRMED DESIGN AUTHORITY:',
             'Create the embroidery directly on this shot\'s garment from the confirmed region prompts below. '
             'There is no separate 2D design or isolated embroidery-preview image. Any legacy template reference to isolated artwork/files means these confirmed motif prompts, not an unattached image. '
             'Read the region prompts as motif content only: their white-background, isolated-design or 2D-preview authoring instructions must not remove the garment or turn its embroidery into a print. '
             'Keep the exact composition, silhouette, proportions, object counts, solid colors and literal lettering; add no text or personalization that the prompt does not specify. '
             'Each motif belongs only to its named region; leave all unselected regions blank. Wearer-left is viewer-right in a front view. '
             'Do not swap chest/sleeve/back motifs, mirror artwork, stretch it, or convert the result into a print, drawing, knitted texture or bulky patch.', stitches]
    for region in image['visible_regions']:
        lines.append(region.upper() + ' — ' + json.dumps(plan['motifs'][region], ensure_ascii=False))
    if {'left_sleeve', 'right_sleeve'} <= set(image['visible_regions']):
        lines.append('Both sleeves repeat the complete SAME motif, upright and unmirrored with identical counts, colors, proportions and cuff-relative placement. Do not generate two different designs.')
    if not plan.get('approved_sample'):
        lines.append('This is the first mockup sample from confirmed prompts. It requires the existing human sample review before the remaining views proceed; no isolated-artwork approval is claimed.')
    for number, reference in enumerate(image.get('references', []), 1):
        if reference.get('role') == 'same_listing_layout_anchor':
            lines.append(f'Image {number}: the approved SAME-LISTING garment sample is the visual master for all motif details, lettering, counts, colors, proportions and relative placement. Reproduce its embroidery consistently in this shot, including the macro. Keep this shot\'s required camera and garment style/color; never copy the sample background or fold into a different shot.')
        else:
            lines.append(f'Image {number}: {reference.get("role", "style_reference")} controls construction, placement, palette or styling only; never copy its decorations, text, blankness or guide strokes as embroidery.')
    if image['name'] == '07_embroidery_closeup.jpg':
        lines.append('MACRO OVERRIDE: show only the complete primary selected motif with a small plain-fabric margin. Use the approved garment sample as the design reference when attached; no isolated region file is expected. No other embroidery regions, whole garment, cuffs, neckline, props or added text.')
    if plan.get('image_correction'):
        lines.append('LATEST CONFIRMED MOCKUP CORRECTION: ' + plan['image_correction'] + '\nApply it within the selected regions and this shot role. Unselected regions remain blank and the permanent no-exterior-outline rule still applies.')
    return '\n'.join(lines)
