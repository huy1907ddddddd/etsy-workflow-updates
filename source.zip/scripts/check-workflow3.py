"""Isolated workflow3 behavior checks; fixture images are never production visual approvals."""
import copy
import importlib.util
import itertools
import json
import unittest
from pathlib import Path
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('check-production-batch.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
engine,batch,flow=fixture.engine,fixture.batch,fixture.flow
import production_profiles as profiles
import production_batch_controls as controls


class Workflow3Tests(fixture.BatchTests):
    def printed(self,kind='apparel_2d',bid='fixture-batch'):
        return {**self.submit,'profile_version':3,'kind':kind,'batch_id':bid}

    def embroidery(self,positions=None,bid='fixture-batch'):
        p=positions or {'chest':'left_right','sleeves':True,'back':True}
        keys=profiles.selected(p)
        return {**self.submit,'profile_version':3,'kind':'embroidery_prompts','batch_id':bid,'positions':p,
                'items':[{'title':'Fixture '+str(i),'designs':{r:'Unique '+r+' scene '+str(i) for r in keys}} for i in range(2)]}

    def test_all_fifteen_position_combinations_and_exact_design_count(self):
        count=0
        for chest,sleeves,back in itertools.product(['none','center','left','left_right'],[False,True],[False,True]):
            p={'chest':chest,'sleeves':sleeves,'back':back}
            if p=={'chest':'none','sleeves':False,'back':False}:
                with self.assertRaises(ValueError):profiles.selected(p)
                continue
            cmd=self.embroidery(p,bid='fixture-regions-'+str(count))
            result=self.execute(cmd);record=batch.manifest(batch.batch(self.c,result['batch_id']))
            keys=set(profiles.selected(p));motifs=record['items'][0]['brief']['motifs']
            self.assertEqual(set(motifs),keys|({'right_sleeve'} if sleeves else set()))
            if sleeves:self.assertEqual(motifs['left_sleeve'],motifs['right_sleeve'])
            bad=copy.deepcopy(cmd);bad['batch_id']+='-bad';bad['items'][0]['designs']['unexpected']='wrong'
            with self.assertRaises(ValueError):self.execute(bad)
            count+=1
        self.assertEqual(count,15)
        self.assertEqual(len(profiles.selected({'chest':'left_right','sleeves':True,'back':True})),4)

    def test_each_printed_product_uses_five_specific_views_and_keeps_legacy_six(self):
        for kind in profiles.PRINT_KINDS:
            cmd=self.printed(kind,bid='fixture-'+kind);r=self.start(cmd);t=self.cycle()['tasks'][0]
            self.assertEqual(t['payload']['product_kind'],kind)
            self.assertEqual(len(profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps({'profile_version':3,'product_kind':kind,'idea_prompt':'fixture','regions':{},**({'product_bundle':__import__('pajama_set').CONTRACT} if kind=='pajama_set' else {})})},self.env)['images']),5)
            self.assertEqual(t['payload']['images'][0]['name'],profiles.PRINT[0])
            self.assertTrue(t['payload']['images'][0]['prompt'].endswith(engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']))
            self.execute({'action':'batch_stop','batch_id':r['batch_id'],**self.auth})
        self.assertEqual(profiles.names({}),profiles.LEGACY)

    def test_shared_correction_reaches_second_item_without_copying_first_design(self):
        self.submit=self.printed();_,_,review=self.first_sample()
        flow.apply_decision(self.c,self.decision(review,'revise','Use natural daylight on every photo'),self.env)
        b=batch.batch(self.c,'fixture-batch');second=batch.item(self.c,b['batch_id'],'0002')
        p=batch.plan_images(self.c,b,second,True,self.env)
        self.assertIn('Use natural daylight on every photo',p['images'][0]['prompt'])
        self.assertIn('otter garden',p['images'][0]['prompt'].lower())
        self.assertNotIn('An otter bakery corner.',p['images'][0]['prompt'])
        self.c.commit();self.c.close();self.c=engine.connect(engine.STORE/'fixture.sqlite')
        self.assertIn('natural daylight',profiles.corrections(self.c,b['batch_id'],'mockups'))

    def test_embroidered_stage_approves_set_without_size_gate_and_locks_vertical_sleeves(self):
        self.start({**self.embroidery(),'mockup_set':profiles.SIX_SET});self.cycle();tasks=self.execute({'action':'browser_queue'})['tasks'];t=tasks[0]
        self.assertEqual(len(t['payload']['images']),5)
        sleeves=[x for x in t['payload']['images'] if x['region'].endswith('sleeve')]
        self.assertEqual(sleeves[0]['prompt'],sleeves[1]['prompt']);self.assertIn('26:7',sleeves[0]['prompt'])
        self.execute(self.candidate(t));review=flow.review_packet(self.c,{'brief_id':t['brief_id']},self.env)
        self.assertEqual(review['stage'],'2d');self.assertEqual(len(review['images']),5)
        flow.apply_decision(self.c,self.decision(review),self.env)
        t=self.execute({'action':'browser_queue'})['tasks'][0]
        command=self.candidate(t)
        # The browser reuses identical sleeve prompts/files; model that exact acquisition behavior.
        left=next(a for a in command['assets'] if a['image_key']=='left_sleeve')
        right=next(a for a in command['assets'] if a['image_key']=='right_sleeve');right.update(path=left['path'],sha256=left['sha256'])
        self.execute(command);review=flow.review_packet(self.c,{'brief_id':t['brief_id']},self.env)
        result=flow.apply_decision(self.c,self.decision(review),self.env)
        plan=self.execute({'action':'design_plan','brief_id':t['brief_id'],'revision':t['revision']})
        self.assertEqual(plan['status'],'approved_artwork_ready')
        self.assertEqual(self.c.execute('select count(*) from design_sizes').fetchone()[0],0)
        self.assertTrue(all('width_cm' not in a for a in plan['plan']['regions'].values()))
        images=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan['plan'])},self.env)['images']
        self.assertEqual([x['name'] for x in images],profiles.EMBROIDERY_SIX)
        self.assertEqual(len({x['wardrobe']['color'] for x in images}),6)
        self.assertEqual(plan['plan']['mockup_set'],profiles.SIX_SET)
        legacy=dict(plan['plan']);legacy.pop('mockup_set')
        old_images=profiles.image_plan({'code':'old','revision':1,'plan':json.dumps(legacy)},self.env)['images']
        self.assertEqual(len(old_images),10)
        self.assertIn('MAX 3.54 W × 3.54 H in',old_images[7]['prompt'])
        self.assertIn('MAX 10.24 W × 10.24 H in',old_images[7]['prompt'])
        self.assertNotIn('PHYSICAL DIMENSIONS IN INCHES',old_images[7]['prompt'])
        engine.validate_plan(plan['plan'])

    def test_new_garment_set_compact_sleeves_survive_both_stages_and_sample_gate(self):
        self.start(self.embroidery({'chest':'left','sleeves':True,'back':False}));self.cycle()
        b=batch.manifest(batch.batch(self.c,'fixture-batch'))
        self.assertEqual(b['mockup_set'],profiles.GARMENT_SET)
        rule=engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for stage in ('2d','embroidery'):
            t=self.execute({'action':'browser_queue'})['tasks'][0]
            self.assertEqual(t['stage'],stage)
            sleeves=[i for i in t['payload']['images'] if i['region'].endswith('sleeve')]
            self.assertEqual(sleeves[0]['prompt'],sleeves[1]['prompt'])
            for image in sleeves:
                self.assertEqual((image['aspect_ratio'],image['output_aspect_ratio']),('9:16','9:16'))
                self.assertIn('COMPACT SLEEVE COMPOSITION',image['prompt'])
                self.assertNotIn('HEIGHT:WIDTH 26:7',image['prompt'])
                self.assertNotIn('MANDATORY SHARED SLEEVE COMPOSITION',image['prompt'])
                self.assertFalse(any(r.get('role')=='design_free_composition_guide' for r in image['references']))
                self.assertTrue(image['prompt'].endswith(rule))
                self.assertIn('broader motif clusters' if stage=='2d' else 'exact approved 2D artwork aspect ratio',image['prompt'])
            candidate=self.candidate(t)
            left=next(a for a in candidate['assets'] if a['image_key']=='left_sleeve')
            next(a for a in candidate['assets'] if a['image_key']=='right_sleeve').update(path=left['path'],sha256=left['sha256'])
            raw=Path(left['path']).read_bytes();self.execute(candidate)
            self.assertEqual(Path(left['path']).read_bytes(),raw)
            review=flow.review_packet(self.c,{'brief_id':t['brief_id']},self.env)
            flow.apply_decision(self.c,self.decision(review),self.env)
        plan=self.execute({'action':'design_plan','brief_id':t['brief_id'],'revision':t['revision']})['plan']
        images=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan)},self.env)['images']
        self.assertEqual([i['name'] for i in images],profiles.GARMENT_SIX)
        sample=self.cycle()['tasks'][0]
        self.assertEqual(sample['stage'],'sample_mockup');self.assertEqual(len(sample['payload']['images']),1)
        self.execute(self.candidate(sample))
        self.assertTrue(self.cycle()['reviews'])

    def test_garment_only_views_all_positions_keep_region_sources_and_macro_isolation(self):
        import embroidery_layout
        from PIL import Image
        asset=engine.STORE/'source.png';Image.new('RGB',(64,64),'green').save(asset)
        ref={'path':str(asset),'sha256':engine.sha(asset)}
        rule=engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for chest,sleeves,back in itertools.product(['none','center','left','left_right'],[False,True],[False,True]):
            if chest=='none' and not sleeves and not back:continue
            selected=set(profiles.selected({'chest':chest,'sleeves':sleeves,'back':back}))
            if sleeves:selected.add('right_sleeve')
            plan={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':{r:ref for r in selected},'layout_profile':embroidery_layout.load(self.env),'approved_sample':ref}
            images=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan)},self.env)['images']
            self.assertEqual([i['name'] for i in images],profiles.GARMENT_SIX)
            self.assertEqual(len({i['wardrobe']['color'] for i in images}),6)
            for image in images:
                self.assertIn('GARMENT ONLY:',image['prompt']);self.assertTrue(image['prompt'].endswith(rule))
                for old in ['Adult models only','Adult male standing','Adult female','female A','male_model','female_a_model','narrow upright sleeve']:
                    self.assertNotIn(old,image['prompt'])
                mapped={r for a in image['references'] for r in a.get('regions',[])}
                self.assertEqual(mapped,set(image['visible_regions']))
                self.assertTrue(mapped<=selected)
                if image['name']=='07_embroidery_closeup.jpg':
                    self.assertEqual(len(image['references']),1);self.assertEqual(len(image['visible_regions']),1)
                else:
                    self.assertIn('Overhead product photograph',image['prompt'])
                    self.assertIn('same_listing_layout_anchor',[r.get('role') for r in image['references']])
                    if image['name'].startswith(('04_','05_')):self.assertIn('Fully unfold',image['prompt'])

    def test_cuff_anchor_only_changes_visible_sleeve_mockup_prompts(self):
        import embroidery_layout
        from PIL import Image
        file=engine.STORE/'cuff-source.png';Image.new('RGB',(64,64),'blue').save(file)
        ref={'path':str(file),'sha256':engine.sha(file)}
        spec=importlib.util.spec_from_file_location('v22_cuff_profiles',engine.ROOT/'workspace/maintenance/versions/20261024-cuff-anchor1/before/scripts/production_profiles.py')
        old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        rule=engine.read(engine.ROOT/'config/artwork-flow-prompts.json')['mandatory_outline_rule']
        for chest,sleeves,back in itertools.product(['none','center','left','left_right'],[False,True],[False,True]):
            if chest=='none' and not sleeves and not back:continue
            selected=set(profiles.selected({'chest':chest,'sleeves':sleeves,'back':back}))
            if sleeves:selected.add('right_sleeve')
            for with_layout,with_sample in itertools.product([False,True],repeat=2):
                p={'profile_version':3,'product_kind':'embroidery_prompts','mockup_set':profiles.GARMENT_SET,'regions':{r:ref for r in selected}}
                if with_layout:p['layout_profile']=embroidery_layout.load(self.env)
                if with_sample:p['approved_sample']=ref
                job={'code':'fixture','revision':1,'plan':json.dumps(p)}
                before=old.image_plan(job,self.env);after=profiles.image_plan(job,self.env)
                self.assertEqual({k:v for k,v in after.items() if k!='images'},{k:v for k,v in before.items() if k!='images'})
                for a,b in zip(after['images'],before['images']):
                    self.assertEqual({k:v for k,v in a.items() if k!='prompt'},{k:v for k,v in b.items() if k!='prompt'})
                    affected=sleeves and a['name']!='07_embroidery_closeup.jpg'
                    self.assertEqual('CUFF-ANCHORED SLEEVE PLACEMENT:' in a['prompt'],affected)
                    if not affected:
                        self.assertEqual(a,b);continue
                    prefix,anchor=a['prompt'].rsplit('\nCUFF-ANCHORED SLEEVE PLACEMENT:',1)
                    self.assertEqual(prefix+'\n'+rule,b['prompt'])
                    self.assertIn('lowest visible stitched element',anchor)
                    self.assertIn('immediately above the seam',anchor)
                    self.assertIn('white padding',anchor)
                    self.assertIn('toward the elbow',anchor)
                    self.assertIn('overrides sleeve placement in the sample photo',anchor)
                    self.assertTrue(a['prompt'].endswith(rule))

    def test_historical_six_and_ten_prompt_payloads_equal_saved_v21_source(self):
        import embroidery_layout
        from PIL import Image
        file=engine.STORE/'approved.png';Image.new('RGB',(64,64),'blue').save(file)
        ref={'path':str(file),'sha256':engine.sha(file)}
        spec=importlib.util.spec_from_file_location('v21_profiles',engine.ROOT/'workspace/maintenance/versions/20261023-garment-only1/before/scripts/production_profiles.py')
        old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        for marker in (None,profiles.SIX_SET,'embroidery_10_v1'):
            p={'profile_version':3,'product_kind':'embroidery_prompts','regions':{r:ref for r in ('center_chest','left_sleeve','right_sleeve','back')},'approved_sample':ref,'layout_profile':embroidery_layout.load(self.env)}
            if marker:p['mockup_set']=marker
            job={'code':'old','revision':1,'plan':json.dumps(p)}
            self.assertEqual(profiles.image_plan(job,self.env),old.image_plan(job,self.env))

    def test_macro_isolates_one_primary_region_and_never_attaches_sleeve_or_sample_to_chest(self):
        from PIL import Image
        import embroidery_layout
        regions={}
        for n,region in enumerate(['center_chest','left_sleeve','right_sleeve','back']):
            file=engine.STORE/(region+'.png');Image.new('RGB',(64,64),(20+n*30,40,60)).save(file)
            regions[region]={'path':str(file),'sha256':engine.sha(file)}
        regions['right_sleeve']=regions['left_sleeve']
        anchor=engine.STORE/'own-listing.png';Image.new('RGB',(64,64),'beige').save(anchor)
        plan={'profile_version':3,'product_kind':'embroidery_prompts','regions':regions,'layout_profile':embroidery_layout.load(self.env),'approved_sample':{'path':str(anchor),'sha256':engine.sha(anchor)}}
        shots=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(plan)},self.env)['images']
        macro=shots[6];self.assertEqual(macro['visible_regions'],['center_chest']);self.assertEqual(len(macro['references']),1)
        self.assertEqual(macro['references'][0]['sha256'],regions['center_chest']['sha256'])
        self.assertIn('TIGHT QUALITY MACRO OF CENTER_CHEST ONLY',macro['prompt'])
        self.assertNotIn('Both sleeves use',macro['prompt']);self.assertNotIn('GARMENT-RELATIVE POSITION LOCK',macro['prompt'])
        self.assertNotIn('design_free_placement_guide',macro['prompt']);self.assertNotIn('same-listing product photo',macro['prompt'])
        self.assertNotIn('crop below the neck',macro['prompt']);self.assertNotIn('below the lowest zipper',macro['prompt'])
        for n in [2,9]:
            anchors=[r for r in shots[n]['references'] if r.get('role')=='same_listing_layout_anchor']
            self.assertEqual(len(anchors),1);self.assertEqual(anchors[0]['sha256'],plan['approved_sample']['sha256'])
            self.assertIn('same-listing product photo',shots[n]['prompt'])
        for n in [5,9]:
            self.assertNotIn('center_chest',{r for a in shots[n]['references'] for r in a.get('regions',[])})
        for region in ['left_chest','right_chest','back','left_sleeve']:
            specific={**plan,'regions':{region:regions['center_chest']}}
            m=profiles.image_plan({'code':'fixture','revision':1,'plan':json.dumps(specific)},self.env)['images'][6]
            self.assertEqual(m['visible_regions'],[region]);self.assertEqual(len(m['references']),1)

    def test_every_new_embroidery_listing_gets_its_own_first_photo_then_five_views_without_new_human_gate(self):
        self.start(self.embroidery({'chest':'center','sleeves':True,'back':False}))
        b=batch.batch(self.c,'fixture-batch')
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=? AND position=0",(b['batch_id'],))
        self.c.execute('INSERT INTO production_batch_policies VALUES(?,?,?,?,?,?)',(b['batch_id'],b['fingerprint'],'a'*64,'Fixture batch approval','fixture-human-message',engine.now()))
        for _ in range(10):
            self.cycle();tasks=self.execute({'action':'browser_queue'})['tasks']
            if not tasks:continue
            task=tasks[0]
            if task.get('stage')=='sample_mockup':break
            cmd=self.candidate(task)
            left=next((a for a in cmd['assets'] if a['image_key']=='left_sleeve'),None)
            right=next((a for a in cmd['assets'] if a['image_key']=='right_sleeve'),None)
            if left and right:right.update(path=left['path'],sha256=left['sha256'])
            self.execute(cmd)
        else:self.fail('second embroidery item never reached its first-photo task')
        self.assertEqual(task['item_id'],'0002');self.assertEqual(len(task['payload']['images']),1)
        sample=self.candidate(task);self.execute(sample);next_task=self.cycle()['tasks'][0]
        self.assertEqual(next_task['stage'],'mockups');self.assertEqual(len(next_task['payload']['images']),5);self.assertFalse(self.cycle()['reviews'])
        expected=sample['assets'][0]['sha256']
        for image in next_task['payload']['images']:
            anchor=[r for r in image['references'] if r.get('role')=='same_listing_layout_anchor']
            if image['name']==profiles.EMBROIDERY[6]:
                self.assertEqual(anchor,[]);self.assertEqual(len(image['references']),1)
                self.assertNotIn('approved sample reference',image['prompt'])
            else:self.assertEqual([r['sha256'] for r in anchor],[expected])

    def test_discard_cancels_only_unfinished_batch_and_keeps_partial_assets(self):
        r=self.start(self.printed());t=self.cycle()['tasks'][0];cmd=self.candidate(t)
        self.execute({'action':'batch_stop','batch_id':r['batch_id'],**self.auth});self.execute(cmd)
        original=Path(cmd['assets'][0]['path']);self.assertTrue(original.exists())
        other=self.execute(self.printed(bid='fixture-other'))
        result=self.execute({'action':'batch_discard_remaining','batch_id':r['batch_id'],'batch_fingerprint':r['batch_fingerprint'],**self.auth})
        self.assertEqual(result['cancelled_items'],2);self.assertTrue(original.exists())
        self.assertEqual(batch.batch(self.c,other['batch_id'])['status'],'submitted')
        with self.assertRaises(ValueError):self.execute(cmd)
        self.assertEqual(self.cycle()['status'],'batch_idle')

    def test_ordinary_queue_never_advances_after_completion_or_restart(self):
        r=self.start(self.printed());self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(r['batch_id'],));self.cycle()
        other=self.execute(self.printed(bid='fixture-next'));self.execute({'action':'batch_confirm','batch_id':other['batch_id'],'batch_fingerprint':other['batch_fingerprint'],**self.auth})
        self.c.commit();self.c.close();self.c=engine.connect(engine.STORE/'fixture.sqlite')
        self.assertEqual(self.cycle()['status'],'batch_idle');self.assertEqual(batch.batch(self.c,other['batch_id'])['status'],'confirmed')

    def test_night_plan_rejects_unapproved_and_stale_corrections(self):
        r=self.execute(self.printed())
        with self.assertRaises(ValueError):self.execute({'action':'batch_run_plan','batch_ids':[r['batch_id']],**self.auth})
        b=batch.batch(self.c,r['batch_id']);self.c.execute("UPDATE production_batches SET status='prepared' WHERE batch_id=?",(b['batch_id'],))
        self.c.execute('INSERT INTO production_batch_policies VALUES(?,?,?,?,?,?)',(b['batch_id'],b['fingerprint'],'a'*64,'fixture','real-fixture',engine.now()))
        self.execute({'action':'batch_run_plan','batch_ids':[b['batch_id']],**self.auth})
        profiles.save_correction(self.c,b['batch_id'],'mockups','Changed after approval','fixture')
        self.assertEqual(self.cycle()['status'],'batch_run_plan_blocked');self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'blocked')

    def test_two_representatives_prepare_and_group_approve_before_a_finite_night_plan(self):
        ids=['fixture-night-a','fixture-night-b']
        for bid in ids:self.execute(self.printed(bid=bid))
        self.execute({'action':'batch_prepare_reviews','batch_ids':ids,**self.auth})
        for bid in ids:
            result=self.cycle();self.assertEqual(result['batch_id'],bid)
            self.execute(self.candidate(result['tasks'][0]));self.cycle()
        self.assertEqual(self.cycle()['status'],'batch_idle')
        bundle=self.execute({'action':'batch_review_bundle','batch_ids':ids,**self.auth})
        self.assertEqual(len(bundle['images']),2)
        self.execute({'action':'batch_approve_bundle','bundle_id':bundle['bundle_id'],'event_id':'fixture-bundle-event','message_id':'fixture-real-card',**self.auth})
        for _ in ids:self.cycle()
        self.assertTrue(all(batch.batch(self.c,bid)['status']=='prepared' for bid in ids))
        self.execute({'action':'batch_run_plan','batch_ids':ids,**self.auth})
        self.assertEqual(controls.choose(self.c,self.env)['batch_id'],ids[0])
        self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id=?",(ids[0],))
        self.assertEqual(controls.choose(self.c,self.env)['batch_id'],ids[1])
        self.execute({'action':'batch_stop','batch_id':ids[1],**self.auth})
        self.assertIsNone(controls.choose(self.c,self.env));self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'stopped')

    def test_group_review_without_images_guides_preparation_without_starting(self):
        ids=['fixture-wait-a','fixture-wait-b']
        for bid in ids:
            result=self.execute(self.printed(bid=bid))
            self.execute({'action':'batch_confirm','batch_id':bid,'batch_fingerprint':result['batch_fingerprint'],**self.auth})
        result=self.execute({'action':'batch_review_bundle','batch_ids':ids,**self.auth})
        self.assertEqual(result['status'],'batch_reviews_not_ready')
        self.assertEqual(result['next_action'],'batch_prepare_reviews')
        self.assertEqual(result['images'],[]);self.assertNotIn('bundle_id',result)
        self.assertTrue(all(batch.batch(self.c,bid)['status']=='confirmed' for bid in ids))
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],0)
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_policies').fetchone()[0],0)

    def test_group_review_while_generating_does_not_request_another_preparation(self):
        result=self.start(self.printed());self.cycle()
        waiting=self.execute({'action':'batch_review_bundle','batch_ids':[result['batch_id']],**self.auth})
        self.assertEqual(waiting['status'],'batch_reviews_not_ready')
        self.assertEqual(waiting['next_action'],'batch_status')
        self.assertEqual(len(batch.queue(self.c)),1)

    def group_samples(self, count=3):
        ids=['fixture-group-a','fixture-group-b','fixture-group-c'] if count==3 else ['fixture-group-'+str(n) for n in range(count)]
        for bid in ids+['fixture-unselected']:
            self.execute(self.printed(bid=bid))
        self.execute({'action':'batch_run_selected','batch_ids':ids,**self.auth})
        reviews={}
        for bid in ids:
            result=self.cycle();self.assertEqual(result['batch_id'],bid)
            task=result['tasks'][0];self.assertEqual(task['stage'],'sample_mockup')
            self.execute(self.candidate(task));self.cycle()
            reviews[bid]=flow.review_packet(self.c,{'batch_id':bid,'item_id':'0001'},self.env)
        return ids,reviews

    def test_ten_selected_batches_require_all_approvals_and_run_in_exact_order_after_resume(self):
        ids,reviews=self.group_samples(10)
        for bid in ids[:-1]:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.assertEqual(self.cycle()['status'],'batch_group_waiting_approval')
        flow.apply_decision(self.c,self.decision(reviews[ids[-1]]),self.env)
        for index,bid in enumerate(ids):
            result=self.cycle();self.assertEqual(result['batch_id'],bid)
            if index==4:
                self.execute({'action':'batch_stop','batch_id':bid,**self.auth})
                resumed=self.execute({'action':'batch_start','batch_id':bid,'batch_fingerprint':batch.batch(self.c,bid)['fingerprint'],**self.auth})
                self.assertTrue(resumed['resumed_group']);self.assertEqual(resumed['batch_ids'],ids)
                self.assertEqual(controls.get(self.c,'batch_run_plan')['index'],index)
            self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(bid,))
            self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(bid,))
            self.assertEqual(self.cycle()['status'],'batch_completed')
        self.cycle();self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'completed')
        self.assertEqual(batch.item(self.c,'fixture-unselected','0001')['state'],'queued')

    def test_large_preparation_bundle_and_night_plan_keep_empty_duplicate_and_approval_guards(self):
        ids=['fixture-large-'+str(n) for n in range(10)]
        for bid in ids:self.execute(self.printed(bid=bid))
        for action in ['batch_run_selected','batch_prepare_reviews','batch_review_bundle','batch_run_plan']:
            for invalid in [[],[ids[0],ids[0]]]:
                with self.assertRaises(ValueError):self.execute({'action':action,'batch_ids':invalid,**self.auth})
        self.assertEqual(self.execute({'action':'batch_prepare_reviews','batch_ids':ids,**self.auth})['batch_ids'],ids)
        self.assertEqual(self.execute({'action':'batch_review_bundle','batch_ids':ids,**self.auth})['batch_ids'],ids)
        with self.assertRaisesRegex(ValueError,'approved representative'):
            self.execute({'action':'batch_run_plan','batch_ids':ids,**self.auth})

    def test_selected_group_waits_for_revised_a_keeps_approved_b_c_then_runs_in_order(self):
        ids,reviews=self.group_samples()
        for bid in ids[1:]:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.assertEqual(self.cycle()['status'],'batch_group_waiting_approval')
        held={bid:dict(self.c.execute('SELECT * FROM production_batch_policies WHERE batch_id=?',(bid,)).fetchone()) for bid in ids[1:]}
        images={bid:batch.item(self.c,bid,'0001')['images'] for bid in ids[1:]}
        reason='Use larger orange fruit and remove exterior outlines throughout this batch.'
        flow.apply_decision(self.c,self.decision(reviews[ids[0]],'revise',reason),self.env)
        fixed=self.cycle()['tasks'][0]
        self.assertEqual(fixed['batch_id'],ids[0]);self.assertEqual(fixed['revision'],2)
        self.assertIn(reason,fixed['payload']['images'][0]['prompt'])
        later=batch.item(self.c,ids[0],'0002')
        self.assertTrue(all(reason in x['prompt'] for x in batch.plan_images(self.c,batch.batch(self.c,ids[0]),later,True,self.env)['images']))
        for bid in ids[1:]:
            self.assertEqual(batch.item(self.c,bid,'0001')['images'],images[bid])
            self.assertEqual(dict(self.c.execute('SELECT * FROM production_batch_policies WHERE batch_id=?',(bid,)).fetchone()),held[bid])
            self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks WHERE batch_id=?',(bid,)).fetchone()[0],1)
            self.assertEqual(profiles.corrections(self.c,bid,'mockups'),'')
        self.c.commit();self.c.close();self.c=engine.connect(engine.STORE/'fixture.sqlite')
        self.execute(self.candidate(fixed));self.cycle()
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'preparing')
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM production_batch_tasks WHERE stage='mockups'").fetchone()[0],0)
        current=flow.review_packet(self.c,{'batch_id':ids[0],'item_id':'0001'},self.env)
        self.assertFalse(flow.apply_decision(self.c,self.decision(reviews[ids[0]]),self.env)['accepted'])
        flow.apply_decision(self.c,self.decision(current),self.env)
        for bid in ids:
            result=self.cycle();self.assertEqual(result['batch_id'],bid)
            self.assertEqual(result['tasks'][0]['stage'],'mockups')
            self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'running')
            self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(bid,))
            self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(bid,))
            self.assertEqual(self.cycle()['status'],'batch_completed')
        self.assertEqual(self.cycle()['status'],'batch_idle')
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'completed')
        self.assertEqual(batch.item(self.c,'fixture-unselected','0001')['state'],'queued')

    def test_group_delivers_separate_reviews_for_parked_members_across_flow_scope(self):
        ids,reviews=self.group_samples()
        with patch('chatgpt_image_orchestration.selection',return_value={'provider':'flow','batch_id':ids[-1]}):
            result=flow.execute(self.c,{'action':'flow_cycle'},self.env)
        self.assertEqual({r['entity']['batch_id'] for r in result['reviews']},set(ids))
        self.assertEqual(len(result['reviews']),3)
        self.assertTrue(all('duyệt riêng mẻ này' in r['summary'] for r in result['reviews']))
        self.assertEqual(result['tasks'],[])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_policies').fetchone()[0],0)

    def test_group_stop_and_single_start_cannot_bypass_the_all_approved_gate(self):
        ids,reviews=self.group_samples()
        for bid in ids[1:]:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.cycle()
        with self.assertRaisesRegex(ValueError,'selected group'):
            self.execute({'action':'batch_start','batch_id':ids[1],'batch_fingerprint':batch.batch(self.c,ids[1])['fingerprint'],**self.auth})
        self.execute({'action':'batch_stop','batch_id':ids[0],**self.auth})
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'stopped')
        self.assertIsNone(controls.choose(self.c,self.env))
        self.assertTrue(all(not controls.prep(self.c,bid) for bid in ids))
        for bid in ids[1:]:self.assertIsNotNone(batch.policy(self.c,batch.batch(self.c,bid)))

    def test_resume_stopped_member_restores_selected_group_and_all_approval_gates(self):
        ids,reviews=self.group_samples()
        for bid in ids[1:]:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.cycle()
        self.execute({'action':'batch_stop','batch_id':ids[0],**self.auth})
        before=controls.get(self.c,'batch_run_plan')
        result=self.execute({'action':'batch_start','batch_id':ids[0],'batch_fingerprint':batch.batch(self.c,ids[0])['fingerprint'],**self.auth})
        run=controls.get(self.c,'batch_run_plan')
        self.assertTrue(result['resumed_group']);self.assertEqual(run['status'],'preparing')
        self.assertEqual(run['entries'],before['entries']);self.assertEqual(run['index'],before['index'])
        self.assertEqual(self.cycle()['status'],'batch_group_waiting_approval')
        flow.apply_decision(self.c,self.decision(reviews[ids[0]]),self.env)
        for bid in ids:
            result=self.cycle();self.assertEqual(result['batch_id'],bid)
            self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(bid,))
            self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(bid,))
            self.assertEqual(self.cycle()['status'],'batch_completed')
        self.cycle();self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'completed')
        self.assertEqual(batch.item(self.c,'fixture-unselected','0001')['state'],'queued')

    def test_resume_running_group_preserves_completed_members_index_and_rejects_changed_binding(self):
        ids,reviews=self.group_samples()
        for bid in ids:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.cycle()
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(ids[0],))
        self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(ids[0],))
        self.cycle();self.cycle()
        self.execute({'action':'batch_stop','batch_id':ids[1],**self.auth})
        before=controls.get(self.c,'batch_run_plan')
        command={'action':'batch_start','batch_id':ids[1],'batch_fingerprint':batch.batch(self.c,ids[1])['fingerprint'],**self.auth}
        controls.put(self.c,'batch_corrections:'+ids[2],[{'stage':'mockups','reason':'changed after stop','reference':'fixture'}])
        with self.assertRaisesRegex(ValueError,'Selected group source or approval changed'):self.execute(command)
        self.assertEqual(controls.get(self.c,'batch_run_plan'),before)
        controls.put(self.c,'batch_corrections:'+ids[2],[])
        result=self.execute(command);self.assertTrue(result['resumed_group'])
        run=controls.get(self.c,'batch_run_plan');self.assertEqual(run['status'],'running')
        self.assertEqual(run['index'],before['index']);self.assertEqual(run['entries'],before['entries'])
        self.assertEqual(batch.batch(self.c,ids[0])['status'],'completed')
        self.assertEqual(batch.batch(self.c,ids[1])['status'],'active')

    def test_resume_group_skips_discarded_member_without_reopening_or_weakening_bindings(self):
        ids,reviews=self.group_samples()
        for bid in ids:flow.apply_decision(self.c,self.decision(reviews[bid]),self.env)
        self.cycle()
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(ids[0],))
        self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(ids[0],))
        self.cycle();self.cycle()
        self.execute({'action':'batch_stop','batch_id':ids[2],**self.auth})
        self.execute({'action':'batch_discard_remaining','batch_id':ids[2],'batch_fingerprint':batch.batch(self.c,ids[2])['fingerprint'],**self.auth})
        before=controls.get(self.c,'batch_run_plan')
        command={'action':'batch_start','batch_id':ids[1],'batch_fingerprint':batch.batch(self.c,ids[1])['fingerprint'],**self.auth}
        self.c.execute("UPDATE production_batch_items SET state='queued' WHERE batch_id=? AND item_id='0001'",(ids[2],))
        with self.assertRaisesRegex(ValueError,'Selected group source or approval changed'):self.execute(command)
        self.c.execute("UPDATE production_batch_items SET state='cancelled' WHERE batch_id=? AND item_id='0001'",(ids[2],))
        task=self.c.execute('SELECT id,status FROM production_batch_tasks WHERE batch_id=? LIMIT 1',(ids[2],)).fetchone()
        self.c.execute("UPDATE production_batch_tasks SET status='pending' WHERE id=?",(task['id'],))
        with self.assertRaisesRegex(ValueError,'Selected group source or approval changed'):self.execute(command)
        self.c.execute('UPDATE production_batch_tasks SET status=? WHERE id=?',(task['status'],task['id']))
        controls.put(self.c,'batch_corrections:'+ids[2],[{'stage':'mockups','reason':'changed','reference':'fixture'}])
        with self.assertRaisesRegex(ValueError,'Selected group source or approval changed'):self.execute(command)
        controls.put(self.c,'batch_corrections:'+ids[2],[])
        result=self.execute(command);self.assertTrue(result['resumed_group']);self.assertEqual(result['worker_batch_id'],ids[1])
        run=controls.get(self.c,'batch_run_plan');self.assertEqual(run['entries'],before['entries']);self.assertEqual(run['index'],before['index'])
        self.assertEqual(batch.batch(self.c,ids[2])['status'],'closed_partial')
        self.c.execute("UPDATE production_batch_items SET state='completed' WHERE batch_id=?",(ids[1],))
        self.c.execute("UPDATE production_batch_tasks SET status='completed' WHERE batch_id=?",(ids[1],))
        self.cycle();self.cycle()
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'completed')
        self.assertEqual(batch.batch(self.c,ids[2])['status'],'closed_partial')
        self.assertEqual(batch.item(self.c,'fixture-unselected','0001')['state'],'queued')

    def test_resume_preparing_group_keeps_cancelled_member_closed_and_still_requires_human_approval(self):
        ids,reviews=self.group_samples()
        flow.apply_decision(self.c,self.decision(reviews[ids[1]]),self.env)
        self.execute({'action':'batch_stop','batch_id':ids[0],**self.auth})
        self.execute({'action':'batch_stop','batch_id':ids[2],**self.auth})
        self.execute({'action':'batch_discard_remaining','batch_id':ids[2],'batch_fingerprint':batch.batch(self.c,ids[2])['fingerprint'],**self.auth})
        self.execute({'action':'batch_start','batch_id':ids[0],'batch_fingerprint':batch.batch(self.c,ids[0])['fingerprint'],**self.auth})
        self.assertEqual(self.cycle()['status'],'batch_group_waiting_approval')
        self.assertEqual(batch.batch(self.c,ids[2])['status'],'closed_partial')
        self.assertNotIn(ids[2],[p['entity']['batch_id'] for p in controls.group_reviews(self.c,self.env)])
        flow.apply_decision(self.c,self.decision(reviews[ids[0]]),self.env)
        self.assertEqual(self.cycle()['batch_id'],ids[0])
        self.assertEqual(batch.batch(self.c,ids[2])['status'],'closed_partial')

    def test_group_selection_preserves_existing_reviews_and_is_idempotent(self):
        ids,reviews=self.group_samples()
        flow.apply_decision(self.c,self.decision(reviews[ids[1]]),self.env)
        count=self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0]
        again=self.execute({'action':'batch_run_selected','batch_ids':ids,**self.auth})
        self.assertEqual(again['group_status'],'preparing')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],count)
        with self.assertRaises(ValueError):self.execute({'action':'batch_run_selected','batch_ids':list(reversed(ids)),**self.auth})

    def test_mixed_group_keeps_embroidery_stage_reviews_before_final_group_gate(self):
        ids=['fixture-group-embroidery','fixture-group-print']
        self.execute(self.embroidery({'chest':'center','sleeves':False,'back':False},bid=ids[0]))
        self.execute(self.printed(bid=ids[1]))
        self.execute({'action':'batch_run_selected','batch_ids':ids,**self.auth})
        self.cycle();design=self.execute({'action':'browser_queue'})['tasks'][0]
        self.execute(self.candidate(design));self.cycle()
        review=flow.review_packet(self.c,{'brief_id':design['brief_id']},self.env)
        self.assertEqual(review['stage'],'2d');flow.apply_decision(self.c,self.decision(review),self.env)
        self.cycle();preview=self.execute({'action':'browser_queue'})['tasks'][0]
        self.execute(self.candidate(preview));self.cycle()
        emb_review=flow.review_packet(self.c,{'brief_id':design['brief_id']},self.env)
        self.assertEqual(emb_review['stage'],'embroidery')
        printed=self.cycle();self.assertEqual(printed['batch_id'],ids[1])
        self.execute(self.candidate(printed['tasks'][0]));self.cycle()
        review=flow.review_packet(self.c,{'batch_id':ids[1],'item_id':'0001'},self.env)
        flow.apply_decision(self.c,self.decision(review),self.env)
        self.assertEqual(self.cycle()['status'],'batch_group_waiting_approval')
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'preparing')
        flow.apply_decision(self.c,self.decision(emb_review),self.env)
        sample=self.cycle();self.assertEqual(sample['batch_id'],ids[0]);self.assertEqual(sample['tasks'][0]['stage'],'sample_mockup')
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'preparing')
        self.execute(self.candidate(sample['tasks'][0]));self.cycle()
        review=flow.review_packet(self.c,{'batch_id':ids[0],'item_id':'0001'},self.env)
        flow.apply_decision(self.c,self.decision(review),self.env)
        self.assertEqual(self.cycle()['tasks'][0]['stage'],'mockups')
        self.assertEqual(controls.get(self.c,'batch_run_plan')['status'],'running')

    def test_selected_group_can_resume_paused_image_worker_while_waiting_for_reviews(self):
        ids,reviews=self.group_samples()
        root=engine.STORE/'isolated-runtime';pause=root/'workspace/flow-worker/runtime/pause.request.json';pause.parent.mkdir(parents=True)
        pause.write_text('{"reference":"fixture pause"}',encoding='utf-8')
        body={**self.auth,'event_id':'fixture-group-click','message_id':'fixture-real-group-button','command':{'action':'batch_run_selected','batch_ids':ids}}
        with patch.object(engine,'ROOT',root),patch('production_batch.canonical_command',return_value=body),patch('chatgpt_image_orchestration.selection',return_value={'provider':'flow'}):
            self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            self.assertFalse(pause.exists())
            selected=engine.read(pause.with_name('image-provider.json'));self.assertEqual(selected['batch_id'],ids[0])
            self.execute({'action':'batch_lark_command','event_id':body['event_id']})
            self.assertEqual(len(list(pause.parent.glob('pause.released-*.json'))),1)
            self.execute({'action':'batch_stop','batch_id':ids[0],**self.auth})
            with self.assertRaises(ValueError):self.execute({'action':'chatgpt_worker_select','mode':'flow','resume_image_worker':True,'batch_id':ids[0],**self.auth})

    def test_five_photo_handoff_registers_each_printed_product_without_dimensions(self):
        for kind in profiles.PRINT_KINDS:
            cmd=self.printed(kind,bid='fixture-handoff-'+kind);cmd['items']=cmd['items'][:1]
            r=self.start(cmd);t=self.cycle()['tasks'][0];self.execute(self.candidate(t));review=self.cycle()['reviews'][0]
            flow.apply_decision(self.c,self.decision(review),self.env)
            rest=self.cycle()['tasks'][0];self.assertEqual(len(rest['payload']['images']),4);self.execute(self.candidate(rest))
            self.c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',('kpi_activation',json.dumps({'activated_at':engine.now()})))
            state=self.cycle();self.assertEqual(len(state['production_jobs']),1,state)
            code=state['production_jobs'][0]['listing_code'];source=engine.read(engine.JOBS/(code+'.json'))
            self.assertEqual(source['packet']['confirmed_product_brief']['product_kind'],kind)
            self.assertEqual(source['packet']['confirmed_product_brief']['approved_resolved_dimensions_in'],{})
            self.assertEqual(len(engine.artifact(self.c,engine.job(self.c,code),'images')['payload']),5)
            self.execute({'action':'batch_stop','batch_id':r['batch_id'],**self.auth})

    def test_public_delivery_contains_ten_mockups_and_only_selected_shared_originals(self):
        self.check_delivery_photo_set(None)

    def test_public_delivery_six_set_keeps_original_numbers_and_only_six_mockups(self):
        self.check_delivery_photo_set(profiles.SIX_SET)

    def test_public_delivery_garment_set_uses_flatlay_filenames(self):
        self.check_delivery_photo_set(profiles.GARMENT_SET)

    def check_delivery_photo_set(self,photo_set):
        import delivery_layout
        from PIL import Image
        code='FIX_261017_01_TQH';images=[]
        photo_names=profiles.names({'profile_version':3,'product_kind':'embroidery_prompts',**({'mockup_set':photo_set} if photo_set else {})})
        for index,name in enumerate(photo_names):
            file=engine.STORE/name;Image.new('RGB',(3000,3000),(index*20,80,90)).save(file)
            images.append({'name':name,'path':str(file),'sha256':engine.sha(file)})
        regions={}
        for index,r in enumerate(['left_chest','right_chest','left_sleeve','back']):
            file=engine.STORE/(r+'.png');Image.new('RGB',(64,64),(index*40,20,80)).save(file)
            regions[r]={'path':str(file),'sha256':engine.sha(file)}
        regions['right_sleeve']=regions['left_sleeve']
        plan={'profile_version':3,'product_kind':'embroidery_prompts','regions':regions}
        if photo_set:plan['mockup_set']=photo_set
        engine.verify_assets(images,True,expected_names=profiles.names(plan))
        j={'code':code,'revision':1,'plan':json.dumps(plan)}
        original=engine.scoped
        def scope(value,*args):
            value=str(value).replace('\\','/')
            for folder in ['Chưa xử lý','Đã xử lý']:
                prefix='C:/Huy/'+folder+'/'
                if value.startswith(prefix):value=engine.STORE/'public'/folder/value[len(prefix):];break
            return original(value,*args)
        with patch.object(engine,'scoped',side_effect=scope):
            result=delivery_layout.package(self.c,j,{'payload':{'images':images},'fingerprint':'a'*64},{'payload':{'title':'Fixture','description':'Fixture','tags':['fixture']}},'b'*64,'package','',vars(engine))
        self.assertEqual(len(result['files']),len(photo_names)+4)
        self.assertEqual(len(list(Path(result['destination']).iterdir())),len(photo_names)+4)
        originals=[x for x in result['files'] if x['role'].startswith(('11_','12_','13_','14_'))]
        self.assertEqual([x['role'] for x in result['files'] if x['role'] in photo_names],photo_names)
        self.assertEqual(len(originals),4);self.assertEqual({x['sha256'] for x in originals},{a['sha256'] for a in regions.values()})


    def test_completion_reports_survive_another_worker_consuming_the_transition(self):
        ids=['fixture-report-a','fixture-report-b','fixture-report-c']
        for number,bid in enumerate(ids):
            self.execute(self.printed(bid=bid))
            self.c.execute("UPDATE production_batches SET status='completed' WHERE batch_id=?",(bid,))
            for pos in range(2):
                code='UST_261018_%02d_TQH'%(number*2+pos+1)
                self.c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?)',(code,1,'completed','a'*64,'{}',engine.now()))
                j=engine.job(self.c,code)
                engine.put(self.c,j,'package',{'destination':str(engine.STORE/'delivered'/code),'review_fingerprint':'b'*64,'files':[{'name':'fixture.jpg'}]})
                self.c.execute('INSERT INTO kpi VALUES(?,?,?,?,?)',(code,1,'2026-10-20',engine.now(),'b'*64))
                task=engine.task(self.c,j,'lark_kpi',{})
                self.c.execute("UPDATE tasks SET status='verified' WHERE id=?",(task['id'],))
                self.c.execute("UPDATE production_batch_items SET state='completed',listing_code=? WHERE batch_id=? AND position=?",(code,bid,pos))
        controls.put(self.c,'batch_run_plan',{'status':'completed','mode':'selected_group','entries':[{'batch_id':bid} for bid in ids]})
        before=self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0]
        first=self.cycle();second=self.cycle()
        self.assertEqual(first['status'],'batch_idle')
        self.assertEqual(first['completion_reports'],second['completion_reports'])
        reports=first['completion_reports']
        self.assertEqual(len(reports),4)
        self.assertEqual(reports[-1]['kind'],'group_completed')
        self.assertEqual(reports[-1]['batch_ids'],ids)
        self.assertEqual(reports[-1]['completed_count'],6)
        self.assertEqual(reports[-1]['kpi_count'],6)
        self.assertEqual(reports[0]['listing_codes'],['UST_261018_01_TQH','UST_261018_02_TQH'])
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM production_batch_tasks').fetchone()[0],before)
        self.c.execute("UPDATE jobs SET state='awaiting_kpi_sync' WHERE code='UST_261018_06_TQH'")
        self.assertEqual(len(self.cycle()['completion_reports']),2)
        self.c.execute("UPDATE jobs SET state='completed' WHERE code='UST_261018_06_TQH'")
        self.c.execute("UPDATE tasks SET status='pending' WHERE code='UST_261018_06_TQH' AND kind='lark_kpi'")
        self.assertEqual(len(self.cycle()['completion_reports']),2)
        self.c.execute("UPDATE tasks SET status='verified' WHERE code='UST_261018_06_TQH'")
        self.c.execute("UPDATE production_batches SET status='stopped' WHERE batch_id=?",(ids[-1],))
        self.assertEqual(len(self.cycle()['completion_reports']),2)


if __name__=='__main__':
    suite=unittest.TestSuite(Workflow3Tests(name) for name in Workflow3Tests.__dict__ if name.startswith('test_'))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
