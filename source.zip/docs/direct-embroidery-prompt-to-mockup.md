# Áo thêu: Prompt → mockup

Lựa chọn mới do user yêu cầu ngày 07/11/2026. Đây là một cách tạo ảnh riêng của **Áo thêu**, bên cạnh luồng 2D → ảnh thêu → mockup đang có.

## Cách chọn

Làm mới bảng Workflow3 → **Tạo mẻ mới → Áo thêu → Cách tạo ảnh → Prompt → mockup áo thêu · bỏ ảnh trung gian**.

Chọn vị trí như trước: không/ngực giữa/ngực trái/ngực trái + phải; bật thêm hai tay và/hoặc lưng. Mỗi vị trí cần một mô tả motif. Hai tay dùng cùng một motif hoàn chỉnh, thẳng đứng, không lật gương. Ngực trái + phải là hai mô tả riêng.

Ví dụ TXT cho ngực trái và hai tay (mã chỉ minh họa):

```text
MÃ: DEMO_261107_01_TQH
TÊN: Cúc nhỏ và tên custom
NGỰC TRÁI: Three small cream daisies with green leaves above the exact name “LUNA”. Preserve the three flowers and literal lettering. No exterior outline.
TAY: One complete slender upright fern branch with five green leaves. Repeat this same full composition on both sleeves, unmirrored, with the lowest stitched motif immediately above each cuff seam.
```

Thêm `NGỰC GIỮA:`, `NGỰC PHẢI:` hoặc `LƯNG:` đúng lựa chọn. Không nhập vị trí chưa chọn. Ngăn mỗi mẫu bằng dòng `---`. Mã được giữ nguyên khi hợp lệ; không tái sử dụng mã minh họa cho hàng thật. Ảnh phong cách thêm là tùy chọn.

## Luồng ảnh và duyệt

Prompt vị trí → mockup áo thêu mẫu → duyệt mockup thật → các góc còn lại dựa trên chính mẫu áo đã duyệt → listing như hiện tại. Bộ mặc định vẫn là sáu ảnh áo thêu. Không tạo task/ảnh design 2D, ảnh thêu riêng hay ảnh ánh xạ motif. Không ghi nhận duyệt giả cho các bước đã bỏ.

Giữ các quy tắc hiện có: motif đúng bố cục, màu, số lượng, tỷ lệ và chữ; vị trí chưa chọn để trống; không đổi ngực/tay/lưng. Không có viền ngoài ở bất kỳ màu nào. Mảng lớn dùng Tatami, chi tiết nhỏ/chữ dùng Satin, mũi chỉ rõ và gọn, hướng chỉ theo hình, màu tách sạch, ánh chỉ tự nhiên do hướng mũi; không gradient, loang màu, giả in, bề mặt nhựa, dệt kim, chỉ rối hoặc patch 3D dày. Giữ quy tắc khoảng cách cổ/zip/túi và họa tiết tay sát phía trên đường ráp bo, bo tay để trống.

Ảnh mẫu áo đã duyệt là nguồn giữ design cho các ảnh sau, **kể cả macro thêu**. Sơ đồ trống chỉ hướng dẫn phom, nếp gấp và vị trí; bảng màu chỉ hướng dẫn màu áo. Không lấy họa tiết từ sơ đồ hoặc đồ trang trí nền. Không gán kích thước đo giả cho từng motif; giới hạn vùng thêu như cũ.

## Giao việc cho Thêu và Nét

**Thêu**: khi user chọn cách mới, viết concept và prompt motif đầy đủ cho từng vị trí, giữ chính xác chữ custom và số lượng/màu/bố cục. Không yêu cầu xuất một ảnh 2D nền trắng hay ảnh preview thêu riêng; không đưa lệnh “không có áo/vải” làm yêu cầu ảnh đầu ra. Đích là motif được thêu trực tiếp trên áo. Nếu user chọn cách cũ thì vẫn dùng luồng cũ.

**Nét**: giữ đúng nhãn vị trí trong TXT và bộ sáu góc/preset đã có. Với cách mới, mô tả design bằng prompt; sau khi mẫu được duyệt, dùng **ảnh áo mẫu cùng listing** làm nguồn nhất quán. Macro cũng dùng ảnh mẫu áo, không đòi file thêu cô lập. Preset chỉ đổi trang trí nền, giữ phom/góc chụp/vị trí/nét thêu và một ảnh flatlay sạch. Không tự chọn lại cách tạo ảnh, phôi hay màu ngoài phân công của hệ thống/user.

Hai chat cần gọi đúng tên lựa chọn để user biết đang dùng cách nào. Không tự chuyển mẻ cũ, duyệt ảnh, chạy mẻ hoặc đổi tài khoản/mạng.

## Gói native

Các công cụ gửi mẻ trực tiếp dùng cùng kind cũ và thêm cờ rõ ràng:

```json
{
  "action": "batch_submit",
  "batch_id": "example-direct-embroidery",
  "profile_version": 3,
  "kind": "embroidery_prompts",
  "embroidery_mode": "prompt_to_mockup",
  "name": "Ví dụ áo thêu trực tiếp",
  "positions": {"chest": "left", "sleeves": true, "back": false},
  "items": [{
    "title": "Cúc nhỏ và tên custom",
    "designs": {
      "left_chest": "Three cream daisies above the exact name LUNA.",
      "left_sleeve": "One complete upright five-leaf fern branch."
    }
  }]
}
```

Gói trên chỉ minh họa dữ liệu; không phải quyền tự chạy. Vẫn phải qua bản nháp/xác nhận và duyệt mockup. Bỏ `embroidery_mode` để dùng luồng cũ; giá trị lạ hoặc dùng cờ này cho loại sản phẩm khác bị từ chối. Mẻ đã lưu có fingerprint riêng, không chuyển cách bằng cách sửa payload.

Kiểm tra đã dùng DB/ảnh fixture, không tạo ảnh Flow thật cho lựa chọn mới. Chất lượng ảnh thực tế cần được xem ở mockup mẫu đầu của mẻ mới.
