# Bộ prompt mockup theo mẻ — 30/10/2026

Bổ sung03/11: dùng **Giáng sinh ấm áp — Áo thêu v3 · ánh sáng tự nhiên** cho bộ mới. Natural window daylight, neutral white balance, không đèn vàng/warmfilter/castvàng-cam hoặc ámxanh; không đổi màu phôi/thread thật. Mẻ lưng mới nhận diện sourceNoelv1/v2 và thay toàn bộ bằng v3 khi normalize; snapshot cũ giữ nguyên. Cover hiện tại dùng một guide crewneck đúng phôi, không gắn cả ba guide.

Cập nhật03/11: mẻ thêu mới có chọn lưng dùng bố cục `dual-front-back-v1`. Cover01 có hai áo cùng sản phẩm (front gấp + back trải phẳng);02/05 front,04/10 back,07 macro một vùng. Front luôn bày đủ hai tay, vùng chưa chọn để trống;10 luôn sạch. Prompt chuẩn/guide được snapshot riêng nên không đổi mẻ cũ. Bộ **Giáng sinh ấm áp — Áo thêu v2** chứa toàn bộ prompt Nét viết lại theo bố cục này. Khi nhận đúng source Noel cũ, backend thay trọn source thành v2 cho mẻ lưng mới; mẻ đã tạo giữ source cũ. Không chọn lưng giữ hành vi hiện tại.

Người dùng chốt tại Mạch: lựa chọn lưu theo tên, mặc định **Không trang trí**. Chỉ đổi trang trí ở hậu cảnh; giữ góc chụp, ánh sáng, tư thế, phôi, artwork, màu, vị trí và mã của từng listing. Không biến trang trí thành họa tiết trên sản phẩm. Ảnh bìa có thể trang trí; ảnh flatlay cuối luôn sạch.

## Dùng trên web

Trong **Tạo mẻ mới → 04 / Bộ prompt mockup**, chọn bộ đã lưu hoặc **＋ Thêm lựa chọn…**, nhập tên và dán trọn bộ prompt từ Nét, rồi **Lưu lựa chọn**. Bộ đã lưu thuộc đúng loại sản phẩm, còn sau khi tải lại trang hoặc mở lại dịch vụ. Tên đã có cần đặt tên mới cho phiên bản khác; không sửa ngầm các mẻ đã nhập.

Mỗi prompt có tiêu đề trên dòng riêng, đúng thứ tự, không có lời mở đầu hoặc khung code bao ngoài:

```text
===== 01_thumbnail.jpg =====
Prompt hoàn chỉnh cho ảnh bìa...
===== 02_female_angle.jpg =====
Prompt hoàn chỉnh cho góc nghiêng...
===== 03_female_seated.jpg =====
Prompt hoàn chỉnh cho góc ngồi...
===== 04_flatlay.jpg =====
Prompt flatlay nền trơn, không đồ trang trí...
===== 05_print_closeup.jpg =====
Prompt hoàn chỉnh cho ảnh cận...
```

Áo 2D/pijama/quần ngủ: đủ 5 phần trên, nhưng prompt phải đúng loại sản phẩm. Bộ pijama gồm áo + quần trong cùng một listing, quần ngủ là sản phẩm riêng.

Áo thêu hiện hành có 6 phần: `01_thumbnail.jpg`, `02_hoodie_folded.jpg`, `04_sweatshirt_flatlay.jpg`, `05_hoodie_flatlay.jpg`, `07_embroidery_closeup.jpg`, `10_flatlay.jpg`. Giữ toàn bộ ảnh không người theo bộ chuẩn; `10_flatlay.jpg` luôn không trang trí. Ảnh cận vẫn chỉ đúng vùng thêu chính, không trộn vùng khác.

## Nét giao trọn bộ

Nét đọc các bộ chuẩn trong `workspace/chat-handoff/20261014-prompt-authoring/` và `scripts/production_profiles.py` trước khi tạo lựa chọn mới. Viết lại toàn bộ prompt tự đủ, chỉ thay phần trang trí phía sau; không giao mảnh prompt nối thêm, không đổi bố cục chụp hay ánh sáng. Mỗi listing vẫn có thiết kế riêng từ brief và mẫu duyệt của chính listing đó. Không nhúng thiết kế/mã của một listing cụ thể vào bộ nền dùng chung.

Mẻ mới đóng băng toàn bộ bộ prompt trong manifest/fingerprint, brief và plan. Các góc sau vẫn dùng đúng mẫu cùng listing. Mặc định không có override nên prompt mẻ cũ giữ nguyên. Runtime giữ ràng buộc sản phẩm/nguồn duyệt/khung chuẩn; nội dung lựa chọn thay phần prompt chụp, không nối với phong cách nền cũ. Flatlay sạch dùng lại góc chuẩn, bỏ nội dung trang trí trong lựa chọn và có ràng buộc nền sạch rõ ràng. Lưu bộ prompt hoặc tạo bản nháp không phải lệnh Generate/duyệt/chạy mẻ.
