# Chuẩn kích thước thêu dùng chung

Người dùng chốt ngày 10/10/2026: lưu giới hạn tối đa làm chuẩn, không tính lại kích thước cho từng ảnh. Nguồn cấu hình: `C:/Huy/etsy-workflow/config/embroidery-size-standard.json`.

| Vùng | Rộng tối đa | Cao tối đa | Nhãn inch tương ứng |
|---|---:|---:|---|
| Ngực giữa | 26 cm | 26 cm | 10.24 × 10.24 in |
| Ngực trái | 9 cm | 9 cm | 3.54 × 3.54 in |
| Mỗi tay | 7 cm | 26 cm | 2.76 × 10.24 in |

Mặc định làm lớn nhất có thể trong khung, giữ nguyên tỷ lệ artwork. Mỗi thiết kế chỉ tính một lần sau khi duyệt artwork, đo toàn bộ vùng thêu gồm lá, cuống, dây, chữ và trang trí; không tính khoảng trắng. Lưu kích thước đã chọn vào metadata sản phẩm và dùng nguyên số đó cho thumbnail, người mẫu, macro, số đo và flatlay. Không đo hoặc tính lại từ ảnh mockup, không đổi kích thước khi đổi góc chụp hay size áo.

Hai giới hạn không có nghĩa mọi hình phải lấp đầy cả chiều rộng và chiều cao. Hình dài, hẹp có thể đạt chiều cao tối đa trước chiều rộng. Công thức fit đồng đều: lấy giá trị nhỏ hơn của `rộng tối đa / rộng artwork` và `cao tối đa / cao artwork`, nhân cả hai chiều với cùng hệ số. Dùng cm chính xác để giữ trong giới hạn; chuyển sang inch và làm tròn hai chữ số khi ghi trên ảnh 05. Các ảnh khác không cần nhãn số đo.

Chỉ tính lại khi đổi artwork, vị trí, người dùng yêu cầu kích thước khác hoặc cấu tạo áo cần thu nhỏ và đã được duyệt. Không tự tăng hình, kéo méo, cắt thiết kế hoặc vượt túi/khóa/bo. Chưa có giới hạn thêu lưng; khi có artwork lưng cần hỏi riêng.

Mẫu bí ngô đã chốt: giữa ngực rộng 10.24 × cao khoảng 9.23 in; toàn bộ dây trên mỗi tay rộng khoảng 2.03 × cao 10.24 in. Bố cục flatlay số đo lớn đã được người dùng duyệt. Bộ ảnh dùng lại các số này. Đây là mục tiêu thiết kế theo tỷ lệ artwork, chưa kiểm tra file thêu máy sản xuất.

File cấu hình và tài liệu đã lưu; chưa có worker n8n tự đọc cấu hình để tạo ảnh. Khi tích hợp worker, dùng file này làm nguồn chuẩn và metadata sản phẩm làm nguồn kích thước của từng thiết kế.
