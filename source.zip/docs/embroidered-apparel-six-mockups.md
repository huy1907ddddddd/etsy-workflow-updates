# Áo thêu — bộ 6 mockup không người và tham chiếu chung

Cập nhật03/11 — ánh sáng tự nhiên: mẻ lưng mới dùng snapshot `dual-front-back-neutral-v2`, guide xám trung tính tại `config/embroidery-guides/dual-front-back-neutral-v2/`. Ảnh bìa hiện hành là crewneck sweatshirt nên chỉ gắn guide crewneck; không gắn cả ba phôi. Guide hoodie/quarterzip chỉ dùng khi shot đó được phân công đúng phôi. Prompt khóa diffuse natural window daylight/white balance trung tính khoảng5500K, không ám vàng/cam, warmfilter, tungsten hoặc ám xanh. Màu beige thật của phôi vẫn giữ, không biến áo beige thành trắng. Bóng đèn trang trí không chiếu sáng lên áo; guide chỉ pose, không sao chép texture/màu của guide. Snapshotv1 và mọi payload cũ giữ nguyên.

## 03/11/2026 — bố cục ngực và lưng mới

Mẻ thêu mới có chọn **lưng** đóng băng thêm `mockup_layout.version=dual-front-back-v1`; giữ sáu tên file và `embroidery_6_flatlay_v1`. Mẻ/task/approval đã lưu không được chuyển đổi. Không chọn lưng thì giữ bố cục cũ.

| File | Bố cục khi có chọn lưng |
|---|---|
| 01_thumbnail.jpg | Một cảnh chụp thật gồm đúng hai áo cùng phôi/màu/size: một áo front-up gấp thân, ngực và cả hai tay/cuffs lộ đủ; một áo back-up trải phẳng, lưng lộ trọn. Không collage hoặc chồng che nhau. |
| 02_hoodie_folded.jpg | Một áo gấp front-up; luôn bày đủ hai tay, cả khi không thêu tay. |
| 04_sweatshirt_flatlay.jpg | Một áo trải phẳng back-up, thấy đầy đủ hình lưng. |
| 05_hoodie_flatlay.jpg | Một áo front-up trải phẳng, bố cục hơi chéo; ngực và hai tay/cuffs đủ trong khung. |
| 07_embroidery_closeup.jpg | Cận một vùng thêu chính, chỉ một nguồn thêu rời. |
| 10_flatlay.jpg | Một áo back-up trải phẳng, luôn nền sạch không trang trí. |

Bốn ảnh toàn áo sau cover chia đều hai trước/hai sau; macro riêng. Không chọn ngực hoặc tay thì vùng đó để trống, không tự thêm artwork. Hai áo chỉ xuất hiện ở cover; mẫu cover cùng listing không được kéo bố cục hai áo sang shot khác. Ánh sáng/phôi/palette/cuff anchor/nguồn thêu và cấm viền ngoài giữ nguyên.

Nét viết trọn bộ ở `workspace/chat-handoff/20261103-dual-front-back-mockups/`. Ba guide áo trơn mới ở `config/embroidery-guides/dual-front-back-v1/` chỉ điều khiển bố cục. Toàn bộ prompt chuẩn và đường dẫn/hash guide được đóng băng trong manifest → brief → plan → task. Nhãn nguồn và mã media vẫn phải khớp.

Bộ Noel cũ đã lưu có hash được nhận diện và thay toàn bộ source bằng bản Nét v2 cho mẻ lưng mới; không nối prompt cũ với prompt mới. Mẻ cũ giữ snapshot cũ. Lựa chọn v2 cũng được lưu trên web để chọn trực tiếp.

Cập nhật24/10/2026 — V24: mockup mới có vùng tay được neo bằng **chi tiết thêu thấp nhất**, đặt sát phía trên đường ráp bo cổ tay trên phần vải tay, chỉ chừa khe may tự nhiên nhỏ. Bo/ribbing để trống; không tính lề trắng của file nguồn làm đáy hình. Artwork đi từ cổ tay lên hướng khuỷu, giữ tỷ lệ và chiều đúng nguồn, không đẩy lên giữa cẳng tay/bắp tay hoặc kéo dài để phủ tay. Hai tay cùng khoảng hở theo bo ngay cả khi trải thẳng, xếp chéo hoặc bày bên thân áo gấp. Thấy rõ đường ráp bo và motif dưới cùng, không bị nếp gấp che. Quy tắc này ưu tiên vị trí tay nếu ảnh01/style/guide cũ để hình quá cao; các vùng khác vẫn khóa như cũ. Áp cho01/02/04/05/10 khi có tay; macro07 giữ khung cận một vùng. Không đổi artwork2D/thêu, số ảnh, palette hoặc payload/task đã lưu. Prompt mới nạp theo executionPython, không cần reloadFlow/8788. ChưaGenerate/QAảnhmới trong bản sửa này.

Cập nhật23/10/2026 sau khi CRM_261025_01–10_TQH hoàn tất và người dùng yêu cầu sửa. Mẻ mới mặc định `embroidery_6_flatlay_v1`: toàn bộ áo đặt trên mặt phẳng, không người, tay người hoặc mannequin. Bộ cũ `embroidery_6_v1` / `embroidery_10_v1` và payload không marker giữ nguyên; không chuyển đổi task/ảnh/approval đã lưu.

| Ảnh mới | Cách chụp |
|---|---|
| 01_thumbnail.jpg | Sweatshirt beige gấp, hai tay bày riêng và thấy vùng thêu |
| 02_hoodie_folded.jpg | Hoodie navy gấp, không che design bằng nếp gấp |
| 04_sweatshirt_flatlay.jpg | Sweatshirt sport grey trải phẳng toàn áo |
| 05_hoodie_flatlay.jpg | Hoodie light pink trải phẳng, bố trí chéo nhẹ trên mặt bàn |
| 07_embroidery_closeup.jpg | Cận đúng một vùng thêu trên áo đặt phẳng; không người/phụ kiện |
| 10_flatlay.jpg | Quarterzip white trải phẳng toàn áo |

Vị trí mặt trước/sau theo vùng đã chọn; hai tay cùng artwork/khôngmirror, cùng cao độ theo áo, không nằm trên đường ráp. Tỷ lệ artwork đã duyệt được giữ tự nhiên, không kéo dài để lấp đầy tay. Ảnh01 cùng listing vẫn là mốc; cận07 chỉ đính một nguồn vùng chính và không palette/guide/sample.

Design tay mới thuộc bộ mới giữ canvas9:16 nhưng không ép bounding box26:7/đủ26cm hoặc guide hẹp. Bố cục rộng hơn tương quan, gọn/bớt dài ngay2D; preview thêu giữ nguyên tỷ lệ2D đã duyệt. Giới hạnMAX vẫn là giới hạn, không phải số đo artwork phải lấp đầy. Chưa chốt tỷ lệ số thay thế. Không kéo giãn ảnh cũ.

Các đoạn dưới là lịch sử bộ6 ngày22/10 và quy tắc cache vẫn còn áp dụng.

Người dùng duyệt ngày 22/10/2026. Mã chính sách: `embroidery_6_v1`, trong profile3.

| Tên ảnh giữ nguyên | Vai trò |
|---|---|
| 01_thumbnail.jpg | Ảnh chính, mốc vị trí/tỷ lệ cùng listing |
| 02_hoodie_folded.jpg | Hoodie, gấp mở để thấy rõ vùng thêu |
| 04_male_front.jpg | Mẫu nam đứng chính diện |
| 05_female_angle.jpg | Mẫu nữ, giữ rõ ngực/tay |
| 07_embroidery_closeup.jpg | Macro đúng một vùng chính, chỉ một artwork nguồn |
| 10_flatlay.jpg | Quarterzip trải phẳng |

Bỏ 03,06,08,09 khỏi bộ mới. Không đánh lại số tên file. Bảng màu/loại áo của từng shot và quy tắc cấm viền ngoài vẫn giữ nguyên. Không thêm ảnh để bù số.

Mẻ áo thêu được normalize mới mặc định có `mockup_set=embroidery_6_v1`. Task mẫu đầu có 01; sau đó tạo năm ảnh còn lại với ảnh01 của chính listing làm mốc. `production_profiles.py` là nguồn danh sách; master10 cũ được giữ làm thư viện shot và hợp đồng lịch sử, không phải yêu cầu chạy đủ10 cho bộ mới.

Payload task/mẻ cũ không có `mockup_set` vẫn dùng10 ảnh. Không sửa fingerprint hoặc sửa trực tiếp task đã đóng băng. CRM10 đang dở giữ nguyên các ảnh đã tạo và quota hold; lượt triển khai này không xóa, đổi revision, bỏ ảnh hoặc Generate lại. Chỉ áp dụng bộ6 cho công việc mới có chính sách đó.

## Tham chiếu

Palette và guide áo trơn được cache theo project Flow+SHA256 và identity đã xác minh, dùng chung trong mẻ. Artwork ngực/tay và ảnh01 vẫn thuộc đúng listing; hai tay giống nhau dùng cùng file theo policy hiện có. Không gộp ảnh chỉ vì trùng tên.

Worker tìm asset có sẵn trong picker, kể cả khi cần cuộn danh sách. Tìm chưa hết giới hạn hoặc asset trùng nhãn không được coi là cache miss để upload thêm. Khi một chip cache rỗng, chỉ SHA đó được ép upload lại; các ảnh tốt được gắn lại từ cache. Upload thành công cập nhật cache như trước.

Log bền: `workspace/flow-worker/runtime/reference-transfers.jsonl`, gồm project, SHA, phương thức `existing_project_asset`/`cache_miss`/`upload`, lý do và thời điểm. Log không có prompt hay credentials. Việc gắn ingredient vào mỗi prompt vẫn cần thiết; reuse không làm giảm số Generate hoặc tự gỡ quota Google.

## Bàn giao cho Nét

Chỉ viết sáu shot ở trên cho bộ mới. Macro07 không có palette/guide/sample hoặc artwork vùng khác. Ảnh01 của listing là mốc bố cục; nguồn thêu rời quyết định design. Không dùng layout anchor của listing khác. Mandatory outline rule phải ở cuối từng prompt. Giữ quy trình n8n và các gate duyệt thật.
